package com.socdm.d.adgeneration.adloader

/**
 * MRAID JSソースの読み込みインターフェース。
 *
 * iOS対応: ADGMRAIDSourceReadable protocol
 */
internal interface MRAIDSourceReadable {
    fun readMRAIDSource(): String?
}
