package com.socdm.d.adgeneration;

import androidx.annotation.NonNull;

public abstract class ADGListener {

    private static final int DEFAULT_FAILED_LIMIT = 5;

    private int failedLimit;

    // constructor
    public ADGListener() {
        this(DEFAULT_FAILED_LIMIT);
    }

    public ADGListener(final int failedLimit) {
        this.failedLimit = failedLimit;
    }

    // getter and setter
    public int getFailedLimit() {
        return failedLimit;
    }

    public void setFailedLimit(final int failedLimit) {
        this.failedLimit = failedLimit;
    }

    // listener methods
    public abstract void onReceiveAd();

    public void onReceiveAd(@NonNull final Object mediationNativeAd) {}

    @Deprecated
    public void onReceiveAd(@NonNull final Object[] mediationNativeAds) {}

    public void onFailedToReceiveAd(@NonNull final ADGConsts.ADGErrorCode code) {}

    @Deprecated
    public void onReadyMediation(@NonNull final Object mediation) {}

    /**
     * @deprecated deprecated on v2.6.2.
     */
    @Deprecated
    public void onOpenUrl() {}

    public void onClickAd() {}

    /** ロードされた広告のインプレッションが有効期限内に発生しませんでした。 このメソッドが呼ばれた場合、広告を再リクエストしてください。 */
    public void onAdExpired() {}
}
