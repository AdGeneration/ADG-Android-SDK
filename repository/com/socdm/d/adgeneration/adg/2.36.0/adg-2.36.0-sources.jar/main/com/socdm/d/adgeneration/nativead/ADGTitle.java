package com.socdm.d.adgeneration.nativead;

import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.adresponse.Native;

public class ADGTitle {
    @Nullable private String text;
    @Nullable private Object ext;

    public ADGTitle(@Nullable final Native.Asset.Title obj) {
        if (obj != null) {
            this.text = obj.text;
            obj.ext.ifPresent(e -> this.ext = e);
        }
    }

    @Nullable
    public String getText() {
        return text;
    }

    @Nullable
    public Object getExt() {
        return ext;
    }
}
