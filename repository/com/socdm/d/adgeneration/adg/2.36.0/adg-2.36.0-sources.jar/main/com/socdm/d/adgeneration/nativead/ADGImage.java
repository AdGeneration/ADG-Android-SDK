package com.socdm.d.adgeneration.nativead;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.adresponse.Native;

public class ADGImage {
    @NonNull private String url;
    private int width;
    private int height;
    @Nullable private Object ext;

    public ADGImage(@NonNull final Native.Asset.Image obj) {
        this.url = obj.url;
        this.width = obj.width;
        this.height = obj.height;
        obj.ext.ifPresent(e -> this.ext = e);
    }

    @NonNull
    public String getUrl() {
        return url;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    @Nullable
    public Object getExt() {
        return ext;
    }
}
