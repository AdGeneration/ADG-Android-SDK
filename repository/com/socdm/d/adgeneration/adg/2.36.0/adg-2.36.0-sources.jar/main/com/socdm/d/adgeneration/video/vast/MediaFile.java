package com.socdm.d.adgeneration.video.vast;

import androidx.annotation.Nullable;

import java.io.Serializable;
import java.net.URL;

public class MediaFile implements Serializable {
    @Nullable private String delivery;
    @Nullable private String type;
    private int bitrate;
    private int width;
    private int height;
    @Nullable private URL url;

    @Nullable
    public String getDelivery() {
        return delivery;
    }

    public void setDelivery(@Nullable final String delivery) {
        this.delivery = delivery;
    }

    @Nullable
    public String getType() {
        return type;
    }

    public void setType(@Nullable final String type) {
        this.type = type;
    }

    public int getBitrate() {
        return bitrate;
    }

    public void setBitrate(final int bitrate) {
        this.bitrate = bitrate;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(final int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(final int height) {
        this.height = height;
    }

    @Nullable
    public URL getUrl() {
        return url;
    }

    public void setUrl(@Nullable final URL url) {
        this.url = url;
    }
}
