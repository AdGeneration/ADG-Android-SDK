package com.socdm.d.adgeneration.video.view;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.nativead.icon.ADGAnimation;
import com.socdm.d.adgeneration.nativead.icon.ADGImageView;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.vast.VASTIcon;

/**
 * VAST広告の情報アイコン（iマーク）を表示するためのビュークラスです。 VASTのIconタグで指定されたアイコンを表示し、クリック時にクリックスルーURLを開きます。
 * 展開可能なテキスト表示機能も提供します。
 */
public class VastInformationIconView extends LinearLayout {

    /** VastInformationIconViewのインスタンスを生成できない場合にスローされる例外です */
    public static final class CannotInstantiateException extends Exception {
        /** CannotInstantiateExceptionを生成します。 */
        public CannotInstantiateException() {
            super();
        }

        /**
         * メッセージを指定してCannotInstantiateExceptionを生成します。
         *
         * @param message エラーメッセージ
         */
        public CannotInstantiateException(@NonNull final String message) {
            super(message);
        }
    }

    private final int WC = ViewGroup.LayoutParams.WRAP_CONTENT;
    private final int MP = ViewGroup.LayoutParams.MATCH_PARENT;
    private final int CONTRACTED_WIDTH = 0;
    private final int ICON_WIDTH = 17;
    private final int ICON_HEIGHT = 15;
    private final int ANIMATION_DURATION = 0;
    private final int SLEEP_MILLISECONDS = 3000;
    private final int TEXT_SIZE = 10;
    private final int ROUND_RECT = 4;

    @NonNull private final Context context;
    @NonNull private final TextView expandableView;
    @NonNull private final ImageView informationIconView;
    private final boolean expandable;
    private final boolean isWipe;
    @NonNull private final VastInformationIconView.Corner corner;
    @NonNull private final VastInformationIconView.BackgroundType backgroundType;
    @NonNull private final VASTIcon vastIcon;

    /**
     * VASTアイコン情報を取得します。
     *
     * @return VASTアイコン情報
     */
    @NonNull
    public VASTIcon getVastIcon() {
        return vastIcon;
    }

    /** アイコンの表示位置を表す列挙型 */
    public enum Corner {
        /** 左上 */
        TOP_LEFT,
        /** 右上 */
        TOP_RIGHT,
        /** 左下 */
        BOTTOM_LEFT,
        /** 右下 */
        BOTTOM_RIGHT
    }

    /** 背景とテキストの色を表す列挙型 */
    public enum BackgroundType {
        WHITE(Color.argb(204, 255, 255, 255), Color.BLACK),
        BLACK(Color.argb(204, 0, 0, 0), Color.WHITE);

        private final int backgroundColor;
        private final int textColor;

        /**
         * BackgroundTypeのコンストラクタ。
         *
         * @param backgroundColor 背景色（ARGB形式）
         * @param textColor テキスト色
         */
        BackgroundType(int backgroundColor, int textColor) {
            this.backgroundColor = backgroundColor;
            this.textColor = textColor;
        }
    }

    /**
     * VastInformationIconViewのインスタンスを生成します（デフォルト設定）。
     *
     * @param context コンテキスト
     * @param vastIcon VASTアイコン情報
     * @throws CannotInstantiateException vastIconが無効なインスタンスの場合にスローします
     */
    public VastInformationIconView(
            @NonNull final Context context, @Nullable final VASTIcon vastIcon)
            throws CannotInstantiateException {
        this(context, vastIcon, false, Corner.TOP_RIGHT, BackgroundType.WHITE, false);
    }

    /**
     * VastInformationIconViewのインスタンスを生成します。
     *
     * @param context コンテキスト
     * @param vastIcon VASTアイコン情報
     * @param expandable 展開可能かどうか
     * @param corner 表示位置
     * @param backgroundType 背景タイプ
     * @param isWipe Wipe広告かどうか
     * @throws CannotInstantiateException vastIconが無効なインスタンスの場合にスローします
     */
    @SuppressLint("ClickableViewAccessibility")
    public VastInformationIconView(
            @NonNull final Context context,
            @Nullable final VASTIcon vastIcon,
            final boolean expandable,
            @NonNull final Corner corner,
            @NonNull final BackgroundType backgroundType,
            final boolean isWipe)
            throws CannotInstantiateException {
        super(context);

        // vastIconのnullチェック
        final boolean isValidIcon =
                vastIcon != null
                        && !TextUtils.isEmpty(vastIcon.getClickThroughURL())
                        && vastIcon.getStaticResource() != null
                        && !TextUtils.isEmpty(vastIcon.getStaticResource().getUrlString());

        this.context = context;
        this.corner = corner;
        this.expandable = expandable;
        this.isWipe = isWipe;
        this.backgroundType = backgroundType;

        if (!isValidIcon) {
            LogUtils.w("information icons not found.");
            throw new CannotInstantiateException(
                    "Invalid VAST icon: icon data is null or incomplete");
        }

        this.vastIcon = vastIcon;

        // WipeAdの場合、iマークのテキストは表示しない
        String containerText = isWipe ? "" : vastIcon.getProgram();
        if (containerText == null) containerText = "";

        String iconUrl = getIconUrl(vastIcon);

        this.setLayoutParams(new LinearLayout.LayoutParams(MP, MP));
        this.setGravity(getLayoutGravity());

        this.expandableView = new TextView(context);
        this.expandableView.setTextSize(TEXT_SIZE / getResources().getConfiguration().fontScale);
        this.expandableView.setText(containerText);
        this.expandableView.setHeight(convertPx(ICON_HEIGHT));
        this.expandableView.setTextColor(this.backgroundType.textColor);
        this.expandableView.setLayoutParams(new RelativeLayout.LayoutParams(WC, WC));
        if (!isWipe) {
            if (corner.equals(Corner.TOP_LEFT) || corner.equals(Corner.BOTTOM_LEFT)) {
                expandableView.setPadding(convertPx(2), convertPx(1), convertPx(4), convertPx(1));
            } else if (corner.equals(Corner.TOP_RIGHT) || corner.equals(Corner.BOTTOM_RIGHT)) {
                expandableView.setPadding(convertPx(4), convertPx(1), convertPx(2), convertPx(1));
            }
        }
        if (this.expandable) {
            expandableView.setWidth(CONTRACTED_WIDTH);
        }
        int expandWidth = getWidthByText(containerText);
        ADGAnimation contract =
                new ADGAnimation(
                        expandableView,
                        -expandWidth,
                        CONTRACTED_WIDTH + expandWidth,
                        ANIMATION_DURATION);
        ADGAnimation expand =
                new ADGAnimation(expandableView, expandWidth, CONTRACTED_WIDTH, ANIMATION_DURATION);
        expandableView.setOnTouchListener(
                getTouchEvent(vastIcon.getClickThroughURL(), contract, expand));
        rounded(expandableView, !(this.expandable || isWipe));

        this.informationIconView =
                new ADGImageView(
                        context, iconUrl, convertPx(ICON_WIDTH - 4), convertPx(ICON_HEIGHT - 2));
        this.informationIconView.setMinimumWidth(convertPx(ICON_WIDTH));
        this.informationIconView.setLayoutParams(
                new ViewGroup.LayoutParams(WC, convertPx(ICON_HEIGHT)));
        this.informationIconView.setPadding(convertPx(2), convertPx(1), convertPx(2), convertPx(1));
        this.informationIconView.setOnTouchListener(
                getTouchEvent(vastIcon.getClickThroughURL(), contract, expand));
        rounded(this.informationIconView, this.expandable || isWipe);

        if (corner.equals(VastInformationIconView.Corner.TOP_LEFT)
                || corner.equals(VastInformationIconView.Corner.BOTTOM_LEFT)) {
            this.addView(informationIconView);
            this.addView(expandableView);
        } else if (corner.equals(VastInformationIconView.Corner.TOP_RIGHT)
                || corner.equals(VastInformationIconView.Corner.BOTTOM_RIGHT)) {
            this.addView(expandableView);
            this.addView(informationIconView);
        }
    }

    /**
     * アイコン画像のURLを取得します。
     *
     * @param vastIcon アイコン情報
     * @return アイコン画像URL
     */
    @Nullable
    private String getIconUrl(@NonNull final VASTIcon vastIcon) {
        if (vastIcon.getStaticResource() == null
                || vastIcon.getStaticResource().getUrlString() == null
                || vastIcon.getStaticResource().getUrlString().isEmpty()) {
            return null;
        }

        return vastIcon.getStaticResource().getUrlString();
    }

    /**
     * Gravityの値を取得します。
     *
     * @return Gravity
     */
    private int getLayoutGravity() {
        if (corner.equals(Corner.TOP_LEFT)) {
            return Gravity.LEFT | Gravity.TOP;
        } else if (corner.equals(Corner.TOP_RIGHT)) {
            return Gravity.RIGHT | Gravity.TOP;
        } else if (corner.equals(Corner.BOTTOM_LEFT)) {
            return Gravity.LEFT | Gravity.BOTTOM;
        } else if (corner.equals(Corner.BOTTOM_RIGHT)) {
            return Gravity.RIGHT | Gravity.BOTTOM;
        }
        return 0;
    }

    /**
     * 文字列からコンテナの表示幅を取得する padding分(計6px), 余裕をもたせる分(1px)を加える
     *
     * @param text 表示する文字列
     * @return コンテナ幅
     */
    private int getWidthByText(@NonNull final String text) {
        return (int) (expandableView.getPaint().measureText(text) + convertPx(6) + convertPx(1));
    }

    /**
     * アイコンをタッチしたときのイベント ビューが閉じていれば, 表示する. ビューが開いていれば対象URLへ遷移する
     *
     * @param url 遷移先URL
     * @param contractAnimation 縮小アニメーション
     * @param expandAnimation 拡大アニメーション
     * @return OnTouchListener
     */
    @NonNull
    private View.OnTouchListener getTouchEvent(
            @NonNull final String url,
            @NonNull final ADGAnimation contractAnimation,
            @NonNull final ADGAnimation expandAnimation) {
        return new View.OnTouchListener() {
            @Override
            public boolean onTouch(@NonNull final View v, @NonNull final MotionEvent event) {
                switch (event.getAction() & MotionEvent.ACTION_MASK) {
                    case MotionEvent.ACTION_DOWN:
                        if (!isWipe) touchedProcess(url, contractAnimation, expandAnimation, v);
                        break;
                    case MotionEvent.ACTION_UP:
                        if (isWipe) touchedProcess(url, contractAnimation, expandAnimation, v);
                        break;
                    default:
                        break;
                }
                return true;
            }
        };
    }

    /**
     * タッチされた時の処理を実行します。
     *
     * @param url url
     * @param contractAnimation 縮小アニメーション
     * @param expandAnimation 拡大アニメーション
     * @param v view
     */
    private void touchedProcess(
            @NonNull final String url,
            @NonNull final ADGAnimation contractAnimation,
            @NonNull final ADGAnimation expandAnimation,
            @NonNull final View v) {
        if (expandable && !isWipe) {
            expandableView.clearAnimation();
            if (expandableView.getWidth() > CONTRACTED_WIDTH) {
                sendIconClickTracking();
                transition(v, url);
            } else {
                expandableView.startAnimation(expandAnimation);
                rounded(expandableView, true);
                rounded(informationIconView, false);
                // 現在のスレッドのLooperを取得。nullの場合はメインLooperを使用
                Looper looper = Looper.myLooper();
                if (looper == null) {
                    looper = Looper.getMainLooper();
                }
                final Looper finalLooper = looper;
                new Handler(looper)
                        .postDelayed(
                                new Runnable() {
                                    @Override
                                    public void run() {
                                        expandableView.startAnimation(contractAnimation);
                                        new Handler(finalLooper)
                                                .postDelayed(
                                                        new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                rounded(informationIconView, true);
                                                            }
                                                        },
                                                        ANIMATION_DURATION);
                                    }
                                },
                                SLEEP_MILLISECONDS);
            }
        } else {
            sendIconClickTracking();
            transition(v, url);
        }
    }

    /**
     * 背景の一部を角丸にします。
     *
     * @param view 対象のビュー
     * @param rounded trueなら角丸
     */
    private void rounded(@NonNull final View view, final boolean rounded) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(this.backgroundType.backgroundColor);
        if (rounded) {
            float[] outerRadii = new float[0];
            if (corner.equals(Corner.TOP_LEFT)) {
                outerRadii =
                        new float[] {
                            0, 0, 0, 0, convertPx(ROUND_RECT), convertPx(ROUND_RECT), 0, 0
                        };
            } else if (corner.equals(Corner.TOP_RIGHT)) {
                outerRadii =
                        new float[] {
                            0, 0, 0, 0, 0, 0, convertPx(ROUND_RECT), convertPx(ROUND_RECT)
                        };
            } else if (corner.equals(Corner.BOTTOM_LEFT)) {
                outerRadii =
                        new float[] {
                            0, 0, convertPx(ROUND_RECT), convertPx(ROUND_RECT), 0, 0, 0, 0
                        };
            } else if (corner.equals(Corner.BOTTOM_RIGHT)) {
                outerRadii =
                        new float[] {
                            convertPx(ROUND_RECT), convertPx(ROUND_RECT), 0, 0, 0, 0, 0, 0
                        };
            }
            drawable.setCornerRadii(outerRadii);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            view.setBackground(drawable);
        } else {
            view.setBackgroundDrawable(drawable);
        }
    }

    /**
     * 対象URLへ遷移させます。
     *
     * @param view view
     * @param url url
     */
    private void transition(@NonNull final View view, @NonNull final String url) {
        Uri uri = Uri.parse(url);
        Intent i = new Intent(Intent.ACTION_VIEW, uri);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            view.getContext().startActivity(i);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * dpをpxに変換します。
     *
     * @param dp dp
     * @return px
     */
    private int convertPx(float dp) {
        float density = this.context.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    /** ClickTrackingを送信します。 */
    private void sendIconClickTracking() {
        this.vastIcon.sendIconClickTracking();
    }
}
