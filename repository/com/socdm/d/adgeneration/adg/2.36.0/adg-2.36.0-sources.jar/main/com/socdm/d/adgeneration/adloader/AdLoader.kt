package com.socdm.d.adgeneration.adloader

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.socdm.d.adgeneration.ADGConsts
import com.socdm.d.adgeneration.ADGSettings
import com.socdm.d.adgeneration.AdParams
import com.socdm.d.adgeneration.IADGLogger
import com.socdm.d.adgeneration.adresponse.Response
import com.socdm.d.adgeneration.adresponse.ResponseParserException
import com.socdm.d.adgeneration.utils.ChildDirectedState
import com.socdm.d.adgeneration.utils.GeolocationProvider
import com.socdm.d.adgeneration.utils.IGeolocationProvider
import jp.supership.sscore.adid.SSCoreAdInfoLoader
import jp.supership.sscore.adrequest.SSCoreAdRequestAPILevelValidator
import jp.supership.sscore.adrequest.SSCoreAdRequestPlacementIDValidator
import jp.supership.sscore.adrequest.SSCoreAdRequestValidator
import jp.supership.sscore.adrequest.SSCoreAdServerDomain
import jp.supership.sscore.adrequest.SSCoreChildDirected
import jp.supership.sscore.adrequest.SSCoreLocation
import jp.supership.sscore.adrequest.SSCoreNonRewardedAdClient
import jp.supership.sscore.device.SSCoreReachability
import jp.supership.sscore.type.Optional
import org.json.JSONObject
import java.lang.ref.WeakReference
import jp.supership.sscore.type.Result as SSCoreResult

/**
 * SSCoreNonRewardedAdClientを使って広告リクエストを行うコア実装。
 * Reachabilityチェック、位置情報変換、ChildDirected変換、JSONパースを担当する。
 *
 */
internal class AdLoader : AdLoadable {

    private val nonRewardedAdClient: SSCoreNonRewardedAdClient
    private val geolocationProvider: IGeolocationProvider
    private val reachability: SSCoreReachability.Reachable2
    private val logger: IADGLogger
    private val appContext: Context
    private val activityRef: WeakReference<Activity>?
    override val adParams: AdParams

    /**
     * プロダクション用コンストラクタ。内部でSSCoreNonRewardedAdClientを生成する。
     * iOS対応: convenience init(logger:)
     */
    constructor(context: Context, logger: IADGLogger) {
        val appContext = context.applicationContext

        val adInfoLoader = SSCoreAdInfoLoader.getInstance(appContext)
        adInfoLoader.setLogger(logger.logger)

        val validator = SSCoreAdRequestValidator(
            listOf(
                SSCoreAdRequestPlacementIDValidator(),
                SSCoreAdRequestAPILevelValidator(Build.VERSION_CODES.M),
            ),
        )

        val serverDomain = if (ADGConsts.DOMAIN == "api-test.scaleout.jp") {
            SSCoreAdServerDomain.Staging
        } else {
            SSCoreAdServerDomain.Production
        }

        this.nonRewardedAdClient = SSCoreNonRewardedAdClient.defaultInstance(
            appContext,
            serverDomain,
            validator,
            null,
        )
        this.geolocationProvider = GeolocationProvider.getInstance(appContext)
        this.reachability = SSCoreReachability.Reachability(appContext)
        this.logger = logger
        this.appContext = appContext
        this.activityRef = if (context is Activity) WeakReference(context) else null
        this.adParams = AdParams()
    }

    /**
     * テスト用コンストラクタ。依存を外部から注入する。
     * iOS対応: init(nonRewardedAdClient:trackingEventSender:reachability:logger:legacyTracking:)
     */
    constructor(
        nonRewardedAdClient: SSCoreNonRewardedAdClient,
        geolocationProvider: IGeolocationProvider,
        reachability: SSCoreReachability.Reachable2,
        logger: IADGLogger,
        appContext: Context,
        adParams: AdParams = AdParams(),
        activity: Activity? = null,
    ) {
        this.nonRewardedAdClient = nonRewardedAdClient
        this.geolocationProvider = geolocationProvider
        this.reachability = reachability
        this.logger = logger
        this.appContext = appContext
        this.activityRef = activity?.let { WeakReference(it) }
        this.adParams = adParams
    }

    private var isRequesting = false

    override fun loadAd(beforeLoading: () -> Unit, completion: (SSCoreResult<Response, AdLoadError>) -> Unit) {
        if (isRequesting) return
        isRequesting = true
        beforeLoading()

        // Permissionチェック（旧AdRequestValidator.PermissionValidator相当）
        val internetGranted = appContext.checkCallingOrSelfPermission(Manifest.permission.INTERNET) ==
            PackageManager.PERMISSION_GRANTED
        val networkStateGranted = appContext.checkCallingOrSelfPermission(Manifest.permission.ACCESS_NETWORK_STATE) ==
            PackageManager.PERMISSION_GRANTED
        if (!internetGranted || !networkStateGranted) {
            isRequesting = false
            logger.logger.error("Required permissions missing. INTERNET=$internetGranted, ACCESS_NETWORK_STATE=$networkStateGranted")
            completion(SSCoreResult.failure(AdLoadError.Communication(null)))
            return
        }

        // Reachabilityチェック（iOS AdLoader準拠）
        if (!reachability.isReachable) {
            isRequesting = false
            completion(SSCoreResult.failure(AdLoadError.NoNetwork()))
            return
        }

        // ActivityStateチェック（旧AdRequestValidator.ActivityStateValidator相当）
        activityRef?.get()?.let { activity ->
            if (activity.isFinishing || activity.isDestroyed) {
                isRequesting = false
                logger.logger.error("Activity is finishing or destroyed. Skip ad request.")
                completion(SSCoreResult.failure(AdLoadError.Communication(null)))
                return
            }
        }

        val location = resolveLocation()
        val childDirected = toSSCoreChildDirected()

        nonRewardedAdClient.requestNonRewardedAd(
            adParams.locationId ?: "",
            ADGConsts.SDKVERSION,
            adParams.getErrorScheduleIds(),
            adParams.isMraidEnabled,
            adParams.headerBiddingParams.toMap(),
            adParams.labelTargeting.toMap(),
            childDirected,
            location,
            object : SSCoreNonRewardedAdClient.Completable {
                override fun onComplete(result: SSCoreResult<JSONObject, Throwable>) {
                    isRequesting = false

                    // APSのbidIdなどは1リクエストごとに払い出され、重複して送信してはいけない気がするため
                    // リクエスト終了時にHeader biddingパラメータをクリアする。
                    // APS連携のときはADGのローテーション設定はOFFにすること。ローテーションした場合、
                    // APSのHeader biddingパラメータは、ここでクリアしているため送信されない
                    adParams.headerBiddingParams.removeAllKeyValues()

                    if (result.data.isPresent) {
                        try {
                            val response = Response.fromJSON(Optional.of(result.data.maybe()))
                            completion(SSCoreResult.success(response))
                        } catch (e: ResponseParserException) {
                            logger.logger.error("Failed to parse response: $e")
                            completion(SSCoreResult.failure(AdLoadError.Parse(e)))
                        }
                    } else {
                        val error = result.error.maybe()
                        logger.logger.error("Ad request failed: $error")
                        completion(SSCoreResult.failure(AdLoadError.Communication(error)))
                    }
                }
            },
        )
    }

    override fun cancelLoad() {
        isRequesting = false
        nonRewardedAdClient.cancelRequest()
    }

    private fun resolveLocation(): SSCoreLocation? {
        if (!geolocationProvider.isValidLocation) {
            geolocationProvider.updateLocation()
        }
        if (!geolocationProvider.isValidLocation) return null

        return runCatching {
            val loc = geolocationProvider.lastKnownLocation().unwrap()
            SSCoreLocation.create(loc.latitude, loc.longitude)
        }.getOrNull()
    }

    private fun toSSCoreChildDirected(): SSCoreChildDirected =
        when (ADGSettings.getChildDirectedState()) {
            ChildDirectedState.TRUE -> SSCoreChildDirected.YES
            ChildDirectedState.FALSE -> SSCoreChildDirected.NO
            else -> SSCoreChildDirected.UNKNOWN
        }
}
