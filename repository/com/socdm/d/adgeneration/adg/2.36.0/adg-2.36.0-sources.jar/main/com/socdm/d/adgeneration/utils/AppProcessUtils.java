package com.socdm.d.adgeneration.utils;

import android.app.ActivityManager;
import android.content.Context;

import androidx.annotation.NonNull;

/** アプリプロセスに関するユーティリティクラスです。 */
public final class AppProcessUtils {
    /**
     * アプリがフォアグラウンド状態かどうかを判定します。
     *
     * @param context Context
     * @return フォアグラウンド状態の場合はtrue、それ以外はfalse
     */
    public static boolean isForeground(@NonNull final Context context) {
        ActivityManager activityManager =
                (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (activityManager == null || activityManager.getAppTasks().isEmpty()) {
            return false;
        }

        ActivityManager.RunningAppProcessInfo processInfo =
                new ActivityManager.RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(processInfo);
        return processInfo.importance
                == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND;
    }
}
