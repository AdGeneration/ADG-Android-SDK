package com.socdm.d.adgeneration.nativead.template;

import android.annotation.TargetApi;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.nativead.ADGNativeAd;

public abstract class ADGNativeAdTemplateBase extends RelativeLayout {
    public ADGNativeAdTemplateBase(@NonNull final Context context) {
        super(context);
    }

    public ADGNativeAdTemplateBase(
            @NonNull final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
    }

    public ADGNativeAdTemplateBase(
            @NonNull final Context context,
            @Nullable final AttributeSet attrs,
            final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @TargetApi(21)
    public ADGNativeAdTemplateBase(
            @NonNull final Context context,
            @Nullable final AttributeSet attrs,
            final int defStyleAttr,
            final int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    @NonNull
    public abstract Boolean apply(@Nullable final ADGNativeAd nativeAd);

    public abstract void destroy();

    public abstract void finishViewability();

    public abstract void setListener(@Nullable final ADGNativeAdTemplateListener listener);
}
