package com.socdm.d.adgeneration.nativead;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.adresponse.Native;
import com.socdm.d.adgeneration.utils.LogUtils;

import java.util.ArrayList;

public class ADGLink {
    @Nullable private String url;
    @NonNull private ArrayList<String> clicktrackers;
    @NonNull private ArrayList<String> postClicktrackers;
    @Nullable private String fallback;
    @Nullable private Object ext;
    @Nullable private View view;

    public ADGLink(@NonNull final Native.Link link) {
        this.url = link.url;
        this.clicktrackers = new ArrayList<>();
        this.postClicktrackers = new ArrayList<>();
        link.clickTrackers.ifPresent(ct -> this.clicktrackers = new ArrayList<>(ct));
        link.postClickTrackers.ifPresent(pct -> this.postClicktrackers = new ArrayList<>(pct));
        link.fallback.ifPresent(fb -> this.fallback = fb);
        link.ext.ifPresent(ext -> this.ext = ext);
    }

    @Nullable
    public String getUrl() {
        return url;
    }

    @NonNull
    public ArrayList<String> getClicktrackers() {
        return clicktrackers;
    }

    @NonNull
    public ArrayList<String> getPostClicktrackers() {
        return postClicktrackers;
    }

    @Nullable
    public String getFallback() {
        return fallback;
    }

    @Nullable
    public Object getExt() {
        return ext;
    }

    /**
     * ViewにClickイベントを設定する
     *
     * @param v clickイベントを設定する対象
     */
    public void setClickEvent(
            @NonNull final View v, @Nullable final ADGNativeAdOnClickListener listener) {
        this.view = v;

        v.setOnClickListener(
                clickedView -> {
                    ADGNativeAd.callTrackers(clicktrackers);
                    ADGNativeAd.callTrackers(postClicktrackers, true);
                    Uri uri = Uri.parse(url);
                    LogUtils.d("new Intent:" + url);
                    Intent i = new Intent(Intent.ACTION_VIEW, uri);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        if (listener != null) {
                            listener.onClickAd();
                        }
                        LogUtils.d("startActivity");
                        clickedView.getContext().startActivity(i);
                    } catch (ActivityNotFoundException e) {
                        LogUtils.e("Failed to start activity for URL: " + url, e);
                    }
                });
    }

    public void callOnClick() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1) {
            if (view != null) {
                view.callOnClick();
            }
        }
    }
}
