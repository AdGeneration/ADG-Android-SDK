package com.socdm.d.adgeneration.utils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.reflect.Field;
import java.util.EnumSet;

public class ClassUtils {

    @NonNull
    public static Enum getEnum(@NonNull final String className, @NonNull final String enumName) {
        try {
            Class enumClass = Class.forName(className);
            return Enum.valueOf(enumClass, enumName);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    @NonNull
    public static EnumSet getEnumSet(@NonNull final String className) {
        try {
            Class enumClass = Class.forName(className);
            return EnumSet.allOf(enumClass);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    @Nullable
    public static Object getPrivateField(
            @NonNull final Object classObject, @NonNull final String fieldName)
            throws IllegalAccessException, NoSuchFieldException {
        Class clazz = classObject.getClass();
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(classObject);
    }
}
