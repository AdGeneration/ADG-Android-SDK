package com.socdm.d.adgeneration.utils;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class LogUtils {

    private static final String TAG = "ADGSDK";
    private static int logLevel = Log.INFO;

    public static void setLogLevel(final int level) {
        logLevel = level;
    }

    private static boolean loggable(final int level) {
        return level >= logLevel;
    }

    public static void v() {
        if (loggable(Log.VERBOSE)) {
            Log.v(TAG, getMetaInfo());
        }
    }

    public static void v(@Nullable final String message) {
        if (loggable(Log.VERBOSE)) {
            Log.v(TAG, getMetaInfo() + null2str(message));
        }
    }

    public static void d() {
        if (loggable(Log.DEBUG)) {
            Log.d(TAG, getMetaInfo());
        }
    }

    public static void d(@Nullable final String message) {
        if (loggable(Log.DEBUG)) {
            Log.d(TAG, getMetaInfo() + null2str(message));
        }
    }

    public static void i() {
        if (loggable(Log.INFO)) {
            Log.i(TAG, getMetaInfo());
        }
    }

    public static void i(@Nullable final String message) {
        if (loggable(Log.INFO)) {
            Log.i(TAG, getMetaInfo() + null2str(message));
        }
    }

    public static void w(@Nullable final String message) {
        if (loggable(Log.WARN)) {
            Log.w(TAG, getMetaInfo() + null2str(message));
        }
    }

    public static void w(@Nullable final String message, @NonNull final Throwable e) {
        if (loggable(Log.WARN)) {
            Log.w(TAG, getMetaInfo() + null2str(message), e);
            printThrowable(e);
            if (e.getCause() != null) {
                printThrowable(e.getCause());
            }
        }
    }

    public static void e(@Nullable final String message) {
        if (loggable(Log.ERROR)) {
            Log.e(TAG, getMetaInfo() + null2str(message));
        }
    }

    public static void e(@Nullable final String message, @NonNull final Throwable e) {
        if (loggable(Log.ERROR)) {
            Log.e(TAG, getMetaInfo() + null2str(message), e);
            printThrowable(e);
            if (e.getCause() != null) {
                printThrowable(e.getCause());
            }
        }
    }

    @NonNull
    private static String null2str(@Nullable final String string) {
        if (string == null) {
            return "(null)";
        }
        return string;
    }

    /**
     * 例外のスタックトレースをログに出力する
     *
     * @param e
     */
    private static void printThrowable(@NonNull final Throwable e) {
        Log.e(TAG, e.getClass().getName() + ": " + e.getMessage());
        for (StackTraceElement element : e.getStackTrace()) {
            Log.e(TAG, "  at " + LogUtils.getMetaInfo(element));
        }
    }

    /**
     * ログ呼び出し元のメタ情報を取得する
     *
     * @return [className#methodName:line]
     */
    @NonNull
    private static String getMetaInfo() {
        // スタックトレースから情報を取得 // 0: VM, 1: Thread, 2: LogUtil#getMetaInfo, 3:
        // LogUtil#d など, 4: 呼び出し元
        final StackTraceElement element = Thread.currentThread().getStackTrace()[4];
        return LogUtils.getMetaInfo(element);
    }

    /**
     * スタックトレースからクラス名、メソッド名、行数を取得する
     *
     * @return [className#methodName:line]
     */
    @NonNull
    public static String getMetaInfo(@NonNull final StackTraceElement element) {
        // クラス名、メソッド名、行数を取得
        final String fullClassName = element.getClassName();
        final String simpleClassName = fullClassName.substring(fullClassName.lastIndexOf(".") + 1);
        final String methodName = element.getMethodName();
        final int lineNumber = element.getLineNumber();
        // メタ情報
        final String metaInfo = "[" + simpleClassName + "#" + methodName + ":" + lineNumber + "] ";
        return metaInfo;
    }
}
