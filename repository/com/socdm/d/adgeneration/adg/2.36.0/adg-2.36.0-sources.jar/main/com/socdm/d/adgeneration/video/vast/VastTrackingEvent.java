package com.socdm.d.adgeneration.video.vast;

import androidx.annotation.NonNull;

public enum VastTrackingEvent {
    CREATIVE_VIEW("creativeView"),
    START("start"),
    FIRST_QUARTILE("firstQuartile"),
    MIDPOINT("midpoint"),
    THIRD_QUARTILE("thirdQuartile"),
    COMPLETE("complete"),
    MUTE("mute"),
    UNMUTE("unmute"),
    PAUSE("pause"),
    REWIND("rewind"),
    RESUME("resume"),
    EXPAND("expand"),
    COLLAPSE("collapse"),
    ACCEPT_INVITATION_LINEAR("acceptInvitationLinear"),
    CLOSE_LINEAR("closeLinear"),
    SKIP("skip"),
    PROGRESS("progress"),
    EXT_INVIEW("inview"),
    EXT_OUTVIEW("outview");

    @NonNull private final String message;

    VastTrackingEvent(@NonNull final String message) {
        this.message = message;
    }

    @NonNull
    @Override
    public String toString() {
        return this.message;
    }
}
