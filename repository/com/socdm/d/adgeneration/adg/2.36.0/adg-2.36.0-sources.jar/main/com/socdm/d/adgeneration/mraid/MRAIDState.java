package com.socdm.d.adgeneration.mraid;

import androidx.annotation.NonNull;

import java.util.Locale;

public enum MRAIDState {
    LOADING,
    DEFAULT,
    RESIZED,
    EXPANDED,
    HIDDEN;

    @NonNull
    String toJavascriptString() {
        return toString().toLowerCase(Locale.US);
    }
}
