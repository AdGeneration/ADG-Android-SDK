package com.socdm.d.adgeneration.mediation;

import androidx.annotation.NonNull;

import com.socdm.d.adgeneration.IADGLogger;

import jp.supership.sscore.timer.SSCoreScheduledTimer;
import jp.supership.sscore.timer.SSCoreTimerResumable;

import java.lang.ref.WeakReference;
import java.util.TimerTask;

class MediationController {
    public interface MediationControllerListener {
        /** 広告ローテーションがスケジュールされた時間になったら実行されるメソッドです */
        void onReachedRotation();

        /** メディエーションのタイムアウトが発生した場合に実行されるメソッドです */
        void onTimedOut();
    }

    private static final long MEDIATION_TIMEOUT_MILLIS = 10000; // 10秒

    @NonNull private final MediationModel model;
    @NonNull private final SSCoreTimerResumable mediationTimer;
    @NonNull private final IADGLogger logger;
    @NonNull private final MediationControllerListener listener;
    public boolean isProcessing = false;
    public boolean isMovieCompleted = false;

    /**
     * インスタンスを生成します。
     *
     * @param model モデル
     * @param listener リスナー
     * @param logger ロガーのオプション
     */
    public MediationController(
            @NonNull final MediationModel model,
            @NonNull final MediationControllerListener listener,
            @NonNull final IADGLogger logger) {
        this.model = model;
        this.listener = listener;
        this.logger = logger;
        this.mediationTimer = new SSCoreScheduledTimer();
    }

    public void setMediationTimer() {
        mediationTimer.cancelIfScheduled();

        if (model.getRotationInMilliseconds() > 0 && (!model.isMovie() || isMovieCompleted)) {
            logger.getLogger().debug("Set mediation rotation timer.");

            mediationTimer.cancelAndSchedule(
                    model.getRotationInMilliseconds(), new MediationRotationTimerTask(this));
        } else {
            // メディアによってローテーションが無効化されている場合はデフォルトのタイムアウトを設定する。
            // また、動画広告で再生が完了していない場合もタイムアウトを設定する(動画ファイルのDLに時間がかかることを想定して強制カットを入れているものと思われる)
            logger.getLogger().debug("Set mediation timeout timer.");
            mediationTimer.cancelAndSchedule(
                    MEDIATION_TIMEOUT_MILLIS, new MediationTimeoutTimerTask(this));
        }
    }

    public void clearMediationTimer() {
        mediationTimer.cancelIfScheduled();
    }

    public void resumeMediationTimer() {
        mediationTimer.resumeTimer();
    }

    public void pauseMediationTimer() {
        mediationTimer.pauseTimer();
    }

    private void onReachedRotation() {
        clearMediationTimer();
        listener.onReachedRotation();
    }

    private void onTimedOut() {
        clearMediationTimer();
        if (isProcessing) {
            logger.getLogger().debug("Mediation timed out.");
            listener.onTimedOut();
        }
    }

    static final class MediationRotationTimerTask extends TimerTask {
        @NonNull private final WeakReference<MediationController> controllerRef;

        public MediationRotationTimerTask(@NonNull final MediationController controller) {
            this.controllerRef = new WeakReference<>(controller);
        }

        @Override
        public void run() {
            MediationController controller = controllerRef.get();
            if (controller == null) {
                return;
            }

            controller.onReachedRotation();
        }
    }

    static final class MediationTimeoutTimerTask extends TimerTask {
        @NonNull private final WeakReference<MediationController> controllerRef;

        public MediationTimeoutTimerTask(@NonNull final MediationController controller) {
            this.controllerRef = new WeakReference<>(controller);
        }

        @Override
        public void run() {
            MediationController controller = controllerRef.get();
            if (controller == null) {
                return;
            }

            controller.onTimedOut();
        }
    }
}
