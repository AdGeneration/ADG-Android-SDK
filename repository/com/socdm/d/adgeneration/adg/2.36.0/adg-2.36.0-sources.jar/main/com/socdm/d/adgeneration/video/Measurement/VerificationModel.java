package com.socdm.d.adgeneration.video.Measurement;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.Serializable;
import java.net.URL;
import java.util.HashMap;

public class VerificationModel implements Serializable {
    @Nullable private String vendor;
    @Nullable private String apiFromework;
    private boolean browserOptional;
    @Nullable private URL javaScriptResource;
    @NonNull private HashMap<String, URL> trackingEvents;
    @Nullable private String verificationParameters;

    public VerificationModel() {
        vendor = null;
        apiFromework = null;
        browserOptional = false;
        javaScriptResource = null;
        trackingEvents = new HashMap<>();
        verificationParameters = null;
    }

    @Nullable
    public String getVendor() {
        return vendor;
    }

    public void setVendor(@Nullable final String vendor) {
        this.vendor = vendor;
    }

    @Nullable
    public String getApiFromework() {
        return apiFromework;
    }

    public void setApiFromework(@Nullable final String apiFromework) {
        this.apiFromework = apiFromework;
    }

    public boolean isBrowserOptional() {
        return browserOptional;
    }

    public void setBrowserOptional(final boolean browserOptional) {
        this.browserOptional = browserOptional;
    }

    @Nullable
    public URL getJavaScriptResource() {
        return javaScriptResource;
    }

    public void setJavaScriptResource(@Nullable final URL javaScriptResource) {
        this.javaScriptResource = javaScriptResource;
    }

    @NonNull
    public HashMap<String, URL> getTrackingEvents() {
        return trackingEvents;
    }

    public void setTrackingEvents(@NonNull final HashMap<String, URL> trackingEvents) {
        this.trackingEvents = trackingEvents;
    }

    @Nullable
    public String getVerificationParameters() {
        return verificationParameters;
    }

    public void setVerificationParameters(@Nullable final String verificationParameters) {
        this.verificationParameters = verificationParameters;
    }
}
