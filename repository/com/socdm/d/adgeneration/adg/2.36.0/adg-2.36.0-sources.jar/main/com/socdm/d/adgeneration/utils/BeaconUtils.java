package com.socdm.d.adgeneration.utils;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.net.MalformedURLException;
import java.net.URL;

public class BeaconUtils {
    @Nullable private static String userAgent;

    public static void applyUserAgent(@NonNull final Context context) {
        if (userAgent == null || userAgent.isEmpty()) {
            userAgent = HttpUtils.getUserAgent(context);
        }
    }

    public static void callBeacon(@Nullable final String beacon) {
        if (userAgent == null || userAgent.isEmpty()) {
            LogUtils.e("Invalid UserAgent.");
            return;
        }

        final URL beaconURL;
        try {
            beaconURL = new URL(beacon);
        } catch (NullPointerException | IllegalArgumentException | MalformedURLException e) {
            LogUtils.d("Invalid URL:" + e.getMessage());
            return;
        }

        HttpURLConnectionTask requestTask =
                new HttpURLConnectionTask(
                        beaconURL.toString(),
                        new AsyncTaskListener<>() {
                            @Override
                            public void onSuccess(@Nullable String s) {
                                LogUtils.d("Beacon request succeed. " + beaconURL);
                            }

                            @Override
                            public void onError(@NonNull Exception e) {
                                LogUtils.d(
                                        "Beacon request failed.("
                                                + e.getMessage()
                                                + ") "
                                                + beaconURL);
                            }
                        });
        requestTask.setUserAgent(userAgent);
        AsyncTaskUtils.execute(requestTask);
    }
}
