package com.socdm.d.adgeneration.observer;

import androidx.annotation.NonNull;

public abstract class ADGRecipient implements Observer {

    @NonNull public String tag;

    public ADGRecipient(@NonNull final String tag) {
        this.tag = tag;
    }
}
