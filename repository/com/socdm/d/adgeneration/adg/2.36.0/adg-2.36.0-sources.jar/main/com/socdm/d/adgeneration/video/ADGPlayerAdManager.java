package com.socdm.d.adgeneration.video;

import static com.socdm.d.adgeneration.video.utils.DeviceUtils.getDeviceDimensions;

import android.Manifest;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.iab.omid.library.supershipjp.adsession.media.InteractionType;
import com.iab.omid.library.supershipjp.adsession.media.Position;
import com.socdm.d.adgeneration.ADGLogger;
import com.socdm.d.adgeneration.Measurement.MeasurementConsts;
import com.socdm.d.adgeneration.Measurement.VideoViewMeasurementManager;
import com.socdm.d.adgeneration.video.broadcast.ScreenStateBroadcastReceiver;
import com.socdm.d.adgeneration.video.cache.CacheService;
import com.socdm.d.adgeneration.video.cache.CachingDownloadTask;
import com.socdm.d.adgeneration.video.config.AdConfiguration;
import com.socdm.d.adgeneration.video.utils.Views;
import com.socdm.d.adgeneration.video.vast.MediaFile;
import com.socdm.d.adgeneration.video.vast.VASTIcon;
import com.socdm.d.adgeneration.video.vast.VastAd;
import com.socdm.d.adgeneration.video.vast.VastEventState;
import com.socdm.d.adgeneration.video.vast.VastRequest;
import com.socdm.d.adgeneration.video.view.VastInformationIconView;

import jp.supership.sscore.video.adg.SSCoreVideoPlayerView;
import jp.supership.sscore.video.adg.SSCoreVideoPlayerViewListener;
import jp.supership.sscore.video.base.SSCorePlayerError;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.RejectedExecutionException;

public class ADGPlayerAdManager
        implements VastRequest.VastRequestListener,
                ScreenStateBroadcastReceiver.ScreenStateBroadcastReceiverListener {
    private static final List<String> VIDEO_MIME_TYPES = Arrays.asList("video/mp4", "video/3gpp");
    private static final double ASPECT_RATIO_WEIGHT = 30;
    private static final double AREA_WEIGHT = 70;

    @NonNull private final Context mContext;
    @Nullable private Activity mActivity;
    @Nullable private ViewGroup mContentView;
    @Nullable private VastRequest mRequesting;
    @Nullable private AdConfiguration mAdConfiguration;
    @Nullable private SSCoreVideoPlayerView mPlayerView;
    @Nullable private ScreenStateBroadcastReceiver mScreenStateBroadcastReceiver;
    @Nullable private ADGPlayerAdListener mAdListener;
    private double mScreenAspectRatio;
    private int mScreenArea;
    @NonNull private final Handler mHander;
    @Nullable private String mVastString;
    private boolean isTiny = false;
    private boolean isWipe = false;

    @NonNull
    private final OnActivityLifecycleCallbacks onActivityLifecycleCallbacks =
            new OnActivityLifecycleCallbacks();

    @Nullable private VideoViewMeasurementManager videoViewMeasurementManager;
    private boolean isNativeOptout = false;

    // SSCore用: InView/OutOfView状態管理
    private boolean isPrepared = false;
    private boolean isInView = false;
    private boolean isCompleted = false;
    private boolean isFirstPlay = true;

    // View状態を管理するenum
    private enum ViewState {
        IN_VIEW,
        OUT_OF_VIEW,
        NONE
    }

    // 異なるスレッドからアクセスされる可能性があるためvolatileで宣言
    private volatile ViewState pendingViewState = ViewState.NONE;

    public ADGPlayerAdManager(@NonNull final Context context) {
        mContext = context;
        mAdConfiguration = null;
        mHander = new Handler(Looper.myLooper());

        initializeScreenDimensions();
    }

    public void setAdListener(@Nullable final ADGPlayerAdListener adListener) {
        mAdListener = adListener;
    }

    public void setIsTiny(boolean isTiny) {
        this.isTiny = isTiny;
    }

    public void setIsWipe(boolean isWipe) {
        this.isWipe = isWipe;
    }

    public boolean isReady() {
        return mAdConfiguration != null;
    }

    @Override
    public void vastAdDidLoaded(@NonNull final VastAd vastAd) {
        ADGLogger.getDefault().debug(this + ": Ad request is running...");
        reset();
        mRequesting = null;
        mAdConfiguration = new AdConfiguration(vastAd);
        ready();
    }

    @Override
    public void failedToLoadVastAd(@NonNull final ADGPlayerError error) {
        mRequesting = null;
        onAdViewFailedToPlay(error);
    }

    public void load(@NonNull final String vastString, @Nullable final Boolean isNativeOptout) {
        mVastString = vastString;

        if (isNativeOptout != null) {
            this.isNativeOptout = isNativeOptout;
        }

        if (!CacheService.initializeDiskCache(mContext)) {
            onAdViewFailedToPlay(ADGPlayerError.CACHE_SERVICE_ERROR);
            return;
        }

        boolean isPermissionApproved = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                isPermissionApproved =
                        ContextCompat.checkSelfPermission(
                                        mContext, Manifest.permission.ACCESS_NETWORK_STATE)
                                == PackageManager.PERMISSION_GRANTED;
            } catch (NoClassDefFoundError | NoSuchMethodError | NullPointerException e) {
                ADGLogger.getDefault()
                        .error(
                                "Needs ACCESS_NETWORK_STATE permission.(not import android support"
                                        + " library)",
                                e);
                return;
            }
        }
        if (!isPermissionApproved) {
            ADGLogger.getDefault().error("Needs ACCESS_NETWORK_STATE permission.");
            onAdViewFailedToPlay(ADGPlayerError.SETTING_ERROR);
            return;
        }

        if (!(mContext instanceof Activity)) {
            ADGLogger.getDefault().error("Activity is required.");
            onAdViewFailedToPlay(ADGPlayerError.SETTING_ERROR);
            return;
        }
        mActivity = (Activity) mContext;
        if (!Views.hasHardwareAcceleration(mActivity)) {
            onAdViewFailedToPlay(ADGPlayerError.HARDWARE_ACCELERATION_DISABLED);
            return;
        }

        if (isReady()) {
            ADGLogger.getDefault().debug("ad is already loaded");
            return;
        }

        if (mRequesting != null) {
            ADGLogger.getDefault().debug(this + ": Ad request is running...");
            return;
        }

        mRequesting = new VastRequest(this, mContext);
        if (mVastString.startsWith("http")) {
            ADGLogger.getDefault().error("unsupported getting VAST by HTTP request");
            return;
        } else {
            mHander.post(
                    new Runnable() {
                        public void run() {
                            if (mRequesting == null) {
                                ADGLogger.getDefault().error("Requesting is null");
                                return;
                            }
                            mRequesting.loadXML(mVastString);
                        }
                    });
        }
        ADGLogger.getDefault().debug(this + ": start ad requesting: " + vastString);
    }

    public void showAd(@NonNull final ViewGroup contentView) {
        mHander.post(
                () -> {
                    if (isReady()) {
                        if (mPlayerView != null) {
                            mPlayerView.release();
                            Views.removeFromParent(mPlayerView);
                            mPlayerView = null;
                        }

                        // 状態リセット
                        isPrepared = false;
                        isCompleted = false;
                        isFirstPlay = true;

                        // 動画URLを取得（キャッシュ優先）
                        final String videoUrl = mAdConfiguration.getVastAd().getBestMediaFileUrl();
                        if (videoUrl == null) {
                            onAdViewFailedToPlay(ADGPlayerError.UNSPECIFIED);
                            return;
                        }

                        // SSCoreVideoPlayerViewを作成
                        final boolean isMuted = !mAdConfiguration.isSoundEnabled();
                        mPlayerView =
                                SSCoreVideoPlayerView.addTo(
                                        contentView, Uri.parse(videoUrl), isMuted, isTiny);

                        // VastInformationIconView（iマーク）を追加
                        // isNativeOptout=true の場合は表示しない（旧VastPlayer準拠）
                        if (!isNativeOptout) {
                            addVastInformationIconView(mPlayerView);
                        }

                        // リスナーを設定
                        mPlayerView.setListener(
                                new SSCoreVideoPlayerViewListener() {
                                    @Override
                                    public void onPrepared(
                                            @NonNull SSCoreVideoPlayerView playerView) {
                                        ADGLogger.getDefault().debug("SSCore: onPrepared");
                                        isPrepared = true;
                                        // InView状態なら再生開始
                                        if (isInView) {
                                            playerView.play();
                                        }
                                    }

                                    @Override
                                    public void onResumed(
                                            @NonNull SSCoreVideoPlayerView playerView) {
                                        if (!isReady()) return;
                                        VastAd vast = mAdConfiguration.getVastAd();
                                        if (isFirstPlay) {
                                            // 初回再生: OM SDKのimpressionとstartを送信
                                            isFirstPlay = false;
                                            sendMediaEvent(
                                                    MeasurementConsts.mediaEvents.impression);
                                            float durationMs = playerView.getDuration();
                                            float volume = playerView.getMuted() ? 0.0f : 1.0f;
                                            if (videoViewMeasurementManager != null) {
                                                videoViewMeasurementManager.sendStartMediaEvent(
                                                        durationMs, volume);
                                            }
                                        } else if (vast.getVastEventState()
                                                == VastEventState.COMPLETE) {
                                            // リプレイ: トラッキング不要（旧VastPlayer準拠）
                                        } else {
                                            // 一時停止後の再開
                                            vast.resume();
                                            sendMediaEvent(MeasurementConsts.mediaEvents.resume);
                                        }
                                    }

                                    @Override
                                    public void onPaused(
                                            @NonNull SSCoreVideoPlayerView playerView) {
                                        if (!isReady()) return;
                                        VastAd vast = mAdConfiguration.getVastAd();
                                        // 再生開始後かつ完了前のみPAUSEを送信
                                        VastEventState state = vast.getVastEventState();
                                        if (!isCompleted
                                                && state.compareTo(VastEventState.START) >= 0) {
                                            vast.pause();
                                            sendMediaEvent(MeasurementConsts.mediaEvents.pause);
                                        }
                                    }

                                    @Override
                                    public void onMuteStateChanged(
                                            @NonNull SSCoreVideoPlayerView playerView) {
                                        if (!isReady()) return;
                                        VastAd vast = mAdConfiguration.getVastAd();
                                        if (playerView.getMuted()) {
                                            vast.mute();
                                            sendMediaEvent(
                                                    MeasurementConsts.mediaEvents.volumeChangeOff);
                                        } else {
                                            vast.unmute();
                                            sendMediaEvent(
                                                    MeasurementConsts.mediaEvents.volumeChangeOn);
                                        }
                                    }

                                    @Override
                                    public void onError(
                                            @NonNull SSCoreVideoPlayerView playerView,
                                            @NonNull SSCorePlayerError error) {
                                        ADGLogger.getDefault().error("SSCore: onError: " + error);
                                        onAdViewFailedToPlay(ADGPlayerError.UNSPECIFIED);
                                    }

                                    @Override
                                    public void onProgress(
                                            @NonNull SSCoreVideoPlayerView playerView,
                                            int currentMs,
                                            int durationMs) {
                                        if (!isReady() || durationMs <= 0) return;
                                        VastAd vast = mAdConfiguration.getVastAd();
                                        float percentile = (float) currentMs / durationMs;
                                        VastEventState state = vast.getVastEventState();

                                        // 現在位置をVastAdに記録（resume/replay判定に使用）
                                        vast.setCurrentTime(currentMs);

                                        // VASTクォータイルトラッキング（旧VastPlayer.onTimeUpdate準拠）
                                        if (state.compareTo(VastEventState.START) < 0
                                                && currentMs > 1000) {
                                            vast.start();
                                        } else if (state == VastEventState.START
                                                && percentile > 0.25f) {
                                            vast.firstQuartile();
                                            sendMediaEvent(
                                                    MeasurementConsts.mediaEvents.firstQuartile);
                                        } else if (state == VastEventState.FIRST_QUARTILE
                                                && percentile > 0.5f) {
                                            vast.midpoint();
                                            sendMediaEvent(MeasurementConsts.mediaEvents.midpoint);
                                        } else if (state == VastEventState.MIDPOINT
                                                && percentile > 0.75f) {
                                            vast.thirdQuartile();
                                            sendMediaEvent(
                                                    MeasurementConsts.mediaEvents.thirdQuartile);
                                        }

                                        if (state != VastEventState.COMPLETE) {
                                            vast.progress(currentMs, (int) (percentile * 100));
                                        }
                                    }

                                    @Override
                                    public void onCompleted(
                                            @NonNull SSCoreVideoPlayerView playerView) {
                                        ADGLogger.getDefault().debug("SSCore: onCompleted");
                                        isCompleted = true;
                                        if (!isReady()) return;
                                        VastAd vast = mAdConfiguration.getVastAd();
                                        // 再生終了間際にonProgressが発生しない可能性があるため
                                        // ここでもprogress(100%)を呼ぶ（旧VastPlayer.onCompletion準拠）
                                        if (vast.compareStateNext(VastEventState.COMPLETE)) {
                                            int dur = playerView.getDuration();
                                            if (dur > 0) {
                                                vast.progress(dur, 100);
                                            }
                                        }
                                        if (vast.getVastEventState()
                                                == VastEventState.THIRD_QUARTILE) {
                                            vast.complete();
                                            sendMediaEvent(MeasurementConsts.mediaEvents.complete);
                                        }
                                    }

                                    @Override
                                    public void onPlayerTapped(
                                            @NonNull SSCoreVideoPlayerView playerView) {
                                        ADGLogger.getDefault().debug("SSCore: onPlayerTapped");
                                        // 再生中のタップ → クリックスルー
                                        if (!isCompleted) {
                                            onAdViewClickThrough();
                                        }
                                    }

                                    @Override
                                    public void onDetailTapped(
                                            @NonNull SSCoreVideoPlayerView playerView) {
                                        ADGLogger.getDefault().debug("SSCore: onDetailTapped");
                                        // LinkButton（詳しくみる）タップ → クリックスルー
                                        onAdViewClickThrough();
                                    }

                                    @Override
                                    public void onDetachedFromWindow(
                                            @NonNull SSCoreVideoPlayerView playerView) {
                                        ADGLogger.getDefault()
                                                .debug("SSCore: onDetachedFromWindow");
                                        // 旧Viewが遅延してコールバックしてきた場合はスキップ
                                        if (playerView != mPlayerView) {
                                            ADGLogger.getDefault()
                                                    .debug(
                                                            "SSCore: onDetachedFromWindow skipped"
                                                                    + " (stale playerView)");
                                            return;
                                        }
                                        unregisterBroadcastReceivers();
                                        unregisterActivityLifecycleCallbacks();
                                    }
                                });

                        mContentView = contentView;

                        // OM SDK計測を開始
                        startMeasurement(mPlayerView);

                        registerScreenStateBroadcastReceiver();
                        mActivity
                                .getApplication()
                                .unregisterActivityLifecycleCallbacks(onActivityLifecycleCallbacks);
                        mActivity
                                .getApplication()
                                .registerActivityLifecycleCallbacks(onActivityLifecycleCallbacks);

                        // 保留中のView状態があれば適用
                        switch (pendingViewState) {
                            case IN_VIEW:
                                callWhenInView();
                                break;
                            case OUT_OF_VIEW:
                                callWhenOutOfView();
                                break;
                        }
                        pendingViewState = ViewState.NONE;

                    } else {
                        onAdViewFailedToPlay(ADGPlayerError.NO_AD);
                    }
                });
    }

    public void destroy() {
        ADGLogger.getDefault().debug("Destroy ADGPlayerAdManager.");

        // VastAdリソースを先に解放（reset()でmAdConfigurationがnullになるため）
        if (mAdConfiguration != null) {
            mAdConfiguration.getVastAd().release();
        }

        reset();
        unregisterScreenStateBroadcastReceiver();
        unregisterActivityLifecycleCallbacks();

        if (mPlayerView != null) {
            mPlayerView.release();
            Views.removeFromParent(mPlayerView);
            mPlayerView = null;
        }
        isPrepared = false;
        isInView = false;
        isCompleted = false;
        isFirstPlay = true;
        // Finishイベントを送信
        sendMediaEvent(MeasurementConsts.mediaEvents.finish);
        videoViewMeasurementManager = null;
    }

    public void callWhenInView() {
        isInView = true;
        if (mPlayerView != null && isPrepared && !isCompleted) {
            mPlayerView.play();
            if (isReady()) {
                mAdConfiguration.getVastAd().inView();
            }
        } else if (mPlayerView == null) {
            pendingViewState = ViewState.IN_VIEW;
        }
    }

    public void callWhenOutOfView() {
        isInView = false;
        if (mPlayerView != null) {
            mPlayerView.pause();
            if (isReady()) {
                mAdConfiguration.getVastAd().outView();
            }
        } else {
            pendingViewState = ViewState.OUT_OF_VIEW;
        }
    }

    public void onReadyToPlayAd() {
        mAdConfiguration.getVastAd().impressions();
        mAdListener.onReadyToPlayAd();
    }

    private void onAdViewFailedToPlay(@NonNull final ADGPlayerError error) {
        ADGLogger.getDefault().error(error.toString());
        mHander.post(
                () -> {
                    if (mAdListener != null) {
                        mAdListener.onFailedToPlayAd(error);
                    }
                });
    }

    private void onAdViewClickThrough() {
        ADGLogger.getDefault().debug("onAdViewClickThrough called.");

        if (isReady()) {
            mAdConfiguration.getVastAd().clickThrough(mContext);

            // InteractionTypeイベントの送信
            if (mAdConfiguration.getVastAd().getClickThrough().startsWith("http")) {
                // URL遷移
                sendUserInteraction(InteractionType.CLICK);
            } else {
                // それ以外(スキーマ遷移など)のケース
                sendUserInteraction(InteractionType.INVITATION_ACCEPTED);
            }

            if (mAdListener != null) {
                mAdListener.onClickAd();
            }
        }
    }

    @Override
    public void onScreenOn() {}

    @Override
    public void onScreenOff() {}

    private void ready() {
        ADGLogger.getDefault().debug("Ad is ready.");
        final VastAd vastAd = mAdConfiguration.getVastAd();
        updateBestMediaFileNetworkUrl(vastAd);
        boolean hasCache = updateBestMediaFileDiskUrl(vastAd);
        if (hasCache) {
            ADGLogger.getDefault().debug("Load video from disk cache.");
            if (mPlayerView != null) {
                // SSCoreVideoPlayerViewは動画URL指定済みのため、再ロード不要
                // InView状態であれば再生を試みる
                if (isInView && isPrepared) {
                    mPlayerView.play();
                }
            } else {
                onReadyToPlayAd();
            }
        } else {
            ADGLogger.getDefault().debug("Load video from network.");
            final CachingDownloadTask cachingDownloadTask =
                    new CachingDownloadTask(
                            new CachingDownloadTask.CachingDownloadTaskListener() {
                                @Override
                                public void onComplete(boolean success) {
                                    if (mAdConfiguration == null) {
                                        ADGLogger.getDefault().error("Already reset.");
                                        return;
                                    }
                                    if (!success) {
                                        ADGLogger.getDefault().error("CachingDownloadTask error.");
                                        onAdViewFailedToPlay(ADGPlayerError.CACHE_SERVICE_ERROR);
                                        return;
                                    }
                                    boolean hasCache = updateBestMediaFileDiskUrl(vastAd);
                                    if (!hasCache) {
                                        ADGLogger.getDefault()
                                                .error("updateBestMediaFileDiskUrl error.");
                                        onAdViewFailedToPlay(ADGPlayerError.CACHE_SERVICE_ERROR);
                                        return;
                                    }
                                    onReadyToPlayAd();
                                }
                            });
            try {
                cachingDownloadTask.executeOnExecutor(
                        AsyncTask.THREAD_POOL_EXECUTOR, vastAd.getBestMediaFileNetworkUrl());
            } catch (IllegalStateException | RejectedExecutionException | NullPointerException e) {
                ADGLogger.getDefault().error("cachingDownloadTask.executeOnExecutor error.", e);
                onAdViewFailedToPlay(ADGPlayerError.CACHE_SERVICE_ERROR);
            }
        }
    }

    private void reset() {
        mAdConfiguration = null;
        mContentView = null;

        if (mRequesting != null) {
            mRequesting.cancel();
            mRequesting = null;
        }
    }

    private MediaFile selectBestMediaFile(List<MediaFile> mediaFiles) {
        double bestMediaFitness = Double.POSITIVE_INFINITY;
        MediaFile bestMediaFile = null;

        for (MediaFile m : mediaFiles) {
            final String mediaType = m.getType();
            final String mediaUrl = m.getUrl().toString();
            if (!VIDEO_MIME_TYPES.contains(mediaType) || mediaUrl == null) {
                continue;
            }

            final int mediaWidth = m.getWidth();
            final int mediaHeight = m.getHeight();
            if (mediaWidth <= 0 || mediaHeight <= 0) {
                continue;
            }

            final double mediaFitness = calculateFitness(mediaWidth, mediaHeight);
            if (mediaFitness < bestMediaFitness) {
                bestMediaFitness = mediaFitness;
                bestMediaFile = m;
            }
        }

        if (bestMediaFile == null && !mAdConfiguration.getVastAd().getMediaFiles().isEmpty()) {
            bestMediaFile = mAdConfiguration.getVastAd().getMediaFiles().get(0);
        }

        return bestMediaFile;
    }

    private double calculateFitness(final int width, final int height) {
        final double mediaAspectRatio = (double) width / height;
        final int mediaArea = width * height;
        final double aspectRatioRatio = mediaAspectRatio / mScreenAspectRatio;
        final double areaRatio = (double) mediaArea / mScreenArea;
        return ASPECT_RATIO_WEIGHT * Math.abs(Math.log(aspectRatioRatio))
                + AREA_WEIGHT * (Math.pow(areaRatio, 2) * Math.abs(Math.log(areaRatio)));
    }

    private boolean updateBestMediaFileDiskUrl(final VastAd vastAd) {
        final String networkMediaFileUrl = vastAd.getBestMediaFileNetworkUrl();
        if (CacheService.containsKeyDiskCache(networkMediaFileUrl)) {
            final String filePathDiskCache = CacheService.getFilePathDiskCache(networkMediaFileUrl);
            vastAd.setBestMediaFileDiskUrl(filePathDiskCache);
            return true;
        }
        return false;
    }

    private void updateBestMediaFileNetworkUrl(final VastAd vastAd) {
        MediaFile bestMediaFile = selectBestMediaFile(vastAd.getMediaFiles());
        vastAd.setBestMediaFileNetworkUrl(bestMediaFile.getUrl().toString());
    }

    private void initializeScreenDimensions() {
        Point screenDimensions = getDeviceDimensions(mContext);
        int x = screenDimensions.x;
        int y = screenDimensions.y;

        // For landscape, width is always greater than height
        int screenX = Math.max(x, y);
        int screenY = Math.min(x, y);

        float density = mContext.getResources().getDisplayMetrics().density;
        int dpX = (int) Math.ceil(screenX / density);
        int dpY = (int) Math.ceil(screenY / density);
        mScreenAspectRatio = (double) dpX / dpY;
        mScreenArea = dpX * dpY;
    }

    public void unregisterBroadcastReceivers() {
        ADGLogger.getDefault().debug("Unregister broadcast receivers.");

        unregisterScreenStateBroadcastReceiver();
    }

    public void unregisterActivityLifecycleCallbacks() {
        if (mActivity != null) {
            mActivity
                    .getApplication()
                    .unregisterActivityLifecycleCallbacks(onActivityLifecycleCallbacks);
        }
    }

    private void registerScreenStateBroadcastReceiver() {
        ADGLogger.getDefault().debug("register");
        unregisterScreenStateBroadcastReceiver();
        mScreenStateBroadcastReceiver = new ScreenStateBroadcastReceiver(this);
        mScreenStateBroadcastReceiver.register(mContext);
    }

    private void unregisterScreenStateBroadcastReceiver() {
        ADGLogger.getDefault().debug("unregister");
        if (mScreenStateBroadcastReceiver != null) {
            mScreenStateBroadcastReceiver.unregister();
        }
    }

    private class OnActivityLifecycleCallbacks implements Application.ActivityLifecycleCallbacks {
        @Override
        public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}

        @Override
        public void onActivityStarted(Activity activity) {}

        @Override
        public void onActivityResumed(Activity activity) {
            if (activity.equals(mActivity)) {
                if (mPlayerView != null && isReady() && isInView && isPrepared && !isCompleted) {
                    mPlayerView.play();
                }
            }
        }

        @Override
        public void onActivityPaused(Activity activity) {
            if (activity.equals(mActivity)) {
                if (mPlayerView != null) {
                    mPlayerView.pause();
                }
            }
        }

        @Override
        public void onActivityStopped(Activity activity) {}

        @Override
        public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}

        @Override
        public void onActivityDestroyed(Activity activity) {
            if (activity.equals(mActivity)) {
                mActivity.getApplication().unregisterActivityLifecycleCallbacks(this);
            }
        }
    }

    /** VastInformationIconView（iマーク）をプレイヤーViewに追加する 旧VastPlayer.setVastInformationIconView()に相当 */
    private void addVastInformationIconView(@NonNull ViewGroup playerView) {
        if (mAdConfiguration == null) return;
        VastAd vastAd = mAdConfiguration.getVastAd();
        if (vastAd.getIcons().isEmpty()) return;

        VastInformationIconView vastInformationIconView;
        try {
            vastInformationIconView =
                    isWipe
                            ? new VastInformationIconView(
                                    mContext,
                                    getIconWithSelectIndustry(vastAd),
                                    false,
                                    VastInformationIconView.Corner.TOP_LEFT,
                                    VastInformationIconView.BackgroundType.WHITE,
                                    true)
                            : new VastInformationIconView(
                                    mContext, getIconWithSelectIndustry(vastAd));
        } catch (VastInformationIconView.CannotInstantiateException | NullPointerException e) {
            ADGLogger.getDefault().warn("Failed to create VastInformationIconView");
            return;
        }
        playerView.addView(vastInformationIconView);
    }

    /** VastIconの選択ロジック（旧VastPlayer.getIconWithSelectIndustry準拠） */
    @Nullable
    private VASTIcon getIconWithSelectIndustry(@NonNull VastAd vastAd) {
        for (VASTIcon icon : vastAd.getIcons()) {
            if (icon == null || icon.getStaticResource() == null) continue;
            if (icon.isAdg()) {
                return android.webkit.URLUtil.isValidUrl(icon.getStaticResource().getUrlString())
                        ? icon
                        : null;
            }
        }
        VASTIcon closestIcon = vastAd.getClosestIcon();
        if (closestIcon != null && closestIcon.getStaticResource() != null) {
            return android.webkit.URLUtil.isValidUrl(closestIcon.getStaticResource().getUrlString())
                    ? closestIcon
                    : null;
        }
        return null;
    }

    /** OM SDKのアドセッションを生成して計測を開始する */
    private void startMeasurement(@NonNull View adView) {
        if (mAdConfiguration == null) return;
        VastAd vastAd = mAdConfiguration.getVastAd();
        videoViewMeasurementManager = new VideoViewMeasurementManager(mContext, vastAd);
        boolean started = videoViewMeasurementManager.startMeasurement(adView);
        if (started) {
            // ADGは常にスキップ不可・自動再生
            videoViewMeasurementManager.sendLoadedForNonSkippableMedia(true, Position.STANDALONE);
        }
    }

    /** スキップ不可能な広告動画をロードした際にコールするイベント */
    public void sendLoadedForNonSkippableVideo() {
        if (videoViewMeasurementManager == null) return;
        videoViewMeasurementManager.sendLoadedForNonSkippableMedia(true, Position.STANDALONE);
    }

    /**
     * 広告クリックでの遷移の際にコールするイベント
     *
     * @param interactionType CLICK(httpまたはhttpsへの遷移) or INVITATION_ACCEPTED(スキーマなどでの遷移)
     */
    public void sendUserInteraction(InteractionType interactionType) {
        try {
            if (interactionType == null || videoViewMeasurementManager == null) return;
            videoViewMeasurementManager.sendUserInteraction(interactionType);
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            ADGLogger.getDefault().error("sendUserInteraction error.", e);
        }
    }

    /**
     * 動画の読み込み〜再生終了に伴うトラッキングイベントを送信する
     *
     * <p>再生開始（start）はduration/volumeが必要なため {@link VideoViewMeasurementManager#sendStartMediaEvent}
     * を直接呼ぶこと。
     *
     * @param event 送信するイベント
     */
    public void sendMediaEvent(MeasurementConsts.mediaEvents event) {
        try {
            if (event == null || videoViewMeasurementManager == null) return;
            videoViewMeasurementManager.sendMediaEvent(event);
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            ADGLogger.getDefault().error("sendMediaEvent error.", e);
        }
    }
}
