package com.socdm.d.adgeneration.adloader

import android.content.Context
import com.socdm.d.adgeneration.utils.AssetUtils

/**
 * assetsからmraid.jsを読み込むMRAIDSourceReadable実装。
 * 読み込み結果をキャッシュする（iOS ADGResources.shared と同じパターン）。
 *
 * iOS対応: ADGResources extension ADGMRAIDSourceReadable
 */
internal class ADGMRAIDSourceReader(private val appContext: Context) : MRAIDSourceReadable {
    private var cachedSource: String? = null
    private var hasLoaded = false

    override fun readMRAIDSource(): String? {
        if (!hasLoaded) {
            cachedSource = AssetUtils.getMRAIDSource(appContext)
            hasLoaded = true
        }
        return cachedSource
    }
}
