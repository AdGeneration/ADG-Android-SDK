package com.socdm.d.adgeneration.observer;

import androidx.annotation.NonNull;

public interface Observer {
    public void onMessage(@NonNull final ADGMessage message);
}
