package com.socdm.d.adgeneration.nativead;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.adresponse.Native;

public class ADGData {
    @NonNull private final String value;
    @Nullable private String label;
    @Nullable private Object ext;

    public ADGData(@NonNull final Native.Asset.NativeData obj) {
        this.value = obj.value;
        obj.label.ifPresent(l -> this.label = l);
        obj.ext.ifPresent(e -> this.ext = e);
    }

    @NonNull
    public String getValue() {
        return value;
    }

    @Nullable
    public String getLabel() {
        return label;
    }

    @Nullable
    public Object getExt() {
        return ext;
    }
}
