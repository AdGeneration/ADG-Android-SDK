package com.socdm.d.adgeneration.utils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public interface AsyncTaskListener<Result> {
    void onSuccess(@Nullable final Result result);

    void onError(@NonNull final Exception e);
}
