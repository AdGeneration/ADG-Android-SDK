package com.socdm.d.adgeneration;

import androidx.annotation.NonNull;

import com.socdm.d.adgeneration.utils.ChildDirectedState;
import com.socdm.d.adgeneration.video.VideoAudioType;

public final class ADGSettings {
    private static boolean isGeolocationEnabled = false;
    @NonNull private static VideoAudioType videoAudioType = VideoAudioType.MIX;
    private static boolean isSSL = true;
    @NonNull private static ChildDirectedState childDirectedState = ChildDirectedState.UNSPECIFIED;

    public static boolean isGeolocationEnabled() {
        return isGeolocationEnabled;
    }

    public static void setGeolocationEnabled(final boolean enable) {
        isGeolocationEnabled = enable;
    }

    @NonNull
    public static VideoAudioType getVideoAudioType() {
        return videoAudioType;
    }

    public static void setVideoAudioType(@NonNull final VideoAudioType type) {
        videoAudioType = type;
    }

    @Deprecated
    public static boolean isSSL() {
        return isSSL;
    }

    @Deprecated
    public static void setIsSSL(final boolean ssl) {
        isSSL = ssl;
    }

    public static boolean isChildDirectedEnabled() {
        switch (childDirectedState) {
            case TRUE:
                return true;
            case FALSE:
            case UNSPECIFIED:
            default:
                return false;
        }
    }

    // Mediation側で設定してないことに意味のある場合が存在するため
    public static boolean isSetChildDirected() {
        switch (childDirectedState) {
            case TRUE:
            case FALSE:
                return true;
            case UNSPECIFIED:
            default:
                return false;
        }
    }

    @NonNull
    public static ChildDirectedState getChildDirectedState() {
        return childDirectedState;
    }

    public static void setChildDirected(final boolean enable) {
        childDirectedState = enable ? ChildDirectedState.TRUE : ChildDirectedState.FALSE;
    }

    /**
     * trueを指定するとデバッグログを出力します。リリース時は必ずfalseに設定してください。
     *
     * @param enabled デバッグログを出力する場合はtrue、そうでない場合はfalse
     */
    public static void setDebugLogging(final boolean enabled) {
        ADGLogger.setEnabled(enabled);
    }

    /**
     * デバッグログを出力する設定になっているかどうかを返します。
     *
     * @return デバッグログを出力する設定になっている場合はtrue、そうでない場合はfalse
     */
    public static boolean isDebugLogging() {
        return ADGLogger.isEnabled();
    }
}
