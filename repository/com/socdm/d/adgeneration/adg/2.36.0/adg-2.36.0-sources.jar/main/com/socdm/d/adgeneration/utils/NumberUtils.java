package com.socdm.d.adgeneration.utils;

import androidx.annotation.NonNull;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class NumberUtils {

    /**
     * 広告に指定する幅サイズを取得する
     *
     * @param originalWidth 広告の元の幅
     * @param originalHeight 広告の元の高さ
     * @param width 指定する幅
     * @param height 指定する高さ
     * @return
     */
    public static int getWidth(
            final int originalWidth, final int originalHeight, final int width, final int height) {
        BigDecimal ratio = getRatio(originalWidth, originalHeight, width, height);
        return new BigDecimal(originalWidth).multiply(ratio).intValue();
    }

    /**
     * 広告に指定する高さを取得する
     *
     * @param originalWidth 広告の元の幅
     * @param originalHeight 広告の元の高さ
     * @param width 指定する幅
     * @param height 指定する高さ
     * @return
     */
    public static int getHeight(
            final int originalWidth, final int originalHeight, final int width, final int height) {
        BigDecimal ratio = getRatio(originalWidth, originalHeight, width, height);
        return new BigDecimal(originalHeight).multiply(ratio).intValue();
    }

    @NonNull
    private static BigDecimal getRatio(
            final int originalWidth, final int originalHeight, final int width, final int height) {
        BigDecimal ratioWidth =
                new BigDecimal(width)
                        .divide(new BigDecimal(originalWidth), 2, RoundingMode.HALF_UP);
        BigDecimal ratioHeight =
                new BigDecimal(height)
                        .divide(new BigDecimal(originalHeight), 2, RoundingMode.HALF_UP);
        return ratioWidth.compareTo(ratioHeight) == -1 ? ratioWidth : ratioHeight;
    }
}
