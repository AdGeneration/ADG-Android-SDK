package com.socdm.d.adgeneration.utils;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class ShowController {

    private static final String PREFS_KEY = "adg_adshowcounts_prefs"; // default prefs key
    @Nullable private SharedPreferences prefs = null;
    @NonNull private final Map<String, AdShowCount> counts = new HashMap<String, AdShowCount>();

    public ShowController(@NonNull final Context ct) {
        this(ct, PREFS_KEY);
    }

    public ShowController(@NonNull final Context ct, @NonNull final String prefsKey) {
        this.prefs = ct.getSharedPreferences(prefsKey, Context.MODE_PRIVATE);
        this.load();
    }

    // HashMap wrapper methods
    @Nullable
    private AdShowCount get(@NonNull final String key) { // to hide AdShowCounts from other classes.
        return this.counts.containsKey(key) ? this.counts.get(key) : null;
    }

    public void remove(@NonNull final String key) {
        this.counts.remove(key);
    }

    public void clear() {
        this.counts.clear();
    }

    public boolean containsKey(@NonNull final String key) {
        return this.counts.containsKey(key);
    }

    @NonNull
    public Set<String> keySet() {
        return this.counts.keySet();
    }

    // put AdShowCounts instance to HashMap
    public void cache(@NonNull final String key, final int span, final boolean isPercentage) {
        cache(key, /* current= */ 0, span, isPercentage);
    }

    public void cache(
            @NonNull final String key,
            final int current,
            final int span,
            final boolean isPercentage) {
        AdShowCount asc = get(key);
        if (asc == null) {
            cache(key, new AdShowCount(current, span, isPercentage));
        } else {
            asc.span = span;
            asc.isPercentage = isPercentage;
            cache(key, asc);
        }
    }

    // load AdShowCounts instances from SharedPreferences to HashMap
    @SuppressWarnings("unchecked")
    public void load() {
        clear();
        if (prefs == null) {
            LogUtils.w("SharedPreferences is null");
            return;
        }
        HashMap<String, String> loaded = (HashMap<String, String>) prefs.getAll();
        for (String key : loaded.keySet()) {
            String value = loaded.get(key);
            if (value == null) {
                continue;
            }
            String[] s = value.split(",");
            if (s.length == 3) {
                cache(
                        key,
                        Integer.parseInt(s[0]),
                        Integer.parseInt(s[1]),
                        Boolean.parseBoolean(s[2]));
            }
        }
    }

    // save AdShowCounts instances from HashMap to SharedPreferences
    public void save() {
        if (prefs == null) {
            LogUtils.w("SharedPreferences is null");
            return;
        }
        SharedPreferences.Editor editor = prefs.edit();
        for (String key : keySet()) {
            AdShowCount asc = get(key);
            if (asc == null) {
                continue;
            }
            editor.putString(key, asc.count + "," + asc.span + "," + asc.isPercentage);
        }
        editor.apply();
    }

    // AdShowCounts wrapper methods
    public void reset(@NonNull final String key) {
        AdShowCount asc = get(key);
        if (asc != null) {
            asc.reset();
            cache(key, asc);
            save();
        }
    }

    public void next(@NonNull final String key) {
        AdShowCount asc = get(key);
        if (asc != null) {
            asc.next();
            cache(key, asc);
            save();
        }
    }

    public boolean isShow(@NonNull final String key) {
        AdShowCount asc = get(key);
        // if asc is null, always return true to prevent the ad from showing.
        return asc == null || asc.isShow();
    }

    private void cache(@Nullable final String key, @Nullable final AdShowCount asc) {
        if (key != null && !key.isEmpty()) {
            this.counts.put(key, asc);
        }
    }

    private static final class AdShowCount {
        private int count = 0;
        private int span = 0;
        private boolean isPercentage;

        public AdShowCount(final int count, final int span, final boolean isPercentage) {
            this.count = count;
            this.span = span;
            this.isPercentage = isPercentage;
        }

        public void reset() {
            if (!this.isPercentage) {
                this.count = 0;
                LogUtils.d("[reset] count: " + count + ", span: " + span);
            }
        }

        public void next() {
            if (!this.isPercentage) {
                this.count++;
                LogUtils.d("[next] count: " + count + ", span: " + span);
            }
        }

        public boolean isShow() {
            if (this.span == 0) {
                LogUtils.d("[isShow] true span: 0");
                return true;
            }
            if (this.isPercentage) {
                Random rnd = new Random();
                return rnd.nextInt(100) < this.span;
            } else {
                LogUtils.d(
                        "[isShow] "
                                + (this.count != 0 && this.count % this.span == 0)
                                + " count: "
                                + count
                                + ", span: "
                                + this.span);
                return this.count != 0 && this.count % this.span == 0;
            }
        }
    }
}
