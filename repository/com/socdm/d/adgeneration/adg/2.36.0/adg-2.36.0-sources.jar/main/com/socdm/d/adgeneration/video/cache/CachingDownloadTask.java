package com.socdm.d.adgeneration.video.cache;

import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.utils.LogUtils;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class CachingDownloadTask extends AsyncTask<String, Void, Boolean> {
    private static final int MAX_SIZE = 25 * 1024 * 1024; // 25 MiB

    public interface CachingDownloadTaskListener {
        void onComplete(final boolean success);
    }

    @Nullable private final CachingDownloadTaskListener mCachingDownloadTaskListener;

    public CachingDownloadTask(@Nullable final CachingDownloadTaskListener listener) {
        mCachingDownloadTaskListener = listener;
    }

    @NonNull
    @Override
    protected Boolean doInBackground(@Nullable final String... params) {
        if (params == null || params[0] == null) {
            return false;
        }

        final String url = params[0];
        InputStream in = null;

        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod("GET");
            connection.setReadTimeout(10000);
            connection.connect();
            if (connection.getContent() == null) {
                throw new IOException("Obtained null response from url: " + url);
            }
            if (connection.getContentLength() > MAX_SIZE) {
                throw new IOException("Exceeded max download size");
            }
            in = connection.getInputStream();
            final boolean diskPutResult = CacheService.putToDiskCache(url, in);
            return diskPutResult;
        } catch (Exception e) {
            e.printStackTrace();
            LogUtils.e(e.getMessage());
            return false;
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                    e.printStackTrace();
                    LogUtils.e(e.getMessage());
                }
            }
        }
    }

    @Override
    protected void onCancelled() {
        onPostExecute(false);
    }

    @Override
    protected void onPostExecute(@NonNull final Boolean success) {
        if (mCachingDownloadTaskListener != null) {
            mCachingDownloadTaskListener.onComplete(success);
        }
    }
}
