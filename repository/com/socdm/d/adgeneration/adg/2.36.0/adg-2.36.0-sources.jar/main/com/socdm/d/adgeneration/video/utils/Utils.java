package com.socdm.d.adgeneration.video.utils;

import androidx.annotation.NonNull;

import java.security.MessageDigest;
import java.util.Locale;

public class Utils {

    @NonNull
    public static String sha1(@NonNull final String string) {
        StringBuilder stringBuilder = new StringBuilder();

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            byte[] bytes = string.getBytes("UTF-8");
            digest.update(bytes, 0, bytes.length);
            bytes = digest.digest();

            for (final byte b : bytes) {
                stringBuilder.append(String.format("%02X", b));
            }

            return stringBuilder.toString().toLowerCase(Locale.US);
        } catch (Exception e) {
            return "";
        }
    }
}
