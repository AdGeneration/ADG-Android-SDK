package com.socdm.d.adgeneration.video.config;

import androidx.annotation.NonNull;

import com.socdm.d.adgeneration.video.vast.VastAd;

import java.io.Serializable;

public class AdConfiguration implements Serializable {
    @NonNull private final VastAd mVastAd;
    private final boolean soundEnabled;

    public AdConfiguration(@NonNull final VastAd vastAd) {
        mVastAd = vastAd;
        soundEnabled = false;
    }

    @NonNull
    public VastAd getVastAd() {
        return mVastAd;
    }

    public boolean isSoundEnabled() {
        return soundEnabled;
    }
}
