package com.socdm.d.adgeneration.mediation;

import androidx.annotation.NonNull;

public abstract class ADGNativeInterfaceChildListener {
    public void onReceiveAd() {}

    public void onReceiveAd(@NonNull final Object nativeAd) {}

    public void onFailedToReceiveAd() {}

    public void onCompleteMovieAd() {}

    public void onClickAd() {}

    public void onReplayMovieAd() {}

    public void onReadyMediation(@NonNull final Object mediation) {}

    public void onSuccessfulBidder(@NonNull final String bidderSuccessfulName) {}
}
