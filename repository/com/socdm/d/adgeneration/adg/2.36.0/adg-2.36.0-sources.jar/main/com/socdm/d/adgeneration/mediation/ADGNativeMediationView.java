package com.socdm.d.adgeneration.mediation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.ADGLogger;
import com.socdm.d.adgeneration.IADGLogger;

/** ネイティブメディエーション広告用のViewクラス 他のネイティブ広告Viewをラップし、ADG SDKのViewable機能を提供します */
public class ADGNativeMediationView extends FrameLayout {

    @Nullable private ADGNativeMediationController controller;
    @NonNull private final IADGLogger logger;

    /**
     * コンストラクタ
     *
     * @param context コンテキスト
     */
    public ADGNativeMediationView(@NonNull final Context context) {
        this(context, null);
    }

    /**
     * コンストラクタ
     *
     * @param context コンテキスト
     * @param attrs 属性セット
     */
    public ADGNativeMediationView(
            @NonNull final Context context, @Nullable final AttributeSet attrs) {
        this(context, attrs, 0);
    }

    /**
     * コンストラクタ
     *
     * @param context コンテキスト
     * @param attrs 属性セット
     * @param defStyleAttr デフォルトスタイル属性
     */
    public ADGNativeMediationView(
            @NonNull final Context context,
            @Nullable final AttributeSet attrs,
            final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.logger = ADGLogger.getInstance();
    }

    /**
     * ネイティブメディエーションViewを設定します 既存のViewをラップして、ADG SDKのViewable機能を提供します
     * このメソッドは引数で渡されたViewをその親から削除します。返されたADGNativeMediationViewインスタンスをレイアウトに再度追加する必要があります。
     *
     * @param view ラップする広告View
     * @param model データモデル
     * @param impressionDelegate インプレッションデリゲート
     * @return 設定されたADGNativeMediationView
     */
    @NonNull
    public static ADGNativeMediationView configureNativeMediationView(
            @NonNull final View view,
            @NonNull final ADGNativeMediationModel model,
            @Nullable final ADGNativeMediationController.OnImpressionListener impressionDelegate) {
        return configureNativeMediationView(
                view, model, impressionDelegate, ADGLogger.getInstance());
    }

    /**
     * ネイティブメディエーションViewを設定します。 既存のViewをラップして、ADG SDKのViewable機能を提供します（テスト用）
     * このメソッドは引数で渡されたViewをその親から削除します。返されたADGNativeMediationViewインスタンスをレイアウトに再度追加する必要があります。
     *
     * @param view ラップする広告View
     * @param model データモデル
     * @param impressionDelegate インプレッションデリゲート
     * @param logger ロガー
     * @return 設定されたADGNativeMediationView
     */
    @NonNull
    static ADGNativeMediationView configureNativeMediationView(
            @NonNull final View view,
            @NonNull final ADGNativeMediationModel model,
            @Nullable final ADGNativeMediationController.OnImpressionListener impressionDelegate,
            @NonNull final IADGLogger logger) {

        final Context context = view.getContext();
        final ADGNativeMediationView mediationView = new ADGNativeMediationView(context);

        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams != null) {
            mediationView.setLayoutParams(layoutParams);
        }

        ViewGroup parent = (ViewGroup) view.getParent();
        if (parent != null) {
            parent.removeView(view);
        }

        mediationView.addView(
                view,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT));

        mediationView.initializeWithModel(model, impressionDelegate, logger);

        return mediationView;
    }

    /**
     * モデルとデリゲートで初期化します
     *
     * @param model データモデル
     * @param impressionDelegate インプレッションデリゲート
     */
    public void initializeWithModel(
            @NonNull final ADGNativeMediationModel model,
            @Nullable final ADGNativeMediationController.OnImpressionListener impressionDelegate) {
        initializeWithModel(model, impressionDelegate, logger);
    }

    /**
     * モデルとデリゲートで初期化します（内部用）
     *
     * @param model データモデル
     * @param impressionDelegate インプレッションデリゲート
     * @param logger ロガー
     */
    @androidx.annotation.VisibleForTesting
    private void initializeWithModel(
            @NonNull final ADGNativeMediationModel model,
            @Nullable final ADGNativeMediationController.OnImpressionListener impressionDelegate,
            @NonNull final IADGLogger logger) {
        // 既存のコントローラーをクリーンアップ
        if (controller != null) {
            controller.destroy();
        }

        // 新しいコントローラーを作成
        controller = new ADGNativeMediationController(model, this, impressionDelegate, logger);
        logger.getLogger().debug("Initialized ADGNativeMediationView with model.");
    }

    /** Viewable計測を開始します */
    public void startViewable() {
        if (controller != null) {
            controller.startViewableMeasurement();
        } else {
            logger.getLogger()
                    .error("Controller is not initialized. Call initializeWithModel first.");
        }
    }

    /** Viewable計測を終了します */
    public void finishViewable() {
        if (controller != null) {
            controller.finishViewableMeasurement();
        }
    }

    /** リソースをクリーンアップします */
    public void destroy() {
        if (controller != null) {
            controller.destroy();
            controller = null;
        }
        removeAllViews();
    }

    /**
     * コントローラーを取得します（テスト用）
     *
     * @return コントローラー
     */
    @Nullable
    @androidx.annotation.VisibleForTesting
    ADGNativeMediationController getController() {
        return controller;
    }
}
