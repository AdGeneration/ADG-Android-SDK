package com.socdm.d.adgeneration.video.view;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.Measurement.MeasurementConsts;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.ADGPlayerError;
import com.socdm.d.adgeneration.video.vast.VASTIcon;
import com.socdm.d.adgeneration.video.vast.VastAd;
import com.socdm.d.adgeneration.video.vast.VastEventState;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/** VAST広告を再生するためのプレイヤークラスです。 VideoViewをラップし、VAST広告の再生制御、イベント通知、Viewable計測などの機能を提供します。 */
public class VastPlayer extends FrameLayout implements VideoView.VideoViewListener {
    @NonNull private final Context mContext;
    @Nullable private VastAd mVastAd;
    @NonNull private final VideoView mVideoView;
    @Nullable private VastMediaEventListener mListener;
    @Nullable private VastMediaEventListenerForManager mListenerForManager;
    private boolean mIsViewable;
    private boolean isCompleted;
    private final boolean isWipe;
    private boolean isNativeOptout = false;
    private volatile boolean mWaitingForPlaybackWhenInView = false;
    @NonNull private final Runner videoLoop = new Runner(this);
    @Nullable private ProgressBar progressBar;

    /**
     * VastPlayerのインスタンスを生成します。
     *
     * @param context コンテキスト
     */
    public VastPlayer(@NonNull final Context context) {
        this(context, false);
    }

    /**
     * VastPlayerのインスタンスを生成します。
     *
     * @param context コンテキスト
     * @param isWipe Wipe広告かどうか
     */
    public VastPlayer(@NonNull final Context context, final boolean isWipe) {
        super(context);
        mContext = context;
        this.isWipe = isWipe;

        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setBackgroundColor(Color.TRANSPARENT);
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        LayoutParams params =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.CENTER;
        setLayoutParams(params);

        mVideoView = new VideoView(mContext);
        mVideoView.setVideoViewListener(this);
        mVideoView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        mVideoView.setBackgroundColor(Color.TRANSPARENT);
        mVideoView.setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        LayoutParams videoViewParams =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        videoViewParams.gravity = Gravity.CENTER;
        mVideoView.setLayoutParams(videoViewParams);
        addView(mVideoView);

        videoLoop.start();
    }

    /**
     * VAST広告データを設定し、動画の読み込みを開始します。
     *
     * @param vastAd VAST広告データ
     * @param isNativeOptout ネイティブオプトアウトの設定
     */
    public void setVastAdThenLoadVideo(@NonNull final VastAd vastAd, final boolean isNativeOptout) {
        mVastAd = vastAd;
        mVideoView.setVideoURL(mVastAd.getBestMediaFileUrl());
        this.isNativeOptout = isNativeOptout;
        // VASTに含まれるIconsを表示させる
        setVastInformationIconView();
        // プログレスバーを表示させる
        setVastProgressBarView();
    }

    /**
     * VAST広告データを設定します。
     *
     * @param vastAd VAST広告データ
     */
    public void setVastAd(@Nullable final VastAd vastAd) {
        mVastAd = vastAd;
    }

    /**
     * 設定されているVAST広告データを取得します。
     *
     * @return VAST広告データ、未設定の場合はnull
     */
    @Nullable
    public VastAd getVastAd() {
        return mVastAd;
    }

    /**
     * VAST広告の再生イベントを受け取るリスナーを設定します。
     *
     * @param listener イベントリスナー
     */
    public void setVastMediaEventListener(@Nullable final VastMediaEventListener listener) {
        mListener = listener;
    }

    /**
     * VAST広告イベントリスナーを設定します。 ADGPlayerAdManager用
     *
     * @param listener イベントリスナー
     */
    public void setVastMediaEventListenerForManger(
            @Nullable final VastMediaEventListenerForManager listener) {
        mListenerForManager = listener;
    }

    /**
     * 動画が再生可能な状態かどうかを返します。
     *
     * @return 再生可能な状態の場合true
     */
    public boolean isInPlaybackState() {
        return mVideoView.isInPlaybackState();
    }

    /**
     * プレイヤーが視認可能な状態かどうかを返します。
     *
     * @return 視認可能な状態の場合true
     */
    public boolean isViewable() {
        return mIsViewable;
    }

    /** VastPlayerのリソースを解放します。 動画の再生を停止し、VAST広告データをクリアします。 */
    public void releaseVastPlayer() {
        videoLoop.stop();
        mVideoView.stopPlayback();
        mIsViewable = false;
        if (mVastAd != null) {
            mVastAd.release();
            mVastAd = null;
        }
    }

    /** 動画の再生を開始します。 既に再生中の場合や、準備が完了していない場合は何もしません。 */
    public void play() {
        if (!mVideoView.isInPlaybackState()
                || mVideoView.isPlaying()
                || isCompleted
                || mVastAd == null) {
            return;
        }

        if (mVastAd.getCurrentTime() > 0) {
            // 以前の続きから再生
            mVastAd.resume();
            if (mListenerForManager != null) {
                mListenerForManager.onVideoTrackingEvent(
                        MeasurementConsts.mediaEvents.resume, mVideoView);
            }
            mVideoView.seekTo((int) mVastAd.getCurrentTime());
        } else {
            // 新規再生
            if (mListenerForManager != null) {
                mListenerForManager.onVideoTrackingEvent(
                        MeasurementConsts.mediaEvents.impression, mVideoView);
            }
        }

        mVideoView.start();

        if (mListener != null) {
            mListener.onPlaying(mVideoView);
        }

        // 新規再生時のみスタートイベントを発行
        if (mVastAd.getCurrentTime() <= 0 && mListenerForManager != null) {
            mListenerForManager.onVideoTrackingEvent(
                    MeasurementConsts.mediaEvents.start, mVideoView);
        }
    }

    /** 動画の再生を一時停止します。 */
    public void pause() {
        if (mVideoView.isInPlaybackState() && mVideoView.isPlaying()) {
            mVideoView.pause();
            if (mVastAd != null) {
                mVastAd.pause();
            }
            if (mListenerForManager != null) {
                mListenerForManager.onVideoTrackingEvent(
                        MeasurementConsts.mediaEvents.pause, mVideoView); // 動画のpause
            }
        }
    }

    /** 動画の音声をオンにします。 */
    public void unmute() {
        if (mVastAd != null) {
            mVideoView.setVolume(1, 1);
            mVastAd.unmute();
        }
    }

    /** 動画の音声をミュートします。 */
    public void mute() {
        if (mVastAd != null) {
            mVideoView.setVolume(0, 0);
            mVastAd.mute();
        }
    }

    /** 動画を最初から再生します。 */
    public void replay() {
        if (!mVideoView.isPlaying()) {
            isCompleted = false;
            mVideoView.pause();
            mVideoView.seekTo(0);
            mVideoView.start();
        }
    }

    /** Video Events */
    @Override
    public void onPrepared() {
        if (mVastAd == null) {
            return;
        }
        mVideoView.seekTo((int) mVastAd.getCurrentTime());

        // InView待機中なら自動的に再生開始
        if (mWaitingForPlaybackWhenInView && mIsViewable) {
            mWaitingForPlaybackWhenInView = false;
            play();
            LogUtils.d("Auto-playing video after preparation completed while in view.");
        }

        process();

        if (mListener != null) {
            mListener.onPrepared(mVideoView); // 動画ロード完了
        }
        if (mListenerForManager != null) {
            mListenerForManager.onVideoLoadEvent(mVideoView);
        }
    }

    @Override
    public void onCompletion() {
        isCompleted = true;
        if (mVastAd == null) {
            return;
        }
        float duration = (float) mVideoView.getDuration();
        if (mVastAd.compareStateNext(VastEventState.COMPLETE)) {
            if (duration != -1) {
                // 再生終了間際の指定だとonProgressが発生しない可能性があるので、ここでも呼んでおく
                mVastAd.progress((long) duration, 100);
            }
        }
        if (mVastAd.getVastEventState() == VastEventState.THIRD_QUARTILE) {
            mVastAd.complete();
            if (mListener != null) {
                mListener.onCompletion(mVideoView); // 動画再生完了
            }
            if (mListenerForManager != null) {
                mListenerForManager.onVideoTrackingEvent(
                        MeasurementConsts.mediaEvents.complete, mVideoView);
            }
        }
    }

    @Override
    public void onError() {
        LogUtils.e(ADGPlayerError.FAILED_TO_PREPARE_MEDIA.toString());
        if (mListener != null) {
            mListener.onError(ADGPlayerError.FAILED_TO_PREPARE_MEDIA);
        }
    }

    @Override
    public void onBuffering(final int percent) {
        if (mListenerForManager != null) {
            mListenerForManager.onBuffering(percent, mVideoView); // 動画のバッファリング量の確認
        }
    }

    @Override
    public void onSeekTo(final int msec) {
        if (mListenerForManager != null) {
            mListenerForManager.onSeekTo(mVideoView); // 動画のシーク
        }
    }

    @Override
    public void onChangeAudioVolume(final boolean isOn) {
        if (mListener != null) {
            mListener.onChangeAudioVolume(isOn, mVideoView); // 動画の音量変更
        }
        if (mListenerForManager != null) {
            mListenerForManager.onChangeAudioVolume(isOn, mVideoView);
        }
    }

    /** 動画の再生時間を更新し、進捗状況に応じたイベントを発火します。 */
    private void onTimeUpdate() {
        if (mVideoView.isPlaying()) {
            float duration = (float) mVideoView.getDuration();
            float currentPosition = (float) mVideoView.getCurrentPosition();
            float percentile = currentPosition / duration;

            // プログレスバーを表示更新
            if (progressBar != null) {
                progressBar.setProgress(Math.round(percentile * 100));
            }

            if (mVastAd == null) {
                return;
            }
            mVastAd.setCurrentTime(currentPosition);

            VastEventState state = mVastAd.getVastEventState();
            if (state.compareTo(VastEventState.START) < 0 && currentPosition > 1000) {
                mVastAd.start();
                if (mListener != null) {
                    mListener.onStartVideo();
                }
            } else if (state == VastEventState.START && percentile > 0.25) {
                mVastAd.firstQuartile();
                if (mListenerForManager != null) {
                    mListenerForManager.onVideoTrackingEvent(
                            MeasurementConsts.mediaEvents.firstQuartile, mVideoView); // 動画25%まで再生
                }
            } else if (state == VastEventState.FIRST_QUARTILE && percentile > 0.5) {
                mVastAd.midpoint();
                if (mListenerForManager != null) {
                    mListenerForManager.onVideoTrackingEvent(
                            MeasurementConsts.mediaEvents.midpoint, mVideoView); // 動画50%まで再生
                }
            } else if (state == VastEventState.MIDPOINT && percentile > 0.75) {
                mVastAd.thirdQuartile();
                if (mListenerForManager != null) {
                    mListenerForManager.onVideoTrackingEvent(
                            MeasurementConsts.mediaEvents.thirdQuartile, mVideoView); // 動画75%まで再生
                }
            }
            if (state != VastEventState.COMPLETE) {
                // 初回再生時のみ（リプレイ時は発生させない
                mVastAd.progress((long) currentPosition, (int) (percentile * 100));
            }
        }
    }

    /* View Events */

    /** VAST広告に対してiマークViewを追加します。 */
    private void setVastInformationIconView() {
        if (mVastAd == null || mVastAd.getIcons().isEmpty()) {
            return;
        }
        VASTIcon icon = getIconWithSelectIndustry(mVastAd.getIcons());
        if (icon == null) {
            return;
        }

        VastInformationIconView vastInformationIconView;
        try {
            vastInformationIconView =
                    isWipe
                            ?
                            // wipeAdの場合は左上配置
                            new VastInformationIconView(
                                    mContext,
                                    icon,
                                    false,
                                    VastInformationIconView.Corner.TOP_LEFT,
                                    com.socdm.d.adgeneration.video.view.VastInformationIconView
                                            .BackgroundType.WHITE,
                                    isWipe)
                            :
                            // wipeAdじゃない場合はデフォルト右上配置
                            new VastInformationIconView(mContext, icon);
        } catch (VastInformationIconView.CannotInstantiateException e) {
            LogUtils.w("Failed to create InformationIconView");
            return;
        }

        if (isNativeOptout) {
            return;
        }
        addView(vastInformationIconView);
    }

    /**
     * apiFramework="adg" & IconURLが有効な場合は優先的に表示する apiFramework="adg" & IconURLが無効な場合は表示しない
     * apiFramework="adg"がない場合はclosestを表示する(一番最後のIconsの一番最初のIconを表示する)
     *
     * @param icons VAST内に含まれる<Icons>タグの要素リスト
     * @return VAST広告に表示するiマーク
     */
    @Nullable
    private VASTIcon getIconWithSelectIndustry(@NonNull final ArrayList<VASTIcon> icons) {
        // iconsの要素をすべてチェック
        for (VASTIcon icon : icons) {
            // 要素内に必須の値がないなら次のリストへ
            if (icon == null || icon.getStaticResource() == null) {
                continue;
            }
            // apiFramework="adg"かチェック
            if (icon.isAdg()) {
                // iマークの画像が有効なURLかチェック
                if (URLUtil.isValidUrl(icon.getStaticResource().getUrlString())) {
                    return icon;
                } else {
                    return null;
                }
            }
        }
        // Closest Iconの値チェック
        if (mVastAd == null) return null;

        VASTIcon closestIcon = mVastAd.getClosestIcon();
        if (closestIcon != null && closestIcon.getStaticResource() != null) {
            // iマークの画像が有効なURLかチェック
            if (URLUtil.isValidUrl(closestIcon.getStaticResource().getUrlString())) {
                return closestIcon;
            } else {
                return null;
            }
        }
        return null;
    }

    /** 動画の進捗状況を表示するプログレスバーを設定します。 */
    private void setVastProgressBarView() {
        progressBar = new ProgressBar(mContext, null, android.R.attr.progressBarStyleHorizontal);
        LayoutParams progressBarParams = new LayoutParams(LayoutParams.MATCH_PARENT, 30);
        progressBarParams.topMargin = -15;
        progressBarParams.bottomMargin = -15;
        progressBarParams.gravity = Gravity.BOTTOM;
        progressBar.setLayoutParams(progressBarParams);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.getProgressDrawable().setColorFilter(Color.RED, PorterDuff.Mode.SRC_IN);
        addView(progressBar);
    }

    /** プレイヤーが視認可能になったときに呼ばれます。 動画の再生を開始または再開します。 */
    void callWhenInView() {
        if (mVastAd != null) {
            mIsViewable = true;

            if (mVideoView.isInPlaybackState()) {
                // 準備完了済みなら即座に再生
                play();
                mWaitingForPlaybackWhenInView = false;
            } else {
                // 準備中の場合はフラグを立てて待機
                mWaitingForPlaybackWhenInView = true;
            }

            mVastAd.inView();
        }

        LogUtils.d("The VAST player is in view.");
    }

    /** プレイヤーが視認不可能になったときに呼ばれます。 動画の再生を一時停止します。 */
    void callWhenOutView() {
        if (mVastAd != null) {
            mIsViewable = false;
            // OutOfViewになったら待機フラグもクリア
            mWaitingForPlaybackWhenInView = false;
            pause();
            mVastAd.outView();
        }

        LogUtils.d("The VAST player is out of view.");
    }

    /** 動画の再生状況を定期的に処理します。 */
    private void process() {
        onTimeUpdate();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        LogUtils.d("called VastPlayer.onDetachedFromWindow()");
        videoLoop.stop();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        LogUtils.d(this + ": onWindowVisibilityChanged:" + (visibility == VISIBLE));
        super.onWindowVisibilityChanged(visibility);
        if (visibility == VISIBLE) {
            videoLoop.start();
        } else {
            videoLoop.stop();
            if (mIsViewable) {
                callWhenOutView();
            }
        }
    }

    /** 動画の再生状況を定期的にチェックするためのRunnableクラスです。 別スレッドで実行され、メインスレッドに更新処理を投稿します。 */
    private static class Runner implements Runnable {
        @Nullable private Thread thread = null;
        @Nullable private Handler handler = null;
        boolean running = false;

        @NonNull private final WeakReference<VastPlayer> mSelf;

        /**
         * Runnerのインスタンスを生成します。
         *
         * @param self VastPlayerの参照
         */
        public Runner(@NonNull final VastPlayer self) {
            this.mSelf = new WeakReference<>(self);
        }

        /** 定期処理を開始します。 */
        public void start() {
            if (thread == null) {
                thread = new Thread(this);
            }

            if (handler == null) {
                // 現在のスレッドのLooperを取得。nullの場合はメインLooperを使用
                Looper looper = Looper.myLooper();
                if (looper == null) {
                    looper = Looper.getMainLooper();
                }
                handler = new Handler(looper);
            }

            try {
                thread.start();
                running = true;
            } catch (IllegalThreadStateException ignore) {
                // nothing to do
            }
        }

        /** 定期処理を停止します。 */
        public void stop() {
            running = false;
            thread = null;
        }

        @Override
        public void run() {
            while (running) {
                final VastPlayer self = mSelf.get();
                if (self == null) {
                    stop();
                    return;
                }

                if (handler != null) {
                    handler.post(
                            new Runnable() {
                                @Override
                                public void run() {
                                    if (self == null) {
                                        return;
                                    }

                                    self.process();
                                }
                            });
                }

                try {
                    Thread.sleep(100);
                } catch (InterruptedException ignore) {
                    // nothing to do
                }
            }
        }
    }

    /** VASTメディアイベントリスナーインターフェース */
    public interface VastMediaEventListener {
        /** 動画の再生が開始されたときに呼ばれます */
        void onStartVideo();

        /**
         * 動画の準備が完了したときに呼ばれます
         *
         * @param videoView 動画再生View
         */
        void onPrepared(@NonNull final VideoView videoView);

        /**
         * 動画の再生中に呼ばれます
         *
         * @param videoView 動画再生View
         */
        void onPlaying(@NonNull final VideoView videoView);

        /**
         * 動画の再生が完了したときに呼ばれます
         *
         * @param videoView 動画再生View
         */
        void onCompletion(@NonNull final VideoView videoView);

        /**
         * エラーが発生したときに呼ばれます
         *
         * @param ADGPlayerError エラー情報
         */
        void onError(@NonNull final ADGPlayerError ADGPlayerError);

        /**
         * 音声のボリュームが変更されたときに呼ばれます
         *
         * @param isOn 音声がオンの場合true
         * @param videoView 動画再生View
         */
        void onChangeAudioVolume(final boolean isOn, @NonNull final VideoView videoView);
    }

    /** VASTメディアイベントリスナーインターフェース */
    public interface VastMediaEventListenerForManager {
        /**
         * 動画の読み込みイベント
         *
         * @param videoView 動画再生View
         */
        void onVideoLoadEvent(@NonNull final VideoView videoView);

        /**
         * 動画のトラッキングイベント
         *
         * @param event イベントタイプ
         * @param videoView 動画再生View
         */
        void onVideoTrackingEvent(
                @NonNull final MeasurementConsts.mediaEvents event,
                @NonNull final VideoView videoView);

        /**
         * バッファリング中に呼ばれます
         *
         * @param percent バッファリング進捗率
         * @param videoView 動画再生View
         */
        void onBuffering(final int percent, @NonNull final VideoView videoView);

        /**
         * シーク操作時に呼ばれます
         *
         * @param videoView 動画再生View
         */
        void onSeekTo(@NonNull final VideoView videoView);

        /**
         * エラーが発生したときに呼ばれます
         *
         * @param ADGPlayerError エラー情報
         */
        void onError(@NonNull final ADGPlayerError ADGPlayerError);

        /**
         * 音声のボリュームが変更されたときに呼ばれます
         *
         * @param isOn 音声がオンの場合true
         * @param videoView 動画再生View
         */
        void onChangeAudioVolume(final boolean isOn, @NonNull final VideoView videoView);
    }
}
