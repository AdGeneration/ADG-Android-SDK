package com.socdm.d.adgeneration.utils;

import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.ADGLogger;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class TrackerUtils {
    @Nullable private static String userAgent;

    public static void applyUserAgent(@NonNull final Context context) {
        if (userAgent == null || userAgent.isEmpty()) {
            userAgent = HttpUtils.getUserAgent(context);
        }
    }

    public static void callTracker(@Nullable final ArrayList<String> trackers) {
        if (trackers != null) {
            boolean uaValid = isUserAgentNotEmpty();
            if (uaValid) {
                for (String tracker : trackers) {
                    callTracker(tracker);
                }
            }
        }
    }

    public static void callTracker(@Nullable final String tracker) {
        if (tracker == null) {
            return;
        }

        final boolean uaValid = isUserAgentNotEmpty();
        if (!uaValid) {
            return;
        }

        final URL trackerURL;
        try {
            trackerURL = new URL(tracker);
        } catch (NullPointerException | IllegalArgumentException | MalformedURLException e) {
            ADGLogger.getDefault().error("Invalid tracker URL.", e);
            return;
        }

        ADGLogger.getDefault().debug("Send tracker: " + trackerURL);

        HttpURLConnectionTask requestTask =
                new HttpURLConnectionTask(
                        trackerURL.toString(),
                        new AsyncTaskListener<>() {
                            @Override
                            public void onSuccess(@Nullable String s) {
                                ADGLogger.getDefault()
                                        .debug("Sending tracker succeeded. " + trackerURL);
                            }

                            @Override
                            public void onError(@NonNull Exception e) {
                                ADGLogger.getDefault()
                                        .error("Sending tracker failed. " + trackerURL, e);
                            }
                        });
        requestTask.setUserAgent(userAgent);
        AsyncTaskUtils.execute(requestTask);
    }

    private static boolean isUserAgentNotEmpty() {
        if (TextUtils.isEmpty(userAgent)) {
            ADGLogger.getDefault().error("User Agent is null or empty.");
            return false;
        }
        return true;
    }
}
