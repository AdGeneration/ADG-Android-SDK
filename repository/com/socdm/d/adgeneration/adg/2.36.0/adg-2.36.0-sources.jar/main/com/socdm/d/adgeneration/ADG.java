package com.socdm.d.adgeneration;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.webkit.ConsoleMessage;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.ADGConsts.ADGErrorCode;
import com.socdm.d.adgeneration.ADGConsts.ADGHeaderBiddingParamKeys;
import com.socdm.d.adgeneration.Measurement.MeasurementConsts;
import com.socdm.d.adgeneration.Measurement.WebViewMeasurementManager;
import com.socdm.d.adgeneration.impression.ImpressionTracker;
import com.socdm.d.adgeneration.mediation.ADGNativeInterface;
import com.socdm.d.adgeneration.mediation.ADGNativeInterfaceListener;
import com.socdm.d.adgeneration.mediation.ADGNativeMediationModel;
import com.socdm.d.adgeneration.mediation.ADGNativeMediationView;
import com.socdm.d.adgeneration.mediation.MediationModel;
import com.socdm.d.adgeneration.mraid.MRAIDHandler;
import com.socdm.d.adgeneration.mraid.MRAIDHandlerResult;
import com.socdm.d.adgeneration.nativead.ADGInformationIconView;
import com.socdm.d.adgeneration.nativead.ADGMediaView;
import com.socdm.d.adgeneration.nativead.ADGNativeAd;
import com.socdm.d.adgeneration.nativead.ADGNativeAdOnClickListener;
import com.socdm.d.adgeneration.nativead.template.ADGNativeAdTemplateBase;
import com.socdm.d.adgeneration.nativead.template.ADGNativeAdTemplateFactory;
import com.socdm.d.adgeneration.observer.ADGMessage;
import com.socdm.d.adgeneration.observer.Observer;
import com.socdm.d.adgeneration.observer.Subject;
import com.socdm.d.adgeneration.utils.AssetUtils;
import com.socdm.d.adgeneration.utils.DisplayUtils;
import com.socdm.d.adgeneration.utils.JsonUtils;
import com.socdm.d.adgeneration.utils.TimerUtils;
import com.socdm.d.adgeneration.utils.TrackerUtils;
import com.socdm.d.adgeneration.viewable.Viewable;
import com.socdm.d.adgeneration.viewable.ViewableDisposableMeasurement;
import com.socdm.d.adgeneration.viewable.ViewableObstacleMeasurement;
import com.socdm.d.adgeneration.viewable.ViewableParameter;
import com.socdm.d.adgeneration.viewable.ViewableParameters;

import jp.supership.sscore.logger.SSCoreNoticeLogger;
import jp.supership.sscore.type.Optional;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;

public class ADG extends FrameLayout
        implements Subject, ADGController.Listener, ADGController.OnRotationTimerFireCallback {
    static {
        // NativeAdのとき、
        // ADGInformationIconViewは親Viewに対してMATCH_PARENTで追加される。
        // このとき、ADGInformationIconViewと同階層のADGMediaView(配下にAdView > VastPlayerがある)と
        // 重なって障害物として認識されてしまうため、除外する
        ViewableObstacleMeasurement.addObstacleViewNameToIgnore(
                ADGInformationIconView.class.getName());
    }

    @NonNull private final Context activityContext;
    @NonNull private final Handler mainHandler = new Handler(Looper.getMainLooper());
    @NonNull private final List<Observer> observers = new ArrayList<>();
    @NonNull private final AdWebViewController adWebViewController;
    @NonNull private Optional<MRAIDHandler> mraidHandler = Optional.empty();
    @NonNull private Optional<Viewable> viewableMeasurement = Optional.empty();
    @NonNull private Optional<Viewable> mraidViewableMeasurement = Optional.empty();
    @NonNull private Point adSize = new Point(AdFrameSize.SP.width, AdFrameSize.SP.height);
    private double adScale = 1.0;
    private boolean enableSound;
    private boolean enableTestMode;
    private boolean informationIconViewDefault = true;
    @Nullable private ADGResponse adResponse = null;
    private int adBackGroundColor = Color.TRANSPARENT;
    private boolean preventAccidentalClick = false;
    private boolean reloadWithVisibilityChanged = false;
    @Nullable private Timer noAdTimer = null;
    private boolean callNativeAdTrackers = true;
    @Nullable private ADGNativeInterface nif = null;
    @Nullable private ADGNativeMediationView nativeMediationView = null;
    private boolean waitShowing = false;
    private boolean divideShowing = false;
    @Nullable private View userView;
    private boolean usePartsResponse = false;
    private boolean expandFrame = false;
    private boolean isWipe = false;
    private boolean storageEnabled = false;

    /** OM SDK計測インスタンス */
    @NonNull
    private Optional<WebViewMeasurementManager> webViewMeasurementManager = Optional.empty();

    @Nullable private String contentUrl;
    @NonNull private final ADGController controller;
    @NonNull private final IADGLogger logger;
    @Nullable private ADGListener listener;

    @NonNull
    private final String VAST_MEDIATION_CLASS = "com.socdm.d.adgeneration.mediation.VASTMediation";

    public ADG(@NonNull Context activity) {
        super(activity);

        logger = ADGLogger.getInstance();
        adWebViewController = new AdWebViewController(activity, logger);
        controller = ADGController.newInstance(activity, logger);
        controller.listener = this;

        this.activityContext = activity;
        this.setBackgroundColor(this.adBackGroundColor);

        // MRAIDモードの初期設定
        setEnableMraidMode(true);

        TrackerUtils.applyUserAgent(activity);
    }

    @Nullable
    public String getLocationId() {
        return controller.getAdParams().getLocationId();
    }

    public void setLocationId(@Nullable String locationId) {
        controller.getAdParams().setLocationId(locationId);
    }

    @Deprecated
    public void setFillerLimit(int fillerLimit) {
        controller.getAdParams().setFillerLimit(fillerLimit);
    }

    public boolean isEnableSound() {
        return enableSound;
    }

    public void setEnableSound(boolean enableSound) {
        this.enableSound = enableSound;
        logger.getLogger().debug("enableSound = " + this.enableSound);
    }

    /** 代わりに {@link #isTestModeEnabled} メソッドを使用してください。 */
    @Deprecated
    public boolean isEnableTestMode() {
        SSCoreNoticeLogger.notice(
                "ADG#isEnableTestMode() method is deprecated. Use ADG#isTestModeEnabled() method"
                        + " instead.");
        return enableTestMode;
    }

    /** 代わりに {@link #setTestModeEnabled} メソッドを使用してください。 */
    @Deprecated
    public void setEnableTestMode(boolean enableTestMode) {
        SSCoreNoticeLogger.notice(
                "ADG#setEnableTestMode method is deprecated. Use ADG#setTestModeEnabled method and"
                        + " ADGSettings.setDebugLogging method instead.");

        this.enableTestMode = enableTestMode;

        // TODO: ADGSettings.setDebugLoggingメソッドに完全移行する
        // ADGSettings.setDebugLogging(true)を設定済ならば、ここで設定の上書きをしない
        // 未設定ならば、旧API仕様と互換性を保つために以下のコードを実行する
        if (!ADGSettings.isDebugLogging()) {
            ADGSettings.setDebugLogging(enableTestMode);
        }

        logger.getLogger().debug("enableTestMode = " + this.enableTestMode);
    }

    /**
     * テストモードが有効かどうかを返します。
     *
     * @return テストモードが有効な場合はtrue、そうでない場合はfalse
     */
    public boolean isTestModeEnabled() {
        return enableTestMode;
    }

    /**
     * trueを指定した場合、テストモードが有効になります。テストモードのままリリースしないようにご注意ください。 配信する広告によっては収益が発生しない場合があります。
     *
     * @param enabled テストモードを有効にする場合はtrue、そうでない場合はfalse
     */
    public void setTestModeEnabled(final boolean enabled) {
        enableTestMode = enabled;
        logger.getLogger().debug("testModeEnabled = " + enableTestMode);
    }

    /** Mraid使用のVersionを満たした時のみisMRAIDEnabledにtrueが入る */
    public void setEnableMraidMode(final boolean enabled) {
        controller.getAdParams().setMraidEnabled(enabled && canUseMraid());
        logger.getLogger().debug("isMraidEnabled = " + controller.getAdParams().isMraidEnabled());
    }

    public void setInformationIconViewDefault(boolean informationIconViewDefault) {
        this.informationIconViewDefault = informationIconViewDefault;
        logger.getLogger().debug("informationIconViewDefault = " + this.informationIconViewDefault);
    }

    @Nullable
    public ADGListener getAdListener() {
        return listener;
    }

    public void setAdListener(@Nullable final ADGListener listener) {
        this.listener = listener;
    }

    public void setAdBackGroundColor(final int color) {
        adBackGroundColor = color;
        setBackgroundColor(adBackGroundColor);
        adWebViewController.setBackgroundColor(adBackGroundColor);
    }

    @Deprecated
    public void setPreLoad(boolean preLoad) {}

    @Deprecated
    public void stopAutomaticLoad() {
        setReloadWithVisibilityChanged(false);
    }

    public void setAdFrameSize(@NonNull final AdFrameSize adFrameSize) {
        logger.getLogger()
                .debug(
                        "adFrameSize.width = "
                                + adFrameSize.width
                                + " / adFrameSize.height = "
                                + adFrameSize.height);
        adSize = new Point(adFrameSize.width, adFrameSize.height);
        updateView();
    }

    public void setAdScale(double scale) {
        logger.getLogger().debug("scale = " + scale);
        this.adScale = scale;
        this.updateView();
    }

    public void setPreventAccidentalClick(boolean preventAccidentalClick) {
        this.preventAccidentalClick = preventAccidentalClick;
    }

    public void setReloadWithVisibilityChanged(boolean reloadWithVisibilityChanged) {
        this.reloadWithVisibilityChanged = reloadWithVisibilityChanged;
    }

    @Deprecated
    public void setFillerRetry(boolean retry) {}

    public void disableCallingNativeAdTrackers() {
        callNativeAdTrackers = false;
    }

    @Deprecated
    @NonNull
    public String getBeacon() {
        return "";
    }

    public void setDivideShowing(final boolean divide) {
        divideShowing = divide;
    }

    @Deprecated
    public void setDatabasePath(@Nullable final String databasePath) {
        // WebSettings#setDatabasePath is deprecated in API level 19
    }

    public void setStorageEnabled(final boolean storageEnabled) {
        this.storageEnabled = storageEnabled;
    }

    public void setUsePartsResponse(final boolean usePartsResponse) {
        this.usePartsResponse = usePartsResponse;
        logger.getLogger().debug("usePartsResponse = " + this.usePartsResponse);
    }

    public void setExpandFrame(final boolean expandFrame) {
        this.expandFrame = expandFrame;
    }

    public void setIsWipe(final boolean isWipe) {
        this.isWipe = isWipe;
        logger.getLogger().debug("isWipe = " + this.isWipe);
    }

    public void setContentUrl(@Nullable final String url) {
        this.contentUrl = url;
    }

    public void updateView() {
        Point p = calcAdSize(adSize);
        LayoutParams lp = new LayoutParams(p.x, p.y);

        adWebViewController.updateViewSize(p.x, p.y, adScale);

        // インバナーネイティブテンプレートもサイズを変更する
        // setAdScaleとsetAdFrameでサイズ変更したときに、表示中のWebViewバナーは変更されるが、
        // インバナーネイティブテンプレートは変更されなかったので、ここで一緒にサイズ変更する
        for (int i = 0; i < this.getChildCount(); i++) {
            View child = this.getChildAt(i);
            if (child instanceof ADGNativeAdTemplateBase) {
                child.setLayoutParams(lp);
            }
        }
    }

    /**
     * 広告リクエストのレスポンス情報を取得します。
     *
     * @return レスポンス情報
     */
    @Nullable
    public ADGResponseInfo getResponseInfo() {
        if (adResponse != null) {
            return new ResponseInfoBuilder()
                    .withAdId(adResponse.getMediationAdId())
                    .withClassName(adResponse.getMediationClassName())
                    .withCreativeId(adResponse.getCreativeId())
                    .withAdNetworkId(adResponse.getAdNetworkId())
                    .withDspId(adResponse.getDspId())
                    .withSeat(adResponse.getSeat())
                    .build();
        }

        return null;
    }

    @NonNull
    private Point calcAdSize(@NonNull final Point size) {
        return new Point(px(size.x), px(size.y));
    }

    @NonNull
    private Optional<WebView> prepareAd() {
        final boolean isSuccess =
                adWebViewController.prepareWebView(
                        this,
                        adSize,
                        storageEnabled,
                        new ADGWebViewClient(),
                        new ADGWebChromeClient());

        if (!isSuccess) {
            return Optional.empty();
        }

        final Optional<WebView> webView = adWebViewController.getWebView();
        webView.ifPresent(
                view -> {
                    mraidHandler = Optional.of(new MRAIDHandler(activityContext));
                    mraidHandler.ifPresent(
                            m -> {
                                m.setWebView(view);
                            });
                });

        return webView;
    }

    private int px(int dipValue) {
        return DisplayUtils.getPixels(getResources(), dipValue);
    }

    public enum AdFrameSize {
        SP(320, 50),
        TABLET(728, 90),
        LARGE(320, 100),
        RECT(300, 250),
        FREE(0, 0);

        private int width;
        private int height;

        private AdFrameSize(int width, int height) {
            this.width = width;
            this.height = height;
        }

        public int getWidth() {
            return this.width;
        }

        public int getHeight() {
            return this.height;
        }

        @NonNull
        public AdFrameSize setSize(int width, int height) {
            if (name().equals("FREE")) {
                this.width = width;
                this.height = height;
            }
            return this;
        }
    }

    /** 広告のロードを開始します。ロードに成功した場合、広告が表示されます。Activity#onResume()で呼び出してください。 */
    public void start() {
        logger.getLogger().debug("ADG is starting.");
        controller.isWorking = true;

        if (nif != null && isWipe) {
            nif.startChild();
        } else {
            startAd();
        }
    }

    private void startAd() {
        // 2.2.4までAdTruth経由で呼ばれていたときは必ずMainThread上だったため、ここでも同様としている。
        // 不要にも思えるが、どう呼ばれるかわからないため、このままの方が無難？
        mainHandler.post(
                () -> {
                    finishMediation();
                    pauseRefresh();
                    removeUserView();
                    controller.cancelRequest();
                    loadRequest();
                });
    }

    @Deprecated
    public void resumeRefreshTimer() {
        SSCoreNoticeLogger.notice(
                "ADG#resumeRefreshTimer() method is deprecated. Use ADG#start() method instead.");
        start();
    }

    /** viewable処理、タイマー処理を再開します */
    public void resumeRefresh() {

        // rotationタイマーの再開
        controller.resumeRotationTimer();
        // 有効期限タイマーの再開
        controller.resumeExpirationTimer();

        restartViewable();

        startMraidViewable();

        if (adResponse != null && adResponse.getNativeAd().isPresent()) {
            adResponse.getNativeAd().ifPresent(ADGNativeAd::startViewable);
        }

        if (this.nativeMediationView != null) {
            this.nativeMediationView.startViewable();
        }

        // メディエーションタイマー
        if (this.nif != null) {
            this.nif.resumeMediationTimer();
        }
    }

    /** viewable処理、タイマー処理を一時停止します */
    public void pauseRefresh() {
        // rotationタイマーの一時停止
        controller.pauseRotationTimer();
        // 有効期限タイマーの一時停止
        controller.pauseExpirationTimer();

        stopAllViewable();

        // メディエーションタイマー
        if (this.nif != null) {
            this.nif.pauseMediationTimer();
        }
    }

    public void addHeaderBiddingParamsWithAmznAdResponse(@Nullable Object adResponse) {
        if (adResponse == null) return;
        if (!adResponse.getClass().getName().equals("com.amazon.device.ads.DTBAdResponse")) {
            return;
        }
        try {
            String bidId = (String) adResponse.getClass().getMethod("getBidId").invoke(adResponse);
            String host = (String) adResponse.getClass().getMethod("getHost").invoke(adResponse);
            String slots =
                    (String)
                            adResponse
                                    .getClass()
                                    .getMethod("getDefaultPricePoints")
                                    .invoke(adResponse);
            logger.getLogger().debug("bidId=" + bidId + ",host=" + host + ",slots=" + slots);
            addHeaderBiddingParam(ADGHeaderBiddingParamKeys.AMZN_BIDID, bidId);
            addHeaderBiddingParam(ADGHeaderBiddingParamKeys.AMZN_HOSTNAME, host);
            addHeaderBiddingParam(ADGHeaderBiddingParamKeys.AMZN_SLOTS, slots);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            logger.getLogger()
                    .error("Failed to add header bidding params with Amazon ad response", e);
        }
    }

    public void addHeaderBiddingParam(
            @NonNull final ADGHeaderBiddingParamKeys key, @Nullable String value) {
        controller.getAdParams().headerBiddingParams.setKeyValue(key.toString(), value);
        setEnableMraidMode(true);
    }

    public void addRequestOptionParam(@Nullable String key, @Nullable String value) {
        controller.getAdParams().headerBiddingParams.setKeyValue(key, value);
    }

    /**
     * Ad Generationのリクエストパラメータにラベルターゲティング用のKey/Valueを追加する
     *
     * @param key ターゲティングのKey
     * @param value ターゲティングのValue
     */
    public void insertADGLabelTargetingWithCustomKey(
            @Nullable final String key, @Nullable final String value) {
        controller.getAdParams().labelTargeting.addKeyValue(key, value);
    }

    /**
     * 現在Ad Generationに指定されているラベルターゲティング用のパラメータから指定されたKeyのパラメータを削除する
     *
     * @param key 削除対象のKey
     */
    public void removeADGLabelTargetingWithCustomKey(@Nullable final String key) {
        controller.getAdParams().labelTargeting.removeKeyValue(key);
    }

    /**
     * 設定されているラベルターゲティング用のKey/Valueを返却します。該当するパラメータが存在しない場合はnullを返却します
     *
     * @return 設定されているラベルターゲティング用のKey/Value
     */
    @Nullable
    public Map<String, String> getADGLabelTargetingWithCustomKeyValues() {
        final Map<String, String> map = controller.getAdParams().labelTargeting.toMap();
        return map.isEmpty() ? null : map;
    }

    private void loadRequest() {
        logger.getLogger().debug("Start loading an ad.");
        controller.requestAd(
                result -> {
                    result.data.ifPresentOrElse(
                            adResponse -> {
                                this.adResponse = adResponse;
                                onSuccessAdResponse(adResponse);
                            },
                            () -> {
                                adResponse = null;
                                controller.dispatchFailedToReceiveAdEvent(
                                        result.error.forced(), null);
                            });
                });
    }

    private void onSuccessAdResponse(@NonNull final ADGResponse adResponse) {
        if (adResponse.isInvalidResponse() || adResponse.isNoAd()) {
            if (adResponse.isInvalidResponse()) {
                logger.getLogger().debug("Received invalid response.");
            } else {
                logger.getLogger().debug("Received NoAd.");
            }
            controller.dispatchFailedToReceiveAdEvent(ADGErrorCode.NO_AD, null);
            return;
        }

        final Optional<ADGNativeAd> nativeAdOpt = adResponse.getNativeAd();
        boolean isIncludedTemplate =
                controller.adModel.flatMap(AdBridgingObject::getIncludedTemplate).orElse(false);

        if (nativeAdOpt.isPresent() && isIncludedTemplate) {
            if (!controller.isWorking) {
                logger.getLogger().debug("Received an ad response but ADG was already stopped.");
                controller.dispatchFailedToReceiveAdEvent(ADGErrorCode.COMMUNICATION_ERROR, null);
                return;
            }
            logger.getLogger().debug("Received a native ad template.");

            final ADGNativeAd nativeAd = nativeAdOpt.forced();

            // OM SDKの初期化
            nativeAd.initNativeDisplayMeasurement(activityContext);
            ADGNativeAdTemplateBase template =
                    ADGNativeAdTemplateFactory.createTemplate(activityContext, adSize);
            if (template == null || !template.apply(nativeAd)) {
                logger.getLogger().error("Failed to create the native ad template.");
                controller.getAdParams().addErrorScheduleId(adResponse.getScheduleId());
                controller.dispatchFailedToReceiveAdEvent(ADGErrorCode.TEMPLATE_FAILED, null);
                return;
            }

            // アプリの実装によってはMATCH_PARENTxMATCH_PARENTとしてしまうと、
            // 親の領域が大きくとっている場合は広がってしまうので、WebViewバナーと揃えるため固定値にしている
            addView(template, new LayoutParams(px(adSize.x), px(adSize.y)));
            template.setListener(() -> controller.dispatchClickedAdEvent(null));

            controller.sendWinNotificationBeacons();
            if (callNativeAdTrackers) {
                controller.sendLoadTriggerEvents();
                nativeAd.callJstracker(activityContext);
            }
            setAutomaticallyRemoveOnReload(template);
            setRotationTimerForNativeAd(adResponse, true);
            controller.dispatchReceivedAdEvent(null);
        } else if (nativeAdOpt.isPresent() && usePartsResponse) {
            logger.getLogger().debug("Received a native ad response.");
            adWebViewController.hideWebView();
            final ADGNativeAd nativeAd = nativeAdOpt.forced();
            nativeAd.setInformationIconViewDefault(informationIconViewDefault);

            controller.sendWinNotificationBeacons();
            if (callNativeAdTrackers) {
                controller.sendLoadTriggerEvents();
                nativeAd.callJstracker(activityContext);
            }
            // OM SDKの初期化
            nativeAd.initNativeDisplayMeasurement(activityContext);
            controller.dispatchReceivedMediationNativeAdEvent(nativeAd, null);
            setRotationTimerForNativeAd(adResponse, false);
        } else if (!TextUtils.isEmpty(adResponse.getVastxml())) {
            logger.getLogger().debug("Received a VAST ad response.");
            String vastxml = JsonUtils.toJsonStr(adResponse.getVastxml());
            String param = String.format("{vast:\"%s\"}", vastxml);
            int movie = 1;
            startMediation(
                    adResponse, VAST_MEDIATION_CLASS, adResponse.getMediationAdId(), param, movie);
        } else if (adResponse.isMediation()) {
            logger.getLogger().debug("Received a mediation ad response.");
            if (ADGNativeInterface.isValidClassName(adResponse.getMediationClassName())) {
                startMediation(
                        adResponse,
                        adResponse.getMediationClassName(),
                        adResponse.getMediationAdId(),
                        adResponse.getMediationParam(),
                        adResponse.getMediationMovie());
            } else {
                controller.getAdParams().addErrorScheduleId(adResponse.getScheduleId());
                stopProcess();
                if (ADGNativeInterface.isNormalCondition()) {
                    logger.getLogger().error("Error of normal condition.");
                    controller.dispatchFailedToReceiveAdEvent(
                            ADGErrorCode.COMMUNICATION_ERROR, null);
                }
            }
        } else { // webView
            logger.getLogger().debug("Received a WebView ad response.");

            final Optional<WebView> adWebView = prepareAd();

            if (adWebView.isEmpty()) {
                logger.getLogger().error("Webview isn't created.");
                controller.dispatchFailedToReceiveAdEvent(ADGErrorCode.UNKNOWN, null);
                // FIXME: returnしていいのでは
            } else {
                logger.getLogger().debug("Prepared WebView.");
            }

            updateView();
            controller.getAdParams().clearErrorScheduleIds();
            String html = adResponse.getAd();
            if (controller.getAdParams().isMraidEnabled()) {
                html = MRAIDHandler.injectMRAIDScriptTag(html);
            }
            // OM SDKの計測用インスタンスがすでに生成済みなら一旦Finishする
            finishOMWebViewViewability();
            // OM計測用インスタンスを生成
            logger.getLogger().debug("Create OM viewability.");
            webViewMeasurementManager = Optional.of(new WebViewMeasurementManager(activityContext));
            // OM計測タグをhtmlに挿入
            html = webViewMeasurementManager.forced().injectWebViewMeasurementTag(html);
            // HTMLの読み込み
            logger.getDevelopmentLogger().debug(html);
            if (adWebView.isPresent()) {
                adWebView
                        .forced()
                        .loadDataWithBaseURL(
                                ADGConsts.getWebViewBaseUrl(),
                                html,
                                "text/html",
                                "UTF-8",
                                ADGConsts.getWebViewBaseUrl());
            }
        }
    }

    private class ADGWebViewClientBase extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(final WebView view, final String url) {
            stopWebViewLoading(view);
            if (!view.equals(adWebViewController.getWebView().maybe())) {
                view.destroy();
            }
            if (URLUtil.isValidUrl(url)
                    || (controller.getAdParams().isMraidEnabled() && !TextUtils.isEmpty(url))) {
                if (preventAccidentalClick) {
                    AlertDialog.Builder dialog = new AlertDialog.Builder(activityContext);
                    dialog.setTitle("リンク先に遷移する");
                    dialog.setPositiveButton("OK", (d, which) -> onClickAd(view, url));
                    dialog.setNegativeButton("Cancel", (d, which) -> d.cancel());
                    dialog.setCancelable(true);
                    dialog.show();
                } else {
                    onClickAd(view, url);
                }
            }
            return true;
        }

        private void onClickAd(@NonNull final WebView view, @NonNull final String url) {
            controller.dispatchClickedAdEvent(null);
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                activityContext.startActivity(intent);
                adWebViewController.destroyWebView(ADG.this);
            } catch (ActivityNotFoundException e) {
                logger.getLogger().error("Failed to start activity.", e);
            }
        }
    }

    private class ADGWebViewClient extends ADGWebViewClientBase {
        // This flag is used to avoid that onPageFinished is called many times.
        boolean isLoading = false;

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            logger.getLogger().debug("called shouldOverrideUrlLoading:" + url);
            if (controller.getAdParams().isMraidEnabled() && mraidHandler.isPresent()) {
                final MRAIDHandlerResult mraidHandlerResult =
                        mraidHandler.forced().handleUrlLoading(url);
                if (!mraidHandlerResult.getShouldLoadRequest()) {
                    logger.getLogger().debug("stop URL loading");
                    return true;
                } else if (mraidHandlerResult.getOpenURL() != null) {
                    final Uri openURL = mraidHandlerResult.getOpenURL();
                    return super.shouldOverrideUrlLoading(view, openURL.toString());
                }
            }
            if (view.getHitTestResult() != null && view.getHitTestResult().getType() > 0) {
                return super.shouldOverrideUrlLoading(view, url);
            } else {
                return false;
            }
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            isLoading = true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (nif != null) return;
            if (adResponse == null) return;
            if (adResponse.getNativeAd().isPresent() && usePartsResponse) return;
            if (isLoading) {
                isLoading = false;
                setRotationTimer(adResponse);

                if (url.contains(ADGConsts.getWebViewBaseUrl())) {
                    if (controller.getAdParams().isMraidEnabled()) {
                        mraidHandler.ifPresent(
                                mraid -> {
                                    mraid.initializeState();
                                    startMraidViewable();
                                });
                    }
                    controller.sendWinNotificationBeacons();
                    controller.sendLoadTriggerEvents();
                    startViewable("HTMLDisplay", view, adResponse);
                    final WebView wv = view;
                    mainHandler.post(
                            () -> {
                                if (wv.getVisibility() != VISIBLE) {
                                    logger.getLogger().debug("WebView.setVisibility(VISIBLE)");
                                    wv.setVisibility(VISIBLE);
                                }

                                updateView();
                                controller.dispatchReceivedAdEvent(null);
                            });

                    // 計測スタート
                    if (controller.isWorking) {
                        webViewMeasurementManager.ifPresent(
                                manager -> {
                                    boolean isMeasured = manager.startMeasurement(view);
                                    if (isMeasured) {
                                        // アドセッションが正常に生成できていればloaded&impイベントを通知
                                        manager.sendWebViewEvent(
                                                MeasurementConsts.webViewEvent.loaded);
                                        manager.sendWebViewEvent(
                                                MeasurementConsts.webViewEvent.impression);
                                    }
                                });
                    }

                    sendMessage(new ADGMessage("AdViewType", "ADG"));
                } else {
                    logger.getLogger().error("Ad creative error.");
                    controller.dispatchFailedToReceiveAdEvent(
                            ADGErrorCode.COMMUNICATION_ERROR, null);
                }
            }
        }

        @Override
        public void onReceivedError(
                WebView view, int errorCode, String description, String failingUrl) {
            /*
             * 以前はアドサーバーのページを表示していたが、
             * 現在のアドサーバーがJSONを返すようになってからはこのメソッドが呼ばれることは基本的にはない。
             * また、API level 23からdeprecatedになっている。
             * https://developer.android.com/reference/android/webkit/WebViewClient.html#onReceivedError(android.webkit.WebView, int, java.lang.String, java.lang.String)
             * */
            if (nif != null) return;
            if (adResponse != null && adResponse.getNativeAd().isPresent() && usePartsResponse)
                return;

            logger.getLogger()
                    .debug(
                            "WebView received error."
                                    + " errorCode="
                                    + errorCode
                                    + ", description="
                                    + description
                                    + ", failingUrl="
                                    + failingUrl);
            controller.dispatchFailedToReceiveAdEvent(ADGErrorCode.COMMUNICATION_ERROR, null);
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
            if (controller.getAdParams().isMraidEnabled()
                    && MRAIDHandler.matchesInjectionUrl(url)) {
                return MRAIDHandler.createMRAIDInjectionResponse(activityContext);
            }
            return super.shouldInterceptRequest(view, url);
        }

        @TargetApi(Build.VERSION_CODES.LOLLIPOP)
        @Override
        public WebResourceResponse shouldInterceptRequest(
                WebView view, WebResourceRequest request) {
            if (controller.getAdParams().isMraidEnabled()
                    && MRAIDHandler.matchesInjectionUrl(request.getUrl().toString())) {
                return MRAIDHandler.createMRAIDInjectionResponse(activityContext);
            }
            return super.shouldInterceptRequest(view, request);
        }

        @TargetApi(Build.VERSION_CODES.O)
        @Override
        public boolean onRenderProcessGone(
                @Nullable final WebView view, @Nullable final RenderProcessGoneDetail detail) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    && adWebViewController.getWebView().maybe() == view) {
                if (detail == null || !detail.didCrash()) {
                    logger.getLogger()
                            .error("Render process is gone for this WebView. Unspecified cause.");
                } else {
                    logger.getLogger().error("Render process for this WebView has crashed.");
                }

                adWebViewController.destroyWebView(ADG.this);

                return true;
            } else {
                return super.onRenderProcessGone(view, detail);
            }
        }
    }

    private class ADGWebChromeClient extends WebChromeClient {
        @Override
        public boolean onCreateWindow(
                @NonNull WebView view,
                boolean isDialog,
                boolean isUserGesture,
                @NonNull Message resultMsg) {
            WebView newWebView = new WebView(view.getContext());
            newWebView.setWebViewClient(new ADGWebViewClientBase());
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(newWebView);
            resultMsg.sendToTarget();
            return true;
        }

        @SuppressLint("NewApi")
        @Override
        public boolean onConsoleMessage(@NonNull final ConsoleMessage cm) {
            logger.getLogger()
                    .debug(
                            cm.message()
                                    + " -- From line "
                                    + cm.lineNumber()
                                    + " of "
                                    + cm.sourceId());
            return true;
        }
    }

    private void setRotationTimer(@Nullable final ADGResponse adResponse) {
        final long rotationTime = adResponse != null ? adResponse.getRotationTime() : 0;
        logger.getLogger().debug("Set rotation timer: " + rotationTime);
        controller.setRotationTimer(rotationTime, this);
    }

    private void setRotationTimerForNativeAd(
            @Nullable final ADGResponse adResponse, final boolean visibleOnly) {
        if (visibleOnly && !this.isShown()) {
            return;
        }
        setRotationTimer(adResponse);
    }

    private void stopWebViewLoading(@NonNull final WebView webView) {
        logger.getLogger().debug("Stop webView loading.");

        try {
            webView.stopLoading();
        } catch (Exception e) {
            logger.getLogger().error("Failed to stop webView loading.", e);
        }
    }

    /** 広告を破棄します。Activity#onPause()で呼び出してください。 */
    public void stop() {
        logger.getLogger().debug("ADG is stopping.");
        controller.isWorking = false;

        stopProcess();
    }

    // 停止処理を実行するが、isWorkingフラグをfalseにしない
    private void stopProcess() {
        if (nif != null) {
            nif.stopChild();
        }

        TimerUtils.stopTimer(noAdTimer);
        noAdTimer = null;

        // アプリがバックグラウンドに遷移した場合、Viewability計測を停止しないとタスクが継続し、
        // Viewabilityのログが無限に出続けてしまう。その結果、ANRを引き起こす原因にもなる
        pauseRefresh();
        finishOMWebViewViewability();

        // 広告リクエスト中の場合、キャンセルしないと正常系レスポンスのあと、
        // WebViewのロードを開始し、ロード完了時にViewability計測を再生成し開始してしまう
        controller.cancelRequest();
        // 上記理由により、WebViewのロード中の場合、ロードを停止する
        // -> webView.stopLoadingを呼ぶと、OM計測のsessionFinishイベントが送信されないため、ここでは実行しないように修正
        // adWebView.ifPresent(this::stopWebViewLoading);

        // リクエストをキャンセルし、onReceiveAd(nativeAd)が呼ばれないようにしてから
        // ネイティブ広告のViewability計測の停止などをする
        controller.stopNativeAds();

        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child instanceof ADGNativeAdTemplateBase) {
                ((ADGNativeAdTemplateBase) child).destroy();
            }
        }

        finishMediation();

        removeUserView();
    }

    @Deprecated
    public void pause() {
        SSCoreNoticeLogger.notice(
                "ADG#pause() method is deprecated. Use ADG#stop() method instead.");
        stop();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);

        logger.getLogger()
                .debug(
                        "ADG("
                                + this
                                + ") window visibility changed: "
                                + visibility
                                + " "
                                + getVisibility()
                                + " visible="
                                + (visibility == View.VISIBLE));

        if (reloadWithVisibilityChanged) {
            // FIXME: getVisibility()の比較は不要と思われる
            if (getVisibility() == View.VISIBLE && visibility == View.VISIBLE) {
                if (adWebViewController.getWebView().isPresent() && nif == null) {
                    if (adResponse != null && adResponse.getRotationTime() > 0) {
                        setRotationTimer(adResponse);
                    } else {
                        startAd();
                    }
                } else {
                    start();
                }
            } else {
                // TODO: WindowVisibilityChanged内のコード消したい

                // NativeAdのパーツ返し対応のタイミングで実装
                // WindowVisibilityChangedのタイミングでstop内のremoveUserViewが呼ばれると
                // イベントが伝搬していく過程でremoveされたViewがNPEになってしまうのでタイミングをずらす
                mainHandler.postDelayed(this::stop, 300);
            }
        }
    }

    // mediation method

    public void setWaitShowing() {
        waitShowing = true;
        finishMediation();
    }

    public void show() {
        if (!isWipe) {
            return;
        }
        logger.getLogger().debug("ADG is showing.");
        waitShowing = false;

        if (nif != null) {
            nif.startChild();
        } else {
            if (controller.getAdParams().isMraidEnabled()) {
                mraidHandler.ifPresent(m -> m.setIsViewable(true));
            }
        }
    }

    public void dismiss() {
        if (!isWipe) return;
        logger.getLogger().debug("ADG is dismissing.");

        stop();

        adWebViewController.destroyWebView(this);
    }

    @Deprecated
    public void addMediationNativeAdView(@Nullable View mediationNativeAdView) {
        if (mediationNativeAdView == null) {
            return;
        }

        removeUserView();

        View viewToAdd = getNativeMediationView(mediationNativeAdView);

        Point p = calcAdSize(adSize);
        LayoutParams lp = new LayoutParams(p.x, p.y);
        viewToAdd.setLayoutParams(lp);
        this.addView(viewToAdd);
        setAutomaticallyRemoveOnReload(viewToAdd);
    }

    /**
     * ネイティブ広告配置時に、ネイティブ広告のViewをADGのライフサイクルで管理します。 ネイティブ広告のクリックやローテーションの制御に必要となります。
     * ADGNativeAd以外のネイティブ広告を配置する場合に使用します。
     *
     * @param view ネイティブ広告を配置しているView
     */
    @Deprecated
    public void delegateViewManagement(@NonNull View view) {
        logger.getLogger()
                .warn(
                        "ADG#delegateViewManagement method is deprecated. Use"
                            + " ADGNativeAd#setClickEvent(Context,View,ADGNativeAdOnClickListener)"
                            + " method and ADG#setAutomaticallyRemoveOnReload method instead.");

        if (this.userView != null) {
            logger.getLogger()
                    .debug(
                            "delegateViewManagement: The ad view transition will not be applied for"
                                    + " the new view, because click view has already been set.");
            return;
        }
        this.userView = view;
        if (adResponse != null && adResponse.getNativeAd().isPresent()) {
            adResponse
                    .getNativeAd()
                    .forced()
                    .setClickEvent(
                            this.activityContext,
                            view,
                            new ADGNativeAdOnClickListener() {
                                @Override
                                public void onClickAd() {
                                    controller.dispatchClickedAdEvent(null);
                                }
                            });
        }
    }

    /**
     * ネイティブ広告配置時に、ネイティブ広告のViewをADGのライフサイクルで管理します。 ネイティブ広告のクリックやローテーションの制御に必要となります。
     * ADGNativeAdのネイティブ広告を配置する場合に使用します。
     *
     * @param view ネイティブ広告を配置しているView(タップ領域となります)
     * @param adgNativeAd ADGNativeAdのインスタンス
     */
    @Deprecated
    public void delegateViewManagement(@NonNull View view, @Nullable ADGNativeAd adgNativeAd) {
        logger.getLogger()
                .warn(
                        "ADG#delegateViewManagement method is deprecated. Use"
                            + " ADGNativeAd#setClickEvent(Context,View,ADGNativeAdOnClickListener)"
                            + " method and ADG#setAutomaticallyRemoveOnReload method instead.");

        if (this.userView != null) {
            logger.getLogger()
                    .debug(
                            "delegateViewManagement: The ad view transition will not be applied for"
                                    + " the new view, because click view has already been set.");
            return;
        }
        this.userView = view;
        if (adgNativeAd != null) {
            adgNativeAd.setClickEvent(
                    this.activityContext,
                    view,
                    new ADGNativeAdOnClickListener() {
                        @Override
                        public void onClickAd() {
                            controller.dispatchClickedAdEvent(null);
                        }
                    });
            if (this.informationIconViewDefault) {
                addInformationIconView(view, adgNativeAd);
            }
        } else {
            this.delegateViewManagement(view);
        }
    }

    public void setAutomaticallyRemoveOnReload(@Nullable View view) {
        this.userView = view;
    }

    @NonNull
    public View getNativeMediationView(@NonNull final View view) {
        if (!controller.isWorking) {
            logger.getLogger().warn("ADG has been stopped.");
            return view;
        }
        if (adResponse != null) {
            // 新しいADGNativeMediationModelを使用
            final AdBridgingObject adObject = adResponse.getAdBridgingObject();
            final ADGNativeMediationModel model = new ADGNativeMediationModel(adObject);

            // インプレッショントラッカーがある場合のみメディエーションViewを作成
            if (model.hasImpressionTracker()) {
                logger.getLogger().debug("Set native mediation View with new model.");

                // ADGNativeMediationView.configureNativeMediationViewを使用してViewをラップ
                this.nativeMediationView =
                        ADGNativeMediationView.configureNativeMediationView(
                                view, model, controller);

                return this.nativeMediationView;
            } else {
                logger.getLogger().warn("No impression tracker available for mediation view.");
                return view;
            }
        } else {
            // ADGNativeAdにtrackerViewableImpが渡されている場合、ADGResponse#getTrackerViewableImp()はnullを返す
            // (ADGNativeAdにtrackerViewableImpを渡すときにADGResponseAdObjectのtrackerViewableImpはnullにリセットされている)
            logger.getLogger()
                    .warn(
                            "Viewable tracker URL is not exist. If this method is called for an ad"
                                    + " in the ADGNativeAd class, please do not call it.");
            return view;
        }
    }

    /** インフォメーションアイコンを追加する. 既にアイコンが追加されている場合は削除してから追加する. */
    private void addInformationIconView(@NonNull View view, @NonNull ADGNativeAd adgNativeAd) {
        removeADGInformationIconView(view);
        if (ViewGroup.class.isAssignableFrom(view.getClass())) {
            ViewGroup viewGroup = (ViewGroup) view;
            ADGInformationIconView informationIconView =
                    ADGInformationIconView.create(this.activityContext, adgNativeAd);
            if (informationIconView != null) {
                viewGroup.addView(informationIconView);
            }
        } else {
            logger.getLogger().warn("can't add an information icon to this view.");
        }
    }

    /** インフォメーションアイコンを削除する */
    private void removeADGInformationIconView(@NonNull View view) {
        if (view instanceof ADGInformationIconView) {
            ViewGroup parent = (ViewGroup) view.getParent();
            if (parent != null) {
                parent.removeView(view);
                return;
            }
        }
        if (ViewGroup.class.isAssignableFrom(view.getClass())) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                View child = viewGroup.getChildAt(i);
                this.removeADGInformationIconView(child);
            }
        }
    }

    /** delegateViewManagementで保持したViewを削除する */
    private void removeUserView() {
        if (userView != null) {
            if (userView instanceof ViewGroup) {
                ADGMediaView.safeRemoveFromParentView((ViewGroup) userView);
            }

            ViewParent parent = userView.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(userView);
            }
            userView = null;
        }
    }

    private void startMediation(
            @NonNull final ADGResponse adResponse,
            @Nullable String className,
            @Nullable String adId,
            @Nullable String param,
            int movie) {
        // 連携先SDK className
        if (ADGLogger.isEnabled()) {
            String sb =
                    "Start Mediation."
                            + "\n"
                            + "className = "
                            + className
                            + "\n"
                            + "adId = "
                            + adId
                            + "\n"
                            + "param = "
                            + param;
            logger.getLogger().debug(sb);
        }

        adWebViewController.hideWebView();
        Point p = calcAdSize(adSize);
        // mediationインスタンスの生成
        MediationModel model;
        try {
            model = new MediationModel(controller.adModel);
        } catch (MediationModel.MediationModelException e) {
            logger.getLogger().error("Failed to create MediationModel.", e);
            controller.dispatchFailedToReceiveAdEvent(ADGErrorCode.COMMUNICATION_ERROR, null);
            return;
        }

        nif = new ADGNativeInterface(model, logger);
        nif.setContext(activityContext);
        nif.setClassName(className);
        nif.setAdId(adId);
        nif.setMovie(movie);
        nif.setParam(param);
        nif.setSize(p.x, p.y);
        nif.setEnableSound(this.enableSound);
        nif.setEnableTestMode(this.enableTestMode);
        nif.setUsePartsResponse(this.usePartsResponse);
        nif.setCallNativeAdTrackers(this.callNativeAdTrackers);
        nif.setExpandFrame(this.expandFrame);
        nif.setContentUrl(this.contentUrl);
        nif.setIsWipe(this.isWipe);
        nif.setLayout(this);
        nif.setAdmPayload(adResponse.getAdmPayload());
        nif.setBidderSuccessfulName(adResponse.getBidderSuccessfulName());

        ArrayList<String> biddingNotifyUrl = adResponse.getTrackerBiddingNotifyUrl();
        if (biddingNotifyUrl != null) {
            nif.setBiddingNotifyUrl(biddingNotifyUrl);
        }

        nif.setListener(
                new ADGNativeInterfaceListener() {
                    @Override
                    public void onReceiveAd() {
                        sendMessage(new ADGMessage("AdViewType", "ADG"));
                        controller.getAdParams().clearErrorScheduleIds();
                        controller.sendWinNotificationBeacons();
                        if (nif != null && nif.isLateImp()) {
                            controller.sendLoadTriggerEvents();
                        }
                        startViewable("ADG", ADG.this, adResponse);
                        controller.dispatchReceivedAdEvent(null);
                    }

                    @Override
                    public void onReceiveAd(@NonNull Object nativeAd) {
                        sendMessage(new ADGMessage("AdViewType", "ADG"));
                        controller.getAdParams().clearErrorScheduleIds();
                        controller.dispatchReceivedMediationNativeAdEvent(nativeAd, null);
                        controller.sendWinNotificationBeacons();
                        if (nif != null && nif.isLateImp() && callNativeAdTrackers) {
                            controller.sendLoadTriggerEvents();
                        }
                    }

                    @Override
                    public void onFailedToReceiveAd() {
                        afterMediationError();
                    }

                    @Override
                    public void onReachRotateTime() {
                        startAd();
                    }

                    @Override
                    public void onClickAd() {
                        controller.dispatchClickedAdEvent(null);
                    }

                    @Override
                    public void onReadyMediation(@NonNull Object mediation) {}

                    @Override
                    public void onSuccessfulBidder(@NonNull String bidderSuccessfulName) {
                        logger.getLogger().debug("bidderSuccessfulName = " + bidderSuccessfulName);
                    }
                });
        boolean res = nif.loadChild(getLocationId());

        if (res) {
            if (!waitShowing && !divideShowing) {
                nif.startChild();
            }
            controller.sendWinNotificationBeacons();
            if (!nif.isLateImp()) {
                controller.sendLoadTriggerEvents();
            }
        } else {
            afterMediationError();
        }
    }

    private void finishMediation() {
        logger.getLogger().debug("ADG is finishing mediation.");
        controller.cancelRotationTimerIfScheduled();
        if (nif != null) {
            nif.finishChild();
            nif = null;
        }
        if (nativeMediationView != null) {
            nativeMediationView.finishViewable();
            nativeMediationView = null;
        }
        adWebViewController.showWebView();
    }

    private void afterMediationError() {
        if (adResponse != null) {
            adResponse.setBeacon(null);
            adResponse.setTrackerImp(null);
            adResponse.setTrackerViewableMeasured(null);
            adResponse.setTrackerViewableImp(null);
        }

        adWebViewController.getWebView().ifPresent(this::stopWebViewLoading);

        if (adResponse != null) {
            controller.getAdParams().addErrorScheduleId(adResponse.getScheduleId());
        }

        finishMediation();

        controller.dispatchFailedToReceiveAdEvent(ADGErrorCode.COMMUNICATION_ERROR, null);
    }

    /**
     * Mraidが使えるVersionかチェック
     *
     * @return Mraidが使えるVersionかどうか
     */
    @NonNull
    private Boolean canUseMraid() {
        return AssetUtils.getMRAIDSource(activityContext) != null;
    }

    private void stopMraidViewable() {
        logger.getLogger().debug("Stop MRAID viewability.");
        mraidViewableMeasurement.ifPresent(Viewable::stopMeasurement);
    }

    private void startMraidViewable() {
        logger.getLogger().debug("Start MRAID viewability.");
        if (adResponse == null) {
            return;
        }
        if (!controller.getAdParams().isMraidEnabled()) {
            return;
        }
        if (!controller.isWorking) {
            return;
        }
        final Optional<WebView> webView = adWebViewController.getWebView();
        if (webView.isEmpty()) {
            return;
        }
        final WebView wv = webView.forced();
        mraidViewableMeasurement.ifPresent(Viewable::stopMeasurement);

        final AdBridgingObject adObject = adResponse.getAdBridgingObject();
        final Viewable viewable =
                new ViewableDisposableMeasurement(
                        new ViewableObstacleMeasurement(
                                "MRAID",
                                activityContext,
                                wv,
                                new ViewableParameters(
                                        adObject.getViewableMeasurementInterval(),
                                        ViewableParameter.MRAID),
                                logger));
        mraidViewableMeasurement = Optional.of(viewable);
        mraidHandler.ifPresent(
                mraid -> {
                    viewable.startMeasurement(
                            (isViewable, key) -> {
                                mraid.setIsViewable(isViewable);
                                // mraidでは、viewableを止めない
                                // if (isViewable) {
                                //    viewable.stopMeasurement();
                                // }
                            });
                });
    }

    private void restartViewable() {
        logger.getLogger().debug("Restart viewability.");
        if (adResponse == null) {
            return;
        }

        if (nif != null) {
            startViewable("ADG", ADG.this, adResponse);
        } else {
            final Optional<WebView> webView = adWebViewController.getWebView();
            if (webView.isPresent()) {
                startViewable("HTMLDisplay", webView.forced(), adResponse);
            }
        }
    }

    private void startViewable(
            @NonNull final String tag,
            @NonNull final View view,
            @NonNull final ADGResponse adResponse) {

        viewableMeasurement.ifPresent(Viewable::stopMeasurement);

        final AdBridgingObject adObject = adResponse.getAdBridgingObject();
        final ViewableParameters viewableParameters;
        if (nif != null) {
            // 動画広告のIn-view/Out-of-view制御に使用するため、Viewable計測パラメータにVIDEO_ADを追加
            final List<ViewableParameter> parameters =
                    new ArrayList<>(adObject.getViewableParameters());
            parameters.add(ViewableParameter.VIDEO_AD);
            viewableParameters =
                    new ViewableParameters(adObject.getViewableMeasurementInterval(), parameters);
        } else {
            viewableParameters =
                    new ViewableParameters(
                            adObject.getViewableMeasurementInterval(),
                            adObject.getViewableParameters());
        }

        final Viewable viewable =
                new ViewableDisposableMeasurement(
                        new ViewableObstacleMeasurement(
                                tag, getContext(), view, viewableParameters, logger));
        viewableMeasurement = Optional.of(viewable);
        viewable.startMeasurement(
                (isViewable, key) -> {
                    if (isViewable) {
                        if (ImpressionTracker.IMP_CONDITION_DATA_KEY.equals(key)) {
                            logger.getLogger()
                                    .debug(
                                            "WebView/VAST ad impression occurred. Canceling"
                                                    + " expiration timer.");
                            controller.cancelExpirationTimerIfScheduled();

                            if (adResponse.getAdBridgingObject().isInViewChargingEnabled()) {
                                logger.getLogger()
                                        .debug(
                                                "In-view charging ad. Setting rotation timer on"
                                                        + " impression.");
                                setRotationTimer(adResponse);
                            }
                        }

                        controller.sendImpressions(key);

                        if (adObject.areAllImpressionsFired() && nif == null) {
                            viewable.stopMeasurement();
                        }

                        if (key.equals(ViewableParameter.VIDEO_AD.key)) {
                            if (nif != null) {
                                nif.callWhenInView();
                            }
                        }

                    } else {
                        if (key.equals(ViewableParameter.VIDEO_AD.key)) {
                            if (nif != null) {
                                nif.callWhenOutOfView();
                            }
                        }
                    }
                });
    }

    private void stopAllViewable() {
        stopMraidViewable();

        viewableMeasurement.ifPresent(Viewable::stopMeasurement);

        for (int i = 0; i < this.getChildCount(); i++) {
            View child = this.getChildAt(i);
            if (child instanceof ADGNativeAdTemplateBase) {
                ((ADGNativeAdTemplateBase) child).finishViewability();
            }
        }

        if (this.nativeMediationView != null) {
            this.nativeMediationView.finishViewable();
        }

        if (adResponse != null && adResponse.getNativeAd().isPresent()) {
            adResponse.getNativeAd().ifPresent(ADGNativeAd::stopViewable);
        }
    }

    private void finishOMWebViewViewability() {
        logger.getLogger().debug("Finish OM viewability.");

        webViewMeasurementManager.ifPresent(WebViewMeasurementManager::finishMeasurement);
        webViewMeasurementManager = Optional.empty();
    }

    // Observer pattern methods
    @Override
    public void sendMessage(@NonNull ADGMessage message) {
        for (Observer observer : observers) {
            observer.onMessage(message);
        }
    }

    @Override
    public void addObserver(@NonNull Observer observer) {
        if (!observers.contains(observer)) {
            observers.add(observer);
        }
    }

    @Override
    public void deleteObserver(@NonNull Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void onReceivedAd() {
        if (listener != null) {
            listener.onReceiveAd();
        }
    }

    @Override
    public void onReceivedMediationNativeAd(@NonNull final Object mediationNativeAd) {
        if (listener != null) {
            listener.onReceiveAd(mediationNativeAd);
        }
    }

    @Override
    public void onFailedToReceiveAd(@NonNull final ADGErrorCode code) {
        if (listener != null) {
            listener.onFailedToReceiveAd(code);
        }
    }

    @Override
    public void onClickedAd() {
        if (listener != null) {
            listener.onClickAd();
        }
    }

    @Override
    public void onFinishImpression() {
        logger.getLogger().debug("ADG received an impression event.");
        // TODO: If you need to notify the app about this event, add a corresponding method to
        // ADGListener.
        // iOS のADGManagerViewControllerFinishImpressionは非推奨になっているのでAndroidでの同様の実装をSKIPする
    }

    @Override
    public void onRotationTimerFired() {
        mainHandler.post(
                () -> {
                    adWebViewController.showWebView();
                    startAd();
                });
    }

    @Override
    public void onExpire() {
        if (listener != null) {
            listener.onAdExpired();
        }
    }
}
