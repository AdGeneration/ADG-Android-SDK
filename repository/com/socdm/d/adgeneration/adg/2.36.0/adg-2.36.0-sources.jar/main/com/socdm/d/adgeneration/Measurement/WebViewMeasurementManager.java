package com.socdm.d.adgeneration.Measurement;

import android.content.Context;
import android.view.View;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.iab.omid.library.supershipjp.Omid;
import com.iab.omid.library.supershipjp.ScriptInjector;
import com.socdm.d.adgeneration.utils.LogUtils;

/** WebViewDisplay フォーマットの広告について OM SDKの計測およびトラッキングをおこなうクラス */
public class WebViewMeasurementManager extends BaseMeasurementManager {

    /**
     * コンストラクタ
     *
     * @param ct コンテキスト
     */
    public WebViewMeasurementManager(@NonNull Context ct) {
        super(ct);
    }

    /**
     * 計測に必要なタグを追加する
     *
     * @param adResponseHtml 受け取ったままのhtml
     * @return htmlString 計測タグを追加したあとのhtml
     */
    @Nullable
    public String injectWebViewMeasurementTag(@NonNull final String adResponseHtml) {
        String htmlString = null;
        try {
            htmlString =
                    ScriptInjector.injectScriptContentIntoHtml(
                            super.omidJsServiceContent, adResponseHtml);
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            e.printStackTrace();
        }

        return htmlString;
    }

    /**
     * アドセッションを生成し計測開始
     *
     * @param adView 計測対象のView
     * @return Activate OK(true) or NG(false)
     */
    @Override
    public boolean startMeasurement(@NonNull View adView) {
        if (!Omid.isActive()) {
            onFailed("OM SDK is not Activated.");
            return false;
        }

        if (adView instanceof WebView) {
            // セッションの準備
            createAdSession(MeasurementConsts.formatType.webViewDisplay, (WebView) adView);
        } else {
            LogUtils.e("View passed is not a WebView.");
            return false;
        }

        LogUtils.d("adSession starts");
        return super.startMeasurement(adView);
    }

    /**
     * WebViewイベントを通知する
     *
     * @param event WebViewイベントのタイプ
     */
    public void sendWebViewEvent(@NonNull final MeasurementConsts.webViewEvent event) {
        try {
            switch (event) {
                    // ロード開始
                case loaded:
                    if (super.adEvents == null) return;
                    super.adEvents.loaded();
                    LogUtils.d("sendAdEvents : loaded");
                    break;
                    // インプレッション開始
                case impression:
                    if (super.adEvents == null) return;
                    super.adEvents.impressionOccurred();
                    LogUtils.d("sendAdEvents : impression");
                    break;
                default:
                    break;
            }
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            onFailed("webViewEvent is not sending");
            e.printStackTrace();
        }
    }

    /**
     * エラー用のトラッキングURLへリクエストをおこない、Exceptionを返却する
     *
     * @param msg エラーメッセージ
     * @return IllegalArgumentException エラー
     */
    @NonNull
    @Override
    public IllegalArgumentException onFailed(@Nullable String msg) {
        return super.onFailed(msg);
    }
}
