package com.socdm.d.adgeneration.video.vast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.utils.TrackerUtils;

import java.io.Serializable;
import java.util.ArrayList;

public class VASTIcon implements Serializable {
    @Nullable private String program;
    private int height;
    private int width;
    private int xPosition;
    private int yPosition;
    @NonNull private String apiFramework;
    @Nullable private VASTResource staticResource;
    @Nullable private String clickThroughURL;
    @NonNull private ArrayList<String> clickTrackings = new ArrayList<>();

    public VASTIcon(@NonNull final String apiFramework) {
        this.apiFramework = apiFramework;
    }

    @Nullable
    public String getProgram() {
        return program;
    }

    public void setProgram(@Nullable final String program) {
        this.program = program;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(final int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(final int width) {
        this.width = width;
    }

    public int getXPosition() {
        return xPosition;
    }

    public void setXPosition(final int xPosition) {
        this.xPosition = xPosition;
    }

    public int getYPosition() {
        return yPosition;
    }

    public void setYPosition(final int yPosition) {
        this.yPosition = yPosition;
    }

    public void setStaticResource(@Nullable final VASTResource staticResource) {
        this.staticResource = staticResource;
    }

    @Nullable
    public VASTResource getStaticResource() {
        return staticResource;
    }

    @Nullable
    public String getClickThroughURL() {
        return clickThroughURL;
    }

    public void setClickThroughURL(@Nullable final String clickThroughURL) {
        this.clickThroughURL = clickThroughURL;
    }

    @NonNull
    public ArrayList<String> getIconClickTrackings() {
        return clickTrackings;
    }

    public void setIconClickTrackings(@NonNull final ArrayList<String> list) {
        this.clickTrackings = list;
    }

    public boolean isAdg() {
        return apiFramework.equals("adg");
    }

    public void sendIconClickTracking() {
        TrackerUtils.callTracker(this.clickTrackings);
    }
}
