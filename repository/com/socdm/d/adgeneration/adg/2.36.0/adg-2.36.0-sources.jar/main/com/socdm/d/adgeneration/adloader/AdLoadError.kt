package com.socdm.d.adgeneration.adloader

/**
 * 広告ロード時のエラー型。
 * ADGControllerが ADGErrorCode へマッピングする際に使用する。
 */
internal sealed class AdLoadError(message: String, cause: Throwable? = null) : Exception(message, cause) {
    /** ネットワーク未接続 */
    class NoNetwork : AdLoadError("No network connection")

    /** 通信エラー */
    class Communication(cause: Throwable?) : AdLoadError("Communication error", cause)

    /** レスポンスパースエラー */
    class Parse(cause: Throwable?) : AdLoadError("Response parse error", cause)
}
