package com.socdm.d.adgeneration.nativead;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.nativead.icon.ADGAnimation;
import com.socdm.d.adgeneration.nativead.icon.ADGImageView;
import com.socdm.d.adgeneration.utils.LogUtils;

import org.json.JSONObject;

/** ネイティブ広告の情報アイコン(iマーク)を表示するビューです。 オプトアウトURLへの遷移機能を提供します。 */
public class ADGInformationIconView extends LinearLayout {
    /** ADGInformationIconViewのインスタンスを生成できない場合にスローされる例外です */
    public static final class CannotInstantiateException extends Exception {
        /**
         * エラー情報を指定してCannotInstantiateExceptionを生成します。
         *
         * @param message エラー情報
         */
        public CannotInstantiateException(@NonNull final String message) {
            super(message);
        }
    }

    private final int WC = ViewGroup.LayoutParams.WRAP_CONTENT;
    private final int MP = ViewGroup.LayoutParams.MATCH_PARENT;
    private final int CONTRACTED_WIDTH = 0;
    private final int ICON_WIDTH = 17;
    private final int ICON_HEIGHT = 15;
    private final int ANIMATION_DURATION = 0;
    private final int SLEEP_MILLISECONDS = 3000;
    private final int TEXT_SIZE = 10;
    private final int ROUND_RECT = 4;

    /** コンテキスト */
    @NonNull private final Context context;

    /** 展開可能なテキストビュー */
    @NonNull private final TextView expandableView;

    /** 情報アイコンのイメージビュー */
    @NonNull private final ImageView informationIconView;

    /** 展開可能かどうか */
    private final boolean expandable;

    /** 表示位置(角) */
    @NonNull private final Corner corner;

    /** 背景タイプ */
    @NonNull private final BackgroundType backgroundType;

    /** オプトアウトURL */
    @NonNull private final String optOutUrl;

    /**
     * オプトアウトURLを取得します。
     *
     * @return オプトアウトURL
     */
    @NonNull
    public String getOptOutUrl() {
        return optOutUrl;
    }

    /** 情報アイコンの表示位置を表す列挙型です。 */
    public enum Corner {
        /** 左上 */
        TOP_LEFT,
        /** 右上 */
        TOP_RIGHT,
        /** 左下 */
        BOTTOM_LEFT,
        /** 右下 */
        BOTTOM_RIGHT
    }

    /** 情報アイコンの背景色とテキスト色を表す列挙型です。 */
    public enum BackgroundType {
        /** 白背景・黒文字 */
        WHITE(Color.argb(204, 255, 255, 255), Color.BLACK),
        /** 黒背景・白文字 */
        BLACK(Color.argb(204, 0, 0, 0), Color.WHITE);

        private final int backgroundColor;
        private final int textColor;

        /**
         * 背景色とテキスト色を指定してBackgroundTypeを生成します。
         *
         * @param backgroundColor 背景色
         * @param textColor テキスト色
         */
        BackgroundType(final int backgroundColor, final int textColor) {
            this.backgroundColor = backgroundColor;
            this.textColor = textColor;
        }
    }

    /**
     * デフォルト設定で情報アイコンビューを生成します。 展開不可、右上配置、白背景で初期化されます。
     *
     * @param context コンテキスト
     * @param nativeAd ネイティブ広告オブジェクト
     * @throws CannotInstantiateException 必要なデータが存在しない場合にスローされます
     * @deprecated Use {@link #create(Context, ADGNativeAd)} instead. This constructor will be
     *     removed in a future version. NOTE: This constructor now throws CannotInstantiateException
     *     for invalid arguments
     */
    @Deprecated(forRemoval = true)
    public ADGInformationIconView(
            @NonNull final Context context, @NonNull final ADGNativeAd nativeAd)
            throws CannotInstantiateException {
        this(context, nativeAd, false, Corner.TOP_RIGHT, BackgroundType.WHITE);
    }

    /**
     * カスタム設定で情報アイコンビューを生成します。
     *
     * @param context コンテキスト
     * @param nativeAd ネイティブ広告オブジェクト
     * @param expandable アイコンが展開可能かどうか
     * @param corner アイコンの表示位置
     * @param backgroundType 背景タイプ
     * @throws CannotInstantiateException 必要なデータが存在しない場合にスローされます
     * @deprecated Use {@link #create(Context, ADGNativeAd, boolean, Corner, BackgroundType)}
     *     instead. This constructor will be removed in a future version. NOTE: This constructor now
     *     throws CannotInstantiateException for invalid arguments
     */
    @Deprecated(forRemoval = true)
    @SuppressLint("ClickableViewAccessibility")
    public ADGInformationIconView(
            @NonNull final Context context,
            @NonNull final ADGNativeAd nativeAd,
            final boolean expandable,
            @NonNull final Corner corner,
            @NonNull final BackgroundType backgroundType)
            throws CannotInstantiateException {
        super(context);

        // 初期化前に必要なデータの存在チェック
        if (nativeAd.getOptout() == null
                || nativeAd.getInformationIcon() == null
                || nativeAd.getAccompany() == null) {
            throw new CannotInstantiateException("information icons not found.");
        }

        String iconUrl = getIconUrl(nativeAd, backgroundType);
        if (iconUrl == null) {
            throw new CannotInstantiateException("icon url not found.");
        }

        this.context = context;
        this.corner = corner;
        this.expandable = expandable;
        this.backgroundType = backgroundType;

        this.optOutUrl = nativeAd.getOptout().getValue();
        String containerText =
                nativeAd.getAccompany() != null ? nativeAd.getAccompany().getValue() : "";

        this.setLayoutParams(new LinearLayout.LayoutParams(MP, MP));
        this.setGravity(getLayoutGravity());

        expandableView = new TextView(context);
        expandableView.setTextSize(TEXT_SIZE / getResources().getConfiguration().fontScale);
        expandableView.setText(containerText);
        expandableView.setHeight(convertPx(ICON_HEIGHT));
        expandableView.setTextColor(this.backgroundType.textColor);
        expandableView.setLayoutParams(new RelativeLayout.LayoutParams(WC, WC));
        if (corner.equals(Corner.TOP_LEFT) || corner.equals(Corner.BOTTOM_LEFT)) {
            expandableView.setPadding(convertPx(2), convertPx(1), convertPx(4), convertPx(1));
        } else if (corner.equals(Corner.TOP_RIGHT) || corner.equals(Corner.BOTTOM_RIGHT)) {
            expandableView.setPadding(convertPx(4), convertPx(1), convertPx(2), convertPx(1));
        }
        if (this.expandable) {
            expandableView.setWidth(CONTRACTED_WIDTH);
        }
        int expandWidth = getWidthByText(containerText);
        ADGAnimation contract =
                new ADGAnimation(
                        expandableView,
                        -expandWidth,
                        CONTRACTED_WIDTH + expandWidth,
                        ANIMATION_DURATION);
        ADGAnimation expand =
                new ADGAnimation(expandableView, expandWidth, CONTRACTED_WIDTH, ANIMATION_DURATION);
        expandableView.setOnTouchListener(getTouchEvent(this.optOutUrl, contract, expand));
        rounded(expandableView, !this.expandable);

        informationIconView =
                new ADGImageView(
                        context, iconUrl, convertPx(ICON_WIDTH - 4), convertPx(ICON_HEIGHT - 2));
        informationIconView.setMinimumWidth(convertPx(ICON_WIDTH));
        informationIconView.setLayoutParams(new ViewGroup.LayoutParams(WC, convertPx(ICON_HEIGHT)));
        informationIconView.setPadding(convertPx(2), convertPx(1), convertPx(2), convertPx(1));
        informationIconView.setOnTouchListener(getTouchEvent(this.optOutUrl, contract, expand));
        rounded(informationIconView, this.expandable);

        if (corner.equals(Corner.TOP_LEFT) || corner.equals(Corner.BOTTOM_LEFT)) {
            this.addView(informationIconView);
            this.addView(expandableView);
        } else if (corner.equals(Corner.TOP_RIGHT) || corner.equals(Corner.BOTTOM_RIGHT)) {
            this.addView(expandableView);
            this.addView(informationIconView);
        }
    }

    /**
     * デフォルト設定でADGInformationIconViewのインスタンスを生成します。 引数が不正な場合はnullを返します。
     *
     * @param context コンテキスト
     * @param nativeAd ネイティブ広告オブジェクト
     * @return ADGInformationIconViewのインスタンス、または生成できない場合はnull
     */
    @Nullable
    public static ADGInformationIconView create(
            @NonNull final Context context, @NonNull final ADGNativeAd nativeAd) {
        try {
            return new ADGInformationIconView(context, nativeAd);
        } catch (CannotInstantiateException e) {
            LogUtils.w("Failed to create ADGInformationIconView: " + e.getMessage());
            return null;
        }
    }

    /**
     * カスタム設定でADGInformationIconViewのインスタンスを生成します。 引数が不正な場合はnullを返します。
     *
     * @param context コンテキスト
     * @param nativeAd ネイティブ広告オブジェクト
     * @param expandable アイコンが展開可能かどうか
     * @param corner アイコンの表示位置
     * @param backgroundType 背景タイプ
     * @return ADGInformationIconViewのインスタンス、または生成できない場合はnull
     */
    @Nullable
    public static ADGInformationIconView create(
            @NonNull final Context context,
            @NonNull final ADGNativeAd nativeAd,
            final boolean expandable,
            @NonNull final Corner corner,
            @NonNull final BackgroundType backgroundType) {
        try {
            return new ADGInformationIconView(
                    context, nativeAd, expandable, corner, backgroundType);
        } catch (CannotInstantiateException e) {
            LogUtils.w("Failed to create ADGInformationIconView: " + e.getMessage());
            return null;
        }
    }

    /**
     * ADGInformationIconViewを生成可能かチェックします。
     *
     * @param nativeAd ネイティブ広告オブジェクト
     * @return 生成可能な場合true
     */
    public static boolean canCreate(@NonNull final ADGNativeAd nativeAd) {
        if (nativeAd.getOptout() == null
                || nativeAd.getInformationIcon() == null
                || nativeAd.getAccompany() == null) {
            return false;
        }
        // アイコンURLの存在チェック
        ADGData informationIcon = nativeAd.getInformationIcon();
        return informationIcon != null && !informationIcon.getValue().isEmpty();
    }

    /**
     * アイコン画像のURLを取得します。 黒背景が指定されていて、black_back拡張データがあればそれを使用します。
     *
     * @param nativeAd ネイティブ広告オブジェクト
     * @param backgroundType 背景タイプ
     * @return アイコン画像URL。取得できない場合はnull
     */
    @Nullable
    private String getIconUrl(
            @NonNull final ADGNativeAd nativeAd, @NonNull final BackgroundType backgroundType) {
        // コンストラクタでnullチェック済み
        ADGData informationIcon = nativeAd.getInformationIcon();
        if (informationIcon == null) {
            LogUtils.w("information icon not found.");
            return null;
        }

        String iconUrl = informationIcon.getValue();
        if (backgroundType.equals(BackgroundType.BLACK)) {
            JSONObject json = (JSONObject) informationIcon.getExt();
            if (json != null) {
                String blackImageUrl = json.optString("black_back");
                if (!blackImageUrl.isEmpty()) {
                    iconUrl = blackImageUrl;
                }
            }
        }
        return iconUrl;
    }

    /**
     * 表示位置に応じたレイアウトGravityを取得します。
     *
     * @return Gravity定数
     */
    private int getLayoutGravity() {
        if (corner.equals(Corner.TOP_LEFT)) {
            return Gravity.LEFT | Gravity.TOP;
        } else if (corner.equals(Corner.TOP_RIGHT)) {
            return Gravity.RIGHT | Gravity.TOP;
        } else if (corner.equals(Corner.BOTTOM_LEFT)) {
            return Gravity.LEFT | Gravity.BOTTOM;
        } else if (corner.equals(Corner.BOTTOM_RIGHT)) {
            return Gravity.RIGHT | Gravity.BOTTOM;
        }
        return 0;
    }

    /**
     * 文字列からコンテナの表示幅を取得します。 padding分(計6px)と余裕をもたせる分(1px)を加えます。
     *
     * @param text 表示する文字列
     * @return コンテナ幅(ピクセル)
     */
    private int getWidthByText(@NonNull final String text) {
        return (int) (expandableView.getPaint().measureText(text) + convertPx(6) + convertPx(1));
    }

    /**
     * アイコンをタッチしたときのイベントリスナーを取得します。 ビューが閉じていれば表示し、ビューが開いていれば対象URLへ遷移します。
     *
     * @param url 遷移先URL
     * @param contractAnimation 縮小アニメーション
     * @param expandAnimation 拡大アニメーション
     * @return タッチイベントリスナー
     */
    @NonNull
    private View.OnTouchListener getTouchEvent(
            @NonNull final String url,
            @NonNull final ADGAnimation contractAnimation,
            @NonNull final ADGAnimation expandAnimation) {
        return new View.OnTouchListener() {
            @Override
            public boolean onTouch(@NonNull final View v, @NonNull final MotionEvent event) {
                switch (event.getAction() & MotionEvent.ACTION_MASK) {
                    case MotionEvent.ACTION_DOWN:
                        if (expandable) {
                            expandableView.clearAnimation();
                            if (expandableView.getWidth() > CONTRACTED_WIDTH) {
                                transition(v, url);
                            } else {
                                expandableView.startAnimation(expandAnimation);
                                rounded(expandableView, true);
                                rounded(informationIconView, false);
                                new Handler(Looper.getMainLooper())
                                        .postDelayed(
                                                new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        expandableView.startAnimation(
                                                                contractAnimation);
                                                        new Handler(Looper.getMainLooper())
                                                                .postDelayed(
                                                                        new Runnable() {
                                                                            @Override
                                                                            public void run() {
                                                                                rounded(
                                                                                        informationIconView,
                                                                                        true);
                                                                            }
                                                                        },
                                                                        ANIMATION_DURATION);
                                                    }
                                                },
                                                SLEEP_MILLISECONDS);
                            }
                        } else {
                            transition(v, url);
                        }
                        break;
                    default:
                        break;
                }
                return true;
            }
        };
    }

    /**
     * 背景の一部を角丸にします。 表示位置に応じて適切な角を丸めます。
     *
     * @param view 対象のビュー
     * @param rounded trueなら角丸、falseなら角丸なし
     */
    private void rounded(@NonNull final View view, final boolean rounded) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(this.backgroundType.backgroundColor);
        if (rounded) {
            float[] outerRadii = new float[0];
            if (corner.equals(Corner.TOP_LEFT)) {
                outerRadii =
                        new float[] {
                            0, 0, 0, 0, convertPx(ROUND_RECT), convertPx(ROUND_RECT), 0, 0
                        };
            } else if (corner.equals(Corner.TOP_RIGHT)) {
                outerRadii =
                        new float[] {
                            0, 0, 0, 0, 0, 0, convertPx(ROUND_RECT), convertPx(ROUND_RECT)
                        };
            } else if (corner.equals(Corner.BOTTOM_LEFT)) {
                outerRadii =
                        new float[] {
                            0, 0, convertPx(ROUND_RECT), convertPx(ROUND_RECT), 0, 0, 0, 0
                        };
            } else if (corner.equals(Corner.BOTTOM_RIGHT)) {
                outerRadii =
                        new float[] {
                            convertPx(ROUND_RECT), convertPx(ROUND_RECT), 0, 0, 0, 0, 0, 0
                        };
            }
            drawable.setCornerRadii(outerRadii);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            view.setBackground(drawable);
        } else {
            view.setBackgroundDrawable(drawable);
        }
    }

    /**
     * 対象URLへ遷移させます。 ブラウザアプリを起動してURLを開きます。
     *
     * @param view ビュー
     * @param url 遷移先URL
     */
    private void transition(@NonNull final View view, @NonNull final String url) {
        Uri uri = Uri.parse(url);
        Intent i = new Intent(Intent.ACTION_VIEW, uri);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            view.getContext().startActivity(i);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * dpをピクセルに変換します。
     *
     * @param dp 変換するdp値
     * @return ピクセル値
     */
    private int convertPx(final float dp) {
        float density = this.context.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
