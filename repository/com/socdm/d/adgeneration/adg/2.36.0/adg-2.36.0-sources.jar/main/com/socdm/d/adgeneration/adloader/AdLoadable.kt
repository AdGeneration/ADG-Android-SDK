package com.socdm.d.adgeneration.adloader

import com.socdm.d.adgeneration.AdParams
import com.socdm.d.adgeneration.adresponse.Response
import jp.supership.sscore.type.Result
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * 広告ロード処理の抽象インターフェース。
 * ADGControllerはこのインターフェースにのみ依存し、具体実装を知らない。
 *
 * ## Java での使用例
 * ```java
 * adLoader.loadAd(() -> { return Unit.INSTANCE; }, result -> { return Unit.INSTANCE; });
 * ```
 *
 * ## Kotlin での使用例（コールバック版）
 * ```kotlin
 * adLoader.loadAd({ }, { result -> })
 * ```
 *
 * ## Kotlin での使用例（コルーチン内）
 * ```kotlin
 * val result = adLoader.loadAdSuspend { }
 * ```
 *
 * iOS対応: AdLoadable protocol (ADGSwift/AdLoader/AdLoader.swift)
 */
internal interface AdLoadable {
    val adParams: AdParams

    fun loadAd(beforeLoading: () -> Unit, completion: (Result<Response, AdLoadError>) -> Unit)

    fun cancelLoad()
}

/**
 * 広告をロードします（suspend関数版 - Kotlin用）
 *
 * @param beforeLoading ロード開始前に実行する処理
 * @return ロード結果
 */
internal suspend fun AdLoadable.loadAdSuspend(
    beforeLoading: () -> Unit = {},
): Result<Response, AdLoadError> = suspendCancellableCoroutine { continuation ->
    loadAd(beforeLoading) { result ->
        if (continuation.isActive) {
            continuation.resume(result)
        }
    }
    continuation.invokeOnCancellation { cancelLoad() }
}
