package com.socdm.d.adgeneration.nativead;

import androidx.annotation.NonNull;

public enum ADGNativeAdType {
    Undefined,
    Default,
    GunosyAds,
    AmebaJointAlliance;

    @NonNull public static final String KEY = "nativeadtype";
}
