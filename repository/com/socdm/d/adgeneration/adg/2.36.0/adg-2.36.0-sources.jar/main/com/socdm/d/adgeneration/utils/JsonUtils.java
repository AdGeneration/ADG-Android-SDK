package com.socdm.d.adgeneration.utils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class JsonUtils {

    /**
     * jsonをJSONObjectに変換する.
     *
     * @param json JSON文字列
     * @return JSONObject obj
     */
    @NonNull
    public static JSONObject fromJson(@Nullable final String json) {
        try {
            if (json == null) {
                throw new JSONException("String is null");
            }
            return new JSONObject(json);
        } catch (JSONException e) {
            LogUtils.i("toJson:JsonParseError");
            return new JSONObject();
        }
    }

    /**
     * JSONObjectをjsonに変換する.
     *
     * @param obj 対象のJSONObject
     * @return String json
     */
    @NonNull
    public static String toJson(@Nullable final JSONObject obj) {
        return obj != null ? obj.toString() : "{}";
    }

    /**
     * JSONArrayをjsonに変換する.
     *
     * @param arr 対象のJsonArray
     * @return String json
     */
    @NonNull
    public static String toJson(@Nullable final JSONArray arr) {
        return arr != null ? arr.toString() : "[]";
    }

    /**
     * JSONArrayをList<T>に変換する.
     *
     * @param arr 対象のJsonArray
     * @return ArrayList<T>
     */
    @Nullable
    @SuppressWarnings("unchecked")
    public static <T> ArrayList<T> JSONArrayToArrayList(@Nullable final JSONArray arr) {
        if (arr == null) {
            return null;
        }

        ArrayList<T> list = new ArrayList<>();

        for (int i = 0; i < arr.length(); i++) {
            try {
                T data = (T) arr.opt(i);
                if (data != null) {
                    list.add(data);
                }
            } catch (ClassCastException ignored) {
            }
        }

        return list;
    }

    /**
     * JSONObjectからIntegerを取り出す
     *
     * @param obj
     * @param key
     * @return Integer
     */
    @Nullable
    public static Integer optInteger(@Nullable final JSONObject obj, @NonNull final String key) {
        try {
            return new Integer(obj.opt(key).toString());
        } catch (NumberFormatException | NullPointerException e) {
            return null;
        }
    }

    /**
     * JSONArrayからIntegerを取り出す
     *
     * @param arr
     * @param index
     * @return Integer
     */
    @Nullable
    public static Integer optInteger(@Nullable final JSONArray arr, final int index) {
        try {
            return new Integer(arr.opt(index).toString());
        } catch (NumberFormatException | NullPointerException e) {
            return null;
        }
    }

    /**
     * MapをJsonObjectに変換する
     *
     * @param map Map
     * @return JsonObject
     * @throws JSONException
     */
    @Nullable
    public static JSONObject mapToJson(@Nullable final Map map) throws JSONException {
        if (map == null) {
            return null;
        }
        JSONObject obj = new JSONObject();
        for (Object key : map.keySet()) {
            if (key instanceof String) {
                Object value = map.get(key);
                if (value == null) {
                    obj.put((String) key, null);
                } else if (value instanceof Map) {
                    obj.put((String) key, mapToJson((Map) value));
                } else if (value instanceof Set) {
                    obj.put((String) key, setToJson((Set) value));
                } else if (value instanceof List) {
                    obj.put((String) key, listToJson((List) value));
                } else if (value instanceof Object[]
                        || value instanceof int[]
                        || value instanceof short[]
                        || value instanceof byte[]
                        || value instanceof char[]
                        || value instanceof long[]
                        || value instanceof boolean[]
                        || value instanceof float[]
                        || value instanceof double[]) {
                    obj.put((String) key, arrayToJson((Object[]) value));
                } else if (value instanceof Integer
                        || value instanceof Long
                        || value instanceof Float
                        || value instanceof Double
                        || value instanceof Short
                        || value instanceof Boolean
                        || value instanceof Byte
                        || value instanceof String) {
                    obj.put((String) key, value);
                }
            }
        }
        return obj;
    }

    @NonNull
    private static JSONArray setToJson(@NonNull final Set set) throws JSONException {
        JSONArray arr = new JSONArray();
        for (Object value : set) {
            put(arr, value);
        }
        return arr;
    }

    @NonNull
    private static JSONArray listToJson(@NonNull final List list) throws JSONException {
        JSONArray arr = new JSONArray();
        for (Object value : list) {
            put(arr, value);
        }
        return arr;
    }

    @NonNull
    private static JSONArray arrayToJson(@NonNull final Object[] list) throws JSONException {
        JSONArray arr = new JSONArray();
        for (Object value : list) {
            put(arr, value);
        }
        return arr;
    }

    private static void put(@NonNull final JSONArray arr, @Nullable final Object value)
            throws JSONException {
        if (value instanceof Map) {
            arr.put(mapToJson((Map) value));
        } else if (value instanceof Set) {
            arr.put(setToJson((Set) value));
        } else if (value instanceof List) {
            arr.put(listToJson((List) value));
        } else if (value instanceof Object[]
                || value instanceof int[]
                || value instanceof short[]
                || value instanceof byte[]
                || value instanceof char[]
                || value instanceof long[]
                || value instanceof boolean[]) {
            arr.put(arrayToJson((Object[]) value));
        } else if (value instanceof Integer
                || value instanceof Long
                || value instanceof Float
                || value instanceof Double
                || value instanceof Short
                || value instanceof Boolean
                || value instanceof Byte
                || value instanceof String) {
            arr.put(value);
        }
    }

    @Nullable
    public static String toJsonStr(@Nullable final String value) {
        if (value == null) {
            return null;
        }
        StringBuilder buf = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); ++i) {
            char c = value.charAt(i);
            switch (c) {
                case '"':
                    buf.append("\\\"");
                    break;
                case '\\':
                    buf.append("\\\\");
                    break;
                case '\n':
                    buf.append("\\n");
                    break;
                case '\r':
                    buf.append("\\r");
                    break;
                case '\t':
                    buf.append("\\t");
                    break;
                case '\f':
                    buf.append("\\f");
                    break;
                case '\b':
                    buf.append("\\b");
                    break;
                default:
                    if ((c < ' ') || (c == '')) {
                        buf.append(" ");
                    } else {
                        buf.append(c);
                    }
            }
        }
        return buf.toString();
    }
}
