package com.socdm.d.adgeneration.nativead;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.ADGConsts;
import com.socdm.d.adgeneration.ADGLogger;
import com.socdm.d.adgeneration.Measurement.MeasurementConsts;
import com.socdm.d.adgeneration.Measurement.NativeDisplayMeasurementManager;
import com.socdm.d.adgeneration.utils.AsyncTaskListener;
import com.socdm.d.adgeneration.utils.HttpURLConnectionTask;
import com.socdm.d.adgeneration.video.ADGPlayerAdListener;
import com.socdm.d.adgeneration.video.ADGPlayerAdManager;
import com.socdm.d.adgeneration.video.ADGPlayerError;
import com.socdm.d.adgeneration.video.Measurement.VerificationModel;
import com.socdm.d.adgeneration.video.utils.Views;
import com.socdm.d.adgeneration.viewable.ViewableParameter;
import com.socdm.d.adgeneration.viewable.ViewableParameters;

import jp.supership.sscore.type.Optional;

import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ADGNativeAd {

    @NonNull ADGNativeAdModel model;
    // version
    @Nullable private final Integer ver;
    @Nullable private View view;
    // assets
    @Nullable private ADGTitle title;
    @Nullable private ADGImage mainImage;
    @Nullable private ADGImage iconImage;
    @Nullable private ADGData sponsored;
    @Nullable private ADGData desc;
    @Nullable private ADGData ctatext;
    @Nullable private ADGVideo video;
    @Nullable private ADGData accompany;
    @Nullable private ADGData optout;
    @Nullable private ADGData informationIcon;

    @Nullable private String multiNativeAdBeacon;
    // link
    @Nullable private ADGLink link;
    // jstracker
    @Nullable private String jstracker;
    // eventTrackers
    @Nullable private ArrayList<VerificationModel> eventTrackers;
    @Nullable private Object ext;
    // OM SDK
    @Nullable private NativeDisplayMeasurementManager nativeDisplayMeasurementManager;

    @Nullable private WebView jstrackerExecutor;

    @Nullable private ArrayList<String> trackerViewableImp;

    public boolean isNativeOptout = false;

    // ネイティブ広告種類
    @NonNull private ADGNativeAdType nativeAdType = ADGNativeAdType.Undefined;

    private boolean informationIconViewDefault = false;

    @NonNull private Optional<ADGPlayerAdManager> playerAdManager = Optional.empty();

    @NonNull private final ADGNativeAdController controller;

    @Deprecated
    public ADGNativeAd(
            @NonNull final String locationId,
            @Nullable final JSONObject json,
            @Nullable final ArrayList<String> trackerViewableImp,
            @NonNull final ViewableParameters viewableParameters) {
        throw new UnsupportedOperationException(
                "This constructor is deprecated. Use ADGNativeAd(ADGNativeAdModel model) instead.");
    }

    public ADGNativeAd(@NonNull final ADGNativeAdModel model) {

        this.model = model;
        this.controller = new ADGNativeAdController(model);
        this.controller.setOnNativeAdControllerListener(this.nativeAdControllerListener);

        // this.locationId = locationId;
        this.ver = model.getVer();

        for (ADGNativeAdModel.ADGNativeAsset asset : model.getAssets()) {
            this.setAsset(asset);
        }

        for (Object eventTracker : model.getEventTrackers()) {
            if (eventTracker instanceof JSONObject) {
                this.setEventTrackers((JSONObject) eventTracker);
            }
        }

        model.getLink().ifPresent(v -> this.link = v);

        model.getJsTracker().ifPresent(v -> this.jstracker = v);

        model.getExt().ifPresent(v -> this.ext = v);

        // 利用していない可能性があるがpublicAPIのため残している
        this.setMediationTarget(ADGNativeAdType.Default.name());
    }

    // setter
    private void setAsset(@NonNull ADGNativeAdModel.ADGNativeAsset asset) {

        ADGNativeAdModel.ADGNativeAsset.AssetID assetId = asset.id;
        switch (assetId) {
            case TITLE:
                asset.title.ifPresent(v -> this.title = v);
                break;
            case MAIN_IMAGE:
                asset.image.ifPresent(v -> this.mainImage = v);
                break;
            case ICON_IMAGE:
                asset.image.ifPresent(v -> this.iconImage = v);
                break;
            case SPONSORED:
                asset.data.ifPresent(v -> this.sponsored = v);
                break;
            case DESC:
                asset.data.ifPresent(v -> this.desc = v);
                break;
            case CTA_TEXT:
                asset.data.ifPresent(v -> this.ctatext = v);
                break;
            case VIDEO:
                asset.video.ifPresent(v -> this.video = v);
                break;
            case ACCOMPANYING_TEXT:
                asset.data.ifPresent(v -> this.accompany = v);
                break;
            case OPT_OUT_URL:
                asset.data.ifPresent(
                        v -> {
                            this.optout = v;
                            isNativeOptout = true;
                        });
                break;
            case ICON_URL:
                asset.data.ifPresent(v -> this.informationIcon = v);
                break;
        }
    }

    private void setEventTrackers(@Nullable final JSONObject eventTrackers) {
        if (eventTrackers == null) return;

        VerificationModel verificationModel = new VerificationModel();

        String urlStr = eventTrackers.optString("url");
        if (!urlStr.isEmpty()) {
            try {
                verificationModel.setJavaScriptResource(new URL(urlStr));
            } catch (MalformedURLException e) {
                ADGLogger.getDefault().error("not OMID-JavaScriptResource.", e);
                return;
            }
        }

        JSONObject ext = eventTrackers.optJSONObject("ext");
        if (ext != null) {
            String vendorKey = ext.optString("vendorKey");
            if (!vendorKey.isEmpty()) {
                verificationModel.setVendor(vendorKey);
            }

            String verificationParam = ext.optString("verification_parameters");
            if (!verificationParam.isEmpty()) {
                verificationModel.setVerificationParameters(verificationParam);
            }
        }

        if (verificationModel.getJavaScriptResource() != null
                || verificationModel.getVendor() != null
                || verificationModel.getVerificationParameters() != null) {
            if (this.eventTrackers == null) {
                this.eventTrackers = new ArrayList<>();
            }
            this.eventTrackers.add(verificationModel);
        } else {
            return;
        }
    }

    @Nullable
    public String getMultiNativeAdBeacon() {
        return multiNativeAdBeacon;
    }

    public void setMultiNativeAdBeacon(@Nullable final String multiNativeAdBeacon) {
        this.multiNativeAdBeacon = multiNativeAdBeacon;
    }

    public void setInformationIconViewDefault(final boolean enable) {
        informationIconViewDefault = enable;
    }

    private void setMediationTarget(@Nullable final String type) {
        try {
            this.nativeAdType = ADGNativeAdType.valueOf(type);
        } catch (IllegalArgumentException | NullPointerException e) {
            this.nativeAdType = ADGNativeAdType.Undefined;
        }
    }

    // getter
    @Nullable
    public Integer getVer() {
        return ver;
    }

    @Nullable
    public ADGTitle getTitle() {
        return title;
    }

    @Nullable
    public ADGImage getMainImage() {
        return mainImage;
    }

    @Nullable
    public ADGImage getIconImage() {
        return iconImage;
    }

    @Nullable
    public ADGData getSponsored() {
        return sponsored;
    }

    @Nullable
    public ADGData getDesc() {
        return desc;
    }

    @Nullable
    public ADGData getCtatext() {
        return ctatext;
    }

    @Nullable
    public ADGVideo getVideo() {
        return video;
    }

    @Nullable
    public ADGData getAccompany() {
        return accompany;
    }

    @Nullable
    public ADGData getOptout() {
        return optout;
    }

    @Nullable
    public ADGData getInformationIcon() {
        return informationIcon;
    }

    @Nullable
    public ADGLink getLink() {
        return link;
    }

    @Nullable
    public ArrayList<VerificationModel> getEventTrackers() {
        return eventTrackers;
    }

    @Nullable
    public ArrayList<String> getTrackerViewableImp() {
        ADGLogger.getDevelopment().debug("trackerViewableImp = " + trackerViewableImp);
        return trackerViewableImp;
    }

    public void setTrackerViewableImp(@Nullable final ArrayList<String> urls) {
        ADGLogger.getDevelopment().debug("Set trackerViewableImp = " + urls);
        trackerViewableImp = urls;
    }

    @Nullable
    public String getJstracker() {
        return jstracker;
    }

    @Nullable
    public Object getExt() {
        return ext;
    }

    @NonNull
    public ADGNativeAdType getNativeAdType() {
        return nativeAdType;
    }

    @NonNull
    public ADGNativeAdController getController() {
        return controller;
    }

    public boolean getInformationIconViewDefault() {
        return informationIconViewDefault;
    }

    /** trackers内の全てのbeaconをHttpURLConnection(GET)を用いて呼び出す ・呼出し完了後、trackersは空にする */
    public static void callTrackers(@NonNull final List<String> trackers) {
        callTrackers(trackers, false);
    }

    public static void callTrackers(
            @NonNull final List<String> trackers, final boolean isPostMethod) {
        for (final String tracker : trackers) {
            HttpURLConnectionTask task =
                    new HttpURLConnectionTask(
                            tracker,
                            new AsyncTaskListener<String>() {
                                @Override
                                public void onSuccess(@Nullable String s) {
                                    ADGLogger.getDefault()
                                            .debug(
                                                    "Tracker calling is succeeded("
                                                            + tracker
                                                            + ").");
                                }

                                @Override
                                public void onError(@NonNull Exception e) {
                                    ADGLogger.getDefault()
                                            .debug("Tracker calling is failed(" + tracker + ").");
                                }
                            });
            if (isPostMethod) {
                task.setMethod("POST");
            }
            task.execute();
        }
        trackers.clear();
    }

    /**
     * WebView経由でjstrackerを呼び出す
     *
     * @param ct コンテキスト
     */
    public void callJstracker(@NonNull final Context ct) {
        if (this.jstrackerExecutor == null) {
            try {
                WebView w = new WebView(ct);
                w.getSettings().setJavaScriptEnabled(true);
                this.jstrackerExecutor = w;
            } catch (Exception e) {
                ADGLogger.getDefault()
                        .error("not called jstracker, problem using WebView for some reason.", e);
                return;
            }
        }
        this.jstrackerExecutor.clearCache(true);

        if (jstracker != null) {
            ADGLogger.getDefault().debug("call jstracker: " + jstracker);
            this.jstrackerExecutor.loadDataWithBaseURL(
                    ADGConsts.getWebViewBaseUrl(),
                    jstracker,
                    "text/html",
                    "UTF-8",
                    ADGConsts.getWebViewBaseUrl());
        }
    }

    /**
     * ViewにClickイベントを設定する - 処理はLinkクラスに委譲する
     *
     * @param v clickイベントを設定する対象
     */
    @Deprecated
    public void setClickEvent(@NonNull final View v) {
        if (link != null) {
            link.setClickEvent(v, null);
        }
    }

    /**
     * 指定した <code>view</code> にクリックイベントを設定します。また、ViewableやOM SDKの計測を開始します。
     *
     * @param context コンテキスト
     * @param view clickイベントを設定する対象
     * @param listener click listener
     */
    // FIXME: クリックイベントの設定以上のことをしているのでメソッド名を変更したい
    public void setClickEvent(
            @NonNull final Context context,
            @NonNull final View view,
            @Nullable final ADGNativeAdOnClickListener listener) {
        if (link != null) {
            this.view = view;

            link.setClickEvent(view, listener);

            if (informationIconViewDefault) {
                addInformationIconView(context, view, this);
            }

            // FIXME: メディアがこのメソッドを呼ばないとViewable,OMの計測を開始しないため、計測開始を別の箇所で実装することを検討する
            // Viewable計測開始
            startViewable();
            // OM SDK計測開始
            startNativeDisplayMeasurement(view);
            // OM SDKイベント発行
            sendNativeDisplayEvent();
        }
    }

    /**
     * インフォメーションアイコンを追加する. 既にアイコンが追加されている場合は削除してから追加する.
     *
     * @param context コンテキスト
     * @param view ネイティブ広告が配置されているview
     * @param nativeAd ネイティブ広告オブジェクト
     */
    private static void addInformationIconView(
            @NonNull final Context context,
            @NonNull final View view,
            @NonNull final ADGNativeAd nativeAd) {
        removeADGInformationIconView(view);
        if (ViewGroup.class.isAssignableFrom(view.getClass())) {
            ViewGroup viewGroup = (ViewGroup) view;
            ADGInformationIconView informationIconView =
                    ADGInformationIconView.create(context, nativeAd);
            if (informationIconView != null) {
                viewGroup.addView(informationIconView);
            }
        } else {
            ADGLogger.getDefault().warn("can't add an information icon to this view.");
        }
    }

    /**
     * インフォメーションアイコンを削除する
     *
     * @param view ネイティブ広告が配置されているview
     */
    private static void removeADGInformationIconView(@Nullable final View view) {
        if (view == null) return;

        if (view instanceof ADGInformationIconView) {
            ViewGroup parent = (ViewGroup) view.getParent();
            if (parent != null) {
                parent.removeView(view);
                return;
            }
        }
        if (ViewGroup.class.isAssignableFrom(view.getClass())) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                View child = viewGroup.getChildAt(i);
                ADGNativeAd.removeADGInformationIconView(child);
            }
        }
    }

    public void callClickTracker() {
        ADGLink link = getLink();
        if (link != null) {
            callTrackers(link.getClicktrackers());
            callTrackers(link.getPostClicktrackers(), true);
        }
    }

    public void callOnClick() {
        if (link != null) {
            link.callOnClick();
        }
    }

    public boolean canLoadMedia() {
        return (video != null && !TextUtils.isEmpty(video.getVasttag()))
                || (mainImage != null && !TextUtils.isEmpty(mainImage.getUrl()));
    }

    private boolean isVideoValid(@NonNull final Context context) {
        return getVideo() != null
                && !TextUtils.isEmpty(getVideo().getVasttag())
                && (context instanceof Activity)
                && Views.hasHardwareAcceleration((Activity) context);
    }

    public void stop() {
        ADGLogger.getDefault().debug("Stop the native ad.");

        // Viewable計測終了
        controller.finishViewableMeasurement();

        // OM SDK計測終了
        finishNativeDisplayMeasurement();
    }

    /**
     * OM SDK(NativeDisplay)の初期化
     *
     * @param ct コンテキスト
     */
    public void initNativeDisplayMeasurement(@NonNull Context ct) {
        if (this.getEventTrackers() != null) {
            // OM SDKの計測用インスタンスがすでに生成済みなら一旦Finishする
            if (nativeDisplayMeasurementManager == null) {
                // 計測用インスタンスを生成
                nativeDisplayMeasurementManager =
                        new NativeDisplayMeasurementManager(ct, this.getEventTrackers());
            } else {
                nativeDisplayMeasurementManager.finishMeasurement();
            }
        }
    }

    /**
     * OM SDK(NativeDisplay)の計測開始
     *
     * @param view 計測対象
     */
    private void startNativeDisplayMeasurement(@NonNull View view) {
        if (nativeDisplayMeasurementManager != null) {
            // 計測開始
            nativeDisplayMeasurementManager.startMeasurement(view);
        }
    }

    /** OM SDK(NativeDisplay)のimpイベントを送信する */
    private void sendNativeDisplayEvent() {
        if (nativeDisplayMeasurementManager != null) {
            // 計測イベント送信
            nativeDisplayMeasurementManager.sendNativeEvent(MeasurementConsts.nativeEvent.loaded);
            nativeDisplayMeasurementManager.sendNativeEvent(
                    MeasurementConsts.nativeEvent.impression);
        }
    }

    /** OM SDK(NativeDisplay)の計測終了 */
    private void finishNativeDisplayMeasurement() {
        if (nativeDisplayMeasurementManager != null) {
            // 計測終了
            nativeDisplayMeasurementManager.finishMeasurement();
        }
    }

    void destroyVideo() {
        playerAdManager.ifPresent(ADGPlayerAdManager::destroy);
        playerAdManager = Optional.empty();
    }

    boolean loadVideo(
            @NonNull final Context context,
            final boolean isTiny,
            @NonNull final OnShowVideoAdListener listener) {
        if (!isVideoValid(context)) {
            // 動画広告に対応していない
            return false;
        }

        final ADGPlayerAdManager manager = new ADGPlayerAdManager(context);
        playerAdManager = Optional.of(manager);

        manager.setIsTiny(isTiny);
        manager.setIsWipe(false);
        manager.setAdListener(
                new ADGPlayerAdListener() {
                    @Override
                    public void onReadyToPlayAd() {
                        playerAdManager.ifPresent(
                                manager -> manager.showAd(listener.onShowVideoAd()));
                    }

                    @Override
                    public void onFailedToPlayAd(@NonNull ADGPlayerError ADGPlayerError) {}

                    @Override
                    public void onStartVideo() {}

                    @Override
                    public void onClickAd() {
                        callOnClick();
                    }
                });

        assert getVideo() != null;
        manager.load(getVideo().getVasttag(), isNativeOptout);

        return true;
    }

    public void startViewable() {
        if (view != null) {
            controller.startViewableMeasurement(view, isVideoValid(view.getContext()));
        }
    }

    public void stopViewable() {
        controller.finishViewableMeasurement();
    }

    public interface OnShowVideoAdListener {
        @NonNull
        ViewGroup onShowVideoAd();
    }

    private final ADGNativeAdController.OnNativeAdControllerListener nativeAdControllerListener =
            new ADGNativeAdController.OnNativeAdControllerListener() {

                @Override
                public void onViewabilityChanged(
                        final boolean isViewable, @NonNull final String key) {
                    if (key.equals(ViewableParameter.VIDEO_AD.key)) {
                        if (isViewable) {
                            playerAdManager.ifPresent(ADGPlayerAdManager::callWhenInView);
                        } else {
                            playerAdManager.ifPresent(ADGPlayerAdManager::callWhenOutOfView);
                        }
                    }
                }
            };
}
