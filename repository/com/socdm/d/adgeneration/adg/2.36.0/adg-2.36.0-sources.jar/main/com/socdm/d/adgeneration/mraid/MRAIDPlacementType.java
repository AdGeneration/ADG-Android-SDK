package com.socdm.d.adgeneration.mraid;

import androidx.annotation.NonNull;

import java.util.Locale;

public enum MRAIDPlacementType {
    INLINE;

    @NonNull
    String toJavascriptString() {
        return toString().toLowerCase(Locale.US);
    }
}
