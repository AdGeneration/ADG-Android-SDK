package com.socdm.d.adgeneration.nativead.icon;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Transformation;

import androidx.annotation.NonNull;

public class ADGAnimation extends Animation {

    final int addWidth;
    @NonNull final View view;
    final int startWidth;

    public ADGAnimation(
            @NonNull final View view,
            final int addWidth,
            final int startWidth,
            final int duration) {
        this.view = view;
        this.addWidth = addWidth;
        this.startWidth = startWidth;
        this.setDuration(duration);
    }

    @Override
    protected void applyTransformation(
            final float interpolatedTime, @NonNull final Transformation t) {
        int newWidth = (int) (startWidth + addWidth * interpolatedTime);
        view.getLayoutParams().width = newWidth;
        view.requestLayout();
    }

    @Override
    public void initialize(
            final int width, final int height, final int parentWidth, final int parentHeight) {
        super.initialize(width, height, parentWidth, parentHeight);
    }

    @Override
    public boolean willChangeBounds() {
        return true;
    }
}
