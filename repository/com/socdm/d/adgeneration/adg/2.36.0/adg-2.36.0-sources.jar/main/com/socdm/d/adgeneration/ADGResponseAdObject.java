package com.socdm.d.adgeneration;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.nativead.ADGNativeAd;
import com.socdm.d.adgeneration.nativead.ADGNativeAdType;

import jp.supership.sscore.type.Optional;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

@Deprecated
public class ADGResponseAdObject {
    @NonNull private static final String RES_KEY_AD = "ad";
    @NonNull private static final String RES_KEY_AD_PARAMS = "ad_params";
    @NonNull private static final String RES_KEY_AD_PARAMS_ADM = "adm";

    @NonNull private static final String RES_KEY_BEACON = "beaconurl";
    @NonNull private static final String RES_KEY_SCHEDULE_ID = "scheduleid";

    @NonNull private static final String RES_KEY_TRACKERS = "trackers";
    @NonNull private static final String RES_TRACKERS_KEY_IMP = "imp";
    @NonNull private static final String RES_TRACKERS_KEY_VIEWABLE_MEASURED = "viewable_measured";
    @NonNull private static final String RES_TRACKERS_KEY_VIEWABLE_IMP = "viewable_imp";

    @NonNull private static final String RES_KEY_CREATIVE_PARAMS = "creative_params";

    @NonNull
    private static final String RES_KEY_CREATIVE_PARAMS_BIDDER_PARAMS =
            "bidder_params"; // Biddingソリューションに関する値が含まれる

    @NonNull
    private static final String RES_KEY_CREATIVE_PARAMS_SUCCESSFUL =
            "successful_bidder"; // Biddingソリューションの勝者に関する値が含まれる

    @NonNull
    private static final String RES_KEY_CREATIVE_PARAMS_TRACKERS = "trackers"; // Win/Lossの通知用URL

    @NonNull private static final String RES_CREATIVE_PARAMS_KEY_MEDIATION = "mediation";
    @NonNull private static final String RES_MEDIATION_KEY_TYPE = "type";
    @NonNull private static final String RES_MEDIATION_KEY_CLASS_NAME = "class";
    @NonNull private static final String RES_MEDIATION_KEY_AD_ID = "adid";
    @NonNull private static final String RES_MEDIATION_KEY_PARAM = "param";
    @NonNull private static final String RES_MEDIATION_KEY_MOVIE = "movie";

    @NonNull private static final String RES_KEY_NATIVE_AD = "native";
    @NonNull private static final String RES_KEY_NATIVE_AD_SINGLE = "native_ad";
    @NonNull private static final String RES_KEY_VAST_XML = "vastxml";
    @NonNull private static final String RES_KEY_CREATIVE_ID = "crid";
    @NonNull private static final String RES_KEY_DSP_ID = "dspid";
    @NonNull private static final String RES_KEY_ADNETWORK_ID = "adnwid";
    @NonNull private static final String RES_KEY_SEAT = "seat";

    @NonNull private final String ad;
    @Nullable private final String admPayload;
    @Nullable private String beacon;
    @NonNull private final String scheduleId;
    private int mediationType;
    @Nullable private String bidderSuccessfulName;
    @Nullable private String mediationClassName;
    @Nullable private String mediationAdId;
    @Nullable private String mediationParam;
    private int mediationMovie;
    @NonNull private final String creativeId;
    @NonNull private final String adNetworkId;
    @NonNull private final String dspId;
    @NonNull private final String seat;

    @Nullable private final ADGNativeAd nativeAd;
    @NonNull private final String vastXML;

    /** Viewable計測パラメータ */
    @NonNull final ResponseViewabilityParams viewabilityParams;

    @Nullable private ArrayList<String> trackerImp;
    @Nullable private ArrayList<String> trackerViewableMeasured;
    @Nullable private ArrayList<String> trackerViewableImp;
    @Nullable private ArrayList<String> trackerBiddingNotifyUrl;

    /**
     * @param obj
     */
    public ADGResponseAdObject(@NonNull final JSONObject obj, @NonNull final String locationId) {
        ad = obj.optString(RES_KEY_AD);
        beacon = obj.optString(RES_KEY_BEACON);
        scheduleId = obj.optString(RES_KEY_SCHEDULE_ID);
        creativeId = obj.optString(RES_KEY_CREATIVE_ID);
        adNetworkId = obj.optString(RES_KEY_ADNETWORK_ID);
        dspId = obj.optString(RES_KEY_DSP_ID);
        seat = obj.optString(RES_KEY_SEAT);

        final JSONObject adParams = obj.optJSONObject(RES_KEY_AD_PARAMS);
        if (adParams != null) {
            admPayload = adParams.optString(RES_KEY_AD_PARAMS_ADM);
        } else {
            admPayload = null;
        }

        final JSONObject tracker = obj.optJSONObject(RES_KEY_TRACKERS);
        if (tracker != null) {
            final JSONArray jsonImp = tracker.optJSONArray(RES_TRACKERS_KEY_IMP);
            if (jsonImp != null) {
                trackerImp = new ArrayList<>();
                for (int i = 0; i < jsonImp.length(); i++) {
                    trackerImp.add(jsonImp.optString(i));
                }
            }

            final JSONArray jsonViewableMeasured =
                    tracker.optJSONArray(RES_TRACKERS_KEY_VIEWABLE_MEASURED);
            if (jsonViewableMeasured != null) {
                trackerViewableMeasured = new ArrayList<>();
                for (int i = 0; i < jsonViewableMeasured.length(); i++) {
                    trackerViewableMeasured.add(jsonViewableMeasured.optString(i));
                }
            }

            final JSONArray jsonViewableImp = tracker.optJSONArray(RES_TRACKERS_KEY_VIEWABLE_IMP);
            if (jsonViewableImp != null) {
                trackerViewableImp = new ArrayList<>();
                for (int i = 0; i < jsonViewableImp.length(); i++) {
                    final String url = jsonViewableImp.optString(i);
                    if (!TextUtils.isEmpty(url)) {
                        trackerViewableImp.add(url);
                    }
                }
            }
        }

        final JSONObject creativeParams = obj.optJSONObject(RES_KEY_CREATIVE_PARAMS);
        if (creativeParams != null) {
            final JSONObject mediation =
                    creativeParams.optJSONObject(RES_CREATIVE_PARAMS_KEY_MEDIATION);
            if (mediation != null) {
                mediationType = mediation.optInt(RES_MEDIATION_KEY_TYPE);
                mediationClassName = mediation.optString(RES_MEDIATION_KEY_CLASS_NAME);
                mediationAdId = mediation.optString(RES_MEDIATION_KEY_AD_ID);
                mediationParam = mediation.optString(RES_MEDIATION_KEY_PARAM);
                mediationMovie = mediation.optInt(RES_MEDIATION_KEY_MOVIE);
            }

            final JSONObject bidderParams =
                    creativeParams.optJSONObject(RES_KEY_CREATIVE_PARAMS_BIDDER_PARAMS);
            if (bidderParams != null) {
                bidderSuccessfulName = bidderParams.optString(RES_KEY_CREATIVE_PARAMS_SUCCESSFUL);
            }

            final JSONArray notifyUrls =
                    creativeParams.optJSONArray(RES_KEY_CREATIVE_PARAMS_TRACKERS);
            if (notifyUrls != null) {
                trackerBiddingNotifyUrl = new ArrayList<>();
                for (int i = 0; i < notifyUrls.length(); i++) {
                    trackerBiddingNotifyUrl.add(notifyUrls.optString(i));
                }
            }
        }

        viewabilityParams = ResponseViewabilityParams.fromJson(creativeParams);

        vastXML = obj.optString(RES_KEY_VAST_XML);

        // ratio, durationに明示的に0が設定されている場合
        if (viewabilityParams.viewableParameter.ratio <= 0.0
                || viewabilityParams.viewableParameter.duration <= 0.0) {
            trackerImp = getTrackerThatRemovedBeacon(trackerImp);
            trackerViewableMeasured = null;
            trackerViewableImp = null;
        } else {
            if (viewabilityParams.chargeWhenLoading) {
                trackerImp = getTrackerThatRemovedBeacon(trackerImp);
                trackerViewableImp = getTrackerThatRemovedBeacon(trackerViewableImp);
            }
        }

        final JSONObject nativeAdParams;
        if (obj.has(RES_KEY_NATIVE_AD_SINGLE)) {
            nativeAdParams = obj.optJSONObject(RES_KEY_NATIVE_AD_SINGLE);
        } else {
            nativeAdParams = obj.optJSONObject(RES_KEY_NATIVE_AD);
        }
        if (nativeAdParams != null) {
            // ネイティブ広告種類の設定
            try {
                nativeAdParams.put(ADGNativeAdType.KEY, ADGNativeAdType.Default.name());
            } catch (JSONException e) {
                ADGLogger.getDefault().warn("Failed to set native ad type.", e);
            }
            nativeAd =
                    new ADGNativeAd(
                            locationId,
                            nativeAdParams,
                            trackerViewableImp,
                            viewabilityParams.toViewableParameters());
            setTrackerViewableImp(null);
        } else {
            nativeAd = null;
        }
    }

    @NonNull
    public String getAd() {
        return ad;
    }

    @Nullable
    public String getAdmPayload() {
        return admPayload;
    }

    @Nullable
    public String getBeacon() {
        return beacon;
    }

    public void setBeacon(@Nullable final String beacon) {
        this.beacon = beacon;
    }

    @NonNull
    public String getScheduleId() {
        return scheduleId;
    }

    @NonNull
    public String getCreativeId() {
        return creativeId;
    }

    @NonNull
    public String getAdNetworkId() {
        return adNetworkId;
    }

    @NonNull
    public String getDspId() {
        return dspId;
    }

    @NonNull
    public String getSeat() {
        return seat;
    }

    public int getMediationType() {
        return mediationType;
    }

    @Nullable
    public String getMediationClassName() {
        return mediationClassName;
    }

    @Nullable
    public String getMediationAdId() {
        return mediationAdId;
    }

    @Nullable
    public String getMediationParam() {
        return mediationParam;
    }

    public int getMediationMovie() {
        return mediationMovie;
    }

    @Nullable
    public String getBidderSuccessfulName() {
        return bidderSuccessfulName;
    }

    @Nullable
    public ArrayList<String> getTrackerBiddingNotifyUrl() {
        return trackerBiddingNotifyUrl;
    }

    public void setTrackerBiddingNotifyUrl(
            @Nullable final ArrayList<String> trackerBiddingNotifyUrl) {
        this.trackerBiddingNotifyUrl = trackerBiddingNotifyUrl;
    }

    @NonNull
    public Optional<ADGNativeAd> getNativeAd() {
        return Optional.of(nativeAd);
    }

    @NonNull
    public String getVastXML() {
        return vastXML;
    }

    @Nullable
    public ArrayList<String> getTrackerImp() {
        return trackerImp;
    }

    public void setTrackerImp(@Nullable final ArrayList<String> trackerImp) {
        this.trackerImp = trackerImp;
    }

    @Nullable
    public ArrayList<String> getTrackerViewableMeasured() {
        return trackerViewableMeasured;
    }

    public void setTrackerViewableMeasured(
            @Nullable final ArrayList<String> trackerViewableMeasured) {
        this.trackerViewableMeasured = trackerViewableMeasured;
    }

    @Nullable
    public ArrayList<String> getTrackerViewableImp() {
        ADGLogger.getDevelopment().debug("trackerViewableImp = " + trackerViewableImp);
        return trackerViewableImp;
    }

    public void setTrackerViewableImp(@Nullable final ArrayList<String> urls) {
        ADGLogger.getDevelopment().debug("Set trackerViewableImp = " + urls);
        trackerViewableImp = urls;
    }

    @Nullable
    private ArrayList<String> getTrackerThatRemovedBeacon(@Nullable final ArrayList<String> list) {
        if (list != null) {
            int index = list.indexOf(this.beacon);
            if (index != -1) {
                list.remove(index);
            }
        }
        return list;
    }
}
