package com.socdm.d.adgeneration.adloader

import com.socdm.d.adgeneration.AdParams
import com.socdm.d.adgeneration.adresponse.Response
import jp.supership.sscore.type.Result

/**
 * AdLoadableのデコレーター。
 * mraid.jsが存在しない場合、isMraidEnabledをfalseに強制設定してからAdLoaderに委譲する。
 *
 * iOS対応: MRAIDParamsFixedAdLoader class (ADGSwift/AdLoader/MRAIDParamsFixedAdLoader.swift)
 */
internal class MRAIDParamsFixedAdLoader(
    private val adLoader: AdLoadable,
    private val mraidJSReader: MRAIDSourceReadable,
) : AdLoadable {

    override val adParams: AdParams
        get() = adLoader.adParams

    override fun loadAd(beforeLoading: () -> Unit, completion: (Result<Response, AdLoadError>) -> Unit) {
        val mraidJS = mraidJSReader.readMRAIDSource()
        if (mraidJS.isNullOrEmpty()) {
            adParams.isMraidEnabled = false
        }
        adLoader.loadAd(beforeLoading, completion)
    }

    override fun cancelLoad() {
        adLoader.cancelLoad()
    }
}
