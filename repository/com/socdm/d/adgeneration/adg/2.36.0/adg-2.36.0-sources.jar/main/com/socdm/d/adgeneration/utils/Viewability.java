package com.socdm.d.adgeneration.utils;

import static android.view.View.VISIBLE;

import static com.socdm.d.adgeneration.ADGConsts.DEFAULT_RATIO;
import static com.socdm.d.adgeneration.ADGConsts.DEFAUTL_DURATION;

import android.content.Context;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.UiThread;
import androidx.core.os.HandlerCompat;

import java.lang.ref.WeakReference;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Viewable計測をおこなうクラスです */
public class Viewability {
    @Nullable private Context mContext = null; // コンテキスト
    @Nullable private WeakReference<View> mWeakView = null; // 計測対象View
    @Nullable private ViewabilityListener mListener = null; // Viewableの状態をコールバックするリスナー
    @Nullable private ViewableTask mTask = null; // Viewableの計測処理をHandler経由でディスパッチするワーカー
    private long mInterval = 500; // ワーカーの実行間隔(ms)
    @NonNull private ViewableState currentViewable = ViewableState.unmeasured; // Viewable状態
    private double mRatio = DEFAULT_RATIO; // inView基準となる視認領域
    private int mDuration = 1; // inView基準となる視認秒数
    private int durationCounter = 0; // 現在までの視認秒数をカウントする
    private boolean counterEnable = true; // 視認秒数をカウント有無を判定するフラグ

    /**
     * コンストラクタ
     *
     * <p>0.1秒間隔で計測し、視認領域が50%以上 & 1秒 でinViewと判定します
     *
     * @param context [Context]
     * @param view 計測対象となるView
     */
    public Viewability(@NonNull final Context context, @NonNull final View view) {
        mContext = context;
        mWeakView = new WeakReference<>(view);
    }

    /**
     * コンストラクタ
     *
     * <p>渡されたinterval秒間隔で計測し、視認領域が50%以上 & 1秒 でinViewと判定します
     *
     * @param context [Context]
     * @param view 計測対象となるView
     * @param interval
     */
    public Viewability(
            @NonNull final Context context, @NonNull final View view, final long interval) {
        mContext = context;
        mWeakView = new WeakReference<>(view);
        mInterval = interval;
    }

    /**
     * コンストラクタ
     *
     * <p>0.1秒ごとに計測し、視認領域がratio%以上 & duration秒 でinViewと判定します
     *
     * @param context [Context]
     * @param view 計測対象となるView
     * @param ratio
     * @param duration
     */
    public Viewability(
            @NonNull final Context context,
            @NonNull final View view,
            double ratio,
            double duration) {
        mContext = context;
        mWeakView = new WeakReference<>(view);
        if (ratio <= 0.0) ratio = DEFAULT_RATIO;
        if (duration <= 0.0) duration = DEFAUTL_DURATION;
        mRatio = ratio;
        mDuration = (int) (duration * 1000 / mInterval);
    }

    /** Viewable計測の開始します */
    public void start() {
        stop();

        if (mTask == null) {
            mTask = new ViewableTask();
        }
        mTask.start();
    }

    /** Viewable計測を停止します */
    public void stop() {
        currentViewable = ViewableState.unmeasured;
        durationCounter = 0;
        counterEnable = true;
        if (mTask != null) {
            mTask.stop();
            mTask = null;
        }
    }

    /**
     * Viewableの計測処理をHandler経由でディスパッチするワーカータスクです
     *
     * <p>このクラス内で定期実行している処理は、WorkerThreadに限らず、UIThreadで動作する可能性があります (Mraidに関する計測の場合、WebView上からの実行(UI
     * Thread)がありえるため)
     */
    @UiThread
    private class ViewableTask {
        @Nullable private ScheduledExecutorService executorService = null;
        @Nullable private Handler handler = null;
        @Nullable private Runnable mainThreadTask = null;

        /** 計測開始 WorkerThreadから定期実行で、Viewable計測処理をメインスレッドにディスパッチします */
        public void start() {
            LogUtils.d("Viewability Start. Primary ThreadId:" + Thread.currentThread().getId());

            if (executorService == null) {
                // シングルスレッドをプール
                executorService = Executors.newSingleThreadScheduledExecutor();
            }

            if (handler == null) {
                // メインスレッドへのHandlerを生成
                handler = HandlerCompat.createAsync(Looper.getMainLooper());
            }

            // 計測対象Viewの値チェック
            if (mWeakView == null) {
                LogUtils.d("Viewability mWeakView == null");
                return;
            }
            final View view = mWeakView.get();
            if (view == null) {
                LogUtils.d("Viewability view == null");
                return;
            }
            // メインスレッドで実行するViewable計測処理を生成
            mainThreadTask = new MainThreadTask(view);

            if (executorService == null) {
                LogUtils.d("Viewability executorService == null");
                return;
            }

            // WorkerThreadからメインスレッドへ処理をPostする
            try {
                executorService.scheduleWithFixedDelay(
                        () -> {
                            // Run background (worker Thread)
                            // LogUtils.d(
                            //        "Viewability worker ThreadId:"
                            //                 + Thread
                            //                 .currentThread()
                            //                 .getId());

                            if (handler == null || mListener == null || mWeakView == null) {
                                LogUtils.d("Viewability handler == null");
                                return;
                            }
                            if (mWeakView.get() == null) {
                                LogUtils.d("Viewability view == null");
                                return;
                            }

                            if (mContext == null) {
                                LogUtils.d("Viewability mContext == null");
                                Viewability.this.stop();
                                return;
                            }

                            if (!AppProcessUtils.isForeground(mContext)) {
                                LogUtils.d(
                                        "Viewability will stop because the app is not in the"
                                                + " foreground.");
                                Viewability.this.stop();
                                return;
                            }

                            handler.post(mainThreadTask);
                        },
                        0,
                        mInterval,
                        TimeUnit.MILLISECONDS);
            } catch (IllegalThreadStateException e) {
                LogUtils.e("Viewability worker thread start error", e);
            } catch (Exception e) {
                LogUtils.e("Viewability worker thread start Unknown error", e);
            }
        }

        /** 計測停止 */
        public void stop() {
            LogUtils.d("Viewability Stop. Primary ThreadId:" + Thread.currentThread().getId());
            mainThreadTask = null;

            if (handler != null) {
                handler.removeCallbacksAndMessages(null);
            }
            if (executorService != null) {
                executorService.shutdown();
            }
        }
    }

    /** 計測対象のViewが現在inViewかどうかを判定し、基準を満たした場合にコールバックをおこないます */
    @UiThread
    private class MainThreadTask implements Runnable {
        @NonNull private final View view;

        /**
         * コンストラクタ
         *
         * @param view 計測対象となるView
         */
        public MainThreadTask(@NonNull final View view) {
            this.view = view;
        }

        /** inView判定 */
        @Override
        public void run() {
            // Run main thread
            // LogUtils.d("Viewability UI ThreadId:" + Thread.currentThread().getId());
            // 現在の視認状態をチェック
            boolean isViewable = getViewability(view);
            if (isViewable) {
                switch (currentViewable) {
                    case unmeasured:
                    case outView:
                        currentViewable = ViewableState.inView;
                    case inView:
                        if (counterEnable) {
                            durationCounter++;
                        }
                        break;
                }
                if (mDuration <= durationCounter && counterEnable) {
                    if (mListener != null) {
                        mListener.onChange(true);
                    }
                    counterEnable = false;
                }
            } else {
                switch (currentViewable) {
                    case unmeasured:
                    case inView:
                        currentViewable = ViewableState.outView;
                        durationCounter = 0;
                        counterEnable = true;
                        if (mListener != null) {
                            mListener.onChange(false);
                        }
                        break;
                    case outView:
                        break;
                }
            }
        }
    }

    /**
     * 計測対象のViewの視認状態を監視します
     *
     * @param view 計測対象となるView
     * @return 視認されているならtrue/されていないならfalse
     */
    private boolean getViewability(@NonNull final View view) {
        if (view.getWindowVisibility() != VISIBLE
                || view.getVisibility() != VISIBLE
                || !view.isShown()) {
            return false;
        }

        // 画面上の位置
        int[] point = {view.getLeft(), view.getTop()};
        view.getLocationOnScreen(point);
        int x = point[0];
        int y = point[1];

        // viewの大きさ
        int width = view.getWidth();
        int height = view.getHeight();
        int area = width * height;

        // viewが配置されているwindowの大きさ(action barが含まれる)
        final Rect displayFrame = new Rect();
        view.getRootView().getWindowVisibleDisplayFrame(displayFrame);

        // contentView(action barが含まれない)
        ViewGroup contentView = (ViewGroup) view.getRootView().findViewById(android.R.id.content);
        if (contentView == null) {
            return false;
        }

        int xDistance;
        // contentViewより左にviewがあるとき
        if (x < contentView.getLeft()) {
            xDistance = contentView.getLeft() - x;
        }
        // contentViewの中にあるとき
        else if ((x + width) <= (contentView.getLeft() + contentView.getWidth())) {
            xDistance = 0;
        }
        // contentViewより右にviewがあるとき
        else {
            xDistance = (x + width) - (contentView.getLeft() + contentView.getWidth());
        }
        // 可視領域の幅
        xDistance = xDistance < 0 ? xDistance * -1 : xDistance;
        int inviewWidth = xDistance <= width ? width - xDistance : 0;

        int yDistance;
        // contentViewより上にviewがあるとき
        if (y < displayFrame.top + contentView.getTop()) {
            yDistance = displayFrame.top + contentView.getTop() - y;
        }
        // contentViewの中にあるとき
        else if ((y + height)
                <= (displayFrame.top + contentView.getTop() + contentView.getHeight())) {
            yDistance = 0;
        }
        // contentViewより下にviewがあるとき
        else {
            yDistance =
                    (y + height)
                            - (displayFrame.top + contentView.getTop() + contentView.getHeight());
        }
        // 可視領域の高さ
        yDistance = yDistance < 0 ? yDistance * -1 : yDistance;
        int inviewHeight = yDistance <= height ? height - yDistance : 0;

        // 可視領域
        int inviewArea = inviewWidth * inviewHeight;
        return inviewArea >= (area * mRatio);
    }

    /** inView/outViewのステータスの変更をコールバックするためのListenerです */
    public interface ViewabilityListener {
        void onChange(final boolean isViewable);
    }

    /**
     * inView/outViewのステータスの変更をコールバックするためのListenerを設定するためのメソッドです
     *
     * @param listener ViewabilityListener
     */
    public void setListener(@Nullable final ViewabilityListener listener) {
        mListener = listener;
    }

    /**
     * 現在の視認状態を返却します
     *
     * @return ViewableState
     */
    @NonNull
    public ViewableState getViewableState() {
        return currentViewable;
    }

    /** 視認状態のステータスを表すEnumです */
    public enum ViewableState {
        unmeasured,
        inView,
        outView
    }
}
