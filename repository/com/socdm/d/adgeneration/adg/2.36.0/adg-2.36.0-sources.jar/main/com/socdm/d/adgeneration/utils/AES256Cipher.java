package com.socdm.d.adgeneration.utils;

import android.annotation.SuppressLint;

import androidx.annotation.NonNull;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AES256Cipher {

    @NonNull private static final String CRYPTO_TYPE = "AES/CBC/PKCS5Padding";

    @SuppressLint("TrulyRandom")
    @NonNull
    public static byte[] encrypt(
            @NonNull final byte[] iv, @NonNull final byte[] key, @NonNull final byte[] text) {
        byte[] result = {};
        AlgorithmParameterSpec ivSpec = new IvParameterSpec(iv);
        SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
        try {
            Cipher cipher = Cipher.getInstance(CRYPTO_TYPE);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
            cipher.doFinal(text);
        } catch (NoSuchAlgorithmException
                | NoSuchPaddingException
                | InvalidKeyException
                | InvalidAlgorithmParameterException
                | IllegalBlockSizeException
                | BadPaddingException e) {
            e.printStackTrace();
        }
        return result;
    }

    @NonNull
    public static byte[] decrypt(
            @NonNull final byte[] iv, @NonNull final byte[] key, @NonNull final byte[] text) {
        byte[] result = {};
        AlgorithmParameterSpec ivSpec = new IvParameterSpec(iv);
        SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
        try {
            Cipher cipher = Cipher.getInstance(CRYPTO_TYPE);
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            result = cipher.doFinal(text);
        } catch (NoSuchAlgorithmException
                | InvalidKeyException
                | NoSuchPaddingException
                | InvalidAlgorithmParameterException
                | IllegalBlockSizeException
                | BadPaddingException e) {
            e.printStackTrace();
        }
        return result;
    }
}
