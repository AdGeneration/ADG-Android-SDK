package com.socdm.d.adgeneration.Measurement;

import androidx.annotation.NonNull;

public class MeasurementConsts {
    @NonNull public static final String PARTNER_NAME = "Supershipjp";
    @NonNull public static final String NOT_EXECUTED = "verificationNotExecuted";

    /** トラッキングイベント用 */
    public enum mediaEvents {
        impression, // インプレッション開始
        start, // 再生開始
        firstQuartile, // 25%
        midpoint, // 50%
        thirdQuartile, // 75%
        complete, // 100%
        pause, // 一時停止
        resume, // 再生再開
        bufferStart, // バッファリングにより再生を停止
        bufferEnd, // バッファリング後に再生を再開
        volumeChangeOn, // プレイヤーのボリュームをONに変更した
        volumeChangeOff, // プレイヤーのボリュームをOFFに変更した
        skipped, // 再生の早期終了
        finish, // プレイヤーの破棄
        // load, playerStateChange, adUserInteractionは別途引数が必要なため別で管理する
    }

    /** Nativeイベント用 */
    public enum nativeEvent {
        loaded, // ロード開始
        impression, // インプレッション開始
    }

    /** WebViewイベント用 */
    public enum webViewEvent {
        loaded, // ロード開始
        impression, // インプレッション開始
    }

    /** OM SDK初期化時に必要な広告別のフォーマット */
    public enum formatType {
        nativeVideo, // ネイティブ動画
        nativeDisplay, // ネイティブ広告
        webViewDisplay, // バナー広告
        webViewVideo, // WebView動画
    }
}
