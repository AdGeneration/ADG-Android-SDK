package com.socdm.d.adgeneration.video.vast;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.utils.HttpURLConnectionTask;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.Measurement.VerificationModel;
import com.socdm.d.adgeneration.video.config.Const;

import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

public class VastAd implements Serializable {
    // Regex patterns
    @NonNull
    private static final Pattern percentagePattern = Pattern.compile("((\\d{1,2})|(100))%");

    @NonNull
    private static final Pattern absolutePattern =
            Pattern.compile("\\d{1,2}:\\d{1,2}:\\d{1,2}(.\\d{1,3})?");

    // tracking
    @NonNull
    private static final List<VastTrackingEvent> clearTrackings =
            new ArrayList<VastTrackingEvent>() {
                {
                    add(VastTrackingEvent.START);
                    add(VastTrackingEvent.FIRST_QUARTILE);
                    add(VastTrackingEvent.MIDPOINT);
                    add(VastTrackingEvent.THIRD_QUARTILE);
                    add(VastTrackingEvent.COMPLETE);
                }
            };

    // ad
    @Nullable private String vastVersion;
    @Nullable private String adId;
    @Nullable private String adSystem;
    @Nullable private String adTitle;
    @Nullable private String description;
    @Nullable private String advertiser;

    // creatives
    @Nullable private String creativeId;
    @Nullable private String durationString;
    @Nullable private String skipOffsetString;

    @NonNull private ArrayList<URL> impressions;
    @NonNull private HashMap<String, ArrayList<URL>> trackingEvents;
    @Nullable private String clickThrough;
    @NonNull private ArrayList<URL> clickTrackings;
    @NonNull private ArrayList<VastProgress> progressTrackings;
    @NonNull private ArrayList<URL> errors;
    @NonNull private ArrayList<MediaFile> mediaFiles;
    @Nullable private String bestMediaFileDiskUrl;
    @Nullable private String bestMediaFileNetworkUrl;
    @NonNull private HashMap<String, ArrayList<URL>> trackingEventExtensions;
    @NonNull private ArrayList<VASTIcon> icons;
    @Nullable private VASTIcon closestIcon;

    // Open Measurement SDK
    @NonNull private ArrayList<VerificationModel> verifications;

    private float currentTime;

    // status
    @NonNull private VastEventState mVastEventState;
    private boolean mWasThroughSkipOffset;
    private long mVastProgressTime;
    private int mVastProgressPercentage;

    public static class VastProgress implements Serializable {
        @NonNull private final String offset;
        @NonNull private final URL url;

        private long time = -1;
        private float percentage = -1;

        public VastProgress(@NonNull String offset, @NonNull URL url) {
            this.offset = offset;
            this.url = url;

            calcOffset();
        }

        private void calcOffset() {
            try {
                if (isAbsoluteTracker(offset)) {
                    Integer result = parseAbsoluteOffset(offset);
                    if (result != null) {
                        time = result;
                    } else {
                        LogUtils.e("progress parse err.");
                    }
                } else if (isPercentageTracker(offset)) {
                    percentage = Float.parseFloat(offset.replace("%", ""));
                } else {
                    LogUtils.e("progress parse err.");
                }
            } catch (Exception e) {
                LogUtils.e("progress parse err.");
            }
        }
    }

    public VastAd() {
        impressions = new ArrayList<>();
        trackingEvents = new HashMap<>();
        clickTrackings = new ArrayList<>();
        progressTrackings = new ArrayList<>();
        errors = new ArrayList<>();
        trackingEventExtensions = new HashMap<>();
        mediaFiles = new ArrayList<>();
        icons = new ArrayList<>();

        // Open Measurement SDK
        verifications = new ArrayList<>();

        reset();
        //        movieCancelEnable = true;
    }

    public void release() {
        impressions.clear();
        trackingEvents.clear();
        clickTrackings.clear();
        progressTrackings.clear();
        errors.clear();
        trackingEventExtensions.clear();
        mediaFiles.clear();
        icons.clear();
        closestIcon = null;
        verifications.clear();
    }

    public void setVastVersion(@Nullable final String vastVersion) {
        this.vastVersion = vastVersion;
    }

    @Nullable
    public String getAdId() {
        return adId;
    }

    public void setAdId(@Nullable final String adId) {
        this.adId = adId;
    }

    public void setAdSystem(@Nullable final String adSystem) {
        this.adSystem = adSystem;
    }

    public void setAdTitle(@Nullable final String adTitle) {
        this.adTitle = adTitle;
    }

    public void setDescription(@Nullable final String description) {
        this.description = description;
    }

    public void setAdvertiser(@Nullable final String advertiser) {
        this.advertiser = advertiser;
    }

    public void setCreativeId(@Nullable final String creativeId) {
        this.creativeId = creativeId;
    }

    public void setDurationString(@Nullable final String durationString) {
        this.durationString = durationString;
    }

    public void setSkipOffsetString(@Nullable final String skipOffsetString) {
        this.skipOffsetString = skipOffsetString;
    }

    @Nullable
    public VASTIcon getClosestIcon() {
        return closestIcon;
    }

    public void setClosestIcon(@Nullable final VASTIcon closestIcon) {
        this.closestIcon = closestIcon;
    }

    @NonNull
    public ArrayList<VASTIcon> getIcons() {
        return icons;
    }

    @NonNull
    public ArrayList<VerificationModel> getVerifications() {
        return verifications;
    }

    @NonNull
    public ArrayList<URL> getImpressions() {
        return impressions;
    }

    @NonNull
    public HashMap<String, ArrayList<URL>> getTrackingEvents() {
        return trackingEvents;
    }

    @Nullable
    public String getClickThrough() {
        return this.clickThrough;
    }

    public void setClickThrough(@Nullable final String clickThrough) {
        this.clickThrough = clickThrough;
    }

    @NonNull
    public ArrayList<VastProgress> getProgressTrackings() {
        return progressTrackings;
    }

    public void setProgressTrackings(@NonNull final ArrayList<VastProgress> progressTrackings) {
        this.progressTrackings = progressTrackings;
    }

    @NonNull
    public ArrayList<URL> getClickTrackings() {
        return clickTrackings;
    }

    @NonNull
    public ArrayList<URL> getErrors() {
        return errors;
    }

    public void setErrors(@NonNull final ArrayList<URL> errors) {
        this.errors = errors;
    }

    @NonNull
    public ArrayList<MediaFile> getMediaFiles() {
        return mediaFiles;
    }

    @Nullable
    public String getBestMediaFileUrl() {
        if (!TextUtils.isEmpty(bestMediaFileDiskUrl)) {
            return bestMediaFileDiskUrl;
        } else {
            return bestMediaFileNetworkUrl;
        }
    }

    public void setBestMediaFileDiskUrl(@Nullable final String bestMediaFileDiskUrl) {
        this.bestMediaFileDiskUrl = bestMediaFileDiskUrl;
    }

    @Nullable
    public String getBestMediaFileNetworkUrl() {
        return bestMediaFileNetworkUrl;
    }

    public void setBestMediaFileNetworkUrl(@Nullable final String bestMediaFileNetworkUrl) {
        this.bestMediaFileNetworkUrl = bestMediaFileNetworkUrl;
    }

    public float getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(final float currentTime) {
        this.currentTime = currentTime;
    }

    @NonNull
    public VastEventState getVastEventState() {
        return mVastEventState;
    }

    public int getDuration() {
        try {
            Integer duration = parseAbsoluteOffset(durationString);
            if (duration == null) {
                throw new AndroidRuntimeException("Invalid VAST duration format:" + durationString);
            }
            return duration;
        } catch (Exception e) {
            throw new AndroidRuntimeException("Invalid VAST duration format:" + durationString);
        }
    }

    public void setVerifications(@NonNull final ArrayList<VerificationModel> verifications) {
        this.verifications = verifications;
    }

    private void reset() {
        mVastEventState = VastEventState.NONE;
        currentTime = 0;
        mWasThroughSkipOffset = false;
        mVastProgressTime = 0;
        mVastProgressPercentage = 0;
    }

    public boolean compareStateNext(@NonNull final VastEventState state) {
        return mVastEventState.compareTo(state) < 0;
    }

    public void impressions() {
        for (URL url : impressions) {
            trackingURL(url, "impression");
        }
        // 2度呼び防止のためクリア
        LogUtils.d("Clear tracking[impression]");
        impressions.clear();

        creativeView();
        mVastEventState = VastEventState.IMPRESSION;
    }

    private void trackingClick() {
        for (URL url : clickTrackings) {
            trackingURL(url, "click");
        }
    }

    public void clickThrough(@NonNull final Context context) {
        this.trackingClick();
        if (clickThrough != null) {
            try {
                // FIXME: ModelっぽいVastAdの中でstartActivityを呼ぶのは適切ではない
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(clickThrough));
                context.startActivity(i);
                LogUtils.d("Click redirect to: " + clickThrough);
            } catch (ActivityNotFoundException e) {
                LogUtils.e("No Activity found to handle Intent");
            }
        }
    }

    public void trackEvent(@NonNull final VastTrackingEvent event) {
        if (trackingEvents.containsKey(event.toString())) {
            ArrayList<URL> urls = trackingEvents.get(event.toString());
            if (urls != null) {
                for (URL url : urls) {
                    trackingURL(url, event.toString());
                }
            }

            // 2度呼び防止のためクリア
            if (clearTrackings.contains(event)) {
                LogUtils.d("Clear tracking[" + event + "]");
                trackingEvents.remove(event.toString());
            }
        }
    }

    private void trackingURL(@NonNull final URL url, @NonNull final String event) {
        if (Const.STOP_TRACKING) {
            LogUtils.d("停止中！！Tracking[" + event + "]");
        } else {
            HttpURLConnectionTask request = new HttpURLConnectionTask(url.toString(), null);
            request.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            LogUtils.d("Tracking[" + event + "]");
        }
    }

    /** TODO: creativeView is private because always called with impression */
    private void creativeView() {
        trackEvent(VastTrackingEvent.CREATIVE_VIEW);
    }

    public void start() {
        trackEvent(VastTrackingEvent.START);
        mVastEventState = VastEventState.START;
    }

    public void firstQuartile() {
        trackEvent(VastTrackingEvent.FIRST_QUARTILE);
        mVastEventState = VastEventState.FIRST_QUARTILE;
    }

    public void midpoint() {
        trackEvent(VastTrackingEvent.MIDPOINT);
        mVastEventState = VastEventState.MIDPOINT;
    }

    public void thirdQuartile() {
        trackEvent(VastTrackingEvent.THIRD_QUARTILE);
        mVastEventState = VastEventState.THIRD_QUARTILE;
    }

    public void complete() {
        trackEvent(VastTrackingEvent.COMPLETE);
        mVastEventState = VastEventState.COMPLETE;
    }

    public void mute() {
        trackEvent(VastTrackingEvent.MUTE);
    }

    public void unmute() {
        trackEvent(VastTrackingEvent.UNMUTE);
    }

    public void pause() {
        trackEvent(VastTrackingEvent.PAUSE);
    }

    public void resume() {
        trackEvent(VastTrackingEvent.RESUME);
    }

    public void inView() {
        trackEvent(VastTrackingEvent.EXT_INVIEW);
    }

    public void outView() {
        trackEvent(VastTrackingEvent.EXT_OUTVIEW);
    }

    public static boolean isPercentageTracker(@Nullable final String progressValue) {
        return !TextUtils.isEmpty(progressValue)
                && percentagePattern.matcher(progressValue).matches();
    }

    public static boolean isAbsoluteTracker(@Nullable final String progressValue) {
        return !TextUtils.isEmpty(progressValue)
                && absolutePattern.matcher(progressValue).matches();
    }

    @Nullable
    public static Integer parseAbsoluteOffset(@Nullable final String progressValue) {
        if (progressValue == null) {
            return null;
        }
        final String[] split = progressValue.split(":");
        if (split.length != 3) {
            return null;
        }

        return Integer.parseInt(split[0]) * 60 * 60 * 1000 // Hours
                + Integer.parseInt(split[1]) * 60 * 1000 // Minutes
                + (int) (Float.parseFloat(split[2]) * 1000);
    }

    public void progress(final long time, final int percentage) {
        //        trackEvent(VastTrackingEvent.PROGRESS);
        if (time > mVastProgressTime) {
            VastProgress trackedProgress = null;
            for (VastProgress progress : progressTrackings) {
                if (progress.time > mVastProgressTime && time >= progress.time) {
                    trackingURL(progress.url, "progress[" + progress.offset + "]");

                    trackedProgress = progress;
                }
                if (progress.percentage > mVastProgressPercentage
                        && percentage >= progress.percentage) {
                    trackingURL(progress.url, "progress[" + progress.offset + "]");

                    trackedProgress = progress;
                }
            }

            // 2度呼び防止のためクリア
            if (trackedProgress != null) {
                LogUtils.d("Clear tracking[progress " + trackedProgress.offset + "]");
                progressTrackings.remove(trackedProgress);
            }
        }

        mVastProgressTime = time;
        mVastProgressPercentage = percentage;
    }
}
