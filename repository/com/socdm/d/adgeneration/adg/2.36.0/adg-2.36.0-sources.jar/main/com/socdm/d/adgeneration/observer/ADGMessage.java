package com.socdm.d.adgeneration.observer;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ADGMessage {

    @NonNull private String type;
    @Nullable private Object message;

    public ADGMessage(@NonNull final String type, @Nullable final Object message) {
        this.setType(type);
        this.message = message;
    }

    @NonNull
    public String getType() {
        return type;
    }

    public void setType(@NonNull final String type) {
        this.type = type;
    }

    @Nullable
    public Object getMessage() {
        return message;
    }

    public void setMessage(@Nullable final Object message) {
        this.message = message;
    }
}
