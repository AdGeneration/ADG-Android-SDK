package com.socdm.d.adgeneration.video.utils;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.utils.HttpUtils;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.ADGPlayerError;
import com.socdm.d.adgeneration.video.config.Const;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

public class AdRequestTask extends AsyncTask<URL, Integer, String> {
    public static final String SUCCESS = "success";
    public static final String FAILED = "failed";

    @Nullable private final AdRequestTaskListener listener;
    @Nullable private Map<String, List<String>> responseHeader;
    @Nullable private String responseBody;
    @NonNull private Context mContext;

    public interface AdRequestTaskListener {
        void onPostExecute(@Nullable Map<String, List<String>> header, @Nullable String body);

        void onCancelled();
    }

    public AdRequestTask(@Nullable AdRequestTaskListener asyncCallback, @NonNull Context context) {
        this.listener = asyncCallback;
        this.mContext = context;
    }

    @NonNull
    @Override
    protected String doInBackground(@Nullable URL... urls) {
        InputStream in = null;
        try {
            HttpURLConnection connection = (HttpURLConnection) urls[0].openConnection();
            connection.setUseCaches(false);
            connection.setRequestMethod("GET");
            connection.setReadTimeout(Const.HTTP_REQUEST_TIMEOUT);
            String userAgent = HttpUtils.getUserAgent(mContext);
            if (userAgent != null) {
                connection.setRequestProperty("User-Agent", userAgent);
            }
            connection.connect();

            in = connection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            responseBody = sb.toString();
            responseHeader = connection.getHeaderFields();
            return SUCCESS;
        } catch (Exception e) {
            LogUtils.e(ADGPlayerError.NETWORK_ERROR.toString(), e);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                    LogUtils.e(ADGPlayerError.UNSPECIFIED.toString(), e);
                }
            }
        }

        return FAILED;
    }

    @Override
    protected void onPostExecute(@NonNull String result) {
        super.onPostExecute(result);
        if (this.listener != null) {
            this.listener.onPostExecute(responseHeader, responseBody);
        }
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
        if (this.listener != null) {
            this.listener.onCancelled();
        }
    }
}
