package com.socdm.d.adgeneration.mediation;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.IADGLogger;
import com.socdm.d.adgeneration.utils.LogUtils;

import java.util.ArrayList;
import java.util.List;

public class ADGNativeInterface {
    @Nullable private Context ct;
    @Nullable private ADGNativeInterfaceListener listener;
    @Nullable private String className;
    @Nullable private String adId;
    @Nullable private String param;
    @Nullable private ViewGroup layout;
    @NonNull private Integer width = 0;
    @NonNull private Integer height = 0;
    @NonNull private Integer movie = 0;
    @Nullable private ADGNativeInterfaceChild childAd;
    @NonNull private Boolean calledStart = false;
    @NonNull private Boolean enableSound = false;
    @NonNull private Boolean enableTestMode = false;
    @NonNull private Boolean usePartsResponse = false;
    @NonNull private Boolean callNativeAdTrackers = true;
    @NonNull private Boolean expandFrame = false;
    @NonNull private Boolean isWipe = false;
    @Nullable private String contentUrl;
    @Nullable private String admPayload;
    @Nullable private String bidderSuccessfulName;
    @Nullable private ArrayList<String> biddingNotifyUrl;

    @NonNull private static final List<String> errorClassNames = new ArrayList<>();
    private static final int CONDITION_BORDER = 2;

    @NonNull
    private final Handler handler =
            new Handler(Looper.myLooper() != null ? Looper.myLooper() : Looper.getMainLooper());

    @NonNull private final IADGLogger logger;
    @NonNull private final MediationController controller;

    @SuppressWarnings("FieldCanBeLocal")
    @NonNull
    private final MediationController.MediationControllerListener mediationControllerListener =
            new MediationController.MediationControllerListener() {
                @Override
                public void onReachedRotation() {
                    if (listener != null) {
                        listener.onReachRotateTime();
                    }
                }

                @Override
                public void onTimedOut() {
                    if (listener != null) {
                        listener.onFailedToReceiveAd();
                    }
                }
            };

    public ADGNativeInterface(
            @NonNull final MediationModel model, @NonNull final IADGLogger logger) {
        super();
        this.logger = logger;
        this.controller = new MediationController(model, mediationControllerListener, logger);
    }

    public static boolean isValidClassName(@Nullable final String name) {
        if (TextUtils.isEmpty(name)) return false;

        final String className = MediationClassNameMapper.getCorrectClassName(name);
        try {
            Class.forName(className);
        } catch (ClassNotFoundException e) {
            addErrorClassName(className);
            return false;
        }

        return !errorClassNames.contains(className);
    }

    private static int numOfInvalidClasses() {
        return errorClassNames.size();
    }

    public static boolean isNormalCondition() {
        return numOfInvalidClasses() < CONDITION_BORDER;
    }

    private static void addErrorClassName(@Nullable final String str) {
        if (str == null) {
            return;
        }

        if (!errorClassNames.contains(str)) {
            errorClassNames.add(str);
        }
    }

    public void setContext(@Nullable final Context ct) {
        this.ct = ct;
    }

    public void setListener(@Nullable final ADGNativeInterfaceListener listener) {
        this.listener = listener;
    }

    public void setClassName(@Nullable final String className) {
        this.className = className;
    }

    public void setAdId(@Nullable final String adId) {
        this.adId = adId;
    }

    public void setMovie(final int movie) {
        this.movie = movie;
    }

    public void setParam(@Nullable final String param) {
        this.param = param;
    }

    public void setExpandFrame(final boolean expandFrame) {
        this.expandFrame = expandFrame;
    }

    public void setLayout(@Nullable final ViewGroup layout) {
        this.layout = layout;
    }

    public void setSize(final int width, final int height) {
        this.width = width;
        this.height = height;
    }

    public void setEnableSound(@NonNull final Boolean enableSound) {
        this.enableSound = enableSound;
    }

    public void setEnableTestMode(@NonNull final Boolean enableTestMode) {
        this.enableTestMode = enableTestMode;
    }

    public void setUsePartsResponse(@NonNull final Boolean usePartsResponse) {
        this.usePartsResponse = usePartsResponse;
    }

    public void setCallNativeAdTrackers(@NonNull final Boolean callNativeAdTrackers) {
        this.callNativeAdTrackers = callNativeAdTrackers;
    }

    public void setContentUrl(@Nullable final String url) {
        this.contentUrl = url;
    }

    public void setIsWipe(final boolean isWipe) {
        this.isWipe = isWipe;
    }

    public void setAdmPayload(@Nullable final String admPayload) {
        this.admPayload = admPayload;
    }

    public void setBidderSuccessfulName(@Nullable final String bidderSuccessfulName) {
        this.bidderSuccessfulName = bidderSuccessfulName;
    }

    public void setBiddingNotifyUrl(@Nullable final ArrayList<String> biddingNotifyUrl) {
        this.biddingNotifyUrl = biddingNotifyUrl;
    }

    public void callWhenInView() {
        if (this.childAd != null) {
            this.childAd.callWhenInView();
        }
    }

    public void callWhenOutOfView() {
        if (this.childAd != null) {
            this.childAd.callWhenOutOfView();
        }
    }

    public Boolean loadChild(@Nullable final String locationId) {
        if (this.className == null || this.className.isEmpty()) {
            return false;
        }

        this.className = MediationClassNameMapper.getCorrectClassName(className);

        if (!isValidClassName(this.className)) {
            return false;
        }

        try {
            Class<?> cls = Class.forName(this.className);
            this.childAd = (ADGNativeInterfaceChild) cls.newInstance();
        } catch (InstantiationException
                | ClassNotFoundException
                | IllegalAccessException
                | ClassCastException
                | NoClassDefFoundError e) {
            return errorProcess(e);
        }

        this.childAd.setLocationId(locationId);
        this.childAd.setContext(this.ct);
        this.childAd.setAdId(this.adId);
        this.childAd.setParam(this.param);
        this.childAd.setLayout(this.layout);
        this.childAd.setSize(this.width, this.height);
        this.childAd.setEnableSound(this.enableSound);
        this.childAd.setEnableTestMode(this.enableTestMode);
        this.childAd.setExpandFrame(this.expandFrame);
        this.childAd.setUsePartsResponse(this.usePartsResponse);
        this.childAd.setCallNativeAdTrackers(this.callNativeAdTrackers);
        this.childAd.setContentUrl(this.contentUrl);
        this.childAd.setIsWipe(this.isWipe);
        this.childAd.setAdmPayload(this.admPayload);
        this.childAd.setBidderSuccessfulName(this.bidderSuccessfulName);
        this.childAd.setBiddingNotifyUrl(this.biddingNotifyUrl);
        this.childAd.setListener(
                new ADGNativeInterfaceChildListener() {
                    @Override
                    public void onReceiveAd() {
                        beforeListener();
                        if (listener != null) {
                            listener.onReceiveAd();
                        }
                    }

                    @Override
                    public void onReceiveAd(@NonNull Object nativeAd) {
                        beforeListener();
                        if (listener != null) {
                            listener.onReceiveAd(nativeAd);
                        }
                    }

                    @Override
                    public void onFailedToReceiveAd() {
                        beforeListener();
                        if (listener != null) {
                            listener.onFailedToReceiveAd();
                        }
                    }

                    @Override
                    public void onCompleteMovieAd() {
                        controller.isMovieCompleted = true;
                        beforeListener();
                        controller.setMediationTimer();
                    }

                    @Override
                    public void onClickAd() {
                        if (listener != null) {
                            listener.onClickAd();
                        }
                    }

                    @Override
                    public void onReplayMovieAd() {
                        controller.clearMediationTimer();
                    }

                    @Override
                    public void onReadyMediation(@NonNull Object mediation) {
                        if (listener != null) {
                            listener.onReadyMediation(mediation);
                        }
                    }

                    @Override
                    public void onSuccessfulBidder(@NonNull String bidderSuccessfulName) {
                        if (listener != null) {
                            listener.onSuccessfulBidder(bidderSuccessfulName);
                        }
                    }
                });

        if (!this.childAd.checkOSVersion()) {
            writeLog("Not supported OS");
            addErrorClassName(className);
            return false;
        }

        try {
            controller.isProcessing = this.childAd.loadProcess();
        } catch (NoClassDefFoundError e) {
            return errorProcess(e);
        }
        return this.controller.isProcessing;
    }

    public void startChild() {
        controller.setMediationTimer();

        if (this.childAd != null) {
            if (!this.calledStart) {
                this.calledStart = true;
                this.childAd.startProcess();
            }
        }
    }

    public void stopChild() {
        controller.clearMediationTimer();

        if (this.childAd != null) {
            this.childAd.stopProcess();
        }
    }

    public void finishChild() {
        controller.clearMediationTimer();
        if (this.childAd != null) {
            this.childAd.finishProcess();
            this.childAd = null;
        }
    }

    // 現在はメディエーションはすべてtrue
    public Boolean isLateImp() {
        return true;
    }

    @NonNull
    private Boolean errorProcess(@NonNull final Throwable e) {
        addErrorClassName(this.className);
        writeLog(e.getMessage());
        this.childAd = null;
        return false;
    }

    private void beforeListener() {
        controller.isProcessing = false;
    }

    public void resumeMediationTimer() {
        controller.resumeMediationTimer();
    }

    public void pauseMediationTimer() {
        controller.pauseMediationTimer();
    }

    private void writeLog(@Nullable final String str) {
        LogUtils.w("Mediation Error:" + str);
    }
}
