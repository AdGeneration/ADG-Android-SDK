package com.socdm.d.adgeneration.mraid;

import android.net.Uri;
import android.text.TextUtils;

import androidx.annotation.Nullable;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URLDecoder;

public class MRAIDHandlerResult {
    private boolean mShouldLoadRequest = false;
    @Nullable private Uri mOpenURL = null;

    MRAIDHandlerResult(final boolean shouldLoadRequest) {
        mShouldLoadRequest = shouldLoadRequest;
    }

    MRAIDHandlerResult(final boolean shouldLoadRequest, @Nullable final String openURL)
            throws MalformedURLException {
        mShouldLoadRequest = shouldLoadRequest;

        if (!TextUtils.isEmpty(openURL)) {
            try {
                String urlStr = URLDecoder.decode(openURL, "UTF-8");
                mOpenURL = Uri.parse(urlStr);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                return;
            }
        } else {
            throw new MalformedURLException("openURL");
        }
    }

    public boolean getShouldLoadRequest() {
        return mShouldLoadRequest;
    }

    @Nullable
    public Uri getOpenURL() {
        return mOpenURL;
    }
}
