package com.socdm.d.adgeneration.mraid;

import android.graphics.Rect;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.utils.LogUtils;

import org.json.JSONObject;

public class MRAIDBridge {

    static void setCurrentPosition(@NonNull final WebView webView, @NonNull final Rect rect) {
        String js = "mraidbridge.setCurrentPosition(" + stringifyRect(rect) + ");";
        injectJavaScript(webView, js);
    }

    static void setDefaultPosition(@NonNull final WebView webView, @NonNull final Rect rect) {
        String js = "mraidbridge.setDefaultPosition(" + stringifyRect(rect) + ");";
        injectJavaScript(webView, js);
    }

    static void setMaxSize(@NonNull final WebView webView, @NonNull final Rect rect) {
        String js = "mraidbridge.setMaxSize(" + stringifySize(rect) + ");";
        injectJavaScript(webView, js);
    }

    static void setScreenSize(@NonNull final WebView webView, @NonNull final Rect rect) {
        String js = "mraidbridge.setScreenSize(" + stringifySize(rect) + ");";
        injectJavaScript(webView, js);
    }

    static void setPlacementType(
            @NonNull final WebView webView, @NonNull final MRAIDPlacementType placementTyp) {
        String js =
                "mraidbridge.setPlacementType("
                        + JSONObject.quote(placementTyp.toJavascriptString())
                        + ");";
        injectJavaScript(webView, js);
    }

    static void setState(@NonNull final WebView webView, @NonNull final MRAIDState state) {
        String js = "mraidbridge.setState(" + JSONObject.quote(state.toJavascriptString()) + ");";
        injectJavaScript(webView, js);
    }

    static void setIsViewable(@NonNull final WebView webView, final boolean isViewable) {
        String js = "mraidbridge.setIsViewable(" + stringifyBool(isViewable) + ");";
        injectJavaScript(webView, js);
    }

    static void notifyReadyEvent(@NonNull final WebView webView) {
        injectJavaScript(webView, "mraidbridge.notifyReadyEvent();");
    }

    static void notifyErrorEvent(
            @NonNull final WebView webView,
            @NonNull final String message,
            @NonNull final MRAIDCommand command) {
        String js =
                "mraidbridge.notifyErrorEvent("
                        + JSONObject.quote(message)
                        + ","
                        + JSONObject.quote(command.toJavascriptString())
                        + ");";
        injectJavaScript(webView, js);
    }

    static void nativeCallComplete(
            @NonNull final WebView webView, @NonNull final MRAIDCommand command) {
        String js =
                "mraidbridge.nativeCallComplete("
                        + JSONObject.quote(command.toJavascriptString())
                        + ");";
        injectJavaScript(webView, js);
    }

    private static void injectJavaScript(
            @Nullable final WebView webView, @NonNull final String javascript) {
        if (webView == null) {
            LogUtils.d(
                    "Attempted to inject Javascript into MRAID WebView while was not attached:\n\t"
                            + javascript);
            return;
        }
        LogUtils.d("Injecting Javascript into MRAID WebView: " + javascript);
        webView.loadUrl("javascript:" + javascript);
    }

    @NonNull
    private static String stringifyRect(@NonNull final Rect rect) {
        return rect.left + "," + rect.top + "," + rect.width() + "," + rect.height();
    }

    @NonNull
    private static String stringifySize(@NonNull final Rect rect) {
        return rect.width() + "," + rect.height();
    }

    @NonNull
    private static String stringifyBool(final boolean bool) {
        return bool ? "true" : "false";
    }
}
