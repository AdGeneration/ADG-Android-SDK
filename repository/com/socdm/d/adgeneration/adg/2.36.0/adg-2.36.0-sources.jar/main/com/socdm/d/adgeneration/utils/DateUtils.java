package com.socdm.d.adgeneration.utils;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DateUtils {

    private static final String _TAG = "ADGDateUtils";
    private static final String RFC822_FORMAT = "EEE, dd-MMM-yyyy HH:mm:ss Z";

    /**
     * 現在日時に引数に与えられた日数分加えたDateインスタンスを返す.
     *
     * @param Integer days
     * @return Date addedDate
     */
    @Nullable
    public static Date addDates(@NonNull final Integer days) {
        if (days == 0) {
            return null;
        }
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, days);
        return cal.getTime();
    }

    /**
     * RFC822Formatの文字列をDate型にパースする.
     *
     * @param dateString
     * @return Date
     */
    @Nullable
    public static Date parseDate(@Nullable final String dateString) {
        SimpleDateFormat sdf = new SimpleDateFormat(RFC822_FORMAT, Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        try {
            if (dateString != null && !dateString.isEmpty()) {
                return sdf.parse(dateString);
            }
        } catch (ParseException e) {
            Log.i(_TAG, "parseDate:ParseException");
        }
        return null;
    }

    /**
     * Date型からRFC822Formatの文字列にフォーマットする.
     *
     * @param date
     * @return
     */
    @NonNull
    public static String formatDate(@Nullable final Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat(RFC822_FORMAT, Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        return date != null ? sdf.format(date) : "";
    }

    /**
     * 与えられたDateが現在日時と比較して過去かどうか判定する.
     *
     * @param target
     * @return boolean
     */
    public static boolean isPast(@Nullable final Date target) {
        if (target != null) {
            return target.getTime() < new Date().getTime();
        }
        return true;
    }

    /**
     * 与えられた日付文字列が現在日時と比較して過去かどうか判定する.
     *
     * @param dateString
     * @return boolean
     */
    public static boolean isPast(@Nullable final String dateString) {
        Date target = parseDate(dateString);
        return isPast(target);
    }
}
