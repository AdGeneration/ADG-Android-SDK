package com.socdm.d.adgeneration.video.vast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.video.ADGPlayerError;

import java.io.Serializable;

public class VASTResource implements Serializable {
    public interface ILoadListener {
        void onCompleted(@NonNull VASTResource resource, @Nullable ADGPlayerError error);
    }

    @Nullable private String creativeType;
    @Nullable private String urlString;

    public VASTResource(@Nullable final String creativeType, @Nullable final String url) {
        this.creativeType = creativeType;
        this.urlString = url;
    }

    @Nullable
    public String getCreativeType() {
        return creativeType;
    }

    @Nullable
    public String getUrlString() {
        return urlString;
    }
}
