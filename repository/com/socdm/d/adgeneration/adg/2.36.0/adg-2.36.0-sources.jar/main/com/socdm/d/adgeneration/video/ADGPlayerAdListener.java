package com.socdm.d.adgeneration.video;

import androidx.annotation.NonNull;

public interface ADGPlayerAdListener {
    void onReadyToPlayAd();

    void onFailedToPlayAd(@NonNull final ADGPlayerError ADGPlayerError);

    void onStartVideo();

    void onClickAd();
}
