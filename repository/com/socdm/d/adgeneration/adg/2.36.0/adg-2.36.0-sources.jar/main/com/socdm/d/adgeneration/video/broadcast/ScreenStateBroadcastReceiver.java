package com.socdm.d.adgeneration.video.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.ADGPlayerError;

public class ScreenStateBroadcastReceiver extends BroadcastReceiver {
    public interface ScreenStateBroadcastReceiverListener {
        void onScreenOff();

        void onScreenOn();
    }

    @NonNull private final ScreenStateBroadcastReceiverListener mListener;
    @Nullable private Context mContext;

    @Nullable private static IntentFilter sIntentFilter;

    public ScreenStateBroadcastReceiver(
            @NonNull final ScreenStateBroadcastReceiverListener listener) {
        mListener = listener;
        sIntentFilter = getIntentFilter();
    }

    @NonNull
    public static IntentFilter getIntentFilter() {
        if (sIntentFilter == null) {
            sIntentFilter = new IntentFilter();
            sIntentFilter.addAction(Intent.ACTION_SCREEN_OFF);
            sIntentFilter.addAction(Intent.ACTION_SCREEN_ON);
            sIntentFilter.addAction(Intent.ACTION_USER_PRESENT);
        }
        return sIntentFilter;
    }

    @Override
    public void onReceive(@NonNull final Context context, @NonNull final Intent intent) {
        LogUtils.d("[ScreenStateBroadcastReceiver] onReceive");

        final String action = intent.getAction();
        if (Intent.ACTION_SCREEN_OFF.equals(action)) {
            mListener.onScreenOff();
        } else if (Intent.ACTION_USER_PRESENT.equals(action)
                || Intent.ACTION_SCREEN_ON.equals(action)) {
            mListener.onScreenOn();
        }
    }

    public void register(@NonNull final Context context) {
        mContext = context;
        try {
            mContext.registerReceiver(this, sIntentFilter);
        } catch (Exception e) {
            LogUtils.w(ADGPlayerError.UNSPECIFIED.toString(), e);
        }
    }

    public void unregister() {
        if (mContext != null) {
            try {
                mContext.unregisterReceiver(this);
            } catch (Exception e) {
                // nothing to do
            }
            mContext = null;
        }
    }
}
