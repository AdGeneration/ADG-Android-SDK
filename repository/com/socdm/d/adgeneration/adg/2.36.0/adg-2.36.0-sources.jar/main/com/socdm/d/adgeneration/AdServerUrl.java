package com.socdm.d.adgeneration;

import android.location.Location;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.adid.SSCoreAdId;
import jp.supership.sscore.device.SSCoreAppInfo;
import jp.supership.sscore.device.SSCoreDevice;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

final class AdServerUrl {
    /** インスタンスを生成できません。詳細はmessageを参照してください */
    public static final class CanNotInstantiateException extends Exception {
        CanNotInstantiateException(@NonNull final String message) {
            super(message);
        }
    }

    /**
     * 0: BrowserSDK<br>
     * 1: AndroidSDK<br>
     * 2: iOSSDK
     */
    @NonNull private static final String SDK_TYPE = "1";

    @NonNull final String url;

    AdServerUrl(@NonNull final AdRequest request) throws CanNotInstantiateException {
        final StringBuilder sb = new StringBuilder(ADGConsts.AD_URL);

        try {
            addParam(
                    sb,
                    "?",
                    "posall",
                    request.scheduleCount > 1 ? request.scheduleCount + "SSPLOC" : "SSPLOC");
            addParam(sb, "&", "id", request.locationId);
            addParam(sb, "&", "sdktype", SDK_TYPE);
            addParam(sb, "&", "sdkver", request.sdkVersion);

            if (request.appInfo.isPresent()) {
                final SSCoreAppInfo appInfo = request.appInfo.forced();
                addParam(sb, "&", "appname", appInfo.appName);
                addParam(sb, "&", "appbundle", appInfo.appId);
                addParam(sb, "&", "appver", appInfo.appVersion);
            }

            if (request.device.isPresent()) {
                final SSCoreDevice device = request.device.forced();
                addParam(sb, "&", "lang", device.language);
                addParam(sb, "&", "locale", device.locale);
                addParam(sb, "&", "tz", device.timeZone);
                addParam(sb, "&", "networktype", device.networkType);
                addParam(sb, "&", "carrier", device.carrierNumber);
                addParam(sb, "&", "model", device.modelName);
                addParam(sb, "&", "platform", device.os);
                addParam(sb, "&", "platformv", device.osVersion);
                addParam(sb, "&", "arch", device.architecture);
                addParam(sb, "&", "bitness", "" + device.bitness);

                if (device.screenWidthInDp > 0) {
                    addParam(sb, "&", "dw", "" + device.screenWidthInDp);
                }

                if (device.screenHeightInDp > 0) {
                    addParam(sb, "&", "dh", "" + device.screenHeightInDp);
                }
            }

            addParam(sb, "&", "imark", "1");
            addParam(sb, "&", "vplayer", "1");

            if (request.isMraidEnabled) {
                addParam(sb, "&", "mraid", "2.0");
            }

            for (final Map.Entry<String, String> param :
                    request.headerBiddingParams.toMap().entrySet()) {
                addParam(sb, "&", param.getKey(), param.getValue());
            }

            for (final Map.Entry<String, String> label :
                    request.labelTargeting.toMapWithPrefix().entrySet()) {
                addParam(sb, "&", label.getKey(), label.getValue());
            }

            if (request.isChildDirectedEnabled) {
                addParam(sb, "&", "child_directed", "1");
            }

            if (request.adId.isPresent() && !request.isChildDirectedEnabled) {
                final SSCoreAdId adId = request.adId.forced();
                addParam(sb, "&", "advertising_id", adId.value);
            }

            final List<String> errorScheduleIds = request.errorScheduleIds;
            if (!errorScheduleIds.isEmpty() && request.scheduleCount <= 1) {
                // wo-sch-idに指定したscheduleIdは配信されない
                // -> エラーレスポンスのscheduleIdは除外される
                addParam(sb, "&", "wo-sch-id", String.join(",", errorScheduleIds));
            }

            // Geolocation
            if (request.location.isPresent()) {
                final Location location = request.location.forced();
                addParam(sb, "&", "lat", "" + location.getLatitude());
                addParam(sb, "&", "lon", "" + location.getLongitude());
            }

            addParam(sb, "&", "t", "json3");

        } catch (UnsupportedEncodingException e) {
            throw new CanNotInstantiateException("Failed to encode. " + e);
        }

        url = sb.toString();
    }

    private static void addParam(
            @NonNull final StringBuilder sb,
            @NonNull final String separator,
            @NonNull final String key,
            @Nullable final String val)
            throws UnsupportedEncodingException {
        final String v = val == null ? "" : val;
        sb.append(separator).append(key).append("=").append(URLEncoder.encode(v, "utf-8"));
    }
}
