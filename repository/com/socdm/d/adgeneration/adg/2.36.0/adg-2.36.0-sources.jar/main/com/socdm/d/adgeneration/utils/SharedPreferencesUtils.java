package com.socdm.d.adgeneration.utils;

import android.annotation.SuppressLint;
import android.content.SharedPreferences.Editor;
import android.os.Build;

import androidx.annotation.NonNull;

@SuppressLint("CommitPrefEdits")
public class SharedPreferencesUtils {

    @SuppressLint("NewApi")
    public static void commitOrApply(@NonNull final Editor editor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            editor.apply();
        } else {
            editor.commit();
        }
    }
}
