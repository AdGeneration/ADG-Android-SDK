package com.socdm.d.adgeneration.utils;

import android.content.Context;
import android.os.Build;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.reflect.Constructor;

public class HttpUtils {

    /**
     * ユーザーエージェントを取得する
     *
     * @param context
     * @return
     */
    @Nullable
    public static String getUserAgent(@NonNull final Context context) {
        try {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    // [注意] 一部の端末でNullPointerExceptionが発生する報告があった
                    return WebSettings.getDefaultUserAgent(context);
                }

                Constructor<WebSettings> constructor =
                        WebSettings.class.getDeclaredConstructor(Context.class, WebView.class);
                constructor.setAccessible(true);
                try {
                    WebSettings settings = constructor.newInstance(context, null);
                    return settings.getUserAgentString();
                } finally {
                    constructor.setAccessible(false);
                }
            } catch (Exception e) {
                e.printStackTrace();
                return new WebView(context).getSettings().getUserAgentString();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
