package com.socdm.d.adgeneration;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

/** ADGインスタンス単位のパラメータ */
public final class AdParams {
    @NonNull private final Object lock = new Object();
    /** 広告枠ID */
    @Nullable private String locationId;

    private boolean isMraidEnabled;
    /** Header biddingのためのパラメータ */
    @NonNull public final HeaderBiddingParams headerBiddingParams = new HeaderBiddingParams();
    /** ラベルターゲティング */
    @NonNull public final LabelTargeting labelTargeting = new LabelTargeting();

    private int fillerLimit = 2;

    @Nullable
    public String getLocationId() {
        synchronized (lock) {
            return locationId;
        }
    }

    public void setLocationId(@Nullable final String locationId) {
        synchronized (lock) {
            this.locationId = locationId;
        }
    }

    public boolean isMraidEnabled() {
        synchronized (lock) {
            return isMraidEnabled;
        }
    }

    public void setMraidEnabled(final boolean mraidEnabled) {
        synchronized (lock) {
            this.isMraidEnabled = mraidEnabled;
        }
    }

    public int getFillerLimit() {
        synchronized (lock) {
            return fillerLimit;
        }
    }

    public void setFillerLimit(final int fillerLimit) {
        synchronized (lock) {
            this.fillerLimit = fillerLimit;
        }
    }
    /** エラーになったレスポンスのscheduleId */
    @NonNull private final List<String> errorScheduleIds = new ArrayList<>();

    public AdParams() {}

    /**
     * エラーになったレスポンスのscheduleIdを返します
     *
     * @return エラーになったレスポンスのscheduleId
     */
    @NonNull
    public List<String> getErrorScheduleIds() {
        synchronized (lock) {
            // ディープコピーを返す
            return new ArrayList<>(errorScheduleIds);
        }
    }

    /**
     * エラーになったレスポンスのscheduleIdを記録します
     *
     * @param scheduleId エラーになったレスポンスのscheduleId
     */
    public void addErrorScheduleId(@Nullable final String scheduleId) {
        synchronized (lock) {
            if (!errorScheduleIds.contains(scheduleId) && !TextUtils.isEmpty(scheduleId)) {
                errorScheduleIds.add(scheduleId);
            }
        }
    }

    /**
     * 記録されているエラーになったレスポンスのscheduleIdを削除するかどうかを判定します
     *
     * <p>呼び出し元で判定後に別操作を行うと排他が分離されるため、更新を伴う用途では 同一ロック内で扱うメソッドから利用します。
     *
     * @return 削除する場合はtrue、それ以外はfalseを返します
     */
    private boolean shouldClearErrorScheduleIds() {
        return fillerLimit < errorScheduleIds.size();
    }

    /** 記録されているエラーになったレスポンスのscheduleIdを削除します */
    public void clearErrorScheduleIds() {
        synchronized (lock) {
            errorScheduleIds.clear();
        }
    }

    /**
     * 広告ロード成功時に、scheduleIdの状態に応じてエラーになったレスポンスのscheduleIdを削除します
     *
     * @param scheduleId ロード成功したレスポンスのscheduleId
     */
    public void clearErrorScheduleIdsOnLoadSuccess(@Nullable final String scheduleId) {
        synchronized (lock) {
            if (TextUtils.isEmpty(scheduleId) || shouldClearErrorScheduleIds()) {
                errorScheduleIds.clear();
            }
        }
    }
}
