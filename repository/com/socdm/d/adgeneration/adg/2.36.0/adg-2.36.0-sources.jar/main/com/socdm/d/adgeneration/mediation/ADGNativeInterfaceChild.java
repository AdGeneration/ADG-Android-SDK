package com.socdm.d.adgeneration.mediation;

import android.content.Context;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.utils.LogUtils;

import jp.supership.sscore.type.Optional;

import java.util.ArrayList;

public abstract class ADGNativeInterfaceChild {
    @Nullable protected Context ct;
    @Nullable protected ADGNativeInterfaceChildListener listener;
    @Nullable protected String adId;
    @Nullable protected String param;
    @Nullable protected ViewGroup layout;
    @NonNull protected Integer width = 0;
    @NonNull protected Integer height = 0;
    @NonNull protected Boolean enableSound = false;
    @NonNull protected Boolean enableTestMode = false;
    @NonNull protected Boolean usePartsResponse = false;
    @NonNull protected Boolean callNativeAdTrackers = true;
    @NonNull protected Boolean expandFrame = false;
    @Nullable protected String contentUrl;
    @NonNull protected Boolean isWipe = false;
    @Nullable protected String admPayload;
    @Nullable protected String bidderSuccessfulName;
    @Nullable protected ArrayList<String> biddingNotifyUrl;
    @NonNull protected Optional<String> locationId = Optional.empty();

    public void setContext(@Nullable final Context ct) {
        this.ct = ct;
    }

    public void setListener(@Nullable final ADGNativeInterfaceChildListener listener) {
        this.listener = listener;
    }

    public void setAdId(@Nullable final String adId) {
        this.adId = adId;
    }

    public void setParam(@Nullable final String param) {
        this.param = param;
    }

    public void setLayout(@Nullable final ViewGroup layout) {
        this.layout = layout;
    }

    public void setSize(final int width, final int height) {
        this.width = width;
        this.height = height;
    }

    public boolean checkOSVersion() {
        return true;
    }

    public void setEnableSound(@NonNull final Boolean enableSound) {
        this.enableSound = enableSound;
    }

    public void setEnableTestMode(@NonNull final Boolean enableTestMode) {
        this.enableTestMode = enableTestMode;
    }

    public void setUsePartsResponse(@NonNull final Boolean usePartsResponse) {
        this.usePartsResponse = usePartsResponse;
    }

    public void setCallNativeAdTrackers(@NonNull final Boolean callNativeAdTrackers) {
        this.callNativeAdTrackers = callNativeAdTrackers;
    }

    public void setExpandFrame(final boolean expandFrame) {
        this.expandFrame = expandFrame;
    }

    public void setContentUrl(@Nullable final String url) {
        this.contentUrl = url;
    }

    public void setIsWipe(@NonNull final Boolean isWipe) {
        this.isWipe = isWipe;
    }

    public void setAdmPayload(@Nullable final String admPayload) {
        this.admPayload = admPayload;
    }

    public void setBidderSuccessfulName(@Nullable final String bidderSuccessfulName) {
        this.bidderSuccessfulName = bidderSuccessfulName;
    }

    public void setBiddingNotifyUrl(@Nullable final ArrayList<String> biddingNotifyUrl) {
        this.biddingNotifyUrl = biddingNotifyUrl;
    }

    public void setLocationId(@Nullable final String locationId) {
        this.locationId = Optional.of(locationId);
    }

    public void errorProcess(@NonNull final Exception e) {
        LogUtils.w(e.getMessage());
    }

    public void callWhenInView() {}

    public void callWhenOutOfView() {}

    public abstract boolean loadProcess();

    public abstract void startProcess();

    @Deprecated
    public abstract void stopProcess();

    public abstract void finishProcess();
}
