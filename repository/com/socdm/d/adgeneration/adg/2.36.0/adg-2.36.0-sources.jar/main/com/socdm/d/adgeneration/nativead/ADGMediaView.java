package com.socdm.d.adgeneration.nativead;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.ADGLogger;
import com.socdm.d.adgeneration.nativead.icon.ADGImageView;

public class ADGMediaView extends RelativeLayout {
    @Nullable private ADGNativeAd mAdgNativeAd;
    @Nullable private ImageView mAdgImageView;
    private boolean isTiny = false;

    public ADGMediaView(@NonNull final Context context) {
        super(context);
    }

    public ADGMediaView(@NonNull final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
    }

    public ADGMediaView(
            @NonNull final Context context,
            @Nullable final AttributeSet attrs,
            final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public ADGMediaView(
            @NonNull final Context context,
            @Nullable final AttributeSet attrs,
            final int defStyleAttr,
            final int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    /**
     * {@link ADGNativeAd} オブジェクトを設定します
     *
     * @param nativeAd {@link ADGNativeAd} オブジェクト
     */
    public void setAdgNativeAd(@NonNull final ADGNativeAd nativeAd) {
        mAdgNativeAd = nativeAd;
    }

    public void setIsTiny(final boolean isTiny) {
        this.isTiny = isTiny;
    }

    /** メイン画像または動画のロードを開始します */
    public void load() {
        if (mAdgNativeAd == null) {
            ADGLogger.getInstance().getLogger().warn("Invalid ADGNativeAd.");
            return;
        }

        // 動画広告
        if (mAdgNativeAd.loadVideo(getContext(), isTiny, () -> ADGMediaView.this)) {
            return;
        }

        // 静止画広告
        if (mAdgNativeAd.getMainImage() != null
                && !TextUtils.isEmpty(mAdgNativeAd.getMainImage().getUrl())) {
            mAdgImageView =
                    new ADGImageView(
                            getContext(), mAdgNativeAd.getMainImage().getUrl(), null, null);
            mAdgImageView.setAdjustViewBounds(true);
            addView(
                    mAdgImageView,
                    new ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            ADGLogger.getInstance().getLogger().warn("Invalid ADGMediaView.");
        }
    }

    /**
     * メイン画像または動画をViewから破棄します。
     * 特に、複数の動画を配置する場合や、アプリ側でMediaPlayerを扱い、動画や音声を再生している場合、不要になったものから適宜破棄を行う必要があります。
     * 破棄されないままMediaPlayerの生成を繰り返すとクラッシュを引き起こす場合があります
     */
    public void destroy() {
        if (mAdgImageView != null) {
            mAdgImageView.setImageDrawable(null);
            removeView(mAdgImageView);
            mAdgImageView = null;
        }

        if (mAdgNativeAd != null) {
            mAdgNativeAd.destroyVideo();
            mAdgNativeAd = null;
        }
    }

    public static void safeRemoveFromParentView(@Nullable final ViewGroup parent) {
        if (parent == null) return;
        for (int i = 0; i < parent.getChildCount(); i++) {
            View child = parent.getChildAt(i);
            if (child instanceof ADGMediaView) {
                ((ADGMediaView) child).destroy();
                parent.removeView(child);
            } else if (child instanceof ViewGroup) {
                safeRemoveFromParentView((ViewGroup) child);
            }
        }
    }
}
