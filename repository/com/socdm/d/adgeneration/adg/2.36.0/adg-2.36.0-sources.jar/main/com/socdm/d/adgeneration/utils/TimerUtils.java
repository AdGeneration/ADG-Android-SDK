package com.socdm.d.adgeneration.utils;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Timer;
import java.util.TimerTask;

public class TimerUtils {
    @NonNull
    public static Timer renew(@Nullable Timer oldTimer) {
        TimerUtils.stopTimer(oldTimer);
        return new Timer();
    }

    public static void stopTimer(@Nullable Timer timer) {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    public static void run(@NonNull final TimerTask task) {
        Timer timer = new Timer();
        timer.schedule(task, 0);
    }

    @NonNull
    public static TimerTask timerTaskWithUIThread(
            @Nullable final Activity activity, @NonNull final Runnable runnable) {
        return new TimerTask() {
            @Override
            public void run() {
                if (activity != null) {
                    activity.runOnUiThread(runnable);
                }
            }
        };
    }

    @NonNull
    public static TimerTask timerTask(@NonNull final Runnable runnable) {
        return new TimerTask() {
            @Override
            public void run() {
                runnable.run();
            }
        };
    }
}
