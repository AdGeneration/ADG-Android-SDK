package com.socdm.d.adgeneration.video.view;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.SurfaceTexture;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.MediaController;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.ADGSettings;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.ADGPlayerError;
import com.socdm.d.adgeneration.video.VideoAudioType;
import com.socdm.d.adgeneration.video.utils.Streams;

import java.io.File;
import java.io.FileInputStream;

/**
 * 動画を再生するためのカスタムビュークラスです。 TextureViewを使用して動画を表示し、MediaPlayerを使って再生制御を行います。
 * 音声フォーカスの管理、再生状態の追跡、バッファリング処理などの機能を提供します。
 */
@TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
public class VideoView extends FrameLayout
        implements MediaController.MediaPlayerControl, TextureView.SurfaceTextureListener {
    @Nullable private String mUrl;

    // all possible internal states
    private static final int STATE_ERROR = -1;
    private static final int STATE_IDLE = 0;
    private static final int STATE_PREPARING = 1;
    private static final int STATE_PREPARED = 2;
    private static final int STATE_PLAYING = 3;
    private static final int STATE_PAUSED = 4;
    private static final int STATE_PLAYBACK_COMPLETED = 5;

    // mCurrentState is a VideoView object's current state.
    // mTargetState is the state that a method caller intends to reach.
    // For instance, regardless the VideoView object's current state,
    // calling pause() intends to bring the object to a target state
    // of STATE_PAUSED.
    private int mCurrentState = STATE_IDLE;
    private int mTargetState = STATE_IDLE;

    // All the stuff we need for playing and showing a video
    @Nullable private MediaPlayer mMediaPlayer;
    @Nullable private SurfaceTexture mSurfaceTexture;
    @Nullable private Surface mSurface;
    private int mVideoWidth;
    private int mVideoHeight;
    private int mSeekWhenPrepared; // recording the seek position while preparing
    private int mCurrentBufferPercentage;
    private int mVideoRetries;
    @Nullable private AudioManager mAudioManager;
    @Nullable private AudioAttributes mPlaybackAttributes;
    @Nullable private AudioFocusChangeListener mAudioFocusChangeListener;
    @Nullable private AudioFocusRequest mAudioFocusRequest;
    private boolean mAudioVolumeIsOn = false;

    @NonNull private final Context mContext;
    @NonNull private TextureView mTextureView;
    @Nullable private VideoViewListener mListener;

    private static final int MAX_VIDEO_RETRIES = 1;
    private static final int VIDEO_VIEW_FILE_PERMISSION_ERROR = Integer.MIN_VALUE;

    private boolean failedPause = false;

    /** 動画再生イベントを受け取るリスナーインターフェース */
    public interface VideoViewListener {
        /** 動画の再生が完了したときに呼ばれます */
        void onCompletion();

        /** 動画の準備が完了したときに呼ばれます */
        void onPrepared();

        /**
         * バッファリング中に呼ばれます
         *
         * @param percent バッファリング進捗率
         */
        void onBuffering(final int percent);

        /**
         * シーク操作時に呼ばれます
         *
         * @param msec シーク位置（ミリ秒）
         */
        void onSeekTo(final int msec);

        /** エラーが発生したときに呼ばれます */
        void onError();

        /**
         * 音声ボリュームが変更されたときに呼ばれます
         *
         * @param isOn 音声がオンの場合true
         */
        void onChangeAudioVolume(final boolean isOn);
    }

    /**
     * VideoViewインスタンスを生成します。
     *
     * @param context コンテキスト
     */
    public VideoView(@NonNull final Context context) {
        super(context);
        mContext = context;
        initVideoView();
    }

    /**
     * VideoViewインスタンスを生成します。
     *
     * @param context コンテキスト
     * @param attrs 属性セット
     */
    public VideoView(@NonNull final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        initVideoView();
    }

    /**
     * VideoViewインスタンスを生成します。
     *
     * @param context コンテキスト
     * @param attrs 属性セット
     * @param defStyleAttr デフォルトスタイル属性
     */
    public VideoView(
            @NonNull final Context context,
            @Nullable final AttributeSet attrs,
            final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        initVideoView();
    }

    /**
     * VideoViewインスタンスを生成します。
     *
     * @param context コンテキスト
     * @param attrs 属性セット
     * @param defStyleAttr デフォルトスタイル属性
     * @param defStyleRes デフォルトスタイルリソース
     */
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public VideoView(
            @NonNull final Context context,
            @Nullable final AttributeSet attrs,
            final int defStyleAttr,
            final int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        mContext = context;
        initVideoView();
    }

    /** VideoViewを初期化します。 TextureViewのセットアップや再生状態の初期化を行います。 */
    private void initVideoView() {
        LogUtils.d(this + ": initVideoView");
        mVideoWidth = 0;
        mVideoHeight = 0;
        mCurrentState = STATE_IDLE;
        mTargetState = STATE_IDLE;

        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);

        mTextureView = new TextureView(mContext);
        mTextureView.setSurfaceTextureListener(this);
        LayoutParams params =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.CENTER;
        addView(mTextureView, params);

        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = getDefaultSize(mVideoWidth, widthMeasureSpec);
        int height = getDefaultSize(mVideoHeight, heightMeasureSpec);
        if (mVideoWidth > 0 && mVideoHeight > 0) {

            int widthSpecMode = MeasureSpec.getMode(widthMeasureSpec);
            int widthSpecSize = MeasureSpec.getSize(widthMeasureSpec);
            int heightSpecMode = MeasureSpec.getMode(heightMeasureSpec);
            int heightSpecSize = MeasureSpec.getSize(heightMeasureSpec);

            if (widthSpecMode == MeasureSpec.EXACTLY && heightSpecMode == MeasureSpec.EXACTLY) {
                // the size is fixed
                width = widthSpecSize;
                height = heightSpecSize;

                // for compatibility, we adjust size based on aspect ratio
                if (mVideoWidth * height < width * mVideoHeight) {
                    // LogUtils.i("@@@", "image too wide, correcting");
                    width = height * mVideoWidth / mVideoHeight;
                } else if (mVideoWidth * height > width * mVideoHeight) {
                    // LogUtils.i("@@@", "image too tall, correcting");
                    height = width * mVideoHeight / mVideoWidth;
                }
            } else if (widthSpecMode == MeasureSpec.EXACTLY) {
                // only the width is fixed, adjust the height to match aspect ratio if possible
                width = widthSpecSize;
                height = width * mVideoHeight / mVideoWidth;
                if (heightSpecMode == MeasureSpec.AT_MOST && height > heightSpecSize) {
                    // couldn't match aspect ratio within the constraints
                    height = heightSpecSize;
                }
            } else if (heightSpecMode == MeasureSpec.EXACTLY) {
                // only the height is fixed, adjust the width to match aspect ratio if possible
                height = heightSpecSize;
                width = height * mVideoWidth / mVideoHeight;
                if (widthSpecMode == MeasureSpec.AT_MOST && width > widthSpecSize) {
                    // couldn't match aspect ratio within the constraints
                    width = widthSpecSize;
                }
            } else {
                // neither the width nor the height are fixed, try to use actual video size
                width = mVideoWidth;
                height = mVideoHeight;
                if (heightSpecMode == MeasureSpec.AT_MOST && height > heightSpecSize) {
                    // too tall, decrease both width and height
                    height = heightSpecSize;
                    width = height * mVideoWidth / mVideoHeight;
                }
                if (widthSpecMode == MeasureSpec.AT_MOST && width > widthSpecSize) {
                    // too wide, decrease both width and height
                    width = widthSpecSize;
                    height = width * mVideoHeight / mVideoWidth;
                }
            }
        } else {
            // no size yet, just adopt the given spec sizes
        }
        setMeasuredDimension(width, height);

        if (mVideoWidth > 0 && mVideoHeight > 0) {
            int measuredWidth = getMeasuredWidth();
            int measuredHeight = getMeasuredHeight();
            float videoAspect = (float) mVideoHeight / mVideoWidth;
            float viewAspect = (float) measuredHeight / measuredWidth;
            int childWidth = width;
            int childHeight = height;
            if (videoAspect < viewAspect) {
                // view is tall
                childHeight = (int) (measuredWidth * videoAspect);
            } else if (videoAspect > viewAspect) {
                // view is wide
                childWidth = (int) (measuredHeight / videoAspect);
            }

            int childWidthMeasureSpec =
                    MeasureSpec.makeMeasureSpec(childWidth, MeasureSpec.EXACTLY);
            int childHeightMeasureSpec =
                    MeasureSpec.makeMeasureSpec(childHeight, MeasureSpec.EXACTLY);
            mTextureView.measure(childWidthMeasureSpec, childHeightMeasureSpec);
        }
    }

    /**
     * 再生する動画URLを設定します。 シーク位置とリトライ回数をリセットし、動画を開きます。
     *
     * @param url 動画URL
     */
    public void setVideoURL(@Nullable final String url) {
        LogUtils.d(this + ": setVideoURL:" + url);
        mUrl = url;
        mSeekWhenPrepared = 0;
        mVideoRetries = 0;
        openVideo();
    }

    /** 動画の再生を停止し、リソースを解放します。 */
    public void stopPlayback() {
        release(false);
    }

    /** 動画を開き、再生の準備を行います。 MediaPlayerを初期化し、各種リスナーを設定します。 */
    private void openVideo() {
        if (mUrl == null) {
            return;
        }

        // we shouldn't clear the target state, because somebody might have
        // called start() previously
        reset(false);
        try {
            mAudioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);

            mMediaPlayer = new MediaPlayer();
            mMediaPlayer.setDataSource(mUrl);
            mMediaPlayer.setOnBufferingUpdateListener(mBufferingUpdateListener);
            mMediaPlayer.setOnCompletionListener(mCompletionListener);
            mMediaPlayer.setOnPreparedListener(mPreparedListener);
            mMediaPlayer.setOnSeekCompleteListener(mSeekCompleteListener);
            mMediaPlayer.setOnVideoSizeChangedListener(mSizeChangedListener);
            mMediaPlayer.setOnErrorListener(mErrorListener);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                mPlaybackAttributes =
                        new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                                .build();
                mMediaPlayer.setAudioAttributes(mPlaybackAttributes);
            } else {
                mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            }
            if (mSurfaceTexture != null) {
                mSurface = new Surface(mSurfaceTexture);
                mMediaPlayer.setSurface(mSurface);
            }
            mMediaPlayer.prepareAsync();
            mCurrentBufferPercentage = 0;
            // we don't set the target state here either, but preserve the
            // target state that was there before.
            mCurrentState = STATE_PREPARING;
        } catch (Exception e) {
            mCurrentState = STATE_ERROR;
            mTargetState = STATE_ERROR;
            mErrorListener.onError(mMediaPlayer, MediaPlayer.MEDIA_ERROR_UNKNOWN, 0);
            LogUtils.e(ADGPlayerError.UNSPECIFIED.toString(), e);
        }
    }

    /**
     * MediaPlayerを解放します。
     *
     * @param clearTargetState ターゲット状態もクリアするかどうか
     */
    @SuppressWarnings("SameParameterValue")
    private void release(final boolean clearTargetState) {
        reset(clearTargetState);
    }

    /**
     * MediaPlayerをリセットし、状態をIDLEに戻します。 Surfaceも解放します。
     *
     * @param clearTargetState ターゲット状態もクリアするかどうか
     */
    @SuppressWarnings("SameParameterValue")
    private void reset(final boolean clearTargetState) {
        if (mMediaPlayer != null) {
            mMediaPlayer.reset();
            mMediaPlayer.release();
            mMediaPlayer = null;
            mCurrentState = STATE_IDLE;
            if (clearTargetState) {
                mTargetState = STATE_IDLE;
            }
            releaseSurface();
        }
    }

    /** Surfaceリソースを解放します。 */
    private void releaseSurface() {
        if (mSurface != null) {
            mSurface.release();
            mSurface = null;
        }
    }

    /**
     * MediaPlayerのエラー後に再試行を試みます。 Android 4.1未満のファイルパーミッションエラーに対応します。
     *
     * @param mediaPlayer MediaPlayerインスタンス
     * @param what エラータイプ
     * @param extra 追加エラー情報
     * @return 再試行に成功した場合true
     */
    @SuppressWarnings({"ConstantConditions"})
    private boolean retryMediaPlayer(
            @Nullable final MediaPlayer mediaPlayer, final int what, final int extra) {
        LogUtils.d(this + ": retryMediaPlayer");
        // XXX
        // VideoView has a bug in versions lower than Jelly Bean, Api Level 16, Android 4.1
        // For api < 16, VideoView is not able to read files written to disk since it reads them in
        // a Context different from the Application and therefore does not have correct permission.
        // To solve this problem we obtain the video file descriptor ourselves with valid
        // permissions
        // and pass it to the underlying MediaPlayer in VideoView.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN
                && what == MediaPlayer.MEDIA_ERROR_UNKNOWN
                && extra == VIDEO_VIEW_FILE_PERMISSION_ERROR
                && mVideoRetries < MAX_VIDEO_RETRIES) {

            FileInputStream inputStream = null;
            try {
                mediaPlayer.reset();
                final File file = new File(mUrl);
                inputStream = new FileInputStream(file);
                mediaPlayer.setDataSource(inputStream.getFD());

                // XXX
                // VideoView has a callback registered with the MediaPlayer to set a flag when the
                // media file has been prepared. Start also sets a flag in VideoView indicating the
                // desired state is to play the video. Therefore, whichever method finishes last
                // will check both flags and begin playing the video.
                mediaPlayer.prepareAsync();
                return true;
            } catch (Exception e) {
                LogUtils.e(ADGPlayerError.UNSPECIFIED.toString(), e);
                return false;
            } finally {
                Streams.closeStream(inputStream);
                mVideoRetries++;
            }
        }
        return false;
    }

    @NonNull
    private final MediaPlayer.OnVideoSizeChangedListener mSizeChangedListener =
            new MediaPlayer.OnVideoSizeChangedListener() {
                public void onVideoSizeChanged(
                        final MediaPlayer mp, final int width, final int height) {
                    LogUtils.d(this + ": OnVideoSizeChangedListener");
                    mVideoWidth = mp.getVideoWidth();
                    mVideoHeight = mp.getVideoHeight();
                    if (mVideoWidth != 0 && mVideoHeight != 0) {
                        requestLayout();
                    }
                }
            };

    @NonNull
    private final MediaPlayer.OnPreparedListener mPreparedListener =
            new MediaPlayer.OnPreparedListener() {
                public void onPrepared(final MediaPlayer mp) {
                    LogUtils.d(this + ": onPreparedListener");
                    mCurrentState = STATE_PREPARED;

                    if (mListener != null) {
                        mListener.onPrepared();
                    }

                    try {
                        mVideoWidth = mp.getVideoWidth();
                        mVideoHeight = mp.getVideoHeight();
                        mp.start();
                        mp.pause();

                        int seekToPosition =
                                mSeekWhenPrepared; // mSeekWhenPrepared may be changed after
                        // seekTo() call
                        if (seekToPosition != 0) {
                            seekTo(seekToPosition);
                        }

                        if (mVideoWidth != 0 && mVideoHeight != 0) {
                            requestLayout();
                        }
                    } catch (IllegalStateException e) {
                        LogUtils.e(ADGPlayerError.UNSPECIFIED.toString(), e);
                        if (mListener != null) {
                            mListener.onError();
                        }
                    }
                }
            };

    @NonNull
    private final MediaPlayer.OnCompletionListener mCompletionListener =
            new MediaPlayer.OnCompletionListener() {
                public void onCompletion(final MediaPlayer mp) {
                    if (mCurrentState != STATE_PLAYBACK_COMPLETED) {
                        mCurrentState = STATE_PLAYBACK_COMPLETED;
                        mTargetState = STATE_PLAYBACK_COMPLETED;

                        if (mListener != null) {
                            abandonAudioFocus();
                            mListener.onCompletion();
                        }
                    }
                }
            };

    @NonNull
    private final MediaPlayer.OnErrorListener mErrorListener =
            new MediaPlayer.OnErrorListener() {
                public boolean onError(
                        final MediaPlayer mp, final int framework_err, final int impl_err) {
                    if (retryMediaPlayer(mp, framework_err, impl_err)) {
                        return true;
                    } else {
                        mCurrentState = STATE_ERROR;
                        mTargetState = STATE_ERROR;
                        /* If an error handler has been supplied, use it and finish. */
                        if (mListener != null) {
                            mListener.onError();
                        }

                        return false;
                    }
                }
            };

    private final MediaPlayer.OnBufferingUpdateListener mBufferingUpdateListener =
            new MediaPlayer.OnBufferingUpdateListener() {
                public void onBufferingUpdate(final MediaPlayer mp, final int percent) {
                    LogUtils.d(this + ": onBufferingUpdateListener");
                    mCurrentBufferPercentage = percent;

                    if (mListener != null) {
                        mListener.onBuffering(percent);
                    }
                }
            };

    private final MediaPlayer.OnSeekCompleteListener mSeekCompleteListener =
            new MediaPlayer.OnSeekCompleteListener() {
                @Override
                public void onSeekComplete(final MediaPlayer mediaPlayer) {
                    if (mTargetState == STATE_PLAYING) {
                        start();
                    }
                }
            };

    /**
     * 動画再生イベントを受け取るリスナーを設定します。
     *
     * @param l VideoViewListenerインスタンス
     */
    public void setVideoViewListener(@Nullable final VideoViewListener l) {
        mListener = l;
    }

    /**
     * SurfaceTextureが使用可能になった時に呼ばれます。 MediaPlayerにSurfaceを設定し、再生を再開します。
     *
     * @param surfaceTexture 使用可能になったSurfaceTexture
     * @param width 幅
     * @param height 高さ
     */
    @Override
    public void onSurfaceTextureAvailable(
            @NonNull final SurfaceTexture surfaceTexture, final int width, final int height) {
        LogUtils.d(this + ": onSurfaceTextureAvailable");
        mSurfaceTexture = surfaceTexture;
        if (mMediaPlayer != null) {
            mSurface = new Surface(mSurfaceTexture);
            mMediaPlayer.setSurface(mSurface);
            if (mCurrentState == STATE_PLAYING && !mMediaPlayer.isPlaying() && !failedPause) {
                failedPause = false;
                mMediaPlayer.start();
            }
        }
    }

    /**
     * SurfaceTextureのサイズが変更された時に呼ばれます。 再生を開始するかどうかを判定します。
     *
     * @param surfaceTexture SurfaceTexture
     * @param width 新しい幅
     * @param height 新しい高さ
     */
    @Override
    public void onSurfaceTextureSizeChanged(
            @NonNull final SurfaceTexture surfaceTexture, final int width, final int height) {
        LogUtils.d(this + ": onSurfaceTextureSizeChanged");
        boolean isValidState = (mTargetState == STATE_PLAYING);
        boolean hasValidSize = (mVideoWidth == width && mVideoHeight == height);
        if (mMediaPlayer != null && isValidState && hasValidSize) {
            if (mSeekWhenPrepared != 0) {
                seekTo(mSeekWhenPrepared);
            }
            start();
        }
    }

    /**
     * SurfaceTextureが破棄される時に呼ばれます。 Surfaceリソースを解放します。
     *
     * @param surfaceTexture 破棄されるSurfaceTexture
     * @return SurfaceTextureの破棄をシステムに委謗する場合true
     */
    @Override
    public boolean onSurfaceTextureDestroyed(@NonNull final SurfaceTexture surfaceTexture) {
        LogUtils.d(this + ": onSurfaceTextureDestroyed");
        mSurfaceTexture = null;
        releaseSurface();
        return false;
    }

    /**
     * SurfaceTextureが更新された時に呼ばれます。 この実装では何も行いません。
     *
     * @param surfaceTexture 更新されたSurfaceTexture
     */
    @Override
    public void onSurfaceTextureUpdated(@NonNull final SurfaceTexture surfaceTexture) {
        // nothing to do
    }

    /** 動画の再生を開始します。 音声がONの場合はAudio Focusをリクエストします。 */
    @Override
    public void start() {
        if (isInPlaybackState()) {
            if (mSurfaceTexture != null && mMediaPlayer != null) {
                if (mAudioVolumeIsOn) {
                    requestAudioFocus();
                }
                mMediaPlayer.start();
            }
            mCurrentState = STATE_PLAYING;
        } else {
            openVideo();
        }
        mTargetState = STATE_PLAYING;
    }

    /** 動画の再生を一時停止します。 Audio Focusを解放します。 */
    @Override
    public void pause() {
        failedPause = false;
        if (isInPlaybackState() && mMediaPlayer != null) {
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.pause();
                abandonAudioFocus();
                mCurrentState = STATE_PAUSED;
            } else {
                failedPause = true;
            }
        }
        mTargetState = STATE_PAUSED;
    }

    /**
     * 動画の総再生時間を取得します。
     *
     * @return 総再生時間(ミリ秒)。再生不可の場合は-1
     */
    @Override
    public int getDuration() {
        if (isInPlaybackState() && mMediaPlayer != null) {
            return mMediaPlayer.getDuration();
        }

        return -1;
    }

    /**
     * 現在の再生位置を取得します。
     *
     * @return 現在の再生位置(ミリ秒)
     */
    @Override
    public int getCurrentPosition() {
        if (isInPlaybackState() && mMediaPlayer != null) {
            return mMediaPlayer.getCurrentPosition();
        }
        return 0;
    }

    /**
     * 指定した位置にシークします。 リスナーにシークイベントを通知します。
     *
     * @param msec シーク位置(ミリ秒)
     */
    @Override
    public void seekTo(final int msec) {
        if (isInPlaybackState() && mMediaPlayer != null) {
            mMediaPlayer.seekTo(msec);
            mSeekWhenPrepared = 0;
            if (mListener != null) {
                mListener.onSeekTo(msec);
            }
        } else {
            mSeekWhenPrepared = msec;
        }
    }

    /**
     * 動画が再生中かどうかを返します。
     *
     * @return 再生中の場合true
     */
    @Override
    public boolean isPlaying() {
        return isInPlaybackState() && mMediaPlayer != null && mMediaPlayer.isPlaying();
    }

    /**
     * 現在のバッファリング進捗率を取得します。
     *
     * @return バッファリング進捗率(0-100)
     */
    @Override
    public int getBufferPercentage() {
        if (mMediaPlayer != null) {
            return mCurrentBufferPercentage;
        }
        return 0;
    }

    /**
     * 再生可能な状態かどうかを返します。 エラー、IDLE、PREPARING状態ではないことを確認します。
     *
     * @return 再生可能な状態の場合true
     */
    public boolean isInPlaybackState() {
        return (mMediaPlayer != null
                && mCurrentState != STATE_ERROR
                && mCurrentState != STATE_IDLE
                && mCurrentState != STATE_PREPARING);
    }

    /**
     * オーディオセッションIDを取得します。
     *
     * @return オーディオセッションID
     */
    @Override
    public int getAudioSessionId() {
        if (mMediaPlayer != null) {
            return mMediaPlayer.getAudioSessionId();
        }
        return 0;
    }

    /**
     * 一時停止が可能かどうかを返します。
     *
     * @return 常にtrue
     */
    @Override
    public boolean canPause() {
        return true;
    }

    /**
     * 巻き戻しが可能かどうかを返します。
     *
     * @return 常にtrue
     */
    @Override
    public boolean canSeekBackward() {
        return true;
    }

    /**
     * 早送りが可能かどうかを返します。
     *
     * @return 常にtrue
     */
    @Override
    public boolean canSeekForward() {
        return true;
    }

    /**
     * 音声がONになっているかどうかを返します。
     *
     * @return 音声がONの場合true
     */
    public boolean isVolume() {
        return mAudioVolumeIsOn;
    }

    /**
     * 音量を設定します。 音量が0でない場合はAudio Focusをリクエストし、リスナーに通知します。
     *
     * @param i 左チャンネルの音量(0.0-1.0)
     * @param i2 右チャンネルの音量(0.0-1.0)
     */
    public void setVolume(final int i, final int i2) {
        if (mMediaPlayer != null) {
            if (i != 0 && i2 != 0) {
                mAudioVolumeIsOn = true;
                requestAudioFocus();
            } else {
                mAudioVolumeIsOn = false;
                abandonAudioFocus();
            }
            mMediaPlayer.setVolume(i, i2);
            if (mListener != null) {
                mListener.onChangeAudioVolume(mAudioVolumeIsOn);
            }
        }
    }

    /** Audio Focusを取得します。 バックグラウンドで流れている音声は停止します。 */
    private void requestAudioFocus() {
        if (ADGSettings.getVideoAudioType() == VideoAudioType.MIX) {
            return;
        }
        if (mAudioManager == null) {
            LogUtils.w("AudioManager is null, cannot request audio focus.");
            return;
        }
        // 現在のスレッドのLooperを取得。nullの場合はメインLooperを使用
        Looper looper = Looper.myLooper();
        if (looper == null) {
            looper = Looper.getMainLooper();
        }
        Handler handler = new Handler(looper);
        if (mAudioFocusChangeListener == null) {
            mAudioFocusChangeListener = new AudioFocusChangeListener();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mPlaybackAttributes == null) {
                return;
            }
            mAudioFocusRequest =
                    new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                            .setAudioAttributes(mPlaybackAttributes)
                            .setWillPauseWhenDucked(true)
                            .setOnAudioFocusChangeListener(mAudioFocusChangeListener, handler)
                            .build();
            int res = mAudioManager.requestAudioFocus(mAudioFocusRequest);
            if (res == AudioManager.AUDIOFOCUS_REQUEST_FAILED) {
                LogUtils.d("AUDIOFOCUS_REQUEST_FAILED");
            } else if (res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                LogUtils.d("AUDIOFOCUS_REQUEST_GRANTED");
            } else if (res == AudioManager.AUDIOFOCUS_REQUEST_DELAYED) {
                LogUtils.d("AUDIOFOCUS_REQUEST_DELAYED");
            }
        } else {
            int res =
                    mAudioManager.requestAudioFocus(
                            mAudioFocusChangeListener,
                            AudioManager.STREAM_MUSIC,
                            AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
            if (res == AudioManager.AUDIOFOCUS_REQUEST_FAILED) {
                LogUtils.d("AUDIOFOCUS_REQUEST_FAILED");
            } else if (res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                LogUtils.d("AUDIOFOCUS_REQUEST_GRANTED");
            }
        }
    }

    /** Audio Focusを破棄します。 バックグラウンドで再生されていた音声は再開されます。 */
    private void abandonAudioFocus() {
        if (ADGSettings.getVideoAudioType() == VideoAudioType.MIX) {
            return;
        }
        if (mAudioManager == null) {
            LogUtils.w("AudioManager is null, cannot abandon audio focus.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else {
            if (mAudioFocusChangeListener != null) {
                mAudioManager.abandonAudioFocus(mAudioFocusChangeListener);
            }
        }
    }

    /** Audio Focusの変更を通知するリスナークラスです。 Focusを失った場合は音量を0に設定します。 */
    private class AudioFocusChangeListener implements AudioManager.OnAudioFocusChangeListener {
        /**
         * Audio Focusの変更時に呼ばれます。
         *
         * @param focusChange Focus変更タイプ
         */
        @Override
        public void onAudioFocusChange(final int focusChange) {
            switch (focusChange) {
                case AudioManager.AUDIOFOCUS_GAIN:
                    LogUtils.d("AUDIOFOCUS_GAIN");
                    break;
                case AudioManager.AUDIOFOCUS_LOSS:
                    LogUtils.d("AUDIOFOCUS_LOSS");
                    setVolume(0, 0);
                    break;
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                    LogUtils.d("AUDIOFOCUS_LOSS_TRANSIENT");
                    setVolume(0, 0);
                    break;
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                    LogUtils.d("AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK");
                    setVolume(0, 0);
                    break;
            }
        }
    }
}
