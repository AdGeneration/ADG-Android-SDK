package com.socdm.d.adgeneration.video.view;

import android.content.Context;
import android.graphics.Color;
import android.util.AndroidRuntimeException;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.ADGPlayerError;
import com.socdm.d.adgeneration.video.config.AdConfiguration;
import com.socdm.d.adgeneration.video.config.Const;
import com.socdm.d.adgeneration.video.utils.Dips;
import com.socdm.d.adgeneration.video.utils.Views;

/** VAST広告を表示するためのビュークラスです。 VastPlayerをラップし、広告の再生制御、UIコンポーネント（音声ボタン、リプレイボタンなど）の管理を行います。 */
public class AdView extends FrameLayout implements VastPlayer.VastMediaEventListener {
    /** AdViewのインスタンスを生成できない場合にスローされる例外です */
    public static final class CannotInstantiateException extends Exception {
        @NonNull public final ADGPlayerError error;

        /**
         * エラー情報を指定してCannotInstantiateExceptionを生成します。
         *
         * @param error エラー情報
         */
        public CannotInstantiateException(@NonNull final ADGPlayerError error) {
            this.error = error;
        }
    }

    /** AdViewからの各種イベントを受け取るリスナーインターフェースです */
    public interface EventListener {
        /** 動画の再生が開始された時に呼ばれます */
        void onAdViewStartVideo();

        /**
         * 広告の再生に失敗した時に呼ばれます
         *
         * @param error エラー情報
         */
        void onAdViewFailedToPlay(@NonNull ADGPlayerError error);

        /** 広告がクリックされた時に呼ばれます */
        void onAdViewClick();

        /** 広告がクリックスルーされた時に呼ばれます */
        void onAdViewClickThrough();

        /** 広告ビューがウィンドウから削除された時に呼ばれます */
        void onAdViewDetachedFromWindow();
    }

    @NonNull private final Context mContext;
    @NonNull final EventListener listener;
    @Nullable private AdConfiguration mAdConfiguration;
    @Nullable private VastPlayer mVastPlayer;
    @Nullable private LinearLayout mEndCreditLayout;
    @Nullable private ImageView mLinkButton;
    @Nullable private ImageView mReplayButton;
    @NonNull private final FrameLayout mSoundButtonLayout;
    @NonNull private final ImageView mSoundOnButton;
    @NonNull private final ImageView mSoundOffButton;
    @Nullable private LinearLayout mPauseLayoutWhenOutView;
    @Nullable private ImageView mPlayIcon;
    private boolean isCompleted;
    private final boolean isTiny;
    private final boolean isNativeOptout;

    // onMeasure()でのオブジェクト割り当てを避けるため、再利用可能なLayoutParamsを事前に割り当て
    @NonNull private final LayoutParams mSoundOffButtonLayoutParams;
    @NonNull private final LayoutParams mSoundOnButtonLayoutParams;
    @Nullable private LinearLayout.LayoutParams mReplayButtonLayoutParams;
    @Nullable private LinearLayout.LayoutParams mLinkButtonLayoutParams;

    /**
     * AdViewのインスタンスを生成します。
     *
     * @param context コンテキスト
     * @param listener イベントリスナー
     * @param isTiny 小さいサイズの広告かどうか
     * @param isWipe Wipe広告かどうか
     * @param isNativeOptout ネイティブオプトアウトの設定
     * @throws CannotInstantiateException インスタンス生成に失敗した場合
     */
    public AdView(
            @NonNull final Context context,
            @NonNull final EventListener listener,
            final boolean isTiny,
            final boolean isWipe,
            final boolean isNativeOptout)
            throws CannotInstantiateException {
        super(context);
        mContext = context;
        this.listener = listener;
        this.isTiny = isTiny;
        this.isNativeOptout = isNativeOptout;

        // onMeasure()で再利用するLayoutParamsを事前に作成
        // 各ボタンに独立したLayoutParamsインスタンスを使用
        mSoundOffButtonLayoutParams = new LayoutParams(0, 0);
        mSoundOnButtonLayoutParams = new LayoutParams(0, 0);
        if (!isTiny) {
            mReplayButtonLayoutParams = new LinearLayout.LayoutParams(0, 0);
            mLinkButtonLayoutParams = new LinearLayout.LayoutParams(0, 0);
        }

        setBackgroundColor(Color.TRANSPARENT);
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        LayoutParams params =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.CENTER;
        setLayoutParams(params);

        mVastPlayer = new VastPlayer(mContext, isWipe);
        mVastPlayer.setVastMediaEventListener(this);
        mVastPlayer.setOnClickListener(new OnClickAdListener());
        mVastPlayer.setBackgroundColor(Color.TRANSPARENT);
        mVastPlayer.setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        LayoutParams vpParams =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        vpParams.gravity = Gravity.CENTER;
        mVastPlayer.setLayoutParams(vpParams);
        addView(mVastPlayer);
        mSoundButtonLayout = new FrameLayout(mContext);
        LayoutParams sblp =
                new LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sblp.gravity = Gravity.START | Gravity.BOTTOM;
        mSoundButtonLayout.setLayoutParams(sblp);
        mSoundButtonLayout.setBackgroundColor(Color.TRANSPARENT);
        addView(mSoundButtonLayout);

        mSoundOffButton = new ImageView(mContext);
        mSoundOffButton.setAdjustViewBounds(true);
        mSoundOffButton.setOnClickListener(new OnSoundOffListener());
        mSoundOffButton.setBackgroundColor(Color.TRANSPARENT);
        mSoundOffButton.setVisibility(INVISIBLE);
        mSoundButtonLayout.addView(mSoundOffButton);

        mSoundOnButton = new ImageView(mContext);
        mSoundOnButton.setAdjustViewBounds(true);
        mSoundOnButton.setOnClickListener(new OnSoundOnListener());
        mSoundOnButton.setBackgroundColor(Color.TRANSPARENT);
        mSoundOnButton.setVisibility(INVISIBLE);
        mSoundButtonLayout.addView(mSoundOnButton);

        if (!isTiny) {
            mEndCreditLayout = new LinearLayout(mContext);
            mEndCreditLayout.setBackgroundColor(Color.argb(80, 0, 0, 0));
            LayoutParams ecwParams =
                    new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
            mEndCreditLayout.setLayoutParams(ecwParams);
            mEndCreditLayout.setOrientation(LinearLayout.HORIZONTAL);
            mEndCreditLayout.setGravity(Gravity.CENTER);
            addView(mEndCreditLayout);

            mReplayButton = new ImageView(mContext);
            mReplayButton.setOnClickListener(new OnReplayListener());
            mReplayButton.setBackgroundColor(Color.TRANSPARENT);
            mEndCreditLayout.addView(mReplayButton);

            mLinkButton = new ImageView(mContext);
            mLinkButton.setOnClickListener(new OnClickThroughAdListener());
            mLinkButton.setBackgroundColor(Color.TRANSPARENT);
            mEndCreditLayout.addView(mLinkButton);

            mPauseLayoutWhenOutView = new LinearLayout(mContext);
            mPauseLayoutWhenOutView.setBackgroundColor(Color.argb(80, 0, 0, 0));
            mPauseLayoutWhenOutView.setLayoutParams(ecwParams);
            mPauseLayoutWhenOutView.setOrientation(LinearLayout.HORIZONTAL);
            mPauseLayoutWhenOutView.setGravity(Gravity.CENTER);
            mPauseLayoutWhenOutView.setVisibility(INVISIBLE);
            addView(mPauseLayoutWhenOutView);

            mPlayIcon = new ImageView(mContext);
            mPlayIcon.setBackgroundColor(Color.TRANSPARENT);
            mPauseLayoutWhenOutView.addView(mPlayIcon);
        }

        try {
            Views.setImageFromAssets(mContext, mSoundOffButton, Const.UI_SOUND_OFF_BUTTON_URL);
            Views.setImageFromAssets(mContext, mSoundOnButton, Const.UI_SOUND_ON_BUTTON_URL);

            if (!isTiny) {
                Views.setImageFromAssets(
                        mContext, mReplayButton, Const.UI_INLINE_REPLAY_BUTTON_URL);
                Views.setImageFromAssets(mContext, mLinkButton, Const.UI_INLINE_LINK_BUTTON_URL);
                Views.setImageFromAssets(mContext, mPlayIcon, Const.UI_VIDEO_ICON_PLAY_URL);
            }
        } catch (Exception e) {
            throw new CannotInstantiateException(ADGPlayerError.UNSPECIFIED);
        }
    }

    /**
     * このコンストラクタは使用できません。常にAndroidRuntimeExceptionをスローします。
     *
     * @param context コンテキスト
     * @throws AndroidRuntimeException 常にスローされます
     * @deprecated このコンストラクタは使用しないでください。{@link #AdView(Context, EventListener, boolean, boolean,
     *     boolean)}を使用してください。
     */
    @Deprecated
    public AdView(@NonNull final Context context) throws AndroidRuntimeException {
        super(context);
        throw new AndroidRuntimeException("Default constructor cannot use.");
    }

    /** ビューがウィンドウから削除される際に呼ばれます。 リスナーに通知を行います。 */
    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        listener.onAdViewDetachedFromWindow();
    }

    /**
     * ビューのサイズを測定します。 広告サイズに応じて音声ボタンやエンドクレジットボタンのサイズを調整します。
     *
     * @param widthMeasureSpec 幅の測定仕様
     * @param heightMeasureSpec 高さの測定仕様
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int soundButtonSize = (int) (MeasureSpec.getSize(widthMeasureSpec) * 0.128);

        int endcreditButtonWidth = (int) (MeasureSpec.getSize(widthMeasureSpec) * 0.285);
        int endcreditButtonHeight = (int) (endcreditButtonWidth / 1.3125);

        if (isTiny) {
            mSoundOffButtonLayoutParams.width = soundButtonSize * 2;
            mSoundOffButtonLayoutParams.height = soundButtonSize * 2;
            mSoundOnButtonLayoutParams.width = soundButtonSize * 2;
            mSoundOnButtonLayoutParams.height = soundButtonSize * 2;
            mSoundOffButton.setLayoutParams(mSoundOffButtonLayoutParams);
            mSoundOnButton.setLayoutParams(mSoundOnButtonLayoutParams);
        } else {
            mSoundOffButtonLayoutParams.width = soundButtonSize;
            mSoundOffButtonLayoutParams.height = soundButtonSize;
            mSoundOnButtonLayoutParams.width = soundButtonSize;
            mSoundOnButtonLayoutParams.height = soundButtonSize;
            mSoundOffButton.setLayoutParams(mSoundOffButtonLayoutParams);
            mSoundOnButton.setLayoutParams(mSoundOnButtonLayoutParams);

            if (mReplayButtonLayoutParams != null && mReplayButton != null) {
                mReplayButtonLayoutParams.width = endcreditButtonWidth;
                mReplayButtonLayoutParams.height = endcreditButtonHeight;
                mReplayButtonLayoutParams.rightMargin = (int) Dips.dipsToFloatPixels(20, mContext);
                mReplayButton.setLayoutParams(mReplayButtonLayoutParams);
            }

            if (mLinkButtonLayoutParams != null && mLinkButton != null) {
                mLinkButtonLayoutParams.width = endcreditButtonWidth;
                mLinkButtonLayoutParams.height = endcreditButtonHeight;
                mLinkButton.setLayoutParams(mLinkButtonLayoutParams);
            }
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    /**
     * VastPlayerインスタンスを取得します。
     *
     * @return VastPlayerインスタンス。未初期化の場合はnull
     */
    @Nullable
    public VastPlayer getVastPlayer() {
        return mVastPlayer;
    }

    /**
     * 広告の再生を開始します。
     *
     * @param config 広告設定。nullの場合は何もしません
     */
    public void startAd(@Nullable final AdConfiguration config) {
        LogUtils.d(this + ": startAd");

        if (config == null) {
            return;
        }

        hideEndCredits();
        mAdConfiguration = config;
        if (mVastPlayer != null) {
            mVastPlayer.setVastAdThenLoadVideo(mAdConfiguration.getVastAd(), this.isNativeOptout);
        }
    }

    /**
     * 広告の再生を再開します。 プレイヤーが視認可能な状態の場合のみ再生を再開します。
     *
     * @param config 広告設定
     */
    public void resume(@NonNull final AdConfiguration config) {
        if (mVastPlayer != null && mVastPlayer.isViewable()) {
            mAdConfiguration = config;
            mVastPlayer.setVastAd(mAdConfiguration.getVastAd());
            mVastPlayer.play();
        }
    }

    /** 広告の再生を一時停止します。 */
    public void pause() {
        if (mVastPlayer != null) {
            mVastPlayer.pause();
        }
    }

    /** AdViewのリソースを解放します。 親ビューから削除し、すべての子ビューを削除してリセットを行います。 */
    public void release() {
        Views.removeFromParent(this);
        removeAllViews();
        reset();
    }

    /** AdViewの状態をリセットします。 VastPlayerを解放し、設定をクリアします。 */
    public void reset() {
        if (mVastPlayer != null) {
            mVastPlayer.releaseVastPlayer();
        }

        mVastPlayer = null;
        mAdConfiguration = null;
    }

    /** 音声をオンにします。 音声ボタンの表示を切り替え、プレイヤーの音声をオンにします。 */
    private void unmute() {
        if (mVastPlayer != null) {
            mSoundOnButton.setVisibility(INVISIBLE);
            mSoundOffButton.setVisibility(VISIBLE);
            mVastPlayer.unmute();
        }
    }

    /** 音声をオフにします。 音声ボタンの表示を切り替え、プレイヤーの音声をオフにします。 */
    private void mute() {
        if (mVastPlayer != null) {
            mSoundOnButton.setVisibility(VISIBLE);
            mSoundOffButton.setVisibility(INVISIBLE);
            mVastPlayer.mute();
        }
    }

    /** 動画を最初から再生します。 エンドクレジット画面を非表示にして再生を開始します。 */
    private void replay() {
        if (mVastPlayer != null && mVastPlayer.isInPlaybackState()) {
            mVastPlayer.replay();
            hideEndCredits();
        }
    }

    /** 動画の再生が開始された時に呼ばれます。 リスナーに通知を行います。 */
    @Override
    public void onStartVideo() {
        listener.onAdViewStartVideo();
    }

    @Override
    public void onPrepared(@NonNull final VideoView videoView) {
        /*
         * 動画準備完了したら背景色を黒にする。
         * ADGMediaViewの大きさはアプリ任意なので、横幅が動作サイズより大きい場合、
         * 音声ボタンが動画領域より外に出るので、黒背景にする。
         * 動画の準備が出来てから動画領域のサイズが決定するため、それまでAdViewは親のView領域と同サイズになっている。
         * 初期値で設定してしまうと、領域全体が黒背景になってしまうので、このタイミングで設定している。
         */
        setBackgroundColor(Color.BLACK);

        if (mAdConfiguration != null && mAdConfiguration.isSoundEnabled()) {
            unmute();
        } else {
            mute();
        }
    }

    /**
     * 動画が再生中の時に呼ばれます。
     *
     * @param videoView 再生中のVideoView
     */
    @Override
    public void onPlaying(@NonNull final VideoView videoView) {}

    /**
     * 動画の再生が完了した時に呼ばれます。 エンドクレジット画面を表示します。
     *
     * @param videoView 再生完了したVideoView
     */
    @Override
    public void onCompletion(@NonNull final VideoView videoView) {
        showEndCredits();
    }

    /**
     * 動画の再生エラーが発生した時に呼ばれます。 状態をリセットし、リスナーにエラーを通知します。
     *
     * @param error エラー情報
     */
    @Override
    public void onError(@NonNull final ADGPlayerError error) {
        reset();
        listener.onAdViewFailedToPlay(error);
    }

    /**
     * 音声のオン/オフが変更された時に呼ばれます。 音声ボタンの表示を切り替えます。
     *
     * @param isOn 音声がオンの場合true
     * @param videoView 対象のVideoView
     */
    @Override
    public void onChangeAudioVolume(final boolean isOn, @NonNull final VideoView videoView) {
        if (isOn) {
            mSoundOnButton.setVisibility(INVISIBLE);
            mSoundOffButton.setVisibility(VISIBLE);
        } else {
            mSoundOnButton.setVisibility(VISIBLE);
            mSoundOffButton.setVisibility(INVISIBLE);
        }
    }

    /**
     * 動画の再生が完了したかどうかを取得します。
     *
     * @return 再生完了している場合true
     */
    public boolean getCompleted() {
        return this.isCompleted;
    }

    /** エンドクレジット画面を表示します。 リプレイボタンとリンクボタンを表示し、音声ボタンを非表示にします。 */
    private void showEndCredits() {
        isCompleted = true;
        if (!isTiny && mEndCreditLayout != null) {
            mEndCreditLayout.setVisibility(VISIBLE);
            mSoundButtonLayout.setVisibility(INVISIBLE);
        }
    }

    /** エンドクレジット画面を非表示にします。 エンドクレジットを非表示にし、音声ボタンを表示します。 */
    private void hideEndCredits() {
        isCompleted = false;
        if (!isTiny && mEndCreditLayout != null) {
            mEndCreditLayout.setVisibility(INVISIBLE);
            mSoundButtonLayout.setVisibility(VISIBLE);
        }
    }

    /** ビューが視認可能になった時に呼ばれます。 動画の自動再生を行い、一時停止画面を非表示にします。 */
    public void callWhenInView() {
        if (mVastPlayer == null) {
            return;
        }

        mVastPlayer.callWhenInView();

        if (mVastPlayer.isInPlaybackState()
                && !isTiny
                && !isCompleted
                && mPauseLayoutWhenOutView != null) {
            mPauseLayoutWhenOutView.setVisibility(INVISIBLE);
        }
    }

    /** ビューが視認不可能になった時に呼ばれます。 動画を一時停止し、一時停止画面を表示します。 */
    public void callWhenOutOfView() {
        if (mVastPlayer == null) {
            return;
        }

        mVastPlayer.callWhenOutView();

        if (!isTiny && !isCompleted && mPauseLayoutWhenOutView != null) {
            mPauseLayoutWhenOutView.setVisibility(VISIBLE);
        }
    }

    /** 広告クリック時のリスナークラスです。 */
    private class OnClickAdListener implements OnClickListener {
        /**
         * 広告がクリックされた時に呼ばれます。
         *
         * @param view クリックされたView
         */
        @Override
        public void onClick(@NonNull final View view) {
            LogUtils.d(this + ": onClick");
            listener.onAdViewClick();
        }
    }

    /** 広告クリックスルー時のリスナークラスです。 エンドクレジット画面のリンクボタンクリック時に使用されます。 */
    private class OnClickThroughAdListener implements OnClickListener {
        /**
         * リンクボタンがクリックされた時に呼ばれます。
         *
         * @param view クリックされたView
         */
        @Override
        public void onClick(@NonNull final View view) {
            LogUtils.d(this + ": onClick");
            listener.onAdViewClickThrough();
        }
    }

    /** リプレイボタンクリック時のリスナークラスです。 */
    private class OnReplayListener implements OnClickListener {
        /**
         * リプレイボタンがクリックされた時に呼ばれます。 動画を最初から再生します。
         *
         * @param view クリックされたView
         */
        @Override
        public void onClick(@NonNull final View view) {
            replay();
        }
    }

    /** 音声ONボタンクリック時のリスナークラスです。 */
    private class OnSoundOnListener implements OnClickListener {
        /**
         * 音声ONボタンがクリックされた時に呼ばれます。 音声をオンにします。
         *
         * @param view クリックされたView
         */
        @Override
        public void onClick(@NonNull final View view) {
            unmute();
        }
    }

    /** 音声OFFボタンクリック時のリスナークラスです。 */
    private class OnSoundOffListener implements OnClickListener {
        /**
         * 音声OFFボタンがクリックされた時に呼ばれます。 音声をオフにします。
         *
         * @param view クリックされたView
         */
        @Override
        public void onClick(@NonNull final View view) {
            mute();
        }
    }
}
