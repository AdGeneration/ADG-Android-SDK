package com.socdm.d.adgeneration.mediation;

import androidx.annotation.NonNull;

import com.socdm.d.adgeneration.AdBridgingObject;

import jp.supership.sscore.type.Optional;

public class MediationModel {
    public static final class MediationModelException extends Exception {
        public MediationModelException(@NonNull final String message) {
            super(message);
        }
    }

    @NonNull private final AdBridgingObject adObject;

    public MediationModel(@NonNull final Optional<AdBridgingObject> adObject)
            throws MediationModelException {
        try {
            this.adObject = adObject.unwrap();
        } catch (Optional.NotPresentException e) {
            throw new MediationModelException("AdBridgingObject is not present.");
        }
    }

    long getRotationInMilliseconds() {
        return adObject.getRotationInMilliseconds();
    }

    boolean isMovie() {
        return adObject.isMediationMovie();
    }
}
