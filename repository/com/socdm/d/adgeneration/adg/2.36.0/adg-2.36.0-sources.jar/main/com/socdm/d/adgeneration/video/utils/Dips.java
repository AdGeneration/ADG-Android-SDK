package com.socdm.d.adgeneration.video.utils;

import android.content.Context;
import android.util.DisplayMetrics;
import android.util.TypedValue;

import androidx.annotation.NonNull;

public class Dips {
    public static float pixelsToFloatDips(final float pixels, @NonNull final Context context) {
        return pixels / getDensity(context);
    }

    public static float dipsToFloatPixels(final float dips, @NonNull final Context context) {
        return dips * getDensity(context);
    }

    private static float getDensity(@NonNull final Context context) {
        return context.getResources().getDisplayMetrics().density;
    }

    public static float asFloatPixels(final float dips, @NonNull final Context context) {
        final DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dips, displayMetrics);
    }

    public static int asIntPixels(final float dips, @NonNull final Context context) {
        return (int) (asFloatPixels(dips, context) + 0.5f);
    }
}
