package com.socdm.d.adgeneration.utils;

import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class UIUtils {

    @NonNull
    public static <T extends View> List<T> findViewsWithClass(
            @NonNull final View v, @NonNull final Class<T> clazz) {
        List<T> views = new ArrayList<T>();
        findViewsWithClass(v, clazz, views);
        return views;
    }

    public static <T extends View> void findViewsWithClass(
            @NonNull final View v, @NonNull final Class<T> clazz, @NonNull final List<T> views) {
        if (clazz.isAssignableFrom(v.getClass())) {
            views.add(clazz.cast(v));
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                findViewsWithClass(g.getChildAt(i), clazz, views);
            }
        }
    }
}
