package com.socdm.d.adgeneration;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.socdm.d.adgeneration.adresponse.Response;
import com.socdm.d.adgeneration.adresponse.ResponseParserException;
import com.socdm.d.adgeneration.nativead.ADGNativeAd;
import com.socdm.d.adgeneration.nativead.ADGNativeAdModel;

import jp.supership.sscore.tracking.SSCoreTrackingEventSender;
import jp.supership.sscore.type.Optional;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

@Deprecated
final class ADGResponse {

    @NonNull private final AdBridgingObject object;

    @Nullable private volatile Optional<ADGNativeAd> nativeAdCache = null;
    @NonNull private final Object lock = new Object(); // nativeAdCache用のロックオブジェクト

    public ADGResponse(@NonNull final AdBridgingObject object) {
        this.object = object;
    }

    @VisibleForTesting
    public ADGResponse(@NonNull final JSONObject obj) throws ResponseParserException {
        this(Objects.requireNonNull(AdBridgingObjectFactory.fromJSON(obj)));
    }

    /**
     * AdBridgingObjectを取得します
     *
     * @return AdBridgingObject
     */
    @NonNull
    public AdBridgingObject getAdBridgingObject() {
        return object;
    }

    public boolean isInvalidResponse() {
        return TextUtils.isEmpty(this.getAd()) && TextUtils.isEmpty(this.getBeacon());
    }

    public boolean isNoAd() {
        return object.isNoAd();
    }

    /**
     * レスポンスにmediationが含まれているかの真偽値を返す
     *
     * @return 含む場合はtrue, 含まない場合はfalse
     */
    public boolean isMediation() {
        return object.isMediationType();
    }

    // getter and setter
    @NonNull
    public String getAd() {
        return object.getAd().orElse("");
    }

    @Nullable
    public String getAdmPayload() {
        return object.getAdmPayload().maybe();
    }

    @NonNull
    public String getBeacon() {
        return object.getBeaconUrl().orElse("");
    }

    @Deprecated
    public void setBeacon(String beacon) {
        // not impl
    }

    @NonNull
    public String getScheduleId() {
        return object.getScheduleId().orElse("");
    }

    @NonNull
    public String getAdNetworkId() {
        return object.getAdNetworkId().orElse("");
    }

    @NonNull
    public String getCreativeId() {
        return object.getCreativeId().orElse("");
    }

    @NonNull
    public String getDspId() {
        return object.getDspId().orElse("");
    }

    @NonNull
    public String getSeat() {
        return object.getSeat().orElse("");
    }

    @NonNull
    public Optional<ADGNativeAd> getNativeAd() {
        if (nativeAdCache == null) {
            synchronized (lock) {
                if (nativeAdCache == null) {
                    nativeAdCache = ADGNativeAdModel.create(this.object).map(ADGNativeAd::new);
                }
            }
        }
        return nativeAdCache;
    }

    @Nullable
    public String getVastxml() {
        return object.getVastXml().maybe();
    }

    private int getMediationType() {
        return object.getMediationType();
    }

    @Nullable
    public String getMediationClassName() {
        return object.getMediationClassName().maybe();
    }

    @Nullable
    public String getMediationAdId() {
        return object.getMediationAdId().maybe();
    }

    @Nullable
    public String getMediationParam() {
        try {
            final Map<String, Object> param = object.getMediationParam().unwrap();
            return new JSONObject(param).toString();
        } catch (Optional.NotPresentException e) {
            return null;
        }
    }

    public int getMediationMovie() {
        return object.getMediationMovie();
    }

    @Nullable
    public String getBidderSuccessfulName() {
        return object.getBidderSuccessfulName().maybe();
    }

    @Nullable
    public ArrayList<String> getTrackerBiddingNotifyUrl() {
        return object.getTrackerBiddingNotifyUrls().map(ArrayList::new).maybe();
    }

    @Deprecated
    public void setTrackerBiddingNotifyUrl(ArrayList<String> trackerBiddingNotifyUrl) {
        // not impl
    }

    /**
     * Viewable計測パラメータを取得します
     *
     * @return Viewable計測パラメータ
     */
    @Deprecated
    @NonNull
    ResponseViewabilityParams getViewabilityParams() {
        return object.getViewabilityParams().orElse(ResponseViewabilityParams.DEFAULT);
    }

    @Deprecated
    @Nullable
    public ArrayList<String> getTrackerImp() {
        return object.getImpBeacon().map(ArrayList::new).maybe();
    }

    @Deprecated
    public void setTrackerImp(ArrayList<String> trackerImp) {
        // not impl
    }

    @Deprecated
    @Nullable
    public ArrayList<String> getTrackerViewableMeasured() {
        return object.getViewableMeasuredBeacon().map(ArrayList::new).maybe();
    }

    @Deprecated
    public void setTrackerViewableMeasured(ArrayList<String> trackerViewableMeasured) {
        // not impl
    }

    @Deprecated
    @Nullable
    public ArrayList<String> getTrackerViewableImp() {
        return object.getViewableImpBeacon().map(ArrayList::new).maybe();
    }

    @Deprecated
    public void setTrackerViewableImp(ArrayList<String> trackerViewableImp) {
        // not impl
    }

    public long getRotationTime() {
        return object.getRotationInMilliseconds();
    }

    @Deprecated
    public void setRotationTime(int rotationTime) {
        // not impl
    }

    @Deprecated
    public int getDisplayType() {
        return object.getDisplayType();
    }

    @Deprecated
    public void setDisplayType(int displayType) {
        // not impl
    }

    @NonNull
    @Deprecated
    public String getSoc() {
        return object.getSoc();
    }

    @Deprecated
    public void setSoc(String soc) {
        // not impl
    }

    @NonNull
    @Deprecated
    public String getIdfa() {
        return object.getIdfa();
    }

    @Deprecated
    public void setIdfa(String idfa) {
        // not impl
    }

    @NonNull
    @Deprecated
    public String getAnid() {
        return object.getAnid();
    }

    @Deprecated
    public void setAnid(String anid) {
        // not impl
    }

    @NonNull
    @Deprecated
    public String getDiid() {
        return object.getDiid();
    }

    @Deprecated
    public void setDiid(String diid) {
        // not impl
    }

    // This class is used for testing only
    @Deprecated
    private static final class AdBridgingObjectFactory {
        private AdBridgingObjectFactory() {}

        @NonNull
        static AdBridgingObject fromJSON(@NonNull final JSONObject jsonObject)
                throws ResponseParserException {
            final Response response = Response.fromJSON(Optional.of(jsonObject));
            return new AdBridgingObject(
                    response, Optional.empty(), new SSCoreTrackingEventSender());
        }
    }
}
