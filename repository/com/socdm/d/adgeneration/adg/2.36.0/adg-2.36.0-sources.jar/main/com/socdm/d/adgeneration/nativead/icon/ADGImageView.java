package com.socdm.d.adgeneration.nativead.icon;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.util.LruCache;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.utils.LogUtils;

import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;

public class ADGImageView extends androidx.appcompat.widget.AppCompatImageView {

    public ADGImageView(
            @NonNull final Context context,
            @NonNull final String url,
            @Nullable final Integer width,
            @Nullable final Integer height) {
        super(context);
        Uri.Builder iconBuilder = Uri.parse(url).buildUpon();
        BitmapCache.createCacheIfNeeded();
        Bitmap cachedBitmap = BitmapCache.getBitmapFromMemoryCache(url);
        if (cachedBitmap != null) {
            LogUtils.d("ADGImageView bitmap uses cache.");
            this.setImageBitmap(cachedBitmap);
        } else {
            LogUtils.d("ADGImageView bitmap is download from URL.");
            AsyncTaskHttpRequest iconTask = new AsyncTaskHttpRequest(this, width, height);
            iconTask.execute(iconBuilder);
        }
    }

    private class AsyncTaskHttpRequest extends AsyncTask<Uri.Builder, Void, Bitmap> {

        @NonNull private final WeakReference<ImageView> imageViewReference;
        @Nullable private Integer width;
        @Nullable private Integer height;
        @Nullable private URL url;

        public AsyncTaskHttpRequest(
                @NonNull final ImageView imageView,
                @Nullable final Integer width,
                @Nullable final Integer height) {
            this.imageViewReference = new WeakReference<>(imageView);
            this.width = width;
            this.height = height;
        }

        @Nullable
        @Override
        protected Bitmap doInBackground(@NonNull final Uri.Builder... builder) {
            HttpURLConnection connection = null;
            InputStream inputStream = null;
            Bitmap bitmap = null;
            try {
                url = new URL(builder[0].toString());
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                inputStream = connection.getInputStream();
                bitmap = BitmapFactory.decodeStream(inputStream);
                if (bitmap != null && width != null && height != null) {
                    bitmap = Bitmap.createScaledBitmap(bitmap, width, height, false);
                }
            } catch (Exception e) {
                // compileSdkVersionが24以降だとgetInputStream()でIndexOutOfBoundsExceptionが発生する場合があった
                // まれにOutOfMemory、EOFExceptionでクラッシュが発生する報告があった
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (inputStream != null) {
                        inputStream.close();
                    }
                } catch (Exception ignored) {
                }
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(@Nullable final Bitmap result) {
            if (this.imageViewReference != null && result != null) {
                ImageView imageView = this.imageViewReference.get();
                if (imageView == null) return;

                imageView.setImageBitmap(result);
                if (url != null) {
                    BitmapCache.addBitmapToMemoryCache(url.toString(), result);
                }
            }
        }
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR1)
    private static class BitmapCache {
        @Nullable private static LruCache<String, Bitmap> mMemoryCache;

        public static void createCacheIfNeeded() {
            if (!canSupported()) return;
            if (mMemoryCache != null) return;

            // Get max available VM memory, exceeding this amount will throw an
            // OutOfMemory exception. Stored in kilobytes as LruCache takes an
            // int in its constructor.
            final int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);

            // Use 1/8th of the available memory for this memory cache.
            final int cacheSize = maxMemory / 8;

            mMemoryCache =
                    new LruCache<String, Bitmap>(cacheSize) {
                        @Override
                        protected int sizeOf(
                                @NonNull final String key, @NonNull final Bitmap bitmap) {
                            // The cache size will be measured in kilobytes rather than
                            // number of items.
                            return bitmap.getByteCount() / 1024;
                        }
                    };
        }

        public static void addBitmapToMemoryCache(
                @NonNull final String key, @NonNull final Bitmap bitmap) {
            if (!canSupported()) return;

            if (getBitmapFromMemoryCache(key) == null) {
                mMemoryCache.put(key, bitmap);
            }
        }

        @Nullable
        public static Bitmap getBitmapFromMemoryCache(@NonNull final String key) {
            if (!canSupported()) return null;

            return mMemoryCache.get(key);
        }

        @NonNull
        private static Boolean canSupported() {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR1;
        }
    }
}
