package com.socdm.d.adgeneration.Measurement;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.iab.omid.library.supershipjp.Omid;
import com.iab.omid.library.supershipjp.adsession.AdEvents;
import com.iab.omid.library.supershipjp.adsession.AdSession;
import com.iab.omid.library.supershipjp.adsession.AdSessionConfiguration;
import com.iab.omid.library.supershipjp.adsession.AdSessionContext;
import com.iab.omid.library.supershipjp.adsession.CreativeType;
import com.iab.omid.library.supershipjp.adsession.FriendlyObstructionPurpose;
import com.iab.omid.library.supershipjp.adsession.ImpressionType;
import com.iab.omid.library.supershipjp.adsession.Owner;
import com.iab.omid.library.supershipjp.adsession.Partner;
import com.iab.omid.library.supershipjp.adsession.VerificationScriptResource;
import com.socdm.d.adgeneration.ADGConsts;
import com.socdm.d.adgeneration.utils.AssetUtils;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.Measurement.VerificationModel;

import java.util.ArrayList;
import java.util.List;

/** OM SDKの利用に関するベースクラス 各広告フォーマットごとに計測時に必要な手順が違うので本クラスを継承させて足りない処理を追加実装する */
public abstract class BaseMeasurementManager {

    @Nullable public String omidJsServiceContent = null;
    @Nullable public Partner partner;
    @NonNull public String customReferenceData = "";
    @Nullable public AdSessionConfiguration adSessionConfiguration;
    @Nullable public AdSessionContext adSessionContext;

    @NonNull
    private final List<VerificationScriptResource> verificationScriptResources = new ArrayList<>();

    @Nullable public AdSession adSession;
    @Nullable public AdEvents adEvents;

    /**
     * コンストラクタ
     *
     * @param ct コンテキスト
     */
    public BaseMeasurementManager(@NonNull Context ct) {
        try {
            // OMSDKを初期化する
            Omid.activate(ct);

            // アクティベート可否で挙動をわける
            if (!Omid.isActive()) {
                // SDK failed to activate. Handle appropriately.
                onFailed("OM SDK is not Activated.");
            } else {
                fetchJSLibrary(ct);
            }
        } catch (IllegalArgumentException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * verificationScriptResourcesを生成する
     *
     * @param list VAST内の<Verification>タグのパラメータを格納したリスト
     */
    public void createVerificationScriptResourceWithoutParameters(
            @Nullable final ArrayList<VerificationModel> list) {
        if (list == null || list.isEmpty()) {
            LogUtils.e("VerificationModel is null.");
            return;
        }

        for (int i = 0; i < list.size(); i++) {
            VerificationModel model = list.get(i);
            if (model != null) {
                boolean isVendor = true;
                boolean isParam = true;

                if (model.getJavaScriptResource() == null
                        || TextUtils.isEmpty(model.getJavaScriptResource().toString())
                        || model.getJavaScriptResource().toString().trim().isEmpty()) {
                    LogUtils.e("JavaScriptResource URL is null.");
                    return;
                }
                if (TextUtils.isEmpty(model.getVendor()) || model.getVendor().trim().isEmpty()) {
                    isVendor = false;
                }
                if (TextUtils.isEmpty(model.getVerificationParameters())
                        || model.getVerificationParameters().trim().isEmpty()) {
                    isParam = false;
                }

                if (!isVendor || !isParam) {
                    this.verificationScriptResources.add(
                            VerificationScriptResource
                                    .createVerificationScriptResourceWithoutParameters(
                                            model.getJavaScriptResource()));
                } else {
                    this.verificationScriptResources.add(
                            VerificationScriptResource
                                    .createVerificationScriptResourceWithParameters(
                                            model.getVendor(),
                                            model.getJavaScriptResource(),
                                            model.getVerificationParameters()));
                }
            }
        }
    }

    /**
     * セッション作成
     *
     * @param formatType 計測対象の広告フォーマット
     * @param webView 計測対象がバナー広告だった場合のWebView
     */
    public void createAdSession(
            @NonNull final MeasurementConsts.formatType formatType,
            @Nullable final WebView webView) {
        if (this.partner == null) {
            LogUtils.e("Failed to create AdSession: partner is null.");
            return;
        }

        try {
            // セッションの作成
            switch (formatType) {
                case nativeVideo:
                    if (this.omidJsServiceContent == null) {
                        LogUtils.e(
                                "Failed to create AdSessionContext: omidJsServiceContent is null.");
                        break;
                    }
                    this.adSessionContext =
                            AdSessionContext.createNativeAdSessionContext(
                                    this.partner,
                                    this.omidJsServiceContent,
                                    this.verificationScriptResources,
                                    null,
                                    this.customReferenceData);

                    this.adSessionConfiguration =
                            AdSessionConfiguration.createAdSessionConfiguration(
                                    CreativeType.VIDEO,
                                    ImpressionType.VIEWABLE,
                                    Owner.NATIVE,
                                    Owner.NATIVE,
                                    false);

                    if (this.adSessionConfiguration != null && this.adSessionContext != null) {
                        this.adSession =
                                AdSession.createAdSession(adSessionConfiguration, adSessionContext);
                    } else {
                        LogUtils.e(
                                "Failed to create AdSession: adSessionConfiguration or"
                                        + " adSessionContext is null.");
                    }
                    break;
                case nativeDisplay:
                    if (this.omidJsServiceContent == null) {
                        LogUtils.e(
                                "Failed to create AdSessionContext: omidJsServiceContent is null.");
                        break;
                    }
                    this.adSessionContext =
                            AdSessionContext.createNativeAdSessionContext(
                                    this.partner,
                                    this.omidJsServiceContent,
                                    this.verificationScriptResources,
                                    null,
                                    this.customReferenceData);

                    this.adSessionConfiguration =
                            AdSessionConfiguration.createAdSessionConfiguration(
                                    CreativeType.NATIVE_DISPLAY,
                                    ImpressionType.VIEWABLE,
                                    Owner.NATIVE,
                                    Owner.NATIVE,
                                    false);

                    if (this.adSessionConfiguration != null && this.adSessionContext != null) {
                        this.adSession =
                                AdSession.createAdSession(adSessionConfiguration, adSessionContext);
                    } else {
                        LogUtils.e(
                                "Failed to create AdSession: adSessionConfiguration or"
                                        + " adSessionContext is null.");
                    }
                    break;
                case webViewDisplay:
                    if (webView == null) {
                        LogUtils.e("WebView is null.");
                        break;
                    }
                    this.adSessionContext =
                            AdSessionContext.createHtmlAdSessionContext(
                                    this.partner, webView, null, this.customReferenceData);
                    this.adSessionConfiguration =
                            AdSessionConfiguration.createAdSessionConfiguration(
                                    CreativeType.HTML_DISPLAY,
                                    ImpressionType.VIEWABLE,
                                    Owner.NATIVE,
                                    Owner.NONE,
                                    false);
                    if (this.adSessionConfiguration != null && this.adSessionContext != null) {
                        this.adSession =
                                AdSession.createAdSession(adSessionConfiguration, adSessionContext);
                    } else {
                        LogUtils.e(
                                "Failed to create AdSession: adSessionConfiguration or"
                                        + " adSessionContext is null.");
                    }
                    break;
                default:
                    onFailed("An error occurred because an unsupported format was specified.");
                    break;
            }
        } catch (IllegalArgumentException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * ローカルのomsdk.jsを取得する
     *
     * @param ct コンテキスト
     */
    private void fetchJSLibrary(@NonNull Context ct) {

        this.omidJsServiceContent = AssetUtils.getOMSDKSource(ct);

        if (this.omidJsServiceContent != null && !this.omidJsServiceContent.isEmpty()) {
            LogUtils.d("Load omsdk.js from assets.");
            // PartnerIDを取得する
            createPartnerIdentify();
        } else {
            LogUtils.w("Error loading omsdk.js from assets.");
        }
    }

    /** パートナーIDを作成する */
    private void createPartnerIdentify() {
        try {
            this.partner =
                    Partner.createPartner(MeasurementConsts.PARTNER_NAME, ADGConsts.SDKVERSION);
        } catch (IllegalArgumentException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    /** イベント発行用インスタンスを生成する */
    public void createAdEventPublisher() {
        if (adSession == null) {
            return;
        }
        try {
            this.adEvents = AdEvents.createAdEvents(this.adSession);
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * 広告Viewを計測対象として登録し計測開始する
     *
     * @param adView 計測対象の広告View
     * @return true : 計測スタート / false : 異常終了
     */
    public boolean startMeasurement(@NonNull View adView) {
        if (this.adSession == null) {
            return false;
        }

        try {
            // Viewを登録
            updateRegisterAdView(adView);
            // イベント発行インスタンスを生成
            createAdEventPublisher();
            // 計測開始
            this.adSession.start();
        } catch (IllegalArgumentException | NullPointerException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * セッションの停止および破棄
     *
     * @return true : 正常に完了した / false : 完了できなかった
     */
    public boolean finishMeasurement() {
        if (this.adSession == null) {
            return false;
        }
        this.adSession.finish();
        this.adSession = null;
        return true;
    }

    /**
     * セッションに広告Viewを登録する
     *
     * @param adView 計測対象の広告View
     */
    public void updateRegisterAdView(@NonNull View adView) {
        if (this.adSession == null) {
            return;
        }
        try {
            // Viewを登録
            this.adSession.registerAdView(adView);
        } catch (IllegalArgumentException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * 広告に関係がないView(閉じるボタンなどの装飾)を登録する
     *
     * @param view 広告に対して障害物となるView
     * @param purpose 障害物のタイプ
     * @param detailedReason 障害物の存在理由
     */
    public void registerObstructions(
            @NonNull final View view,
            @NonNull final FriendlyObstructionPurpose purpose,
            @Nullable final String detailedReason) {
        if (this.adSession == null) {
            return;
        }
        try {
            this.adSession.addFriendlyObstruction(view, purpose, detailedReason);
        } catch (IllegalArgumentException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * 広告に関係がないViewとして登録した障害物を削除する
     *
     * @param view 広告に対して障害物として登録していたView
     */
    public void removeFriendlyObstruction(@NonNull View view) {
        if (this.adSession == null) {
            return;
        }
        try {
            this.adSession.removeFriendlyObstruction(view);
        } catch (IllegalArgumentException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    /** 広告に関係がないViewとして登録した障害物をすべて削除する */
    public void removeAllFriendlyObstruction() {
        if (this.adSession == null) {
            return;
        }
        try {
            this.adSession.removeAllFriendlyObstructions();
        } catch (IllegalArgumentException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * エラー処理
     *
     * @param msg エラーメッセージ
     * @return IllegalArgumentException
     */
    @NonNull
    public IllegalArgumentException onFailed(@Nullable String msg) {
        if (msg == null || msg.isEmpty()) {
            return new IllegalArgumentException();
        }
        return (new IllegalArgumentException(msg));
    }
}
