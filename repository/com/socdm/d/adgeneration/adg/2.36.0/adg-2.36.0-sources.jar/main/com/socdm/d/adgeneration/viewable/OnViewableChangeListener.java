package com.socdm.d.adgeneration.viewable;

import androidx.annotation.NonNull;

/** 視認性に変更があったときに呼ばれるリスナーです */
public interface OnViewableChangeListener {
    /**
     * 視認性に変更があったときに呼ばれます
     *
     * @param viewable trueなら視認可能、falseなら視認不可能
     * @param key 識別キー
     */
    void onViewableChanged(boolean viewable, @NonNull String key);
}
