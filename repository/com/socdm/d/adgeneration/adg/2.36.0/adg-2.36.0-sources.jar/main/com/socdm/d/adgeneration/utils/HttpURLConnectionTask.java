package com.socdm.d.adgeneration.utils;

import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.ADGConsts;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;

public class HttpURLConnectionTask extends AsyncTask<String, Void, String> {

    @Nullable AsyncTaskListener<String> listener = null;
    @Nullable private HttpURLConnection connection = null;
    @NonNull private String method = "GET";
    private boolean hasError = false;
    @Nullable private Exception exception;
    @NonNull private String url = "";
    @Nullable private String userAgent = null;

    // constructor
    public HttpURLConnectionTask(@NonNull final String url) {
        this(
                url,
                new AsyncTaskListener<>() {
                    @Override
                    public void onSuccess(@Nullable String result) {
                        LogUtils.d("HttpURLConnectionTask onSuccess");
                    }

                    @Override
                    public void onError(@NonNull Exception e) {
                        LogUtils.d("HttpURLConnectionTask onFailed");
                    }
                });
    }

    public HttpURLConnectionTask(
            @NonNull final String url, @Nullable final AsyncTaskListener<String> listener) {
        this.url = url;
        this.listener = listener;
    }

    // getter / setter
    @Nullable
    public HttpURLConnection getConnection() {
        return this.connection;
    }

    @NonNull
    public String getMethod() {
        return this.method;
    }

    public void setMethod(@NonNull final String method) {
        this.method = method;
    }

    @Nullable
    public String getUserAgent() {
        return this.userAgent;
    }

    public void setUserAgent(@Nullable final String userAgent) {
        this.userAgent = userAgent;
    }

    // task methods
    @Nullable
    @Override
    protected String doInBackground(@NonNull final String... params) {
        String result = "";
        try {
            this.connection = (HttpURLConnection) new URL(this.url).openConnection();
            this.connection.setReadTimeout(ADGConsts.TIMEOUT_INTERVAL);
        } catch (Exception e) {
            this.connection = null;
        }
        if (connection == null) {
            onError(new Exception("Failed to initialize HttpUrlConnection."));
            return null;
        }
        // switch reqeust method to POST
        if (method.equals("POST")) {
            toPostRequest(params.length > 0 ? params[0] : "");
        }

        if (this.userAgent != null && !this.userAgent.isEmpty()) {
            this.connection.setRequestProperty("User-Agent", this.userAgent);
        }

        // send request
        try {
            if (!hasError) {
                int status = connection.getResponseCode();
                if (status == HttpURLConnection.HTTP_OK) {
                    // try-with-resourcesでInputStreamを自動的にクローズ
                    try (InputStream in = new BufferedInputStream(connection.getInputStream())) {
                        result = readStream(in);
                    }
                } else if (status >= HttpURLConnection.HTTP_CREATED
                        && status <= HttpURLConnection.HTTP_PARTIAL) {
                    // 201-206
                } else if (status >= HttpURLConnection.HTTP_MULT_CHOICE
                        && status <= HttpURLConnection.HTTP_USE_PROXY) {
                    // 300-305
                } else if (status >= HttpURLConnection.HTTP_BAD_REQUEST
                        && status <= HttpURLConnection.HTTP_REQ_TOO_LONG) {
                    // 400-414
                    onError(new Exception("HTTP Request Failed:" + status));
                } else if (status >= HttpURLConnection.HTTP_INTERNAL_ERROR
                        && status <= HttpURLConnection.HTTP_VERSION) {
                    // 500-505
                    onError(new Exception("HTTP Request Failed:" + status));
                }
            }
        } catch (Exception e) {
            // クラッシュを防ぐため、すべての例外をここでキャッチする
            e.printStackTrace();
            onError(e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return result;
    }

    @Override
    protected void onPostExecute(@Nullable final String result) {
        if (listener != null) {
            if (!hasError) {
                listener.onSuccess(result);
            } else {
                listener.onError(
                        exception != null ? exception : new Exception("Unknown error occurred"));
            }
        }
    }

    // private methods
    private void onError(@NonNull final Exception e) {
        hasError = true;
        exception = e;
    }

    @SuppressWarnings("ConstantConditions")
    private void toPostRequest(@NonNull final String body) {
        try {
            connection.setRequestMethod("POST");
        } catch (NullPointerException | ProtocolException e) {
            onError(new Exception("Failed to set the request method to HttpUrlConnection."));
            return;
        }

        connection.setDoInput(true);
        connection.setDoOutput(true);

        try (BufferedOutputStream os = new BufferedOutputStream(connection.getOutputStream())) {
            os.write(body.getBytes());
            os.flush();
        } catch (Exception e) {
            onError(new Exception("Failed to get the output stream from HttpUrlConnection."));
        }
    }

    @NonNull
    private String readStream(@NonNull final InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        char[] buf = new char[1024];
        try (InputStreamReader reader = new InputStreamReader(in)) {

            int n;
            while (0 <= (n = reader.read(buf))) {
                sb.append(buf, 0, n);
            }
        }

        return sb.toString();
    }
}
