package com.socdm.d.adgeneration.Measurement;

import android.content.Context;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.iab.omid.library.supershipjp.Omid;
import com.iab.omid.library.supershipjp.adsession.media.InteractionType;
import com.iab.omid.library.supershipjp.adsession.media.MediaEvents;
import com.iab.omid.library.supershipjp.adsession.media.PlayerState;
import com.iab.omid.library.supershipjp.adsession.media.Position;
import com.iab.omid.library.supershipjp.adsession.media.VastProperties;
import com.socdm.d.adgeneration.utils.AsyncTaskListener;
import com.socdm.d.adgeneration.utils.AsyncTaskUtils;
import com.socdm.d.adgeneration.utils.HttpURLConnectionTask;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.Measurement.VerificationModel;
import com.socdm.d.adgeneration.video.vast.VastAd;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

/** ネイティブビデオ (NativeVideo) フォーマットの広告について OM SDKの計測およびトラッキングをおこなうクラス */
public class VideoViewMeasurementManager extends BaseMeasurementManager {

    @Nullable public MediaEvents mediaEvents;
    @NonNull private VastAd vastAd;
    public boolean loaded;

    public boolean isLoaded() {
        return this.loaded;
    }

    public void setLoaded(final boolean loaded) {
        this.loaded = loaded;
    }

    /**
     * コンストラクタ
     *
     * @param ct コンテキスト
     * @param vastAd 動画広告のVASTデータ
     */
    public VideoViewMeasurementManager(@NonNull Context ct, @NonNull VastAd vastAd) {
        super(ct);
        this.vastAd = vastAd;
        setLoaded(false);
    }

    /**
     * アドセッションを生成し計測開始
     *
     * @param adView 計測対象のView
     * @return Activate OK(true) or NG(false)
     */
    @Override
    public boolean startMeasurement(@NonNull View adView) {
        if (!Omid.isActive()) {
            onFailed("OM SDK is not Activated.");
            return false;
        }

        // VASTで返却された値を元にリソースファイルを準備する
        createVerificationScriptResourceWithoutParameters(this.vastAd.getVerifications());
        // セッションの準備
        createAdSession(MeasurementConsts.formatType.nativeVideo, null);
        // ビデオイベント発行用インスタンスを生成
        createMediaEventsPublisher();

        LogUtils.d("adSession starts.");
        return super.startMeasurement(adView);
    }

    /**
     * 動画再生開始イベントを送信する
     *
     * @param durationMs 動画の総再生時間（ミリ秒）
     * @param volume 音量（0.0 = ミュート, 1.0 = 最大）
     */
    public void sendStartMediaEvent(float durationMs, float volume) {
        if (!isLoaded() || this.adSession == null || this.mediaEvents == null) return;
        try {
            this.mediaEvents.start(durationMs, volume);
            LogUtils.d("sendMediaEvent : start");
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            onFailed("mediaEvents is not sending start");
            LogUtils.e("VideoViewMeasurementManager error", e);
        }
    }

    /** イベント発行用インスタンスを生成する */
    private void createMediaEventsPublisher() {
        if (super.adSession == null) {
            return;
        }
        try {
            this.mediaEvents = MediaEvents.createMediaEvents(this.adSession);
            LogUtils.d("mediaEvents Publish");
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            onFailed("mediaEvents is not Published");
            LogUtils.e("VideoViewMeasurementManager error", e);
        }
    }

    /**
     * スキップ可能な広告動画のロード開始を通知する
     *
     * @param skipOffset スキップ可能となる秒数
     * @param isAutoPlay 自動再生の有無
     * @param position ビデオの再生位置
     */
    public void sendLoadedForSkippableMedia(
            @NonNull final Float skipOffset,
            final boolean isAutoPlay,
            @NonNull final Position position) {
        final VastProperties vProps =
                VastProperties.createVastPropertiesForSkippableMedia(
                        skipOffset, isAutoPlay, position);
        try {
            if (this.adEvents == null) {
                return;
            }

            setLoaded(true);
            this.adEvents.loaded(vProps);
            LogUtils.d("ForSkip loaded :");
        } catch (Exception e) {
            onFailed("adEvents is not sending ForSkip");
            LogUtils.e("VideoViewMeasurementManager error", e);
        }
    }

    /**
     * スキップ不可の広告動画のロード開始を通知する
     *
     * @param isAutoPlay 自動再生の有無
     * @param position ビデオの再生位置
     */
    public void sendLoadedForNonSkippableMedia(
            final boolean isAutoPlay, @NonNull final Position position) {
        final VastProperties vProps =
                VastProperties.createVastPropertiesForNonSkippableMedia(isAutoPlay, position);
        try {
            if (this.adEvents == null) {
                return;
            }

            setLoaded(true);
            this.adEvents.loaded(vProps);
            LogUtils.d("NonSkip loaded :");
        } catch (Exception e) {
            onFailed("adEvents is not sending NonSkip");
            LogUtils.e("VideoViewMeasurementManager error", e);
        }
    }

    /**
     * プレイヤー領域の変化を通知する
     *
     * @param state プレイヤーの再生モード
     */
    public void sendPlayerStateChange(@NonNull final PlayerState state) {
        try {
            if (this.mediaEvents == null) {
                return;
            }
            this.mediaEvents.playerStateChange(state);
            LogUtils.d("playerStateChange : state = " + state);
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            onFailed("mediaEvents is not sending PlayerStateChange");
            LogUtils.e("VideoViewMeasurementManager error", e);
        }
    }

    /**
     * 画面遷移時のタイプを通知する
     *
     * @param type ユーザーインタラクションのタイプ
     */
    public void sendUserInteraction(@NonNull final InteractionType type) {
        try {
            if (this.mediaEvents == null) {
                return;
            }
            this.mediaEvents.adUserInteraction(type);
            LogUtils.d("adUserInteraction : type = " + type);
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            onFailed("mediaEvents is not sending adUserInteraction");
            LogUtils.e("VideoViewMeasurementManager error", e);
        }
    }

    /**
     * 動画イベントを通知する
     *
     * <p>再生開始（start）はduration/volumeが必要なため {@link #sendStartMediaEvent} を使用すること。
     *
     * @param event 動画イベントのタイプ
     */
    public void sendMediaEvent(@NonNull final MeasurementConsts.mediaEvents event) {
        // 動画のロードが未完了ならトラッキングイベントを受け付けない
        if (!isLoaded() || this.adSession == null) {
            return;
        }

        try {
            switch (event) {
                    // インプレッション開始
                case impression:
                    if (super.adEvents == null) return;
                    super.adEvents.impressionOccurred();
                    LogUtils.d("sendMediaEvent : impression");
                    break;
                    // 25%
                case firstQuartile:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.firstQuartile();
                    LogUtils.d("sendMediaEvent : firstQuartile");
                    break;
                    // 50%
                case midpoint:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.midpoint();
                    LogUtils.d("sendMediaEvent : midpoint");
                    break;
                    // 75%
                case thirdQuartile:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.thirdQuartile();
                    LogUtils.d("sendMediaEvent : thirdQuartile");
                    break;
                    // 100%
                case complete:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.complete();
                    LogUtils.d("sendMediaEvent : complete");
                    break;
                    // 一時停止
                case pause:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.pause();
                    LogUtils.d("sendMediaEvent : pause");
                    break;
                    // 再生再開
                case resume:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.resume();
                    LogUtils.d("sendMediaEvent : resume");
                    break;
                    // バッファリングにより再生を停止
                case bufferStart:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.bufferStart();
                    LogUtils.d("sendMediaEvent : bufferStart");
                    break;
                    // バッファリング後に再生を再開
                case bufferEnd:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.bufferFinish();
                    LogUtils.d("sendMediaEvent : bufferEnd");
                    break;
                    // プレイヤーのボリュームをONに変更した
                case volumeChangeOn:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.volumeChange(1.0f);
                    LogUtils.d("sendMediaEvent : volumeChangeOn");
                    break;
                    // プレイヤーのボリュームをOFFに変更した
                case volumeChangeOff:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.volumeChange(0.0f);
                    LogUtils.d("sendMediaEvent : volumeChangeOff");
                    break;
                    // 再生の早期終了
                case skipped:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.skipped();
                    LogUtils.d("sendMediaEvent : skipped");
                    break;
                    // プレイヤーの破棄
                case finish:
                    finishMeasurement();
                    LogUtils.d("sendMediaEvent : finish");
                    break;
                default:
                    break;
            }
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            onFailed("mediaEvent is not sending");
            LogUtils.e("VideoViewMeasurementManager error", e);
        }
    }

    /**
     * エラー用のトラッキングURLへリクエストをおこない、Exceptionを返却する
     *
     * @param msg エラーメッセージ
     * @return Exception エラー
     */
    @NonNull
    @Override
    public IllegalArgumentException onFailed(@Nullable String msg) {
        ArrayList<VerificationModel> verificationsList = this.vastAd.getVerifications();
        // VASTに含まれる各計測ベンダーのトラッキングイベントを検索
        for (VerificationModel model : verificationsList) {
            // 各計測ベンダーのverificationNotExecutedのURLを検索
            HashMap<String, URL> trackingEvents = model.getTrackingEvents();
            if (trackingEvents.get(MeasurementConsts.NOT_EXECUTED) == null) {
                continue;
            }
            // エラー用のURLへリクエストをおこなう
            httpErrorRequest(trackingEvents.get(MeasurementConsts.NOT_EXECUTED));
        }

        return super.onFailed(msg);
    }

    /**
     * HTTPリクエストを行う
     *
     * @param url エラー通知先
     */
    private void httpErrorRequest(@Nullable final URL url) {
        if (url == null) {
            LogUtils.w("httpErrorRequest URL is none.");
            return;
        }

        HttpURLConnectionTask requestTask =
                new HttpURLConnectionTask(
                        url.toString(),
                        new AsyncTaskListener<>() {
                            @Override
                            public void onSuccess(@Nullable String s) {
                                LogUtils.d("request succeed. " + url);
                            }

                            @Override
                            public void onError(@NonNull Exception e) {
                                LogUtils.d("request failed.(" + e.getMessage() + ") " + url);
                            }
                        });
        AsyncTaskUtils.execute(requestTask);
    }
}
