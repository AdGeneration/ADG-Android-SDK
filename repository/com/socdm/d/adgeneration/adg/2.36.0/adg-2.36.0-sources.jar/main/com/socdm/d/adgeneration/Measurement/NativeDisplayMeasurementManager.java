package com.socdm.d.adgeneration.Measurement;

import android.content.Context;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.iab.omid.library.supershipjp.Omid;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.Measurement.VerificationModel;

import java.util.ArrayList;

/** NativeDisplay フォーマットの広告について OM SDKの計測およびトラッキングをおこなうクラス */
public class NativeDisplayMeasurementManager extends BaseMeasurementManager {

    @Nullable private ArrayList<VerificationModel> eventTrackers;

    public void setEventTrackers(@Nullable final ArrayList<VerificationModel> eventTrackers) {
        this.eventTrackers = eventTrackers;
    }

    /** コンストラクタ */
    public NativeDisplayMeasurementManager(
            @NonNull final Context ct, @NonNull final ArrayList<VerificationModel> eventTrackers) {
        super(ct);

        setEventTrackers(eventTrackers);
    }

    /**
     * アドセッションを生成し計測開始
     *
     * @param adView 計測対象のView
     * @return Activate OK(true) or NG(false)
     */
    @Override
    public boolean startMeasurement(@NonNull View adView) {
        if (!Omid.isActive()) {
            onFailed("OM SDK is not Activated.");
            return false;
        }

        // NativeAdで返却された値を元にリソースファイルを準備する
        createVerificationScriptResourceWithoutParameters(this.eventTrackers);
        // セッションの準備
        createAdSession(MeasurementConsts.formatType.nativeDisplay, null);

        LogUtils.d("adSession starts");
        return super.startMeasurement(adView);
    }

    /**
     * Nativeイベントを通知する
     *
     * @param event 送信するイベントタイプ
     */
    public void sendNativeEvent(@NonNull final MeasurementConsts.nativeEvent event) {
        try {
            switch (event) {
                    // ロード開始
                case loaded:
                    if (super.adEvents == null) return;
                    super.adEvents.loaded();
                    LogUtils.d("sendNativeEvent : loaded");
                    break;
                    // インプレッション開始
                case impression:
                    if (super.adEvents == null) return;
                    super.adEvents.impressionOccurred();
                    LogUtils.d("sendNativeEvent : impression");
                    break;
                default:
                    break;
            }
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            onFailed("nativeEvent is not sending");
            e.printStackTrace();
        }
    }

    /**
     * エラー用のトラッキングURLへリクエストをおこない、Exceptionを返却する
     *
     * @param msg エラーメッセージ
     * @return IllegalArgumentException
     */
    @NonNull
    @Override
    public IllegalArgumentException onFailed(@Nullable String msg) {
        return super.onFailed(msg);
    }
}
