package com.socdm.d.adgeneration.observer;

import androidx.annotation.NonNull;

public interface Subject {
    public void sendMessage(@NonNull ADGMessage message);

    public void addObserver(@NonNull Observer observer);

    public void deleteObserver(@NonNull Observer observer);
}
