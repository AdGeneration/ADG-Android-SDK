package com.socdm.d.adgeneration.interstitial.templates.partsfactory;

import android.content.Context;

import com.socdm.d.adgeneration.interstitial.templates.parts.CloseButton;

import java.util.ArrayList;
import java.util.List;

@Deprecated
public class CloseButton40x40Factory extends CloseButtonFactory {
    List<CloseButton<?>> availableItems;

    public CloseButton40x40Factory(Context context) {
        super(context);
    }

    @Override
    public int getWidth() {
        return 40;
    }

    @Override
    public int getHeight() {
        return 40;
    }

    @Override
    public List<String> getAvailableItems() {
        List<String> availableItems = new ArrayList<String>();
        availableItems.add("adg_interstitial_cb_40x40_000.png");
        return availableItems;
    }
}
