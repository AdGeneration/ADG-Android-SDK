package com.socdm.d.adgeneration.video.vast;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;

import com.socdm.d.adgeneration.utils.HttpURLConnectionTask;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.Measurement.VerificationModel;
import com.socdm.d.adgeneration.video.config.Const;

import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

public class VastAd implements Serializable {
    // Regex patterns
    private static Pattern percentagePattern = Pattern.compile("((\\d{1,2})|(100))%");
    private static Pattern absolutePattern =
            Pattern.compile("\\d{1,2}:\\d{1,2}:\\d{1,2}(.\\d{1,3})?");

    // tracking
    private static List<VastTrackingEvent> clearTrackings =
            new ArrayList<VastTrackingEvent>() {
                {
                    add(VastTrackingEvent.START);
                    add(VastTrackingEvent.FIRST_QUARTILE);
                    add(VastTrackingEvent.MIDPOINT);
                    add(VastTrackingEvent.THIRD_QUARTILE);
                    add(VastTrackingEvent.COMPLETE);
                }
            };

    // ad
    private String vastVersion;
    private String adId;
    private String adSystem;
    private String adTitle;
    private String description;
    private String advertiser;

    // creatives
    private String creativeId;
    private String durationString;
    private String skipOffsetString;

    private ArrayList<URL> impressions;
    private HashMap<String, ArrayList<URL>> trackingEvents;
    private String clickThrough;
    private ArrayList<URL> clickTrackings;
    private ArrayList<VastProgress> progressTrackings;
    private ArrayList<URL> errors;
    private ArrayList<MediaFile> mediaFiles;
    private String bestMediaFileDiskUrl;
    private String bestMediaFileNetworkUrl;
    private HashMap<String, ArrayList<URL>> trackingEventExtensions;
    private ArrayList<VASTIcon> icons;
    private VASTIcon closestIcon;

    // Open Measurement SDK
    private ArrayList<VerificationModel> verifications;

    private float currentTime;

    // status
    private VastEventState mVastEventState;
    private boolean mWasThroughSkipOffset;
    private long mVastProgressTime;
    private int mVastProgressPercentage;

    public static class VastProgress implements Serializable {
        private String offset;
        private URL url;

        private long time = -1;
        private float percentage = -1;

        public VastProgress(String offset, URL url) {
            this.offset = offset;
            this.url = url;

            calcOffset();
        }

        private void calcOffset() {
            try {
                if (isAbsoluteTracker(offset)) {
                    time = parseAbsoluteOffset(offset);
                } else if (isPercentageTracker(offset)) {
                    percentage = Float.parseFloat(offset.replace("%", ""));
                } else {
                    LogUtils.e("progress parse err.");
                }
            } catch (Exception e) {
                LogUtils.e("progress parse err.");
            }
        }
    }

    public VastAd() {
        impressions = new ArrayList<>();
        trackingEvents = new HashMap<>();
        clickTrackings = new ArrayList<>();
        progressTrackings = new ArrayList<>();
        errors = new ArrayList<>();
        trackingEventExtensions = new HashMap<>();
        mediaFiles = new ArrayList<>();
        icons = new ArrayList<>();

        // Open Measurement SDK
        verifications = new ArrayList<>();

        reset();
        //        movieCancelEnable = true;
    }

    public void release() {
        if (impressions != null) {
            impressions.clear();
        }
        if (trackingEvents != null) {
            trackingEvents.clear();
        }
        if (clickTrackings != null) {
            clickTrackings.clear();
        }
        if (progressTrackings != null) {
            progressTrackings.clear();
        }
        if (errors != null) {
            errors.clear();
        }
        if (trackingEventExtensions != null) {
            trackingEventExtensions.clear();
        }
        if (mediaFiles != null) {
            mediaFiles.clear();
        }
        if (icons != null) {
            icons.clear();
        }
        if (closestIcon != null) {
            closestIcon = null;
        }
        if (verifications != null) {
            verifications.clear();
        }
    }

    public void setVastVersion(String vastVersion) {
        this.vastVersion = vastVersion;
    }

    public String getAdId() {
        return adId;
    }

    public void setAdId(String adId) {
        this.adId = adId;
    }

    public void setAdSystem(String adSystem) {
        this.adSystem = adSystem;
    }

    public void setAdTitle(String adTitle) {
        this.adTitle = adTitle;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setAdvertiser(String advertiser) {
        this.advertiser = advertiser;
    }

    public void setCreativeId(String creativeId) {
        this.creativeId = creativeId;
    }

    public void setDurationString(String durationString) {
        this.durationString = durationString;
    }

    public void setSkipOffsetString(String skipOffsetString) {
        this.skipOffsetString = skipOffsetString;
    }

    public VASTIcon getClosestIcon() {
        return closestIcon;
    }

    public void setClosestIcon(VASTIcon closestIcon) {
        this.closestIcon = closestIcon;
    }

    public ArrayList<VASTIcon> getIcons() {
        return icons;
    }

    public ArrayList<VerificationModel> getVerifications() {
        return verifications;
    }

    public ArrayList<URL> getImpressions() {
        return impressions;
    }

    public HashMap<String, ArrayList<URL>> getTrackingEvents() {
        return trackingEvents;
    }

    public String getClickThrough() {
        return this.clickThrough;
    }

    public void setClickThrough(String clickThrough) {
        this.clickThrough = clickThrough;
    }

    public ArrayList<VastProgress> getProgressTrackings() {
        return progressTrackings;
    }

    public void setProgressTrackings(ArrayList<VastProgress> progressTrackings) {
        this.progressTrackings = progressTrackings;
    }

    public ArrayList<URL> getClickTrackings() {
        return clickTrackings;
    }

    public ArrayList<URL> getErrors() {
        return errors;
    }

    public void setErrors(ArrayList<URL> errors) {
        this.errors = errors;
    }

    public ArrayList<MediaFile> getMediaFiles() {
        return mediaFiles;
    }

    public String getBestMediaFileUrl() {
        if (!TextUtils.isEmpty(bestMediaFileDiskUrl)) {
            return bestMediaFileDiskUrl;
        } else {
            return bestMediaFileNetworkUrl;
        }
    }

    public void setBestMediaFileDiskUrl(String bestMediaFileDiskUrl) {
        this.bestMediaFileDiskUrl = bestMediaFileDiskUrl;
    }

    public String getBestMediaFileNetworkUrl() {
        return bestMediaFileNetworkUrl;
    }

    public void setBestMediaFileNetworkUrl(String bestMediaFileNetworkUrl) {
        this.bestMediaFileNetworkUrl = bestMediaFileNetworkUrl;
    }

    public float getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(float currentTime) {
        this.currentTime = currentTime;
    }

    public VastEventState getVastEventState() {
        return mVastEventState;
    }

    public int getDuration() {
        try {
            return parseAbsoluteOffset(durationString);
        } catch (Exception e) {
            throw new AndroidRuntimeException("Invalid VAST duration format:" + durationString);
        }
    }

    public void setVerifications(ArrayList<VerificationModel> verifications) {
        this.verifications = verifications;
    }

    private void reset() {
        mVastEventState = VastEventState.NONE;
        currentTime = 0;
        mWasThroughSkipOffset = false;
        mVastProgressTime = 0;
        mVastProgressPercentage = 0;
    }

    public boolean compareStateNext(VastEventState state) {
        return mVastEventState.compareTo(state) < 0;
    }

    public void impressions() {
        for (URL url : impressions) {
            trackingURL(url, "impression");
        }
        // 2度呼び防止のためクリア
        LogUtils.d("Clear tracking[impression]");
        impressions.clear();

        creativeView();
        mVastEventState = VastEventState.IMPRESSION;
    }

    private void trackingClick() {
        for (URL url : clickTrackings) {
            trackingURL(url, "click");
        }
    }

    public void clickThrough(Context context) {
        this.trackingClick();
        if (clickThrough != null) {
            try {
                // FIXME: ModelっぽいVastAdの中でstartActivityを呼ぶのは適切ではない
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(clickThrough));
                context.startActivity(i);
                LogUtils.d("Click redirect to: " + clickThrough);
            } catch (ActivityNotFoundException e) {
                LogUtils.e("No Activity found to handle Intent");
            }
        }
    }

    public void trackEvent(VastTrackingEvent event) {
        if (trackingEvents.containsKey(event.toString())) {
            ArrayList<URL> urls = trackingEvents.get(event.toString());
            for (URL url : urls) {
                trackingURL(url, event.toString());
            }

            // 2度呼び防止のためクリア
            if (clearTrackings.contains(event)) {
                LogUtils.d("Clear tracking[" + event.toString() + "]");
                trackingEvents.remove(event.toString());
            }
        }
    }

    private void trackingURL(URL url, String event) {
        if (Const.STOP_TRACKING) {
            LogUtils.d("停止中！！Tracking[" + event + "]");
        } else {
            HttpURLConnectionTask request = new HttpURLConnectionTask(url.toString(), null);
            request.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            LogUtils.d("Tracking[" + event + "]");
        }
    }

    /** TODO: creativeView is private because always called with impression */
    private void creativeView() {
        trackEvent(VastTrackingEvent.CREATIVE_VIEW);
    }

    public void start() {
        trackEvent(VastTrackingEvent.START);
        mVastEventState = VastEventState.START;
    }

    public void firstQuartile() {
        trackEvent(VastTrackingEvent.FIRST_QUARTILE);
        mVastEventState = VastEventState.FIRST_QUARTILE;
    }

    public void midpoint() {
        trackEvent(VastTrackingEvent.MIDPOINT);
        mVastEventState = VastEventState.MIDPOINT;
    }

    public void thirdQuartile() {
        trackEvent(VastTrackingEvent.THIRD_QUARTILE);
        mVastEventState = VastEventState.THIRD_QUARTILE;
    }

    public void complete() {
        trackEvent(VastTrackingEvent.COMPLETE);
        mVastEventState = VastEventState.COMPLETE;
    }

    public void mute() {
        trackEvent(VastTrackingEvent.MUTE);
    }

    public void unmute() {
        trackEvent(VastTrackingEvent.UNMUTE);
    }

    public void pause() {
        trackEvent(VastTrackingEvent.PAUSE);
    }

    public void resume() {
        trackEvent(VastTrackingEvent.RESUME);
    }

    public void inView() {
        trackEvent(VastTrackingEvent.EXT_INVIEW);
    }

    public void outView() {
        trackEvent(VastTrackingEvent.EXT_OUTVIEW);
    }

    public static boolean isPercentageTracker(String progressValue) {
        return !TextUtils.isEmpty(progressValue)
                && percentagePattern.matcher(progressValue).matches();
    }

    public static boolean isAbsoluteTracker(String progressValue) {
        return !TextUtils.isEmpty(progressValue)
                && absolutePattern.matcher(progressValue).matches();
    }

    public static Integer parseAbsoluteOffset(String progressValue) {
        final String[] split = progressValue.split(":");
        if (split.length != 3) {
            return null;
        }

        return Integer.parseInt(split[0]) * 60 * 60 * 1000 // Hours
                + Integer.parseInt(split[1]) * 60 * 1000 // Minutes
                + (int) (Float.parseFloat(split[2]) * 1000);
    }

    public void progress(long time, int percentage) {
        //        trackEvent(VastTrackingEvent.PROGRESS);
        if (time > mVastProgressTime) {
            VastProgress trackedProgress = null;
            for (VastProgress progress : progressTrackings) {
                if (progress.time > mVastProgressTime && time >= progress.time) {
                    trackingURL(progress.url, "progress[" + progress.offset + "]");

                    trackedProgress = progress;
                }
                if (progress.percentage > mVastProgressPercentage
                        && percentage >= progress.percentage) {
                    trackingURL(progress.url, "progress[" + progress.offset + "]");

                    trackedProgress = progress;
                }
            }

            // 2度呼び防止のためクリア
            if (trackedProgress != null) {
                LogUtils.d("Clear tracking[progress " + trackedProgress.offset + "]");
                progressTrackings.remove(trackedProgress);
            }
        }

        mVastProgressTime = time;
        mVastProgressPercentage = percentage;
    }
}
