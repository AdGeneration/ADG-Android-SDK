package com.socdm.d.adgeneration.interstitial.templates.partsfactory;

import android.content.Context;

import com.socdm.d.adgeneration.interstitial.templates.parts.CloseButton;

import java.util.ArrayList;
import java.util.List;

@Deprecated
public class CloseButton300x30Factory extends CloseButtonFactory {

    List<CloseButton<?>> availableItems;

    public CloseButton300x30Factory(Context ct) {
        super(ct);
    }

    @Override
    public int getWidth() {
        return 300;
    }

    @Override
    public int getHeight() {
        return 30;
    }

    @Override
    public List<String> getAvailableItems() {
        List<String> availableItems = new ArrayList<String>();
        availableItems.add("adg_interstitial_cb_300x30_000.png");
        availableItems.add("adg_interstitial_cb_300x30_001.png");
        availableItems.add("adg_interstitial_cb_300x30_002.png");
        availableItems.add("adg_interstitial_cb_300x30_003.png");
        availableItems.add("adg_interstitial_cb_300x30_004.png");
        return availableItems;
    }
}
