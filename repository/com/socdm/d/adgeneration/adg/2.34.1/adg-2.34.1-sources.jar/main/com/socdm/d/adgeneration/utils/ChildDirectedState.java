package com.socdm.d.adgeneration.utils;

public enum ChildDirectedState {
    TRUE, FALSE, UNSPECIFIED
}
