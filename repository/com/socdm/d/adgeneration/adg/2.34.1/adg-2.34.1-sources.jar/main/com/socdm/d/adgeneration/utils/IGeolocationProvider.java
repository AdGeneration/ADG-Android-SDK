package com.socdm.d.adgeneration.utils;

import android.location.Location;

import androidx.annotation.NonNull;

import jp.supership.sscore.type.Optional;

public interface IGeolocationProvider {
    /**
     * 最後に取得した位置情報を返します
     *
     * @return 最後に取得した位置情報
     */
    @NonNull
    Optional<Location> lastKnownLocation();

    boolean isValidLocation();

    void updateLocation();
}
