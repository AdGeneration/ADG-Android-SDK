package com.socdm.d.adgeneration.nativead;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.View;

import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.adresponse.Native;
import com.socdm.d.adgeneration.utils.LogUtils;

import java.util.ArrayList;

public class ADGLink {
    private String url;
    private ArrayList<String> clicktrackers;
    private ArrayList<String> postClicktrackers;
    private String fallback;
    private Object ext;
    private View view;

    public ADGLink(@Nullable Native.Link link) {
        if (link != null) {
            this.url = link.url;
            link.clickTrackers.ifPresent(ct -> this.clicktrackers = new ArrayList<>(ct));
            link.postClickTrackers.ifPresent(pct -> this.postClicktrackers = new ArrayList<>(pct));
            link.fallback.ifPresent(fb -> this.fallback = fb);
            link.ext.ifPresent(ext -> this.ext = ext);
        }
    }

    public String getUrl() {
        return url;
    }

    public ArrayList<String> getClicktrackers() {
        return clicktrackers;
    }

    public ArrayList<String> getPostClicktrackers() {
        return postClicktrackers;
    }

    public String getFallback() {
        return fallback;
    }

    public Object getExt() {
        return ext;
    }

    /**
     * ViewにClickイベントを設定する
     *
     * @param v clickイベントを設定する対象
     */
    public void setClickEvent(View v, final ADGNativeAdOnClickListener listener) {
        if (v == null) return;
        this.view = v;

        v.setOnClickListener(
                clickedView -> {
                    ADGNativeAd.callTrackers(clicktrackers);
                    ADGNativeAd.callTrackers(postClicktrackers, true);
                    Uri uri = Uri.parse(url);
                    LogUtils.d("new Intent:" + url);
                    Intent i = new Intent(Intent.ACTION_VIEW, uri);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        if (listener != null) {
                            listener.onClickAd();
                        }
                        LogUtils.d("startActivity");
                        clickedView.getContext().startActivity(i);
                    } catch (ActivityNotFoundException e) {
                        LogUtils.e("Failed to start activity for URL: " + url, e);
                    }
                });
    }

    public void callOnClick() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1) {
            if (view != null) {
                view.callOnClick();
            }
        }
    }
}
