package com.socdm.d.adgeneration;

import android.graphics.Color;

import com.socdm.d.adgeneration.viewable.ViewableParameter;

public class ADGConsts {
    /** ADG SDKのバージョン番号 */
    public static final String SDKVERSION = BuildConfig.VERSION_NAME;

    public static final String _TAG = "ADG";
    // production: d.socdm.com / staging: api-test.scaleout.jp
    public static final String DOMAIN =
            BuildConfig.BUILD_TYPE == "staging" ? "api-test.scaleout.jp" : "d.socdm.com";
    public static final String AD_PATH = "/adsv/v1";
    public static final String AD_URL = "https://" + DOMAIN + AD_PATH;
    private static final String WEBVIEW_BASE_URL = DOMAIN + AD_PATH;
    public static final int TIMEOUT_INTERVAL = 10 * 1000;
    public static final String MEDIATION_NATIVE_AD_VIEW_TAG = "ADG_MEDIATION_NATIVE_VIEW";

    @Deprecated public static final double DEFAULT_RATIO = ViewableParameter.DEFAULT.ratio;
    @Deprecated public static final double DEFAUTL_DURATION = ViewableParameter.DEFAULT.duration;

    public static final double DEVICES_SCREEN_PORTRAIT_DEFAULT_SIZE_RATIO = 0.53;
    public static final double DEVICES_SCREEN_LANDSCAPE_DEFAULT_SIZE_RATIO = 0.35;

    public enum ADGErrorCode {
        // 不明なエラー
        UNKNOWN("UNKNOWN"),
        // サーバー間通信エラー
        COMMUNICATION_ERROR("COMMUNICATION_ERROR"),
        // 在庫検知によるNO_AD判定
        RECEIVED_FILLER("RECEIVED_FILLER"),
        // サーバ通信での明確な在庫切れ
        NO_AD("NO_AD"),
        // 通信不通
        NEED_CONNECTION("NEED_CONNECTION"),
        // エラー回数上限到達
        EXCEED_LIMIT("EXCEED_LIMIT"),
        // テンプレート作成失敗
        TEMPLATE_FAILED("TEMPLATE_FAILED");

        private final String name;

        ADGErrorCode(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public enum ADGHeaderBiddingParamKeys {
        AMZN_BIDID("hb_amzn_b"),
        AMZN_HOSTNAME("hb_amzn_h"),
        AMZN_SLOTS("hb_amznslots");

        private final String name;

        ADGHeaderBiddingParamKeys(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public enum ADGWipePosition {
        TOP_RIGHT,
        TOP_LEFT,
        BOTTOM_RIGHT,
        BOTTOM_LEFT;
    }

    public enum ADGWipeTheme {
        DARK(Color.parseColor("#555555"), Color.parseColor("#FFFFFF")),
        LIGHT(Color.parseColor("#E5E5E5"), Color.parseColor("#555555"));

        private final int frameColor;
        private final int textColor;

        ADGWipeTheme(int frameColor, int textColor) {
            this.frameColor = frameColor;
            this.textColor = textColor;
        }

        public int getFrameColor() {
            return this.frameColor;
        }

        public int getTextColor() {
            return this.textColor;
        }
    }

    public static String getWebViewBaseUrl() {
        if (ADGSettings.isSSL()) return "https://" + WEBVIEW_BASE_URL;
        return "http://" + WEBVIEW_BASE_URL;
    }
}
