package com.socdm.d.adgeneration.interstitial;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;

import com.socdm.d.adgeneration.ADG;
import com.socdm.d.adgeneration.ADG.AdFrameSize;
import com.socdm.d.adgeneration.ADGConsts;
import com.socdm.d.adgeneration.ADGConsts.ADGErrorCode;
import com.socdm.d.adgeneration.ADGListener;
import com.socdm.d.adgeneration.ADGLogger;
import com.socdm.d.adgeneration.interstitial.templates.BaseTemplate;
import com.socdm.d.adgeneration.interstitial.templates.TemplateFactory;
import com.socdm.d.adgeneration.interstitial.templates.TemplateFactory.TemplateOrientation;
import com.socdm.d.adgeneration.interstitial.templates.TemplateFactory.TemplateType;
import com.socdm.d.adgeneration.utils.DisplayUtils;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.utils.ShowController;
import com.socdm.d.adgeneration.utils.UIUtils;

import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Map;

@Deprecated
public class ADGInterstitial extends View {

    // instance variables
    private Activity activity;
    private PopupWindow window;
    private LinearLayout contentView;
    private ShowController showController;
    private BaseTemplate portraitTemplate;
    private BaseTemplate landscapeTemplate;
    private int currentSystemUiVisibility;
    private boolean isFullScreen;

    private ADG adg;
    private ADGInterstitialListener listener;
    private boolean isShow = false;
    private boolean isReady = false;

    private Handler handler = new Handler(Looper.myLooper());

    // instance variable for showController
    private int span = 0;
    private boolean isPercentage = false;

    private boolean isLoaded = false;

    // constant values
    private static final int FP = DisplayUtils.getFP();
    //	private static final int WC = DisplayUtils.getWC();

    // constructor
    public ADGInterstitial(Context ct) {
        super(ct);
        this.setActivity(ct);
        this.window = new PopupWindow(ct);
        this.contentView = new LinearLayout(ct);
        this.showController = new ShowController(ct);

        // create contentView
        contentView.setLayoutParams(new LayoutParams(FP, FP));

        // initialize adg
        adg = new ADG(ct);
        setTemplateForDefault();
        adg.setAdListener(new ADGListenerProxy());
        adg.addObserver(new ADGInterstitialRecipient(this));
        adg.setPreventAccidentalClick(false);
        adg.setReloadWithVisibilityChanged(false);
        adg.setVisibility(View.GONE);
        adg.setIsInterstitial(true);

        // initialize window settings
        window.setContentView(contentView);
        window.setWindowLayoutMode(FP, FP); // for after Android 3.x
        window.setWidth(DisplayUtils.getClientSize(activity).x); // for before Android 2.x
        window.setHeight(DisplayUtils.getClientSize(activity).y); // for before Android 2.x
        window.setFocusable(true);
        window.setClippingEnabled(true);
        window.setOnDismissListener(
                new OnDismissListener() {
                    @Override
                    public void onDismiss() {
                        if (isLoaded) dismiss();
                        if (listener != null) {
                            listener.onCloseInterstitial();
                        }
                    }
                });
    }

    // getter / setter
    public void setActivity(Context ct) {
        if (ct instanceof Activity) {
            this.activity = (Activity) ct;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                currentSystemUiVisibility =
                        activity.getWindow().getDecorView().getSystemUiVisibility();
            }
        }
    }

    public void setAdListener(ADGInterstitialListener listener) {
        this.listener = listener;
    }

    public void setSpan(int span) {
        this.span = span;
    }

    public void setSpan(int span, boolean isPercentage) {
        this.span = span;
        this.isPercentage = isPercentage;
    }

    // switch design methods
    public void setWindowBackground(int color) {
        ColorDrawable drawable = new ColorDrawable(color);
        this.window.setBackgroundDrawable(drawable);
    }

    public void setTemplateType(int type) {
        this.setPortraitTemplateType(type);
        this.setLandscapeTemplateType(type);
    }

    public void setPortraitTemplateType(int index) {
        TemplateType type = TemplateType.fromIndex(index);
        setPortraitTemplateType(type);
    }

    public void setPortraitTemplateType(TemplateType type) {
        BaseTemplate template =
                TemplateFactory.create(getContext(), type, TemplateOrientation.PORTRAIT);
        if (template != null) {
            this.portraitTemplate = template;
            initTemplate(this.portraitTemplate);
        }
    }

    public void setLandscapeTemplateType(int index) {
        TemplateType type = TemplateType.fromIndex(index);
        setLandscapeTemplateType(type);
    }

    public void setLandscapeTemplateType(TemplateType type) {
        BaseTemplate template =
                TemplateFactory.create(getContext(), type, TemplateOrientation.LANDSCAPE);
        if (template != null) {
            this.landscapeTemplate = template;
            initTemplate(this.landscapeTemplate);
        }
    }

    public void setBackgroundType(int designType) {
        this.setPortraitBackgroundType(designType);
        this.setLandscapeBackgroundType(designType);
    }

    public void setPortraitBackgroundType(int designType) {
        this.portraitTemplate.setBackgroundType(designType);
    }

    public void setLandscapeBackgroundType(int designType) {
        this.landscapeTemplate.setBackgroundType(designType);
    }

    public void setCloseButtonType(int designType) {
        this.setPortraitCloseButtonType(designType);
        this.setLandscapeCloseButtonType(designType);
    }

    public void setPortraitCloseButtonType(int designType) {
        this.portraitTemplate.setCloseButtonType(designType);
        this.portraitTemplate.createCloseButton(new CloseAction());
    }

    public void setLandscapeCloseButtonType(int designType) {
        this.landscapeTemplate.setCloseButtonType(designType);
        this.landscapeTemplate.createCloseButton(new CloseAction());
    }

    public void setFullScreen(boolean isFullScreen) {
        this.isFullScreen = isFullScreen;
        if (isFullScreen) {
            this.setPortraitTemplateType(TemplateType.TEMPLATE_TYPE_FULL_SCREEN);
            this.setLandscapeTemplateType(TemplateType.TEMPLATE_TYPE_FULL_SCREEN);
        } else {
            setTemplateForDefault();
        }
    }

    public boolean isShow() {
        return isShow;
    }

    public void setShow(boolean isShow) {
        this.isShow = isShow;
    }

    public boolean isReady() {
        return isReady;
    }

    public void setReady(boolean isReady) {
        this.isReady = isReady;
    }

    // adg proxy methods
    public void addHeaderBiddingParamsWithAmznAdResponse(Object adResponse) {
        this.setFullScreen(true);
        adg.addHeaderBiddingParamsWithAmznAdResponse(adResponse);
    }

    public void addHeaderBiddingParam(ADGConsts.ADGHeaderBiddingParamKeys key, String value) {
        adg.addHeaderBiddingParam(key, value);
    }

    public void addRequestOptionParam(String key, String value) {
        adg.addRequestOptionParam(key, value);
    }

    /**
     * Ad Generationのリクエストパラメータにラベルターゲティング用のKey/Valueを追加する
     *
     * @param key ターゲティングのKey
     * @param value ターゲティングのValue
     */
    public void insertADGLabelTargetingWithCustomKey(String key, String value) {
        adg.insertADGLabelTargetingWithCustomKey(key, value);
    }

    /**
     * 現在Ad Generationに指定されているラベルターゲティング用のパラメータから指定されたKeyのパラメータを削除する
     *
     * @param key 削除対象のKey
     */
    public void removeADGLabelTargetingWithCustomKey(String key) {
        adg.removeADGLabelTargetingWithCustomKey(key);
    }

    /**
     * 現在Ad Generationに指定されているラベルターゲティング用のKey/Valueを返却する 該当するパラメータが存在しない場合は、nullを返却します
     *
     * @return 指定されているラベルターゲティング用のKey/Value
     */
    public Map<String, String> getADGLabelTargetingWithCustomKeyValues() {
        return adg.getADGLabelTargetingWithCustomKeyValues();
    }

    public void setLocationId(String locationId) {
        adg.setLocationId(locationId);
    }

    public void setAdFrameSize(AdFrameSize adSize) {
        adg.setAdFrameSize(adSize);
    }

    public void setAdBackGroundColor(int color) {
        adg.setAdBackGroundColor(color);
    }

    public void setAdScale(double scale) {
        adg.setAdScale(scale);
    }

    public void setPreventAccidentalClick(boolean prevent) {
        adg.setPreventAccidentalClick(prevent);
    }

    public boolean isEnableSound() {
        return adg.isEnableSound();
    }

    public void setEnableSound(boolean enableSound) {
        adg.setEnableSound(enableSound);
    }

    /** 代わりに {@link #setTestModeEnabled} メソッドを使用してください。 */
    @Deprecated
    public void setEnableTestMode(boolean enableTestMode) {
        ADGLogger.getDefault()
                .warn(
                        "ADGInterstitial#setEnableTestMode(boolean) method is deprecated. Use"
                                + " ADGInterstitial#setTestModeEnabled(boolean) method instead.");
        adg.setEnableTestMode(enableTestMode);
    }

    /**
     * テストモードが有効かどうかを返します。
     *
     * @return テストモードが有効な場合はtrue、そうでない場合はfalse
     */
    public boolean isTestModeEnabled() {
        return adg.isTestModeEnabled();
    }

    /**
     * trueを指定した場合、テストモードが有効になります。テストモードのままリリースしないようにご注意ください。
     *
     * @param enabled テストモードを有効にする場合はtrue、そうでない場合はfalse
     */
    public void setTestModeEnabled(final boolean enabled) {
        adg.setTestModeEnabled(enabled);
    }

    public void setContentUrl(String url) {
        adg.setContentUrl(url);
    }

    public void setEnableMraidMode(Boolean isMRAIDEnabled) {
        adg.setEnableMraidMode(isMRAIDEnabled);
    }

    @Deprecated
    public void setFillerLimit(int fillerLimit) {
        adg.setFillerLimit(fillerLimit);
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public void naviBarStatusBarHidden(boolean hidden) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
            return;
        }
        int fullScreenSystemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar
                        | View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
                        | View.SYSTEM_UI_FLAG_IMMERSIVE;
        if (hidden) {
            contentView.setSystemUiVisibility(fullScreenSystemUiVisibility);
        } else {
            contentView.setSystemUiVisibility(currentSystemUiVisibility);
        }
    }

    // private methods
    private BaseTemplate getCurrentTemplate() {
        List<BaseTemplate> templates = UIUtils.findViewsWithClass(contentView, BaseTemplate.class);
        return templates.isEmpty() ? null : templates.get(0);
    }

    private void initTemplate(BaseTemplate template) {
        if (template != null) {
            template.refresh();
            template.createCloseButton(new CloseAction());
            setTemplateByCurrentOrientation();
        }
    }

    private void setTemplateForDefault() {
        this.setPortraitTemplateType(TemplateType.TEMPLATE_TYPE_300x250_1);
        this.setLandscapeTemplateType(TemplateType.TEMPLATE_TYPE_300x250_1);
        this.adg.setAdFrameSize(AdFrameSize.RECT);
    }

    private void setTemplateByCurrentOrientation() {
        int orientation = getContext().getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            changeTemplate(portraitTemplate);
        } else if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            changeTemplate(landscapeTemplate);
        } else {
            changeTemplate(portraitTemplate);
        }
    }

    private void changeTemplate(BaseTemplate template) {
        if (contentView != null && template != null) {
            BaseTemplate oldTemplate = getCurrentTemplate();
            if (oldTemplate != null) {
                oldTemplate.getAdgLayout().removeView(adg);
                contentView.removeAllViews();
            }
            template.getAdgLayout().addView(adg);
            if (isFullScreen) {
                adg.setLayoutParams(
                        new LinearLayout.LayoutParams(
                                LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
                if (activity != null) {
                    DisplayUtils.Size size = DisplayUtils.getScreenSize(activity);
                    adg.setAdFrameSize(
                            AdFrameSize.FREE.setSize(
                                    DisplayUtils.getDip(getResources(), size.getWidth()),
                                    DisplayUtils.getDip(getResources(), size.getHeight())));
                } else {
                    LogUtils.e(
                            "Activity instance is null. Please set activity instance by"
                                    + " contractor.");
                }
            }
            contentView.addView(template);
        }
    }

    private boolean checkShow() {
        String key = adg.getLocationId();
        BaseTemplate template = getCurrentTemplate();
        if (key != null && key.length() > 0) {
            this.showController.cache(key, span, isPercentage);
            if (window == null) {
                LogUtils.w("adg interstitial failed to initialize.");
            } else if (activity == null) {
                LogUtils.w("adg interstitial must have activity instance.");
            } else if (activity.isFinishing()) {
                LogUtils.w("activity was finished.");
            } else if (template != null && !template.checkViews()) {
                LogUtils.w("adg interstitial have invalid template.");
            } else if (!this.showController.isShow(key)) {
                LogUtils.d("adg interstitial show next.");
                this.showController.next(key);
            } else {
                this.showController.reset(key);
                return true;
            }
        } else {
            LogUtils.w("ADGInterstitial must set locationId before show.");
        }
        return false;
    }

    // public methods
    public void preload() {
        if (!adg.isReadyForInterstitial()) { // not called close from origin_interstitial
            adg.readyForInterstitial();
            boolean tempIsShow = isShow;
            dismiss();
            this.setShow(tempIsShow);
        }
        if (adg.getVisibility() != View.VISIBLE) {
            adg.setWaitShowing();
            adg.setVisibility(View.VISIBLE);
            adg.start();
            this.isLoaded = true;
        }
    }

    public boolean show() {
        isShow = checkShow();
        if (isShow) {
            preload();
            activity.getWindow().getDecorView().post(new ShowRunnable(this));
        }
        return isShow;
    }

    public void dismiss() {
        this.isLoaded = false;
        if (adg.isReadyToDismissInterstitial()) {
            adg.setVisibility(View.GONE);
            if (adg.hasOwnInterstitialTemplate() && listener != null) {
                listener.onCloseInterstitial();
            }
            adg.dismiss();
            try {
                isShow = false;
                isReady = false;
                window.dismiss();
            } catch (NullPointerException e) {
                LogUtils.w("Failed to dismiss the interstitial window.");
            }
        }
    }

    public void callADGShow() {
        adg.show();
    }

    // show interstitial
    static class ShowRunnable implements Runnable {
        WeakReference<ADGInterstitial> interstitialRef;

        public ShowRunnable(ADGInterstitial interstitial) {
            this.interstitialRef = new WeakReference<ADGInterstitial>(interstitial);
        }

        @Override
        public void run() {
            ADGInterstitial interstitial = interstitialRef.get();
            if (interstitial != null) {
                View decorView = interstitial.activity.getWindow().getDecorView();
                if (decorView.getWindowToken() != null) {
                    if (interstitial.isReady && interstitial.isLoaded) {
                        interstitial.setTemplateByCurrentOrientation();
                        interstitial.callADGShow();
                        if (interstitial.adg != null
                                && !interstitial.adg.hasOwnInterstitialTemplate()) {
                            interstitial.window.showAtLocation(decorView, Gravity.NO_GRAVITY, 0, 0);
                        }
                    } else {
                        LogUtils.d(
                                "Ad is not loaded yet. Window will be shown, after ad was loaded.");
                    }
                } else {
                    LogUtils.w("Failed to open the interstitial window.");
                    if (interstitial.listener != null) {
                        interstitial.listener.onCloseInterstitial();
                    }
                }
            }
        }
    }

    // dismiss interstitial action on click close button
    private class CloseAction implements OnClickListener {
        @Override
        public void onClick(View v) {
            dismiss();
        }
    }

    // ADGListener proxy
    private class ADGListenerProxy extends ADGListener {

        @Override
        public void onReceiveAd() {
            handler.post(
                    new Runnable() {
                        @Override
                        public void run() {
                            adg.setVisibility(View.VISIBLE);
                            LogUtils.d("onReceiveAd");
                            if (listener != null) {
                                listener.onReceiveAd();
                            }
                        }
                    });
        }

        @Override
        public void onFailedToReceiveAd(final ADGErrorCode code) {
            handler.post(
                    new Runnable() {
                        @Override
                        public void run() {
                            adg.setVisibility(View.GONE);
                            LogUtils.d("onFailedToReceiveAd (code:" + code.name() + ")");
                            if (listener != null) {
                                listener.onFailedToReceiveAd(code);
                            }
                        }
                    });
        }

        @Override
        public void onClickAd() {
            handler.post(
                    new Runnable() {
                        @Override
                        public void run() {
                            LogUtils.d("onAdClicked");
                            if (listener != null) {
                                listener.onClickAd();
                                listener.onOpenUrl();
                            }
                        }
                    });
        }
    }
}
