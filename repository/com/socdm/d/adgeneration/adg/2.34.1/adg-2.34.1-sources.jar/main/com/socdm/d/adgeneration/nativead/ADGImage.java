package com.socdm.d.adgeneration.nativead;

import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.adresponse.Native;

public class ADGImage {
    private String url;
    private int width;
    private int height;
    private Object ext;

    public ADGImage(@Nullable Native.Asset.Image obj) {
        if (obj != null) {
            this.url = obj.url;
            this.width = obj.width;
            this.height = obj.height;
            obj.ext.ifPresent(e -> this.ext = e);
        }
    }

    public String getUrl() {
        return url;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public Object getExt() {
        return ext;
    }
}
