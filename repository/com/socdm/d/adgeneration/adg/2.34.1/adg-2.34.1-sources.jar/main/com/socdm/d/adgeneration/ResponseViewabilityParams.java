package com.socdm.d.adgeneration;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.socdm.d.adgeneration.viewable.KeyProvider;
import com.socdm.d.adgeneration.viewable.UuidKeyProvider;
import com.socdm.d.adgeneration.viewable.ViewableMeasurementInterval;
import com.socdm.d.adgeneration.viewable.ViewableParameter;
import com.socdm.d.adgeneration.viewable.ViewableParameters;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Objects;

final class ResponseViewabilityParams {
    private static final boolean DEFAULT_CHARGE_WHEN_LOADING = true;

    final boolean chargeWhenLoading;
    /** Viewable計測パラメータ */
    final ViewableParameter viewableParameter;
    /** 計測間隔[秒] */
    final ViewableMeasurementInterval measurementInterval;

    ResponseViewabilityParams(
            final boolean chargeWhenLoading,
            final double ratio,
            final double duration,
            final double measurementInterval) {
        this(chargeWhenLoading, ratio, duration, measurementInterval, UuidKeyProvider.INSTANCE);
    }

    @VisibleForTesting
    ResponseViewabilityParams(
            final boolean chargeWhenLoading,
            final double ratio,
            final double duration,
            final double measurementInterval,
            @NonNull final KeyProvider keyProvider) {
        viewableParameter = new ViewableParameter(keyProvider.generateKey(), ratio, duration);
        this.measurementInterval = new ViewableMeasurementInterval(measurementInterval);

        // Viewable計測に必要な値が0.0以下の場合は強制的にViewableをOFFにする
        if (viewableParameter.ratio <= 0
                || viewableParameter.duration <= 0
                || this.measurementInterval.inSeconds <= 0) {
            this.chargeWhenLoading = true;
        } else {
            this.chargeWhenLoading = chargeWhenLoading;
        }
    }

    private ResponseViewabilityParams(@NonNull final JSONObject jsonObject) {
        this(
                jsonObject.optBoolean("charge_when_loading", DEFAULT_CHARGE_WHEN_LOADING),
                jsonObject.optDouble("ratio", ViewableParameter.DEFAULT.ratio),
                jsonObject.optDouble("duration", ViewableParameter.DEFAULT.duration),
                jsonObject.optDouble(
                        "measurement_interval", ViewableMeasurementInterval.DEFAULT.inSeconds));
    }

    /**
     * 以下のJSONから {@link ResponseViewabilityParams} を生成します。引数にnullを渡した場合、または <code>viewability</code>
     * キーが存在しない場合はデフォルト値を返します
     *
     * <p>
     *
     * <pre>
     * {
     *   "viewability": {
     *     "charge_when_loading": true,
     *     "ratio": 0.5,
     *     "duration": 1.0,
     *     "measurement_interval": 0.5
     *   }
     * }
     * </pre>
     *
     * @param jsonObject JSON
     * @return {@link ResponseViewabilityParams} オブジェクト
     */
    @NonNull
    static ResponseViewabilityParams fromJson(@Nullable final JSONObject jsonObject) {
        if (jsonObject == null) {
            return DEFAULT;
        } else {
            try {
                return new ResponseViewabilityParams(jsonObject.getJSONObject("viewability"));
            } catch (JSONException e) {
                return DEFAULT;
            }
        }
    }

    @NonNull
    @Override
    public String toString() {
        return "{ chargeWhenLoading: "
                + chargeWhenLoading
                + ", viewableParameter: "
                + viewableParameter
                + ", measurementInterval: "
                + measurementInterval
                + " }";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        final ResponseViewabilityParams that = (ResponseViewabilityParams) obj;
        return chargeWhenLoading == that.chargeWhenLoading
                && viewableParameter.equals(that.viewableParameter)
                && measurementInterval.equals(that.measurementInterval);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                chargeWhenLoading, viewableParameter.hashCode(), measurementInterval.hashCode());
    }

    /**
     * {@link ViewableParameters} オブジェクトに変換します
     *
     * @return {@link ViewableParameters} オブジェクト
     */
    @NonNull
    ViewableParameters toViewableParameters() {
        return new ViewableParameters(measurementInterval, viewableParameter);
    }

    @NonNull
    static final ResponseViewabilityParams DEFAULT =
            new ResponseViewabilityParams(
                    DEFAULT_CHARGE_WHEN_LOADING,
                    ViewableParameter.DEFAULT.ratio,
                    ViewableParameter.DEFAULT.duration,
                    ViewableMeasurementInterval.DEFAULT.inSeconds);
}
