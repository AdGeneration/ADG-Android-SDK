package com.socdm.d.adgeneration.video.view;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.SurfaceTexture;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.MediaController;

import com.socdm.d.adgeneration.ADGSettings;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.ADGPlayerError;
import com.socdm.d.adgeneration.video.VideoAudioType;
import com.socdm.d.adgeneration.video.utils.Streams;

import java.io.File;
import java.io.FileInputStream;

@TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
public class VideoView extends FrameLayout implements MediaController.MediaPlayerControl,
        TextureView.SurfaceTextureListener {
    private String mUrl;

    // all possible internal states
    private static final int STATE_ERROR = -1;
    private static final int STATE_IDLE = 0;
    private static final int STATE_PREPARING = 1;
    private static final int STATE_PREPARED = 2;
    private static final int STATE_PLAYING = 3;
    private static final int STATE_PAUSED = 4;
    private static final int STATE_PLAYBACK_COMPLETED = 5;

    // mCurrentState is a VideoView object's current state.
    // mTargetState is the state that a method caller intends to reach.
    // For instance, regardless the VideoView object's current state,
    // calling pause() intends to bring the object to a target state
    // of STATE_PAUSED.
    private int mCurrentState = STATE_IDLE;
    private int mTargetState = STATE_IDLE;


    // All the stuff we need for playing and showing a video
    private MediaPlayer mMediaPlayer;
    private SurfaceTexture mSurfaceTexture;
    private Surface mSurface;
    private int mVideoWidth;
    private int mVideoHeight;
    private int mSeekWhenPrepared;  // recording the seek position while preparing
    private int mCurrentBufferPercentage;
    private int mVideoRetries;
    private AudioManager mAudioManager;
    private AudioAttributes mPlaybackAttributes;
    private AudioFocusChangeListener mAudioFocusChangeListener;
    private AudioFocusRequest mAudioFocusRequest;
    private boolean mAudioVolumeIsOn = false;

    private Context mContext;
    private TextureView mTextureView;
    private VideoViewListener mListener;

    private static final int MAX_VIDEO_RETRIES = 1;
    private static final int VIDEO_VIEW_FILE_PERMISSION_ERROR = Integer.MIN_VALUE;

    private boolean failedPause = false;

    public interface VideoViewListener {
        void onCompletion();

        void onPrepared();

        void onBuffering(int percent);

        void onSeekTo(int msec);

        void onError();

        void onChangeAudioVolume(boolean isOn);
    }

    public VideoView(Context context) {
        super(context);
        mContext = context;
        initVideoView();
    }

    public VideoView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        initVideoView();
    }

    public VideoView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        initVideoView();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public VideoView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        mContext = context;
        initVideoView();
    }

    private void initVideoView() {
        LogUtils.d(toString() + ": initVideoView");
        mVideoWidth = 0;
        mVideoHeight = 0;
        mCurrentState = STATE_IDLE;
        mTargetState = STATE_IDLE;

        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);

        mTextureView = new TextureView(mContext);
        mTextureView.setSurfaceTextureListener(this);
        LayoutParams params = new LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.CENTER;
        addView(mTextureView, params);

        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = getDefaultSize(mVideoWidth, widthMeasureSpec);
        int height = getDefaultSize(mVideoHeight, heightMeasureSpec);
        if (mVideoWidth > 0 && mVideoHeight > 0) {

            int widthSpecMode = MeasureSpec.getMode(widthMeasureSpec);
            int widthSpecSize = MeasureSpec.getSize(widthMeasureSpec);
            int heightSpecMode = MeasureSpec.getMode(heightMeasureSpec);
            int heightSpecSize = MeasureSpec.getSize(heightMeasureSpec);

            if (widthSpecMode == MeasureSpec.EXACTLY && heightSpecMode == MeasureSpec.EXACTLY) {
                // the size is fixed
                width = widthSpecSize;
                height = heightSpecSize;

                // for compatibility, we adjust size based on aspect ratio
                if (mVideoWidth * height < width * mVideoHeight) {
                    //LogUtils.i("@@@", "image too wide, correcting");
                    width = height * mVideoWidth / mVideoHeight;
                } else if (mVideoWidth * height > width * mVideoHeight) {
                    //LogUtils.i("@@@", "image too tall, correcting");
                    height = width * mVideoHeight / mVideoWidth;
                }
            } else if (widthSpecMode == MeasureSpec.EXACTLY) {
                // only the width is fixed, adjust the height to match aspect ratio if possible
                width = widthSpecSize;
                height = width * mVideoHeight / mVideoWidth;
                if (heightSpecMode == MeasureSpec.AT_MOST && height > heightSpecSize) {
                    // couldn't match aspect ratio within the constraints
                    height = heightSpecSize;
                }
            } else if (heightSpecMode == MeasureSpec.EXACTLY) {
                // only the height is fixed, adjust the width to match aspect ratio if possible
                height = heightSpecSize;
                width = height * mVideoWidth / mVideoHeight;
                if (widthSpecMode == MeasureSpec.AT_MOST && width > widthSpecSize) {
                    // couldn't match aspect ratio within the constraints
                    width = widthSpecSize;
                }
            } else {
                // neither the width nor the height are fixed, try to use actual video size
                width = mVideoWidth;
                height = mVideoHeight;
                if (heightSpecMode == MeasureSpec.AT_MOST && height > heightSpecSize) {
                    // too tall, decrease both width and height
                    height = heightSpecSize;
                    width = height * mVideoWidth / mVideoHeight;
                }
                if (widthSpecMode == MeasureSpec.AT_MOST && width > widthSpecSize) {
                    // too wide, decrease both width and height
                    width = widthSpecSize;
                    height = width * mVideoHeight / mVideoWidth;
                }
            }
        } else {
            // no size yet, just adopt the given spec sizes
        }
        setMeasuredDimension(width, height);

        if (mVideoWidth > 0 && mVideoHeight > 0) {
            int measuredWidth = getMeasuredWidth();
            int measuredHeight = getMeasuredHeight();
            float videoAspect = (float) mVideoHeight / mVideoWidth;
            float viewAspect = (float) measuredHeight / measuredWidth;
            int childWidth = width;
            int childHeight = height;
            if (videoAspect < viewAspect) {
                // view is tall
                childHeight = (int) (measuredWidth * videoAspect);
            } else if (videoAspect > viewAspect) {
                // view is wide
                childWidth = (int) (measuredHeight / videoAspect);
            }

            int childWidthMeasureSpec = MeasureSpec.makeMeasureSpec(childWidth, MeasureSpec.EXACTLY);
            int childHeightMeasureSpec = MeasureSpec.makeMeasureSpec(childHeight, MeasureSpec.EXACTLY);
            mTextureView.measure(childWidthMeasureSpec, childHeightMeasureSpec);
        }
    }

    public void setVideoURL(String url) {
        LogUtils.d(toString() + ": setVideoURL:" + url);
        mUrl = url;
        mSeekWhenPrepared = 0;
        mVideoRetries = 0;
        openVideo();
    }

    public void stopPlayback() {
        release(false);
    }

    private void openVideo() {
        if (mUrl == null) {
            return;
        }

        // we shouldn't clear the target state, because somebody might have
        // called start() previously
        reset(false);
        try {
            mAudioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);

            mMediaPlayer = new MediaPlayer();
            mMediaPlayer.setDataSource(mUrl);
            mMediaPlayer.setOnBufferingUpdateListener(mBufferingUpdateListener);
            mMediaPlayer.setOnCompletionListener(mCompletionListener);
            mMediaPlayer.setOnPreparedListener(mPreparedListener);
            mMediaPlayer.setOnSeekCompleteListener(mSeekCompleteListener);
            mMediaPlayer.setOnVideoSizeChangedListener(mSizeChangedListener);
            mMediaPlayer.setOnErrorListener(mErrorListener);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                mPlaybackAttributes = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                        .build();
                mMediaPlayer.setAudioAttributes(mPlaybackAttributes);
            } else {
                mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            }
            if (mSurfaceTexture != null) {
                mSurface = new Surface(mSurfaceTexture);
                mMediaPlayer.setSurface(mSurface);
            }
            mMediaPlayer.prepareAsync();
            mCurrentBufferPercentage = 0;
            // we don't set the target state here either, but preserve the
            // target state that was there before.
            mCurrentState = STATE_PREPARING;
        } catch (Exception e) {
            mCurrentState = STATE_ERROR;
            mTargetState = STATE_ERROR;
            mErrorListener.onError(mMediaPlayer, MediaPlayer.MEDIA_ERROR_UNKNOWN, 0);
            LogUtils.e(ADGPlayerError.UNSPECIFIED.toString(), e);
        }
    }

    /**
     * release the media player in any state
     */
    private void release(boolean cleartargetstate) {
        reset(cleartargetstate);
    }

    private void reset(boolean cleartargetstate) {
        if (mMediaPlayer != null) {
            mMediaPlayer.reset();
            mMediaPlayer.release();
            mMediaPlayer = null;
            mCurrentState = STATE_IDLE;
            if (cleartargetstate) {
                mTargetState = STATE_IDLE;
            }
            releaseSurface();
        }
    }

    private void releaseSurface() {
        if (mSurface != null) {
            mSurface.release();
            mSurface = null;
        }
    }

    private boolean retryMediaPlayer(final MediaPlayer mediaPlayer, final int what, final int extra) {
        LogUtils.d(toString() + ": retryMediaPlayer");
        // XXX
        // VideoView has a bug in versions lower than Jelly Bean, Api Level 16, Android 4.1
        // For api < 16, VideoView is not able to read files written to disk since it reads them in
        // a Context different from the Application and therefore does not have correct permission.
        // To solve this problem we obtain the video file descriptor ourselves with valid permissions
        // and pass it to the underlying MediaPlayer in VideoView.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN
                && what == MediaPlayer.MEDIA_ERROR_UNKNOWN
                && extra == VIDEO_VIEW_FILE_PERMISSION_ERROR
                && mVideoRetries < MAX_VIDEO_RETRIES) {

            FileInputStream inputStream = null;
            try {
                mediaPlayer.reset();
                final File file = new File(mUrl);
                inputStream = new FileInputStream(file);
                mediaPlayer.setDataSource(inputStream.getFD());

                // XXX
                // VideoView has a callback registered with the MediaPlayer to set a flag when the
                // media file has been prepared. Start also sets a flag in VideoView indicating the
                // desired state is to play the video. Therefore, whichever method finishes last
                // will check both flags and begin playing the video.
                mediaPlayer.prepareAsync();
                return true;
            } catch (Exception e) {
                LogUtils.e(ADGPlayerError.UNSPECIFIED.toString(), e);
                return false;
            } finally {
                Streams.closeStream(inputStream);
                mVideoRetries++;
            }
        }
        return false;
    }

    MediaPlayer.OnVideoSizeChangedListener mSizeChangedListener = new MediaPlayer.OnVideoSizeChangedListener() {
        public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
            LogUtils.d(toString() + ": OnVideoSizeChangedListener");
            mVideoWidth = mp.getVideoWidth();
            mVideoHeight = mp.getVideoHeight();
            if (mVideoWidth != 0 && mVideoHeight != 0) {
                requestLayout();
            }
        }
    };

    MediaPlayer.OnPreparedListener mPreparedListener = new MediaPlayer.OnPreparedListener() {
        public void onPrepared(MediaPlayer mp) {
            LogUtils.d(toString() + ": onPreparedListener");
            mCurrentState = STATE_PREPARED;

            if (mListener != null) {
                mListener.onPrepared();
            }

            try {
                mVideoWidth = mp.getVideoWidth();
                mVideoHeight = mp.getVideoHeight();
                mp.start();
                mp.pause();

                int seekToPosition = mSeekWhenPrepared;  // mSeekWhenPrepared may be changed after seekTo() call
                if (seekToPosition != 0) {
                    seekTo(seekToPosition);
                }

                if (mVideoWidth != 0 && mVideoHeight != 0) {
                    requestLayout();
                }
            } catch (IllegalStateException e) {
                LogUtils.e(ADGPlayerError.UNSPECIFIED.toString(), e);
                if (mListener != null) {
                    mListener.onError();
                }
            }
        }
    };

    private MediaPlayer.OnCompletionListener mCompletionListener =
            new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer mp) {
                    if (mCurrentState != STATE_PLAYBACK_COMPLETED) {
                        mCurrentState = STATE_PLAYBACK_COMPLETED;
                        mTargetState = STATE_PLAYBACK_COMPLETED;

                        if (mListener != null) {
                            abandonAudioFocus();
                            mListener.onCompletion();
                        }
                    }
                }
            };

    private MediaPlayer.OnErrorListener mErrorListener = new MediaPlayer.OnErrorListener() {
        public boolean onError(MediaPlayer mp, int framework_err, int impl_err) {
            if (retryMediaPlayer(mp, framework_err, impl_err)) {
                return true;
            } else {
                mCurrentState = STATE_ERROR;
                mTargetState = STATE_ERROR;
                /* If an error handler has been supplied, use it and finish. */
                if (mListener != null) {
                    mListener.onError();
                }

                return false;
            }
        }
    };

    private MediaPlayer.OnBufferingUpdateListener mBufferingUpdateListener = new MediaPlayer.OnBufferingUpdateListener() {
        public void onBufferingUpdate(MediaPlayer mp, int percent) {
            LogUtils.d(toString() + ": onBufferingUpdateListener");
            mCurrentBufferPercentage = percent;

            if (mListener != null) {
                mListener.onBuffering(percent);
            }
        }
    };

    private MediaPlayer.OnSeekCompleteListener mSeekCompleteListener = new MediaPlayer.OnSeekCompleteListener() {
        @Override
        public void onSeekComplete(MediaPlayer mediaPlayer) {
            if (mTargetState == STATE_PLAYING) {
                start();
            }
        }
    };

    public void setVideoViewListener(VideoViewListener l) {
        mListener = l;
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int width, int height) {
        LogUtils.d(toString() + ": onSurfaceTextureAvailable");
        mSurfaceTexture = surfaceTexture;
        if (mMediaPlayer != null) {
            mSurface = new Surface(mSurfaceTexture);
            mMediaPlayer.setSurface(mSurface);
            if (mCurrentState == STATE_PLAYING && !mMediaPlayer.isPlaying() && !failedPause) {
                failedPause = false;
                mMediaPlayer.start();
            }
        }
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int width, int height) {
        LogUtils.d(toString() + ": onSurfaceTextureSizeChanged");
        boolean isValidState = (mTargetState == STATE_PLAYING);
        boolean hasValidSize = (mVideoWidth == width && mVideoHeight == height);
        if (mMediaPlayer != null && isValidState && hasValidSize) {
            if (mSeekWhenPrepared != 0) {
                seekTo(mSeekWhenPrepared);
            }
            start();
        }
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        LogUtils.d(toString() + ": onSurfaceTextureDestroyed");
        mSurfaceTexture = null;
        releaseSurface();
        return false;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        // nothing to do
    }

    @Override
    public void start() {
        if (isInPlaybackState()) {
            if (mSurfaceTexture != null) {
                if (mAudioVolumeIsOn == true) {
                    requestAudioFocus();
                }
                mMediaPlayer.start();
            }
            mCurrentState = STATE_PLAYING;
        } else {
            openVideo();
        }
        mTargetState = STATE_PLAYING;
    }

    @Override
    public void pause() {
        failedPause = false;
        if (isInPlaybackState()) {
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.pause();
                abandonAudioFocus();
                mCurrentState = STATE_PAUSED;
            } else {
                failedPause = true;
            }
        }
        mTargetState = STATE_PAUSED;
    }

    @Override
    public int getDuration() {
        if (isInPlaybackState()) {
            return mMediaPlayer.getDuration();
        }

        return -1;
    }

    @Override
    public int getCurrentPosition() {
        if (isInPlaybackState()) {
            return mMediaPlayer.getCurrentPosition();
        }
        return 0;
    }

    @Override
    public void seekTo(int msec) {
        if (isInPlaybackState()) {
            mMediaPlayer.seekTo(msec);
            mSeekWhenPrepared = 0;
            if (mListener != null) {
                mListener.onSeekTo(msec);
            }
        } else {
            mSeekWhenPrepared = msec;
        }
    }

    @Override
    public boolean isPlaying() {
        return isInPlaybackState() && mMediaPlayer.isPlaying();
    }

    @Override
    public int getBufferPercentage() {
        if (mMediaPlayer != null) {
            return mCurrentBufferPercentage;
        }
        return 0;
    }

    public boolean isInPlaybackState() {
        return (mMediaPlayer != null &&
                mCurrentState != STATE_ERROR &&
                mCurrentState != STATE_IDLE &&
                mCurrentState != STATE_PREPARING);
    }

    @Override
    public int getAudioSessionId() {
        return mMediaPlayer.getAudioSessionId();
    }

    @Override
    public boolean canPause() {
        return true;
    }

    @Override
    public boolean canSeekBackward() {
        return true;
    }

    @Override
    public boolean canSeekForward() {
        return true;
    }


    public boolean isVolume() {
        return mAudioVolumeIsOn;
    }

    public void setVolume(int i, int i2) {
        if (mMediaPlayer != null) {
            if (i != 0 && i2 != 0) {
                mAudioVolumeIsOn = true;
                requestAudioFocus();
            } else {
                mAudioVolumeIsOn = false;
                abandonAudioFocus();
            }
            mMediaPlayer.setVolume(i, i2);
            if (mListener != null) {
                mListener.onChangeAudioVolume(mAudioVolumeIsOn);
            }
        }
    }

    /**
     * Audio Focusを取得する
     * バックグラウンドで流れている音声は停止する
     */
    private void requestAudioFocus() {
        if (ADGSettings.getVideoAudioType() == VideoAudioType.MIX) {
            return;
        }
        final Object mFocusLock = new Object();
        Handler handler = new Handler(Looper.myLooper());
        if (mAudioFocusChangeListener == null) {
            mAudioFocusChangeListener = new AudioFocusChangeListener();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mPlaybackAttributes == null) {
                return;
            }
            mAudioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(mPlaybackAttributes)
                    .setWillPauseWhenDucked(true)
                    .setOnAudioFocusChangeListener(mAudioFocusChangeListener, handler)
                    .build();
            int res = mAudioManager.requestAudioFocus(mAudioFocusRequest);
            synchronized (mFocusLock) {
                if (res == AudioManager.AUDIOFOCUS_REQUEST_FAILED) {
                    LogUtils.d("AUDIOFOCUS_REQUEST_FAILED");
                } else if (res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    LogUtils.d("AUDIOFOCUS_REQUEST_GRANTED");
                } else if (res == AudioManager.AUDIOFOCUS_REQUEST_DELAYED) {
                    LogUtils.d("AUDIOFOCUS_REQUEST_DELAYED");

                }
            }
        } else {
            int res = mAudioManager.requestAudioFocus(mAudioFocusChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
            synchronized (mFocusLock) {
                if (res == AudioManager.AUDIOFOCUS_REQUEST_FAILED) {
                    LogUtils.d("AUDIOFOCUS_REQUEST_FAILED");
                } else if (res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    LogUtils.d("AUDIOFOCUS_REQUEST_GRANTED");
                }
            }
        }
    }

    /**
     * Audio Focusを破棄する
     * バックグラウンドで再生されていた音声は再開される
     */
    private void abandonAudioFocus() {
        if (ADGSettings.getVideoAudioType() == VideoAudioType.MIX) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mAudioFocusRequest != null) {
                mAudioManager.abandonAudioFocusRequest(mAudioFocusRequest);
            }
        } else {
            if (mAudioFocusChangeListener != null) {
                mAudioManager.abandonAudioFocus(mAudioFocusChangeListener);
            }
        }
    }

    /**
     * Audio Focusに変更があった場合通知される
     */
    private class AudioFocusChangeListener implements AudioManager.OnAudioFocusChangeListener {
        @Override
        public void onAudioFocusChange(int focusChange) {
            switch (focusChange) {
                case AudioManager.AUDIOFOCUS_GAIN:
                    LogUtils.d("AUDIOFOCUS_GAIN");
                    break;
                case AudioManager.AUDIOFOCUS_LOSS:
                    LogUtils.d("AUDIOFOCUS_LOSS");
                    setVolume(0, 0);
                    break;
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                    LogUtils.d("AUDIOFOCUS_LOSS_TRANSIENT");
                    setVolume(0, 0);
                    break;
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                    LogUtils.d("AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK");
                    setVolume(0, 0);
                    break;
            }
        }
    }
}