package com.socdm.d.adgeneration.video.config;

import android.os.Build;

public class Const {
    public static final String SHARED_PREFERENCES_KEY = "ADGPlayerSharedPreferences";
    public static final int HTTP_REQUEST_CONNECTION_TIMEOUT = 5000;          // 5秒
    public static final int HTTP_REQUEST_READ_TIMEOUT = 5000;                // 5秒

    public static final String UI_INLINE_LINK_BUTTON_URL = "adg_video_button_detail.png";
    public static final String UI_INLINE_REPLAY_BUTTON_URL = "adg_video_button_replay.png";
    public static final String UI_CLOSE_BUTTON_URL = "adg_video_button_close.png";
    public static final String UI_LINK_BUTTON_URL = "adg_video_button_detail2.png";
    public static final String UI_SOUND_ON_BUTTON_URL = "adg_video_button_volume_off.png";
    public static final String UI_SOUND_OFF_BUTTON_URL = "adg_video_button_volume_on.png";
    public static final String UI_VIDEO_ICON_PLAY_URL = "adg_video_icon_play.png";

    public static final String ADMANAGER_BROADCAST_IDENTIFIER_KEY = "com.socdm.d.adgeneration.video.ads.AdManagerBroadcastIdentifier";
    public static final String ADACTIVITY_BROADCAST_IDENTIFIER_KEY = "com.socdm.d.adgeneration.video.ads.AdActivityBroadcastIdentifier";
    public static final int HTTP_REQUEST_TIMEOUT = 10000;

    // Fields from default config.
    public static final boolean STOP_TRACKING = false;

    // min_varsion
    public static final int MINVERSION = Build.VERSION_CODES.LOLLIPOP;
}
