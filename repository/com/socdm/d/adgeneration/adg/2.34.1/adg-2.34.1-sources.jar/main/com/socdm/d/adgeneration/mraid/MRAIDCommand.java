package com.socdm.d.adgeneration.mraid;

import androidx.annotation.NonNull;

public enum MRAIDCommand {
    CLOSE("close"),
    EXPAND("expand"),
    USE_CUSTOM_CLOSE("useCustomClose"),
    OPEN("open"),
    RESIZE("resize"),
    SET_ORIENTATION_PROPERTIES("setOrientationProperties"),
    UNSPECIFIED("");

    @NonNull private final String mJavascriptString;

    MRAIDCommand(@NonNull String javascriptString) {
        mJavascriptString = javascriptString;
    }

    static MRAIDCommand fromJavascriptString(@NonNull String string) {
        for (MRAIDCommand command : MRAIDCommand.values()) {
            if (command.mJavascriptString.equals(string)) {
                return command;
            }
        }

        return UNSPECIFIED;
    }

    String toJavascriptString() {
        return mJavascriptString;
    }
}
