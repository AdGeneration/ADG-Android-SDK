package com.socdm.d.adgeneration.video.vast;

import android.annotation.TargetApi;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import androidx.annotation.NonNull;
import android.util.Patterns;

import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.ADGPlayerError;
import com.socdm.d.adgeneration.video.Measurement.VerificationModel;
import com.socdm.d.adgeneration.video.utils.AdRequestTask;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class VastRequest implements AdRequestTask.AdRequestTaskListener {

    private VastAd mVastAd;
    private VastRequestListener mListener;
    private AdRequestTask mRequest;
    private Context mContext;

    public interface VastRequestListener {

        void vastAdDidLoaded(VastAd vastAd);

        void failedToLoadVastAd(ADGPlayerError error);
    }

    public VastRequest(VastRequestListener listener, Context context) {
        mListener = listener;
        mVastAd = new VastAd();
        mContext = context;
    }

    public VastAd getVastAd() {
        return mVastAd;
    }

    public void loadXML(String xml) {
        try {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            InputStream is = new ByteArrayInputStream(xml.getBytes("utf-8"));
            Document dom = builder.parse(is);
            loadWrapperAdIfNeeded(dom);
        } catch (Exception e) {
            LogUtils.e(ADGPlayerError.SERVER_ERROR.toString(), e);
            mListener.failedToLoadVastAd(ADGPlayerError.SERVER_ERROR);
        }

    }

    public void cancel() {
        if (mRequest != null) {
            mRequest.cancel(true);
        }
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void requestHandler(URL url) {
        mRequest = new AdRequestTask(this, mContext);
        mRequest.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, url);
    }

    private void loadWrapperAdIfNeeded(Document dom) throws MalformedURLException {
        NodeList wrappedVASTAd = dom.getElementsByTagName("VASTAdTagURI");
        if (wrappedVASTAd.getLength() > 0) {
            setExtentions(dom);
            setImpressions(dom);
            setErrors(dom);
            setTrackers(dom);
            setIcons(dom);

            URL vastAdTagUri = new URL(wrappedVASTAd.item(0).getTextContent());
            requestHandler(vastAdTagUri);
        } else {
            setAll(dom);
        }
    }

    private void setIcons(Document dom) throws MalformedURLException {
        Element creatives = (Element) dom.getElementsByTagName("Creatives").item(0);
        Element creative = (Element) creatives.getElementsByTagName("Creative").item(0);
        Element linear = (Element) creative.getElementsByTagName("Linear").item(0);
        NodeList icons = linear.getElementsByTagName("Icon");
        for (int i = 0; i < icons.getLength(); i++) {
            Element iconElem = (Element) icons.item(i);

            if (iconElem != null) {
                String apiFramework = iconElem.getAttribute("apiFramework");

                VASTIcon icon = new VASTIcon(apiFramework);
                icon.setProgram(iconElem.getAttribute("program"));
                try {
                    icon.setWidth(Integer.parseInt(iconElem.getAttribute("width")));
                } catch (NumberFormatException e) {
                    LogUtils.w(e.getMessage());
                }
                try {
                    icon.setHeight(Integer.parseInt(iconElem.getAttribute("height")));
                } catch (NumberFormatException e) {
                    LogUtils.w(e.getMessage());
                }
                try {
                    icon.setXPosition(Integer.parseInt(iconElem.getAttribute("xPosition")));
                } catch (NumberFormatException e) {
                    LogUtils.w(e.getMessage());
                }
                try {
                    icon.setYPosition(Integer.parseInt(iconElem.getAttribute("yPosition")));
                } catch (NumberFormatException e) {
                    LogUtils.w(e.getMessage());
                }
                
                Element resourceElem = (Element) iconElem.getElementsByTagName("StaticResource").item(0);
                if (resourceElem != null) {
                    String creativeType = resourceElem.getAttribute("creativeType");
                    VASTResource vastResource = new VASTResource(creativeType, resourceElem.getTextContent());
                    icon.setStaticResource(vastResource);
                }

                Element iconClickThrough = (Element) iconElem.getElementsByTagName("IconClickThrough").item(0);
                NodeList iconClickTrackings = iconElem.getElementsByTagName("IconClickTracking");
                try {
                    for (int j = 0; j < iconClickTrackings.getLength(); j++) {
                        URL url = getTrackingURLContent(iconClickTrackings.item(j));
                        if (url != null) {
                            ArrayList<String> list = icon.getIconClickTrackings();
                            if (list != null) {
                                list.add(url.toString());
                                icon.setIconClickTrackings(list);
                            }
                        }
                    }
                } catch (MalformedURLException e) {
                    LogUtils.w(ADGPlayerError.UNSPECIFIED.toString(), e);
                }
                icon.setClickThroughURL(iconClickThrough.getTextContent());

                // Iconを保持
                mVastAd.getIcons().add(icon);
                // ClosestなIconを保持
                if (i == 0) {
                    mVastAd.setClosestIcon(icon);
                }
            }
        }
    }
  
    private void setExtentions(Document dom) {
        // Extentionsを取得
        NodeList extensions = dom.getElementsByTagName("Extension");
        for (int i = 0; i < extensions.getLength(); i++) {
            Element extension = (Element) extensions.item(i);
            // ExtentionからtypeがAdVerificationsのものを取り出す
            if (extension != null && extension.getAttribute("AdVerifications") != null) {
                // Verificationを取得
                NodeList verifications = extension.getElementsByTagName("Verification");
                // AdVerificationsをパース
                if (verifications != null) {
                    parseMeasurementVerifications(verifications);
                }
            }
        }
    }

    private void setImpressions(Document dom) throws MalformedURLException {
        NodeList nodes = dom.getElementsByTagName("Impression");
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            try {
                URL url = getTrackingURLContent(node);
                mVastAd.getImpressions().add(url);
            } catch (MalformedURLException e) {
                LogUtils.w(ADGPlayerError.UNSPECIFIED.toString(), e);
            }
        }
    }

    private void setErrors(Document dom) {
        NodeList nodes = dom.getElementsByTagName("Error");
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            try {
                URL url = getTrackingURLContent(node);
                mVastAd.getErrors().add(url);
            } catch (MalformedURLException e) {
                LogUtils.w(ADGPlayerError.UNSPECIFIED.toString(), e);
            }
        }
    }

    private void setTrackers(Document dom) {
        NodeList nodes = dom.getElementsByTagName("ClickTracking");
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            try {
                URL url = getTrackingURLContent(node);
                mVastAd.getClickTrackings().add(url);
            } catch (MalformedURLException e) {
                LogUtils.e(ADGPlayerError.UNSPECIFIED.toString(), e);
            }
        }

        NodeList events = dom.getElementsByTagName("Tracking");
        for (int i = 0; i < events.getLength(); i++) {
            Element el = (Element) events.item(i);
            String event = el.getAttribute("event");
            if ("progress".equals(event)) {
                // progressの場合はurl以外にoffsetの情報も必要なので別リストとしてセット
                try {
                    URL url = getTrackingURLContent(el);
                    mVastAd.getProgressTrackings().add(new VastAd.VastProgress(el.getAttribute("offset"), url));
                } catch (MalformedURLException e) {
                    LogUtils.e(ADGPlayerError.UNSPECIFIED.toString(), e);
                }
            } else {
                ArrayList<URL> urls = mVastAd.getTrackingEvents().get(event);
                if (urls == null) {
                    urls = new ArrayList<>();
                    mVastAd.getTrackingEvents().put(event, urls);
                }

                try {
                    URL url = getTrackingURLContent(el);
                    mVastAd.getTrackingEvents().get(event).add(url);
                } catch (MalformedURLException e) {
                    LogUtils.e(ADGPlayerError.UNSPECIFIED.toString(), e);
                }
            }
        }
    }

    private void setAll(Document dom) {
        if (dom == null) {
            return;
        }

        try {
            Element vast = (Element) dom.getElementsByTagName("VAST").item(0);
            mVastAd.setVastVersion(vast.getAttribute("version"));

            Element ad = (Element) vast.getElementsByTagName("Ad").item(0);
            if (ad == null) {
                LogUtils.d(ADGPlayerError.NO_AD.toString());
                mListener.failedToLoadVastAd(ADGPlayerError.NO_AD);
                return;
            }

            mVastAd.setAdId(ad.getAttribute("id"));

            Element inLine = (Element) ad.getElementsByTagName("InLine").item(0);
            Element adSystem = (Element) inLine.getElementsByTagName("AdSystem").item(0);
            if (adSystem != null) {
                mVastAd.setAdSystem(adSystem.getTextContent());
            }

            Element adTitle = (Element) inLine.getElementsByTagName("AdTitle").item(0);
            if (adTitle != null) {
                mVastAd.setAdTitle(adTitle.getTextContent());
            }

            Element description = (Element) inLine.getElementsByTagName("Description").item(0);
            if (description != null) {
                mVastAd.setDescription(description.getTextContent());
            }

            Element advertiser = (Element) inLine.getElementsByTagName("Advertiser").item(0);
            if (advertiser != null) {
                mVastAd.setAdvertiser(advertiser.getTextContent());
            }

            Element creative = (Element) inLine.getElementsByTagName("Creative").item(0);
            mVastAd.setCreativeId(creative.getAttribute("id"));

            Element linear = (Element) creative.getElementsByTagName("Linear").item(0);
            mVastAd.setSkipOffsetString(linear.getAttribute("skipoffset"));

            Element duration = (Element) linear.getElementsByTagName("Duration").item(0);
            if (duration != null) {
                mVastAd.setDurationString(duration.getTextContent());
            }

            Element clickThrough = (Element) linear.getElementsByTagName("ClickThrough").item(0);
            if (clickThrough != null) {
                Uri uri = getUriContent(clickThrough);
                mVastAd.setClickThrough(uri.toString());
            }

            NodeList mediaFiles = linear.getElementsByTagName("MediaFile");
            for (int i = 0; i < mediaFiles.getLength(); i++) {
                Element mediaFileElement = (Element) mediaFiles.item(i);
                if (mediaFileElement != null) {
                    MediaFile mediaFile = new MediaFile();
                    mediaFile.setDelivery(mediaFileElement.getAttribute("delivery"));
                    mediaFile.setType(mediaFileElement.getAttribute("type"));

                    try {
                        mediaFile.setBitrate(Integer.parseInt(mediaFileElement.getAttribute("bitrate")));
                    } catch (NumberFormatException e) {
                        LogUtils.w(e.getMessage());
                    }

                    try {
                        mediaFile.setWidth(Integer.valueOf(mediaFileElement.getAttribute("width")));
                    } catch (NumberFormatException e) {
                        LogUtils.w(e.getMessage());
                    }

                    try {
                        mediaFile.setHeight(Integer.valueOf(mediaFileElement.getAttribute("height")));
                    } catch (NumberFormatException e) {
                        LogUtils.w(e.getMessage());
                    }

                    try {
                        URL url = getURLContent(mediaFileElement);
                        mediaFile.setUrl(url);
                        mVastAd.getMediaFiles().add(mediaFile);
                    } catch (MalformedURLException e) {
                        LogUtils.e(ADGPlayerError.UNSPECIFIED.toString(), e);
                    }
                }
            }

            // Iconsを取得
            setIcons(dom);
            setExtentions(dom);
            setImpressions(dom);
            setErrors(dom);
            setTrackers(dom);

            mListener.vastAdDidLoaded(mVastAd);
        } catch (Exception e) {
            LogUtils.w(ADGPlayerError.SERVER_ERROR.toString(), e);
            mListener.failedToLoadVastAd(ADGPlayerError.SERVER_ERROR);
        }
    }

    private URL getURLContent(Node node) throws MalformedURLException {
        String textContent = node.getTextContent();
        textContent = excludeWhitespaceCRLF(textContent);
        return new URL(textContent);
    }

    private Uri getUriContent(Node node) {
        String textContent = node.getTextContent();
        textContent = excludeWhitespaceCRLF(textContent);
        return Uri.parse(textContent);
    }

    private URL getTrackingURLContent(Node node) throws MalformedURLException {
        String textContent = node.getTextContent();
        textContent = excludeWhitespaceCRLF(textContent);

        if (isValidWebURL(textContent)) {
            return new URL(textContent);
        } else {
            throw new MalformedURLException(textContent);
        }
    }

    private String excludeWhitespaceCRLF(String value) {
        return value.replaceAll("\\n", "").replaceAll("\\r", "").replaceAll("\\s", "");
    }

    private Boolean isValidWebURL(String str) {
        return Patterns.WEB_URL.matcher(str).matches();
    }

    private void parseMeasurementVerifications(@NonNull NodeList verifications) {
        try {
            ArrayList<VerificationModel> list = mVastAd.getVerifications();

            for (int i = 0; i < verifications.getLength(); i++) {
                // Verificationを取得
                Element verification = (Element) verifications.item(i);
                if (verification != null) {
                    // Listにモデルを追加
                    VerificationModel model = parseMeasurementVerification(verification);
                    if (model != null) {
                        list.add(model);
                    }
                }
            }
            if (list != null) {
                mVastAd.setVerifications(list);
            }
            list = null;
        } catch (Exception e) {
            LogUtils.w(ADGPlayerError.PARSE_ERROR.toString(), e);
            mListener.failedToLoadVastAd(ADGPlayerError.PARSE_ERROR);
        }
    }

    private VerificationModel parseMeasurementVerification(@NonNull Element verification) {
        // モデルを生成
        VerificationModel model = new VerificationModel();

        try {
            // verificationのtypeからVendorKeyを取得してset
            model.setVendor(String.valueOf(verification.getAttribute("vendor")));
            // JavaScriptResourceを取得
            Element jsResource = (Element) verification.getElementsByTagName("JavaScriptResource").item(0);
            if (jsResource != null) {
                // JavaScriptResourceのtypeからApiFrameworkを取得してset
                model.setApiFromework(String.valueOf(jsResource.getAttribute("apiFramework")));
                // JavaScriptResourceのtypeからBrowserOptionalを取得してset
                model.setBrowserOptional(Boolean.valueOf(jsResource.getAttribute("browserOptional")));
                // JavaScriptResourceのURLを取得してset
                String url = excludeWhitespaceCRLF(jsResource.getTextContent());
                if (isValidWebURL(url)) {
                    model.setJavaScriptResource(new URL(url));
                }
            }
            // VerificationParametersを取得
            Element verificationParameters = (Element) verification.getElementsByTagName("VerificationParameters").item(0);
            if (verificationParameters != null) {
                // VerificationParametersのURLを取得してset
                model.setVerificationParameters(verificationParameters.getTextContent());
            }
            // TrackingEventsを取得
            NodeList trackingEvents = verification.getElementsByTagName("TrackingEvent");
            if (model != null && trackingEvents != null) {
                // モデルにTrackingEventを追加
                HashMap<String, URL> hashMap = parseMeasurementTrackingEvents(trackingEvents);
                if (hashMap != null) {
                    model.setTrackingEvents(hashMap);
                }
            }
        } catch (Exception e) {
            LogUtils.w(ADGPlayerError.PARSE_ERROR.toString(), e);
            mListener.failedToLoadVastAd(ADGPlayerError.PARSE_ERROR);
            return null;
        }

        return model;
    }

    private HashMap<String, URL> parseMeasurementTrackingEvents(@NonNull NodeList trackingEvents) {
        // HashMapを生成
        HashMap<String, URL> hashMap = new HashMap<>();

        try {
            for (int i = 0; i < trackingEvents.getLength(); i++) {
                // TrackingEventを取得
                Element trackingEvent = (Element) trackingEvents.item(i);
                if (trackingEvent != null && String.valueOf(trackingEvent.getAttribute("event")) != null) {
                    // TrackingEventの名前を取得
                    String eventName = String.valueOf(trackingEvent.getAttribute("event"));
                    // TrackingEventのURLを取得
                    String url = excludeWhitespaceCRLF(trackingEvent.getTextContent());
                    if (isValidWebURL(url)) {
                        hashMap.put(String.valueOf(trackingEvent.getAttribute("event")), new URL(url));
                    }
                }
            }
        } catch (Exception e) {
            LogUtils.w(ADGPlayerError.PARSE_ERROR.toString(), e);
            mListener.failedToLoadVastAd(ADGPlayerError.PARSE_ERROR);
            return null;
        }

        return hashMap;
    }

    @Override
    public void onPostExecute(Map<String, List<String>> header, String body) {
        if (header == null || body == null) {
            LogUtils.w(ADGPlayerError.SERVER_ERROR.toString());
            mListener.failedToLoadVastAd(ADGPlayerError.SERVER_ERROR);
            return;
        }

        loadXML(body);
    }

    @Override
    public void onCancelled() {
        mRequest = null;
        mVastAd = null;
    }
}
