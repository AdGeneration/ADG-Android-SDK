package com.socdm.d.adgeneration.observer;

public interface Subject {
    public void sendMessage(ADGMessage message);

    public void addObserver(Observer observer);

    public void deleteObserver(Observer observer);
}
