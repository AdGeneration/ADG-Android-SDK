package com.socdm.d.adgeneration.interstitial.templates.partsfactory;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;

import com.socdm.d.adgeneration.utils.AssetUtils;

import java.util.List;

@Deprecated
public abstract class BackgroundFactory {

    Context ct;
    private static final String CUSTOM_ASSETS_PREFIX = "adg_interstitial_background_";

    public BackgroundFactory(Context ct) {
        this.ct = ct;
    }

    public abstract List<String> getAvailableItems();

    public BitmapDrawable get(int designType) {
        if (designType <= 0) {
            // set transparent to the background drawable.
            return null;
        } else {
            // get a bitmap from the default set.
            int index = designType - 1;
            List<String> items = getAvailableItems();
            Bitmap bitmap;
            try {
                String fileName = items.get(index);
                bitmap = AssetUtils.getBitmap(ct, fileName);
            } catch (IndexOutOfBoundsException e) {
                // get a bitmap from the custom assets.
                bitmap = AssetUtils.getBitmap(ct, fileName(designType));
            }
            return bitmap != null ? new BitmapDrawable(ct.getResources(), bitmap) : null;
        }
    }

    public String fileName(int n) {
        return CUSTOM_ASSETS_PREFIX + intToString3(n) + ".png";
    }

    public String intToString3(int n) {
        return (100 <= n && n < 1000) ? "" + n : "xxx";
    }
}
