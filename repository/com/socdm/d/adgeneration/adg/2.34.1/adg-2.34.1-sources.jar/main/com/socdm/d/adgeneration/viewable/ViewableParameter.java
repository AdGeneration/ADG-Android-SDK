package com.socdm.d.adgeneration.viewable;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import java.util.Objects;

/** このクラスは、Viewable計測パラメータを表します */
public final class ViewableParameter {
    /** デフォルトの表示割合 */
    @VisibleForTesting public static final double DEFAULT_RATIO = 0.5;

    @VisibleForTesting public static final double MAX_RATIO = 1.0;
    @VisibleForTesting public static final double MIN_RATIO = 0.0;
    /** デフォルトの表示時間[秒] */
    @VisibleForTesting public static final double DEFAULT_DURATION = 1.0;
    // ユーザー設定される値のため大きすぎる値を弾く、サーバーとの取り決めがあるわけではなく、SDKの都合上設定している
    @VisibleForTesting public static final double MAX_DURATION = 60.0;
    @VisibleForTesting public static final double MIN_DURATION = 0.0;

    /** パラメータ識別用のキー */
    @NonNull public final String key;
    /** 表示割合 (0.0-1.0) */
    public final double ratio;
    /** 表示時間[秒] */
    public final double duration;

    /**
     * インスタンスを生成します
     *
     * @param key パラメータ識別用のキー
     * @param ratio 表示割合 (0.0-1.0)
     * @param duration 表示時間[秒]
     */
    public ViewableParameter(@NonNull final String key, final double ratio, final double duration) {
        this.key = key;
        this.ratio = Math.min(Math.max(ratio, MIN_RATIO), MAX_RATIO);
        this.duration = Math.min(Math.max(duration, MIN_DURATION), MAX_DURATION);
    }

    @NonNull
    @Override
    public String toString() {
        return "{ key: " + key + ", ratio: " + ratio + ", duration: " + duration + " }";
    }

    @Override
    public boolean equals(@Nullable final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final ViewableParameter that = (ViewableParameter) o;
        return Double.compare(that.ratio, ratio) == 0
                && Double.compare(that.duration, duration) == 0
                && Objects.equals(key, that.key);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key, ratio, duration);
    }

    /** デフォルトのViewable計測パラメータ */
    @NonNull
    public static final ViewableParameter DEFAULT =
            new ViewableParameter("default", DEFAULT_RATIO, DEFAULT_DURATION);

    /** 動画広告制御用のViewable計測パラメータ */
    @NonNull
    public static final ViewableParameter VIDEO_AD = new ViewableParameter("video-ad", 0.5, 0.1);

    /** MRAID viewableChange イベント用のViewable計測パラメータ */
    @NonNull
    public static final ViewableParameter MRAID = new ViewableParameter("mraid", 0.01, 0.1);
}
