package com.socdm.d.adgeneration;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.socdm.d.adgeneration.adresponse.CreativeParams;
import com.socdm.d.adgeneration.adresponse.Native;
import com.socdm.d.adgeneration.adresponse.Response;
import com.socdm.d.adgeneration.adresponse.ResponseResult;
import com.socdm.d.adgeneration.adresponse.Trackers;
import com.socdm.d.adgeneration.impression.ImpressionTracker;
import com.socdm.d.adgeneration.impression.ImpressionTracking;
import com.socdm.d.adgeneration.impression.LegacyImpressionTracker;
import com.socdm.d.adgeneration.viewable.ViewableMeasurementInterval;
import com.socdm.d.adgeneration.viewable.ViewableParameter;

import jp.supership.sscore.tracking.SSCoreSingleFireTracker;
import jp.supership.sscore.tracking.SSCoreTracker;
import jp.supership.sscore.tracking.SSCoreTrackerException;
import jp.supership.sscore.tracking.SSCoreTrackingEvent;
import jp.supership.sscore.tracking.SSCoreTrackingEventSendable;
import jp.supership.sscore.type.Optional;
import jp.supership.sscore.type.Result;
import jp.supership.sscore.vast.VastLoadable;
import jp.supership.sscore.vast.VastManager;
import jp.supership.sscore.vast.model.Vast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class AdBridgingObject {
    @NonNull private final Response response;
    @NonNull private final Optional<Vast> vast;
    @NonNull private final Optional<List<SSCoreTrackingEvent>> winNotificationBeacons;
    @NonNull private final SSCoreTrackingEventSendable trackingEventSender;
    @NonNull private final Optional<ImpressionTracking> impressionTracker;

    /**
     * インスタンスを生成します
     *
     * @param response 広告レスポンス
     * @param vast VAST
     * @param trackingEventSender トラッキングイベント送信オブジェクト
     */
    // FIXME: ADGResponseを削除したらprivateアクセス修飾子に変更
    AdBridgingObject(
            @NonNull final Response response,
            @NonNull final Optional<Vast> vast,
            @NonNull final SSCoreTrackingEventSendable trackingEventSender) {
        this.response = response;
        this.vast = vast;
        this.trackingEventSender = trackingEventSender;

        final Optional<ResponseResult> result = getFirstResult(response);

        // Win通知ビーコンの初期化
        this.winNotificationBeacons =
                result.flatMap(responseResult -> responseResult.creativeParams)
                        .flatMap(CreativeParams::getTrackers)
                        .map(
                                trackers -> {
                                    final List<SSCoreTrackingEvent> events = new ArrayList<>();
                                    for (final String url : trackers) {
                                        try {
                                            events.add(
                                                    new SSCoreSingleFireTracker(
                                                            new SSCoreTracker(url)));
                                        } catch (SSCoreTrackerException ignored) {
                                        }
                                    }
                                    return events;
                                });

        // インプレッショントラッカーの初期化
        this.impressionTracker =
                result.flatMap(
                        responseResult -> {
                            if (ADGDebugUtils.useLegacyTracking) {
                                return LegacyImpressionTracker.create(responseResult, vast);
                            } else {
                                return ImpressionTracker.create(responseResult, vast);
                            }
                        });
    }

    /**
     * 広告リソースをロードします
     *
     * @param response レスポンスデータ
     * @param trackingEventSender トラッキングイベントを送信するオブジェクト
     * @param listener 完了時に呼ばれるリスナー
     */
    static void loadResources(
            @NonNull final Response response,
            @NonNull final SSCoreTrackingEventSendable trackingEventSender,
            @NonNull final OnLoadResourcesListener listener) {
        loadResources(response, trackingEventSender, null, listener);
    }

    /**
     * 広告リソースをロードします
     *
     * @param response レスポンスデータ
     * @param trackingEventSender トラッキングイベントを送信するオブジェクト
     * @param vastLoader VASTローダー。nullを指定するとデフォルトのローダーを使用します
     * @param listener 完了時に呼ばれるリスナー
     */
    @VisibleForTesting
    static void loadResources(
            @NonNull final Response response,
            @NonNull final SSCoreTrackingEventSendable trackingEventSender,
            @Nullable final VastLoadable vastLoader,
            @NonNull final OnLoadResourcesListener listener) {

        final Optional<ResponseResult> result = getFirstResult(response);

        try {
            final String vastXml =
                    result.flatMap(responseResult -> responseResult.vastXML).unwrap();
            VastManager.getInstance()
                    .parseVastWithChaining(
                            vastXml,
                            vastLoader,
                            result1 -> {
                                // TODO: 動画ファイルのダウンロードもここで行ってしまいたい

                                if (result1.data.isPresent()) {
                                    final AdBridgingObject adObject =
                                            new AdBridgingObject(
                                                    response, result1.data, trackingEventSender);
                                    listener.onLoaded(Result.success(adObject));
                                } else {
                                    final Exception e =
                                            result1.error
                                                    .map(error -> (Exception) error)
                                                    .orElse(new Exception("Vast object is null."));
                                    listener.onLoaded(Result.failure(e));
                                }
                            });
        } catch (Optional.NotPresentException e) {
            final AdBridgingObject adObject =
                    new AdBridgingObject(response, Optional.empty(), trackingEventSender);
            listener.onLoaded(Result.success(adObject));
        }
    }

    @Override
    @NonNull
    public String toString() {
        return response.toString();
    }

    /**
     * インプレッショントラッカーが存在するかどうかを返します
     *
     * @return インプレッショントラッカーが存在する場合はtrue
     */
    public boolean hasImpressionTracker() {
        return impressionTracker.isPresent();
    }

    /**
     * インプレッションの有効期限[ミリ秒]を取得します
     *
     * @return インプレッションの有効期限[ミリ秒]
     */
    double getImpExpireInMilliseconds() {
        try {
            final Trackers.ImpExpire impExpire =
                    getFirstResult(response).unwrap().trackers.unwrap().impExpire.unwrap();
            return impExpire.inMilliseconds;
        } catch (Optional.NotPresentException e) {
            return 0;
        }
    }

    /**
     * インプレッションの有効期限が有効かどうかを返します
     *
     * @return インプレッションの有効期限が有効な場合はtrue
     */
    boolean isImpExpirationEnabled() {
        // impconditionが存在しない場合はロード完了時にインプレッション発生とするため、有効期限をカウントする必要がない
        try {
            final Optional<Trackers.ImpCondition> impCondition =
                    getFirstResult(response).unwrap().trackers.unwrap().impCondition;
            return getImpExpireInMilliseconds() > 0 && impCondition.isPresent();
        } catch (Optional.NotPresentException e) {
            return false;
        }
    }

    /**
     * InView課金が有効かどうかを返します
     *
     * @return InView課金が有効な場合はtrue
     */
    boolean isInViewChargingEnabled() {
        try {
            final Optional<Trackers.ImpCondition> impCondition =
                    getFirstResult(response).unwrap().trackers.unwrap().impCondition;
            return impCondition.isPresent() && !ADGDebugUtils.useLegacyTracking;
        } catch (Optional.NotPresentException e) {
            return false;
        }
    }

    /**
     * Win/Loss通知ビーコンを送信します
     *
     * @param listener ビーコンごとに送信結果をコールバックします
     */
    void sendWinNotificationBeacons(@Nullable final OnProgressListener listener) {
        if (winNotificationBeacons.isEmpty()) {
            return;
        }

        final List<SSCoreTrackingEvent> beacons = winNotificationBeacons.forced();
        for (final SSCoreTrackingEvent event : beacons) {
            event.fire(
                    trackingEventSender,
                    error -> {
                        if (listener != null) {
                            listener.onProgress(event.getUrl(), error);
                        }
                    });
        }
    }

    /**
     * 広告読み込み時にこのメソッドを呼び、トラッキングイベントを送信してください
     *
     * @param listener トラッキングイベントごとに送信結果をコールバックします
     */
    void sendLoadTriggerEvents(@Nullable final OnProgressListener listener) {
        if (impressionTracker.isEmpty()) {
            return;
        }

        final ImpressionTracking tracking = impressionTracker.forced();
        tracking.sendLoadTriggerEvents(
                trackingEventSender,
                (url, error) -> {
                    if (listener != null) {
                        listener.onProgress(url, error);
                    }
                });
    }

    /**
     * 指定された条件(表示面積と表示時間)を満たした場合、このメソッドを呼び、トラッキングイベントを送信してください
     *
     * @param key 識別キー
     * @param listener トラッキングイベントごとに送信結果をコールバックします
     */
    public void sendImpressions(
            @NonNull final String key, @Nullable final OnProgressListener listener) {
        if (impressionTracker.isEmpty()) {
            return;
        }

        final ImpressionTracking tracking = impressionTracker.forced();
        tracking.sendImpressions(
                key,
                trackingEventSender,
                (url, error) -> {
                    if (listener != null) {
                        listener.onProgress(url, error);
                    }
                });
    }

    /**
     * 広告枠IDを取得します
     *
     * @return ロケーションID
     */
    @Deprecated
    @NonNull
    String getLocationId() {
        return response.locationId;
    }

    /**
     * 表示タイプを取得します
     *
     * @return 表示タイプ
     */
    @Deprecated
    int getDisplayType() {
        return response.displayType;
    }

    /**
     * ANIDを取得します
     *
     * @return ANID
     */
    @Deprecated
    @NonNull
    String getAnid() {
        return response.ids.anid;
    }

    /**
     * DIIDを取得します
     *
     * @return DIID
     */
    @Deprecated
    @NonNull
    String getDiid() {
        return response.ids.diid;
    }

    /**
     * IDFAを取得します
     *
     * @return IDFA
     */
    @Deprecated
    @NonNull
    String getIdfa() {
        return response.ids.idfa;
    }

    /**
     * SOCを取得します
     *
     * @return SOC
     */
    @Deprecated
    @NonNull
    String getSoc() {
        return response.ids.soc;
    }

    /**
     * ローテーション間隔[ミリ秒]を取得します
     *
     * @return ローテーション間隔[ミリ秒]
     */
    public long getRotationInMilliseconds() {
        return response.rotation.inMilliseconds;
    }

    /**
     * location_params.option.native_ad.included_templateを取得します
     *
     * @return included_template
     */
    @NonNull
    Optional<Boolean> getIncludedTemplate() {
        return response.locationParams
                .flatMap(locationParams -> locationParams.option.nativeAd)
                .map(nativeAdOption -> nativeAdOption.includedTemplate);
    }

    /**
     * location_params.option.open_measurement.enable_webview_displayを取得します
     *
     * @return enable_webview_display
     */
    @NonNull
    Optional<Boolean> getEnableWebViewDisplay() {
        return response.locationParams
                .flatMap(locationParams -> locationParams.option.openMeasurement)
                .map(openMeasurementOption -> openMeasurementOption.enableWebViewDisplay);
    }

    /**
     * 広告HTMLを取得します
     *
     * @return 広告HTML
     */
    @NonNull
    Optional<String> getAd() {
        return getFirstResult(response).flatMap(result -> result.ad);
    }

    /**
     * ビーコンURLを取得します
     *
     * @return ビーコンURL
     */
    @NonNull
    Optional<String> getBeaconUrl() {
        return getFirstResult(response).flatMap(result -> result.beaconUrl);
    }

    /**
     * ADMペイロードを取得します
     *
     * @return ADMペイロード
     */
    @Deprecated
    @NonNull
    Optional<String> getAdmPayload() {
        return getFirstResult(response).flatMap(result -> result.admPayload);
    }

    /**
     * creative_params.bidder_params.successful_bidderを取得します
     *
     * @return 成功した入札者名
     */
    @NonNull
    Optional<String> getBidderSuccessfulName() {
        return getFirstResult(response)
                .flatMap(result -> result.creativeParams)
                .flatMap(creativeParams -> creativeParams.bidderParams)
                .map(bidderParams -> bidderParams.successfulBidder);
    }

    /**
     * creative_params.viewabilityを取得します
     *
     * @deprecated Legacy viewable specification.
     * @return creative_params.viewability
     */
    @Deprecated
    @NonNull
    Optional<ResponseViewabilityParams> getViewabilityParams() {
        final CreativeParams.Viewability viewability;
        try {
            viewability =
                    getFirstResult(response)
                            .flatMap(result -> result.creativeParams)
                            .flatMap(creativeParams -> creativeParams.viewability)
                            .unwrap();
        } catch (Optional.NotPresentException e) {
            // 新仕様では定義されていない
            return Optional.empty();
        }

        return Optional.of(
                new ResponseViewabilityParams(
                        viewability.chargeWhenLoading,
                        viewability.ratio,
                        viewability.duration,
                        viewability.measurementInterval.orElse(
                                ViewableMeasurementInterval.DEFAULT.inSeconds)));
    }

    /**
     * creative_params.viewability.measurement_intervalを取得します
     *
     * @return Viewable計測間隔を表す {@link ViewableMeasurementInterval}
     *     インスタンスを返します。サーバから値が返却されない場合はデフォルト値を返します
     */
    @NonNull
    public ViewableMeasurementInterval getViewableMeasurementInterval() {
        return getFirstResult(response)
                .flatMap(result -> result.creativeParams)
                .flatMap(creativeParams -> creativeParams.viewability)
                .flatMap(viewability -> viewability.measurementInterval)
                .map(ViewableMeasurementInterval::new)
                .orElse(ViewableMeasurementInterval.DEFAULT);
    }

    /**
     * @deprecated Use {@link AdBridgingObject#sendLoadTriggerEvents} instead.
     * @return trackers.imp
     */
    @Deprecated
    @NonNull
    Optional<List<String>> getImpBeacon() {
        if (getViewabilityParams().isPresent()
                && !getViewabilityParams().forced().chargeWhenLoading) {
            return getFirstResult(response)
                    .flatMap(result -> result.trackers)
                    .map(trackers -> trackers.imp.getUrls());
        } else {
            final List<String> urls;
            try {
                urls =
                        getFirstResult(response)
                                .flatMap(result -> result.trackers)
                                .map(trackers -> trackers.imp.getUrls())
                                .unwrap();
            } catch (Optional.NotPresentException e) {
                return Optional.empty();
            }

            // trackers.impの中からbeaconurlと重複している値を削除する
            final List<String> filteredUrls = new ArrayList<>();
            for (final String url : urls) {
                if (!url.equals(getBeaconUrl().maybe())) {
                    filteredUrls.add(url);
                }
            }
            return Optional.of(filteredUrls);
        }
    }

    /**
     * trackers.viewable_measuredを取得します
     *
     * @deprecated Legacy viewable specification.
     * @return trackers.viewable_measured
     */
    @Deprecated
    @NonNull
    Optional<List<String>> getViewableMeasuredBeacon() {
        return getFirstResult(response)
                .flatMap(result -> result.trackers)
                .flatMap(trackers -> trackers.viewableMeasured)
                .map(Trackers.ViewableMeasured::getUrls);
    }

    /**
     * trackers.viewable_impを取得します
     *
     * @deprecated Legacy viewable specification.
     * @return trackers.viewable_imp
     */
    @Deprecated
    @NonNull
    Optional<List<String>> getViewableImpBeacon() {
        if (getViewabilityParams().isPresent()
                && !getViewabilityParams().forced().chargeWhenLoading) {
            return getFirstResult(response)
                    .flatMap(result -> result.trackers)
                    .flatMap(trackers -> trackers.viewableImp)
                    .map(Trackers.ViewableImp::getUrls);
        } else {
            final List<String> urls;
            try {
                urls =
                        getFirstResult(response)
                                .flatMap(result -> result.trackers)
                                .flatMap(trackers -> trackers.viewableImp)
                                .map(Trackers.ViewableImp::getUrls)
                                .unwrap();
            } catch (Optional.NotPresentException e) {
                return Optional.empty();
            }

            // trackers.viewable_impの中からbeaconurlと重複している値を削除する
            final List<String> filteredUrls = new ArrayList<>();
            for (final String url : urls) {
                if (!url.equals(getBeaconUrl().maybe())) {
                    filteredUrls.add(url);
                }
            }
            return Optional.of(filteredUrls);
        }
    }

    /**
     * スケジュールIDを取得します
     *
     * @return スケジュールID
     */
    @NonNull
    Optional<String> getScheduleId() {
        return getFirstResult(response).flatMap(result -> result.scheduleId);
    }

    /**
     * クリエイティブIDを取得します
     *
     * @return クリエイティブID
     */
    @NonNull
    Optional<String> getCreativeId() {
        return getFirstResult(response).flatMap(result -> result.creativeId);
    }

    /**
     * アドネットワークIDを取得します
     *
     * @return アドネットワークID
     */
    @NonNull
    Optional<String> getAdNetworkId() {
        return getFirstResult(response).flatMap(result -> result.adNetworkId);
    }

    /**
     * DSP IDを取得します
     *
     * @return DSP ID
     */
    @NonNull
    Optional<String> getDspId() {
        return getFirstResult(response).flatMap(result -> result.dspId);
    }

    /**
     * Seatを取得します
     *
     * @return Seat
     */
    @NonNull
    Optional<String> getSeat() {
        return getFirstResult(response).flatMap(result -> result.seat);
    }

    /**
     * VAST XMLを取得します
     *
     * @return VAST XML
     */
    @NonNull
    Optional<String> getVastXml() {
        return getFirstResult(response).flatMap(result -> result.vastXML);
    }

    /**
     * メディエーションタイプを取得します
     *
     * @return メディエーションタイプ
     */
    int getMediationType() {
        return getFirstResult(response)
                .flatMap(result -> result.creativeParams)
                .flatMap(creativeParams -> creativeParams.mediation)
                .flatMap(mediation -> mediation.type)
                .orElse(0);
    }

    /**
     * メディエーションタイプかどうかを返します
     *
     * @return メディエーションタイプの場合はtrue
     */
    boolean isMediationType() {
        // 従来実装が奇数かどうかで判定していたため、そのまま仕様を踏襲
        return getMediationType() % 2 == 1;
    }

    /**
     * メディエーションクラス名を取得します
     *
     * @return メディエーションクラス名
     */
    @NonNull
    Optional<String> getMediationClassName() {
        return getFirstResult(response)
                .flatMap(result -> result.creativeParams)
                .flatMap(creativeParams -> creativeParams.mediation)
                .flatMap(mediation -> mediation.className);
    }

    /**
     * メディエーション広告IDを取得します
     *
     * @return メディエーション広告ID
     */
    @NonNull
    Optional<String> getMediationAdId() {
        return getFirstResult(response)
                .flatMap(result -> result.creativeParams)
                .flatMap(creativeParams -> creativeParams.mediation)
                .flatMap(mediation -> mediation.adId);
    }

    /**
     * メディエーションパラメータを取得します
     *
     * @return メディエーションパラメータ
     */
    @NonNull
    Optional<Map<String, Object>> getMediationParam() {
        return getFirstResult(response)
                .flatMap(result -> result.creativeParams)
                .flatMap(creativeParams -> creativeParams.mediation)
                .flatMap(mediation -> mediation.param);
    }

    /**
     * メディエーション動画フラグを取得します
     *
     * @return メディエーション動画フラグ
     */
    int getMediationMovie() {
        return getFirstResult(response)
                .flatMap(result -> result.creativeParams)
                .flatMap(creativeParams -> creativeParams.mediation)
                .flatMap(mediation -> mediation.movie)
                .orElse(0);
    }

    /**
     * メディエーションが動画かどうかを返します
     *
     * @return メディエーションが動画の場合はtrue
     */
    public boolean isMediationMovie() {
        // 従来実装が奇数かどうかで判定していたため、そのまま仕様を踏襲
        return getMediationMovie() % 2 == 1;
    }

    /**
     * No Adかどうかを返します
     *
     * @return No Adの場合はtrue
     */
    public boolean isNoAd() {
        // TODO: 従来実装のままにしているが、No Ad条件の再確認。iOSとも条件が異なるが良いのか
        final String ad = getAd().maybe();
        final String scheduleId = getScheduleId().maybe();
        return ad == null || ad.contains("st=noad : id=") && TextUtils.isEmpty(scheduleId);
    }

    /**
     * 有効なViewable計測パラメータを生成します
     *
     * @return Viewable計測パラメータ
     */
    @NonNull
    public List<ViewableParameter> getViewableParameters() {
        return impressionTracker
                .map(ImpressionTracking::getViewableParameters)
                .orElse(new ArrayList<>());
    }

    /**
     * すべての広告読み込み時トリガーイベントが発火したかどうかを確認します
     *
     * @return すべての広告読み込み時トリガーイベントが発火した場合はtrue
     */
    public boolean areLoadTriggerEventsFired() {
        return impressionTracker.map(ImpressionTracking::areLoadTriggerEventsFired).orElse(false);
    }

    /**
     * すべてのインプレッションイベントが発火したかどうかを確認します
     *
     * @return すべてのインプレッションイベントが発火した場合はtrue
     */
    public boolean areAllImpressionsFired() {
        return impressionTracker.map(ImpressionTracking::areAllImpressionsFired).orElse(false);
    }

    @NonNull
    public Optional<List<String>> getTrackerBiddingNotifyUrls() {
        return getFirstResult(response)
                .flatMap(responseResult -> responseResult.creativeParams)
                .flatMap(CreativeParams::getTrackers);
    }

    /**
     * ネイティブ広告データを取得します
     *
     * @return ネイティブ広告データ
     */
    @NonNull
    public Optional<Native> getNativeAd() {
        return getFirstResult(response).flatMap(result -> result.nativeAd);
    }

    @NonNull
    private static Optional<ResponseResult> getFirstResult(@NonNull final Response response) {
        if (response.getResults().isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(response.getResults().get(0));
    }

    /** リソース読み込み完了時のリスナーです */
    interface OnLoadResourcesListener {
        /**
         * 読み込み完了時に呼ばれます
         *
         * @param result 読み込み処理の結果
         */
        void onLoaded(@NonNull Result<AdBridgingObject, Exception> result);
    }

    /** 進捗通知用のリスナーです */
    public interface OnProgressListener {
        /**
         * 進捗通知時に呼ばれます
         *
         * @param url 処理されたURL
         * @param error エラー情報。成功時は {@link Optional#empty()} が渡されます
         */
        void onProgress(@NonNull String url, @NonNull Optional<Exception> error);
    }
}
