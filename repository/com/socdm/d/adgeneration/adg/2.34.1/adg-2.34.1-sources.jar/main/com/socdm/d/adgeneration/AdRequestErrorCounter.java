package com.socdm.d.adgeneration;

/** リクエストエラー回数をカウントするクラスです */
final class AdRequestErrorCounter {
    private final int max;
    private int count;

    /**
     * カウンターの現在値を取得します
     *
     * @return カウンターの現在値
     */
    int getCount() {
        return count;
    }

    /**
     * カウンターが上限に達しているならばtrueを返し、それ以外はfalseを返します
     *
     * @return カウンターが上限に達しているならばtrue、それ以外はfalse
     */
    boolean isReachedLimit() {
        return count == max;
    }

    /**
     * インスタンスを生成します。カウンターは0から始まります
     *
     * @param max カウンターの最大値
     */
    AdRequestErrorCounter(final int max) {
        this(max, 0);
    }

    /**
     * インスタンスを生成します
     *
     * @param max カウンターの最大値
     * @param initialValue カウンターの初期値
     */
    AdRequestErrorCounter(final int max, final int initialValue) {
        this.max = max;
        this.count = initialValue;
    }

    /** リクエストエラー回数を+1します。なお、設定されている最大値を超えてカウントされることはありません */
    void increase() {
        if (count < max) {
            count++;
        }
    }
}
