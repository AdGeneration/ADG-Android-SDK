package com.socdm.d.adgeneration.nativead;

public abstract class ADGNativeAdOnClickListener {
    public void onClickAd() {
    }
}
