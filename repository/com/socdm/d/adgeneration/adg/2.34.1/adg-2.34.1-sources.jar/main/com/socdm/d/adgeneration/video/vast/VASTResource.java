package com.socdm.d.adgeneration.video.vast;

import androidx.annotation.Nullable;

import java.io.Serializable;

import com.socdm.d.adgeneration.video.ADGPlayerError;

public class VASTResource implements Serializable {
    public interface ILoadListener {
        void onCompleted(VASTResource resource, ADGPlayerError error);
    }

    private String creativeType;
    private String urlString;

    public VASTResource(@Nullable String creativeType, @Nullable String url) {
        this.creativeType = creativeType;
        this.urlString = url;
    }

    public String getCreativeType() {
        return creativeType;
    }

    public String getUrlString() {
        return urlString;
    }
}