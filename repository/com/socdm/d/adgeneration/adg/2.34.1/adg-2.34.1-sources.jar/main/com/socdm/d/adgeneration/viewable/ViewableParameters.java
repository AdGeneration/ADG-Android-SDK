package com.socdm.d.adgeneration.viewable;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.type.Optional;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class ViewableParameters {
    @NonNull public final ViewableMeasurementInterval measurementInterval;
    @NonNull private final List<ViewableParameter> parameters = new ArrayList<>();

    /**
     * インスタンスを生成します。Viewable計測パラメータは複数指定できます。重複するパラメータは除外されます
     *
     * @param measurementInterval Viewable計測間隔
     * @param parameters Viewable計測パラメータ
     */
    public ViewableParameters(
            @NonNull final ViewableMeasurementInterval measurementInterval,
            @NonNull final ViewableParameter... parameters) {
        this.measurementInterval = measurementInterval;

        List<ViewableParameter> viewableParameters = new ArrayList<>();
        for (ViewableParameter parameter : parameters) {
            if (viewableParameters.contains(parameter)) {
                // 重複を除外
                continue;
            }

            if (parameter.ratio <= 0 || parameter.duration <= 0) {
                // 0以下の値を除外
                continue;
            }

            viewableParameters.add(
                    new ViewableParameter(parameter.key, parameter.ratio, parameter.duration));
        }

        this.parameters.addAll(viewableParameters);
    }

    /**
     * インスタンスを生成します。Viewable計測パラメータは複数指定できます。重複するパラメータは除外されます
     *
     * @param measurementInterval Viewable計測間隔
     * @param parameters Viewable計測パラメータ
     */
    public ViewableParameters(
            @NonNull final ViewableMeasurementInterval measurementInterval,
            @NonNull final List<ViewableParameter> parameters) {
        this(measurementInterval, parameters.toArray(new ViewableParameter[0]));
    }

    @NonNull
    @Override
    public String toString() {
        return "{ measurementInterval: "
                + measurementInterval
                + ", parameters: "
                + parameters
                + " }";
    }

    @Override
    public boolean equals(@Nullable final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final ViewableParameters that = (ViewableParameters) o;
        return measurementInterval.equals(that.measurementInterval)
                && parameters.equals(that.parameters);
    }

    @Override
    public int hashCode() {
        return Objects.hash(measurementInterval.hashCode(), parameters.hashCode());
    }

    /**
     * Viewable計測パラメータを取得します
     *
     * @return Viewable計測パラメータのリスト
     */
    @NonNull
    public List<ViewableParameter> getParameters() {
        List<ViewableParameter> copiedList = new ArrayList<>(parameters.size());
        for (ViewableParameter parameter : parameters) {
            copiedList.add(
                    new ViewableParameter(parameter.key, parameter.ratio, parameter.duration));
        }
        return copiedList;
    }

    /**
     * 表示割合の最小値を取得します
     *
     * @return 表示割合の最小値
     */
    public double getMinimumRatio() {
        if (parameters.isEmpty()) {
            return 0;
        }

        double minimumRatio = parameters.get(0).ratio;

        for (ViewableParameter parameter : parameters) {
            minimumRatio = Math.min(minimumRatio, parameter.ratio);
        }

        return minimumRatio;
    }

    /** デフォルトのViewable計測パラメータ */
    @NonNull
    public static final ViewableParameters DEFAULT =
            new ViewableParameters(ViewableMeasurementInterval.DEFAULT, ViewableParameter.DEFAULT);

    @Nullable private static ViewableParameters parametersForDebugging;

    /**
     * このメソッドはデバッグ用です。このメソッドを使用すると、Viewable計測パラメータは指定されたパラメータで上書きされます
     *
     * @param measurementInterval Viewable計測間隔
     * @param parameters Viewable計測パラメータ
     */
    public static void setParametersForDebugging(
            @NonNull final ViewableMeasurementInterval measurementInterval,
            @NonNull final List<ViewableParameter> parameters) {
        synchronized (ViewableParameters.class) {
            parametersForDebugging =
                    new ViewableParameters(
                            measurementInterval, parameters.toArray(new ViewableParameter[0]));
        }
    }

    /**
     * このメソッドはデバッグ用です。 {@link ViewableParameters#setParametersForDebugging}
     * メソッドで追加されたViewable計測パラメータを削除します
     */
    public static void removeParametersForDebugging() {
        synchronized (ViewableParameters.class) {
            parametersForDebugging = null;
        }
    }

    /**
     * デバッグ用のViewable計測パラメータを取得します
     *
     * @return Viewable計測パラメータ
     */
    @NonNull
    public static Optional<ViewableParameters> parametersForDebugging() {
        return Optional.of(parametersForDebugging);
    }
}
