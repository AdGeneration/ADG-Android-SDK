package com.socdm.d.adgeneration.interstitial.templates;

import android.content.Context;
import android.view.Gravity;
import android.widget.RelativeLayout;

import com.socdm.d.adgeneration.interstitial.templates.layout.ADGLayout;
import com.socdm.d.adgeneration.interstitial.templates.layout.CloseButtonLayout;
import com.socdm.d.adgeneration.interstitial.templates.partsfactory.CloseButton40x40Factory;
import com.socdm.d.adgeneration.utils.DisplayUtils;

@Deprecated
public class FullScreenTemplate extends BaseTemplate {

    public FullScreenTemplate(Context context) {
        super(context);
        this.setCloseButtonFactory(new CloseButton40x40Factory(context));
    }

    @Override
    public void initTemplate() {
        // templateView自体のサイズ
        int width = DisplayUtils.getFP();
        int height = DisplayUtils.getFP();
        RelativeLayout frame = new RelativeLayout(getContext());
        frame.setGravity(Gravity.CENTER_HORIZONTAL);
        frame.setLayoutParams(new RelativeLayout.LayoutParams(width, height));
        frame.addView(initAdgLayout());
        frame.addView(initCloseButtonLayout());
        this.setContainer(frame);
    }

    // ADG自体の表示領域
    private ADGLayout initAdgLayout() {
        ADGLayout layout = this.getAdgLayout();
        layout.setLayoutParams(
                new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.MATCH_PARENT,
                        RelativeLayout.LayoutParams.MATCH_PARENT));
        return layout;
    }

    private CloseButtonLayout initCloseButtonLayout() {
        final CloseButtonLayout layout = this.getCloseButtonLayout();
        int width = DisplayUtils.getPixels(getContext().getResources(), 40);
        int height = DisplayUtils.getPixels(getContext().getResources(), 40);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(width, height);
        params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, TRUE);
        layout.setLayoutParams(params);
        layout.setGravity(Gravity.RIGHT);
        return layout;
    }
}
