package com.socdm.d.adgeneration.viewable;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import java.util.Objects;

public final class ViewableMeasurementInterval {
    /** デフォルトの計測間隔[秒] */
    // 0.1sだとパフォーマンスに影響する可能性があるため、0.5sに設定
    @VisibleForTesting public static final double DEFAULT_MEASUREMENT_INTERVAL = 0.5;
    /** 計測間隔の最大値[秒] */
    // ユーザー設定される値のため大きすぎる値を弾く、サーバーとの取り決めがあるわけではなく、SDKの都合上設定している
    @VisibleForTesting public static final double MAX_MEASUREMENT_INTERVAL = 60.0;
    /** 計測間隔の最小値[秒] */
    @VisibleForTesting public static final double MIN_MEASUREMENT_INTERVAL = 0.1;

    /** 計測間隔[秒] */
    public final double inSeconds;

    /**
     * インスタンスを生成します
     *
     * @param measurementInterval 計測間隔[秒]
     */
    public ViewableMeasurementInterval(final double measurementInterval) {
        inSeconds =
                Math.min(
                        Math.max(measurementInterval, MIN_MEASUREMENT_INTERVAL),
                        MAX_MEASUREMENT_INTERVAL);
    }

    @NonNull
    @Override
    public String toString() {
        return "" + inSeconds;
    }

    @Override
    public boolean equals(@Nullable final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final ViewableMeasurementInterval that = (ViewableMeasurementInterval) o;
        return Double.compare(that.inSeconds, inSeconds) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(inSeconds);
    }

    /**
     * 計測間隔をミリ秒単位で取得します
     *
     * @return 計測間隔[ミリ秒]
     */
    public long inMilliseconds() {
        return (long) (inSeconds * 1000L);
    }

    /** デフォルトのViewable計測間隔 */
    @NonNull
    public static final ViewableMeasurementInterval DEFAULT =
            new ViewableMeasurementInterval(DEFAULT_MEASUREMENT_INTERVAL);
}
