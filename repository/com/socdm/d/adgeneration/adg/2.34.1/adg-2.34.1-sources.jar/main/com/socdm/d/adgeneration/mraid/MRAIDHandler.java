package com.socdm.d.adgeneration.mraid;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import androidx.annotation.NonNull;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;

import com.socdm.d.adgeneration.utils.AssetUtils;
import com.socdm.d.adgeneration.utils.DisplayUtils;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.utils.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MRAIDHandler {

    private static final String MRAID_JS = "mraid.js";
    private static final String MRAID_SCHEME = "mraid";
    private static String mraidSource = null;
    private static Boolean mraidLoaded = false;
    private boolean wasClicked = false;

    private static String getMRAIDSource(Context context) {
        if (!mraidLoaded) {
            LogUtils.d("Load mraid.js from assets.");
            mraidSource = AssetUtils.getMRAIDSource(context);
        } else {
            return "";
        }

        if (mraidSource == null) {
            LogUtils.e("Error loading mraid.js from assets.");
            return "";
        }
        mraidLoaded = true;
        return "javascript:(function(){" + mraidSource + "})()";
    }

    public static boolean matchesInjectionUrl(@NonNull final String url) {
        final Uri uri = Uri.parse(url.toLowerCase(Locale.US));
        return MRAID_JS.equals(uri.getLastPathSegment());
    }

    /**
     * 広告のレスポンス時にのみ呼ばれる
     * @param html
     * @return
     */
    public static String injectMRAIDScriptTag(String html) {
        if (!html.matches(MRAID_JS)) {
            mraidLoaded = false;
            return html.replace("<body>", "<body><script src=\"adg/" + MRAID_JS + "\" type=\"text/javascript\"></script>");
        }
        return html;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public static WebResourceResponse createMRAIDInjectionResponse(Context context) {
        InputStream data = new ByteArrayInputStream(getMRAIDSource(context).getBytes());
        return new WebResourceResponse("text/javascript", "UTF-8", data);
    }

    public static MRAIDHandler getCurrentHandler(MRAIDHandler[] handlers, WebView webView) {
        for (MRAIDHandler handler :handlers) {
            if (handler.getWebView().equals(webView)) {
                return handler;
            }
        }
        return null;
    }

    public static boolean matchesMRAIDScheme(String url) {
        if (url == null) {
            return false;
        }
        final Uri uri = Uri.parse(url.toLowerCase(Locale.US));
        final String scheme = uri.getScheme();
        return scheme.equals(MRAID_SCHEME);
    }

    private Context mContext = null;
    private WebView mWebView = null;
    private MRAIDScreenMetrics mScreenMetrics = null;
    private MRAIDPlacementType mPlacementTyp = MRAIDPlacementType.INLINE;

    public MRAIDHandler(Context context) {
        mContext = context;
    }

    public void setWebView(WebView webView) {
        mWebView = webView;
        mWebView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        wasClicked = true;
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    public WebView getWebView() { return mWebView; }

    public void setIsInterstitial(boolean isInterstitial) {
        mPlacementTyp = isInterstitial ? MRAIDPlacementType.INTERSTITIAL : MRAIDPlacementType.INLINE;
    }

    public void initializeState() {
        mScreenMetrics = new MRAIDScreenMetrics(mContext);
        int[] location = new int[2];

        View rootView = getRootView();
        if (rootView != null) {
            rootView.getLocationOnScreen(location);
            mScreenMetrics.setRootViewPosition(location[0], location[1], rootView.getWidth(), rootView.getHeight());
            MRAIDBridge.setMaxSize(mWebView, mScreenMetrics.getRootViewRectDips());
        }

        ViewGroup adContainerView = getAdContainerView();
        if (adContainerView != null) {
            adContainerView.getLocationOnScreen(location);
            mScreenMetrics.setCurrentAdPosition(location[0], location[1], mWebView.getWidth(), mWebView.getHeight());
            mScreenMetrics.setDefaultAdPosition(location[0], location[1], mWebView.getWidth(), mWebView.getHeight());

            MRAIDBridge.setCurrentPosition(mWebView, mScreenMetrics.getCurrentAdRectDips());
            MRAIDBridge.setDefaultPosition(mWebView, mScreenMetrics.getDefaultAdRectDips());

            if (mContext instanceof Activity) {
                DisplayUtils.Size size = DisplayUtils.getScreenSize((Activity)mContext);
                mScreenMetrics.setScreenSize(size.getWidth(), size.getHeight());
                MRAIDBridge.setScreenSize(mWebView, mScreenMetrics.getScreenRectDips());
            }
        }

        MRAIDBridge.setPlacementType(mWebView, mPlacementTyp);
        MRAIDBridge.setState(mWebView, MRAIDState.DEFAULT);
        MRAIDBridge.notifyReadyEvent(mWebView);
    }

    public MRAIDHandlerResult handleUrlLoading(String url) {
        if (!matchesMRAIDScheme(url)) {
            wasClicked = false;
            return new MRAIDHandlerResult(true);
        }
        String[] splitUrl = url.split("\\?", 0);

        final Uri uri = Uri.parse(url.toLowerCase(Locale.US));
        final String command = uri.getHost();
        final String query =  1 < splitUrl.length ? splitUrl[1] : null;
        final Map<String, String> parameter = query != null ? StringUtils.queryToMap(query) : new HashMap<String, String>();

        if (command.equals(MRAIDCommand.EXPAND.toJavascriptString())) {
            MRAIDBridge.notifyErrorEvent(mWebView, "not implementation", MRAIDCommand.EXPAND);
            MRAIDBridge.nativeCallComplete(mWebView, MRAIDCommand.EXPAND);
            wasClicked = false;
            return new MRAIDHandlerResult(false);
        } else if (command.equals(MRAIDCommand.USE_CUSTOM_CLOSE.toJavascriptString())) {
            MRAIDBridge.notifyErrorEvent(mWebView, "not implementation", MRAIDCommand.USE_CUSTOM_CLOSE);
            MRAIDBridge.nativeCallComplete(mWebView, MRAIDCommand.CLOSE);
            wasClicked = false;
            return new MRAIDHandlerResult(false);
        } else if (command.equals(MRAIDCommand.RESIZE.toJavascriptString())) {
            MRAIDBridge.notifyErrorEvent(mWebView, "not implementation", MRAIDCommand.RESIZE);
            MRAIDBridge.nativeCallComplete(mWebView, MRAIDCommand.RESIZE);
            wasClicked = false;
            return new MRAIDHandlerResult(false);
        } else if (command.equals(MRAIDCommand.OPEN.toJavascriptString())) {
            String openURLString = parameter.get("url");
            try {
                if (wasClicked) {
                    return new MRAIDHandlerResult(true, openURLString);
                } else {
                    MRAIDBridge.notifyErrorEvent(mWebView, "not user interaction", MRAIDCommand.OPEN);
                    return new MRAIDHandlerResult(false);
                }
            } catch (MalformedURLException e) {
                MRAIDBridge.notifyErrorEvent(mWebView, "url parameter error", MRAIDCommand.OPEN);
                return new MRAIDHandlerResult(false);
            } finally {
                MRAIDBridge.nativeCallComplete(mWebView, MRAIDCommand.OPEN);
                wasClicked = false;
            }
        } else if (command.equals(MRAIDCommand.CLOSE.toJavascriptString())) {
            MRAIDBridge.notifyErrorEvent(mWebView, "not implementation", MRAIDCommand.CLOSE);
            MRAIDBridge.nativeCallComplete(mWebView, MRAIDCommand.CLOSE);
            wasClicked = false;
            return new MRAIDHandlerResult(false);
        } else if (command.equals(MRAIDCommand.SET_ORIENTATION_PROPERTIES.toJavascriptString())) {
            MRAIDBridge.notifyErrorEvent(mWebView, "not implementation", MRAIDCommand.SET_ORIENTATION_PROPERTIES);
            MRAIDBridge.nativeCallComplete(mWebView, MRAIDCommand.SET_ORIENTATION_PROPERTIES);
            wasClicked = false;
            return new MRAIDHandlerResult(false);
        } else {
            wasClicked = false;
            return new MRAIDHandlerResult(false);
        }
    }

    public void setIsViewable(boolean isViewable) {
        MRAIDBridge.setIsViewable(mWebView, isViewable);
    }

    private View getRootView() {
        return mWebView.getRootView();
    }

    private ViewGroup getAdContainerView() {
        return (ViewGroup) mWebView.getParent();
    }

}
