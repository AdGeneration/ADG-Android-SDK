package com.socdm.d.adgeneration.interstitial.templates.parts;

import android.view.View;

@Deprecated
public interface CloseButton<T extends View> {
    public T get();
}
