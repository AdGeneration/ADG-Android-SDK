package com.socdm.d.adgeneration.nativead;

public enum ADGNativeAdType {
    Undefined,
    Default,
    GunosyAds,
    AmebaJointAlliance;

    public static final String KEY = "nativeadtype";
}