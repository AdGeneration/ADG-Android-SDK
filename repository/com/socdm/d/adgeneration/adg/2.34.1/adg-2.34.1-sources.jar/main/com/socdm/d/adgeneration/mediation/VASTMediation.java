package com.socdm.d.adgeneration.mediation;

import android.os.Build;
import android.view.Gravity;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;

import com.socdm.d.adgeneration.utils.JsonUtils;
import com.socdm.d.adgeneration.video.ADGPlayerAdListener;
import com.socdm.d.adgeneration.video.ADGPlayerAdManager;
import com.socdm.d.adgeneration.video.ADGPlayerError;
import com.socdm.d.adgeneration.video.config.Const;

import jp.supership.sscore.type.Optional;

public class VASTMediation extends ADGNativeInterfaceChild {
    @NonNull private Optional<ADGPlayerAdManager> playerAdManager = Optional.empty();

    @Override
    public boolean loadProcess() {
        String vastxml = JsonUtils.fromJson(param).optString("vast");

        final ADGPlayerAdManager manager = new ADGPlayerAdManager(ct);
        manager.setIsWipe(isWipe);
        manager.setAdListener(
                new ADGPlayerAdListener() {
                    @Override
                    public void onReadyToPlayAd() {
                        if (listener != null) {
                            listener.onReceiveAd();
                        }

                        showAd();
                    }

                    @Override
                    public void onFailedToPlayAd(ADGPlayerError ADGPlayerError) {
                        listener.onFailedToReceiveAd();
                    }

                    @Override
                    public void onStartVideo() {}

                    @Override
                    public void onClickAd() {
                        if (listener != null) {
                            listener.onClickAd();
                        }
                    }
                });
        manager.load(vastxml, null);
        playerAdManager = Optional.of(manager);

        return true;
    }

    @Override
    public void startProcess() {}

    @Override
    public void stopProcess() {}

    @Override
    public void finishProcess() {
        playerAdManager.ifPresent(ADGPlayerAdManager::destroy);
        playerAdManager = Optional.empty();
    }

    @Override
    public boolean checkOSVersion() {
        return Build.VERSION.SDK_INT >= Const.MINVERSION;
    }

    @Override
    public void callWhenInView() {
        playerAdManager.ifPresent(ADGPlayerAdManager::callWhenInView);
    }

    @Override
    public void callWhenOutOfView() {
        playerAdManager.ifPresent(ADGPlayerAdManager::callWhenOutOfView);
    }

    private void showAd() {
        // ViewGroupにはgravityが設定できないため、FrameLayoutをwrapしてgravityが設定できるようにする
        FrameLayout centeringWrapperView = new FrameLayout(ct);
        FrameLayout.LayoutParams layoutParams =
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.gravity = Gravity.CENTER;

        centeringWrapperView.setLayoutParams(layoutParams);

        layout.addView(centeringWrapperView);

        playerAdManager.ifPresent(manager -> manager.showAd(centeringWrapperView));
    }
}
