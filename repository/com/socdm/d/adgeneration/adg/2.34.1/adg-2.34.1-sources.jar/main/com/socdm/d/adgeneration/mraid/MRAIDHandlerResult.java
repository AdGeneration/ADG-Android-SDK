package com.socdm.d.adgeneration.mraid;

import android.net.Uri;
import android.text.TextUtils;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URLDecoder;

public class MRAIDHandlerResult {
    private boolean mShouldLoadRequest = false;
    private Uri mOpenURL = null;

    MRAIDHandlerResult(boolean shouldLoadRequest) {
        mShouldLoadRequest = shouldLoadRequest;
    }

    MRAIDHandlerResult(boolean shouldLoadRequest, String openURL) throws MalformedURLException {
        mShouldLoadRequest = shouldLoadRequest;

        if (!TextUtils.isEmpty(openURL)) {
            try {
                String urlStr = URLDecoder.decode(openURL, "UTF-8");
                mOpenURL = Uri.parse(urlStr);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                return;
            }
        } else {
            throw new MalformedURLException("openURL");
        }
    }

    public boolean getShouldLoadRequest() {
        return mShouldLoadRequest;
    }

    public Uri getOpenURL() {
        return mOpenURL;
    }
}
