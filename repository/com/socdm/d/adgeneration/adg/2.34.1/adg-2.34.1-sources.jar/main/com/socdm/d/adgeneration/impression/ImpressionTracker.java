package com.socdm.d.adgeneration.impression;

import androidx.annotation.NonNull;

import com.socdm.d.adgeneration.adresponse.ResponseResult;
import com.socdm.d.adgeneration.adresponse.Trackers;

import jp.supership.sscore.tracking.SSCoreSingleFireTracker;
import jp.supership.sscore.tracking.SSCoreTracker;
import jp.supership.sscore.tracking.SSCoreTrackingEvent;
import jp.supership.sscore.type.Optional;
import jp.supership.sscore.vast.VastManager;
import jp.supership.sscore.vast.model.Impression;
import jp.supership.sscore.vast.model.Vast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** InView課金用インプレッショントラッキングイベントを生成するクラスです */
public final class ImpressionTracker implements ImpressionTracking {
    public static final String IMP_CONDITION_DATA_KEY = "inViewCharge.imp";
    public static final String AREA_TIME_DATA_KEY_PREFIX = "inViewCharge.areaTime";

    @NonNull private final List<SSCoreTrackingEvent> loadTriggerEvents;
    @NonNull private final Map<String, ImpressionData> impressions;

    /**
     * インスタンスを初期化します
     *
     * @param result レスポンスデータ
     * @param vast レスポンスにVASTが含まれる場合は VAST オブジェクトを渡す必要があります
     * @return 初期化されたインスタンス、初期化に失敗した場合は {@link Optional#empty()}
     */
    @NonNull
    public static Optional<ImpressionTracking> create(
            @NonNull final ResponseResult result, @NonNull final Optional<Vast> vast) {
        try {
            final Trackers trackers = result.trackers.unwrap();
            return Optional.of(new ImpressionTracker(result, trackers, vast));
        } catch (Optional.NotPresentException e) {
            return Optional.empty();
        }
    }

    private ImpressionTracker(
            @NonNull final ResponseResult result,
            @NonNull final Trackers trackers,
            @NonNull final Optional<Vast> vast) {
        final List<SSCoreTrackingEvent> impressionEvents = makeImpressionEvents(result, vast);

        // ロードトリガーイベントの初期化
        this.loadTriggerEvents = initializeLoadTriggerEvents(trackers, impressionEvents);

        // インプレッションイベントの初期化
        this.impressions = initializeImpressions(trackers, impressionEvents);
    }

    @Override
    @NonNull
    public List<SSCoreTrackingEvent> getLoadTriggerEvents() {
        return new ArrayList<>(loadTriggerEvents);
    }

    @Override
    @NonNull
    public Map<String, ImpressionData> getImpressions() {
        return new HashMap<>(impressions);
    }

    @NonNull
    private static List<SSCoreTrackingEvent> initializeLoadTriggerEvents(
            @NonNull final Trackers trackers,
            @NonNull final List<SSCoreTrackingEvent> impressionEvents) {
        final List<String> urls = new ArrayList<>();

        // areaTimeからロードトリガーのURLを抽出
        for (final Trackers.AreaTime areaTime : trackers.getAreaTime()) {
            if (areaTime.isLoadTrigger()) {
                urls.addAll(areaTime.getUrls());
            }
        }

        final List<SSCoreTrackingEvent> events = new ArrayList<>();
        for (final String url : urls) {
            try {
                final SSCoreTracker tracker = new SSCoreTracker(url);
                events.add(new SSCoreSingleFireTracker(tracker));
            } catch (final Exception e) {
                // 無効なURLはスキップ
            }
        }

        // impconditionが存在しない場合はロード完了時をインプレッション発生とする
        if (!trackers.impCondition.isPresent()) {
            events.addAll(impressionEvents);
        }

        return events;
    }

    @NonNull
    private static Map<String, ImpressionData> initializeImpressions(
            @NonNull final Trackers trackers,
            @NonNull final List<SSCoreTrackingEvent> impressionEvents) {
        final Map<String, ImpressionData> data = new HashMap<>();

        // impconditionで送信するイベント
        // (impconditionが存在しない場合はloadTriggerEventsに含める)
        try {
            final Trackers.ImpCondition impCondition = trackers.impCondition.unwrap();
            final ImpressionData impressionData =
                    new ImpressionData(
                            IMP_CONDITION_DATA_KEY,
                            impCondition.area,
                            impCondition.ms,
                            impressionEvents);
            data.put(impressionData.key, impressionData);
        } catch (Optional.NotPresentException ignored) {
        }

        // areaTimeイベントを処理
        final List<Trackers.AreaTime> areaTimeList = trackers.getAreaTime();
        for (int index = 0; index < areaTimeList.size(); index++) {
            final Trackers.AreaTime areaTime = areaTimeList.get(index);

            if (areaTime.area.isPresent() && areaTime.ms.isPresent()) {
                final List<SSCoreTrackingEvent> events = new ArrayList<>();
                for (final String url : areaTime.getUrls()) {
                    try {
                        final SSCoreTracker tracker = new SSCoreTracker(url);
                        events.add(new SSCoreSingleFireTracker(tracker));
                    } catch (final Exception e) {
                        // 無効なURLはスキップ
                    }
                }

                final ImpressionData impressionData =
                        new ImpressionData(
                                AREA_TIME_DATA_KEY_PREFIX + index,
                                areaTime.area.forced(),
                                areaTime.ms.forced(),
                                events);
                data.put(impressionData.key, impressionData);
            }
        }

        return data;
    }

    @NonNull
    private static List<SSCoreTrackingEvent> makeImpressionEvents(
            @NonNull final ResponseResult result, @NonNull final Optional<Vast> vast) {
        final List<String> urls = new ArrayList<>();

        // ネイティブ広告のインプレッショントラッカー
        try {
            urls.addAll(result.nativeAd.unwrap().getImpTrackers());
        } catch (Optional.NotPresentException ignored) {
        }

        // VASTの <Impression> 要素
        try {
            final List<Impression> impressions =
                    VastManager.getInstance().getImpressions(vast.unwrap());
            for (final Impression impression : impressions) {
                urls.add(impression.getUrl());
            }
        } catch (Optional.NotPresentException ignored) {
        }

        final List<SSCoreTrackingEvent> events = new ArrayList<>();
        for (final String url : urls) {
            try {
                final SSCoreTracker tracker = new SSCoreTracker(url);
                events.add(new SSCoreSingleFireTracker(tracker));
            } catch (final Exception e) {
                // 無効なURLはスキップ
            }
        }

        return events;
    }
}
