package com.socdm.d.adgeneration.mediation;

abstract public class ADGNativeInterfaceListener {
    public void onReceiveAd() {
    }

    public void onReceiveAd(Object nativeAd) {
    }

    public void onFailedToReceiveAd() {
    }

    public void onCompleteMovieAd() {
    }

    public void onReachRotateTime() {
    }

    public void onCloseInterstitial() {
    }

    public void onClickAd() {
    }

    public void onReadyMediation(Object mediation) {
    }

    public void onSuccessfulBidder(String bidderSuccessfulName) {
    }
}
