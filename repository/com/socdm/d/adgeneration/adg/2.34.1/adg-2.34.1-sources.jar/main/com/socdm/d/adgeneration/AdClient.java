package com.socdm.d.adgeneration;

import androidx.annotation.NonNull;

import com.socdm.d.adgeneration.adresponse.Response;
import com.socdm.d.adgeneration.utils.IGeolocationProvider;

import jp.supership.sscore.adid.SSCoreAdIdClientNotFoundException;
import jp.supership.sscore.adid.SSCoreAdIdProvidable;
import jp.supership.sscore.device.SSCoreAppInfoProvidable;
import jp.supership.sscore.device.SSCoreDeviceProvidable;
import jp.supership.sscore.http.SSCoreHttpClient;
import jp.supership.sscore.http.SSCoreHttpException;
import jp.supership.sscore.http.SSCoreHttpRequest;
import jp.supership.sscore.http.SSCoreHttpResponse;
import jp.supership.sscore.sequence.Sequencer;
import jp.supership.sscore.type.Optional;
import jp.supership.sscore.type.Result;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;

final class AdClient {
    interface Completable {
        /**
         * リクエスト処理が完了したときに呼ばれます
         *
         * @param result リクエスト結果
         */
        void onComplete(@NonNull Result<Response, Throwable> result);
    }

    interface IAdClient {
        /**
         * 広告リクエストを開始します
         *
         * @param request リクエストパラメータ
         * @param completion リクエスト完了時に呼ばれるコールバック
         */
        void requestAd(@NonNull AdRequest request, @NonNull Completable completion);

        /** リクエストをキャンセルします */
        void cancelRequest();
    }

    private static final class Client implements IAdClient {
        @NonNull private final IADGLogger logger;
        @NonNull private final SSCoreHttpClient httpClient;
        @NonNull private final IGeolocationProvider geolocationProvider;
        @NonNull private final SSCoreDeviceProvidable deviceProvider;
        @NonNull private final SSCoreAppInfoProvidable appInfoProvider;
        @NonNull private final SSCoreAdIdProvidable adIdProvider;
        @NonNull private final AdRequestValidation validator;

        private Client(
                @NonNull final IADGLogger logger,
                @NonNull final SSCoreHttpClient httpClient,
                @NonNull final IGeolocationProvider geolocationProvider,
                @NonNull final SSCoreDeviceProvidable deviceProvider,
                @NonNull final SSCoreAppInfoProvidable appInfoProvider,
                @NonNull final SSCoreAdIdProvidable adIdProvider,
                @NonNull final AdRequestValidation validator) {
            this.logger = logger;
            this.httpClient = httpClient;
            this.geolocationProvider = geolocationProvider;
            this.deviceProvider = deviceProvider;
            this.appInfoProvider = appInfoProvider;
            this.adIdProvider = adIdProvider;
            this.validator = validator;
        }

        @Override
        public void requestAd(
                @NonNull final AdRequest adRequest, @NonNull final Completable completion) {
            final Sequencer seq =
                    new Sequencer(
                            completable -> {
                                adIdProvider.getAdInfo(
                                        e -> {
                                            if (e instanceof SSCoreAdIdClientNotFoundException) {
                                                // com.google.android.gms.ads.identifier.AdvertisingIdClientクラスがインポートされていない
                                                logger.getLogger()
                                                        .error(
                                                                "Please import Google Play services"
                                                                        + " SDK.");
                                                completable.onComplete(Result.failure(e));
                                            } else {
                                                adRequest.adId = adIdProvider.adId();
                                                completable.onComplete(Result.success());
                                            }
                                        });
                            });
            seq.then(
                    (data, completable) -> {
                        deviceProvider.provideDevice(
                                deviceResult -> {
                                    adRequest.device = deviceResult.data;
                                    completable.onComplete(Result.success());
                                });
                    });
            seq.then(
                    (data, completable) -> {
                        appInfoProvider.provideAppInfo(
                                appInfoResult -> {
                                    adRequest.appInfo = appInfoResult.data;
                                    completable.onComplete(Result.success());
                                });
                    });
            seq.then(
                    (data, completable) -> {
                        if (geolocationProvider.isValidLocation()) {
                            adRequest.location = geolocationProvider.lastKnownLocation();
                        } else {
                            geolocationProvider.updateLocation();
                            if (geolocationProvider.isValidLocation()) {
                                adRequest.location = geolocationProvider.lastKnownLocation();
                            } else {
                                adRequest.location = Optional.empty();
                            }
                        }
                        completable.onComplete(Result.success());
                    });
            seq.then(
                    (data, completable) -> {
                        final Optional<Exception> error = validator.validate(adRequest);
                        error.ifPresentOrElse(
                                e -> completable.onComplete(Result.failure(e)),
                                () -> completable.onComplete(Result.success()));
                    });
            seq.then(
                    (data, completable) -> {
                        logger.getLogger().debug("Ad request parameter: " + adRequest);

                        final AdServerUrl server;
                        try {
                            server = new AdServerUrl(adRequest);
                            logger.getDevelopmentLogger().debug("Ad request URL: " + server.url);
                        } catch (AdServerUrl.CanNotInstantiateException e) {
                            completable.onComplete(Result.failure(e));
                            return;
                        }

                        final SSCoreHttpRequest request;
                        try {
                            request =
                                    new SSCoreHttpRequest.Builder(server.url)
                                            .withReadTimeout(
                                                    SSCoreHttpRequest.Timeout.inMilliseconds(
                                                            ADGConsts.TIMEOUT_INTERVAL))
                                            .build();
                        } catch (MalformedURLException
                                | SSCoreHttpRequest.InvalidRequestParameterException e) {
                            completable.onComplete(Result.failure(e));
                            return;
                        }

                        httpClient.request(
                                request,
                                response -> completable.onComplete(parseResponse(response)));
                    });
            seq.run(
                    result -> {
                        if (result.error.isPresent()) {
                            completion.onComplete(Result.failure(result.error.forced()));
                        } else if (result.data.isEmpty()) {
                            completion.onComplete(Result.failure(new Exception("No data")));
                        } else {
                            final Response response = (Response) result.data.forced();
                            completion.onComplete(Result.success(response));
                        }
                    });
        }

        @Override
        public void cancelRequest() {
            httpClient.cancel();
        }

        @NonNull
        private Result<Object, Throwable> parseResponse(
                @NonNull final Result<SSCoreHttpResponse, SSCoreHttpException> result) {
            if (result.error.isPresent()) {
                return Result.failure(result.error.forced());
            }

            if (result.data.isEmpty()) {
                return Result.failure(new Exception("No response data"));
            }

            final SSCoreHttpResponse response = result.data.forced();
            final Optional<JSONObject> jsonOpt = response.readJson();
            try {
                logger.getLogger().debug(jsonOpt.orElse(new JSONObject()).toString(2));
            } catch (JSONException ignored) {
            }

            if (jsonOpt.isEmpty()) {
                return Result.failure(new Exception("Invalid JSON"));
            }

            try {
                final Response resp = Response.fromJSON(jsonOpt);
                return Result.success(resp);
            } catch (Exception e) {
                return Result.failure(e);
            }
        }
    }

    private AdClient() {}

    /**
     * デフォルトのインスタンスを生成します
     *
     * @param logger ロガー
     * @param httpClient HTTPクライアント
     * @param geolocationProvider 位置情報プロバイダ
     * @param deviceProvider デバイス情報プロバイダ
     * @param appInfoProvider アプリ情報プロバイダ
     * @param adIdProvider 広告IDプロバイダ
     * @param validator バリデーション
     * @return 新しいインスタンス
     */
    @NonNull
    static IAdClient newClient(
            @NonNull final IADGLogger logger,
            @NonNull final SSCoreHttpClient httpClient,
            @NonNull final IGeolocationProvider geolocationProvider,
            @NonNull final SSCoreDeviceProvidable deviceProvider,
            @NonNull final SSCoreAppInfoProvidable appInfoProvider,
            @NonNull final SSCoreAdIdProvidable adIdProvider,
            @NonNull final AdRequestValidation validator) {
        return new Client(
                logger,
                httpClient,
                geolocationProvider,
                deviceProvider,
                appInfoProvider,
                adIdProvider,
                validator);
    }
}
