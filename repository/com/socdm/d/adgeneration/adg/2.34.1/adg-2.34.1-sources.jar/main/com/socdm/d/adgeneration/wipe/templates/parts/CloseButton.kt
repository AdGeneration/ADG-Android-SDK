package com.socdm.d.adgeneration.wipe.templates.parts

import android.annotation.SuppressLint
import android.content.Context
import android.view.ViewGroup
import android.widget.ImageView
import com.socdm.d.adgeneration.utils.AssetUtils
import com.socdm.d.adgeneration.utils.DisplayUtils

@SuppressLint("AppCompatCustomView")
@Deprecated("Wipe ad is deprecated.")
class CloseButton(context: Context) : ImageView(context) {
    init {
        val width = DisplayUtils.getPixels(context.resources, 20)
        val height = DisplayUtils.getPixels(context.resources, 20)
        this.layoutParams = ViewGroup.LayoutParams(width, height)
        AssetUtils.getBitmap(context, "adg_wipe_cb_40x40.png").let {
            this.setImageBitmap(it)
        }
    }
}
