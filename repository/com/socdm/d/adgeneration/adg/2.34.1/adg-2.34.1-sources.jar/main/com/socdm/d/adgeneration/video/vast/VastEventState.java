package com.socdm.d.adgeneration.video.vast;

public enum VastEventState {
    NONE,
    IMPRESSION,
    START,
    FIRST_QUARTILE,
    MIDPOINT,
    THIRD_QUARTILE,
    COMPLETE
}
