package com.socdm.d.adgeneration;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.type.Optional;

class ResponseInfoBuilder {
    @Nullable private String adId;
    @Nullable private String className;
    @Nullable private String creativeId;
    @Nullable private String adNetworkId;
    @Nullable private String dspId;
    @Nullable private String seat;

    public ResponseInfoBuilder() {}

    @NonNull
    public ResponseInfoBuilder withAdId(@Nullable String adId) {
        this.adId = adId;
        return this;
    }

    @NonNull
    public ResponseInfoBuilder withClassName(@Nullable String className) {
        this.className = className;
        return this;
    }

    @NonNull
    public ResponseInfoBuilder withCreativeId(@Nullable String creativeId) {
        this.creativeId = creativeId;
        return this;
    }

    @NonNull
    public ResponseInfoBuilder withAdNetworkId(@Nullable String adNetworkId) {
        this.adNetworkId = adNetworkId;
        return this;
    }

    @NonNull
    public ResponseInfoBuilder withDspId(@Nullable String dspId) {
        this.dspId = dspId;
        return this;
    }

    @NonNull
    public ResponseInfoBuilder withSeat(@Nullable String seat) {
        this.seat = seat;
        return this;
    }

    @NonNull
    public ADGResponseInfo build() {
        return new ADGResponseInfo(
                Optional.of(adId),
                Optional.of(className),
                Optional.of(creativeId),
                Optional.of(adNetworkId),
                Optional.of(dspId),
                Optional.of(seat));
    }
}
