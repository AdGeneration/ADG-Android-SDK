package com.socdm.d.adgeneration.viewable;

import androidx.annotation.Nullable;

/** Viewable計測インタフェースです */
public interface Viewable {
    /**
     * 計測を開始します
     *
     * @param listener 視認性に変更があったときに呼ばれるリスナー
     */
    void startMeasurement(@Nullable OnViewableChangeListener listener);

    /** 計測を終了します */
    void stopMeasurement();
}
