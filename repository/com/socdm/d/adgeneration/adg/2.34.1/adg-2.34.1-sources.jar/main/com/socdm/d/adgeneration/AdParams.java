package com.socdm.d.adgeneration;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

/** ADGインスタンス単位のパラメータ */
final class AdParams {
    /** 広告枠ID */
    @Nullable String locationId;

    boolean isMraidEnabled;
    /** Header biddingのためのパラメータ */
    @NonNull final HeaderBiddingParams headerBiddingParams = new HeaderBiddingParams();
    /** ラベルターゲティング */
    @NonNull final LabelTargeting labelTargeting = new LabelTargeting();

    int fillerLimit = 2;
    /** エラーになったレスポンスのscheduleId */
    @NonNull private final List<String> errorScheduleIds = new ArrayList<>();

    AdParams() {}

    /**
     * エラーになったレスポンスのscheduleIdを返します
     *
     * @return エラーになったレスポンスのscheduleId
     */
    @NonNull
    List<String> getErrorScheduleIds() {
        // ディープコピーを返す
        return new ArrayList<>(errorScheduleIds);
    }

    /**
     * エラーになったレスポンスのscheduleIdを記録します
     *
     * @param scheduleId エラーになったレスポンスのscheduleId
     */
    void addErrorScheduleId(@Nullable final String scheduleId) {
        if (!errorScheduleIds.contains(scheduleId) && !TextUtils.isEmpty(scheduleId)) {
            errorScheduleIds.add(scheduleId);
        }
    }

    /**
     * 記録されているエラーになったレスポンスのscheduleIdを削除するかどうかを判定します
     *
     * @return 削除する場合はtrue、それ以外はfalseを返します
     */
    boolean shouldClearErrorScheduleIds() {
        return fillerLimit < errorScheduleIds.size();
    }

    /** 記録されているエラーになったレスポンスのscheduleIdを削除します */
    void clearErrorScheduleIds() {
        errorScheduleIds.clear();
    }
}
