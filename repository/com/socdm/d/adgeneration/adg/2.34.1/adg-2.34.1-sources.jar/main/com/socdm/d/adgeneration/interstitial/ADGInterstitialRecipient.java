package com.socdm.d.adgeneration.interstitial;

import android.os.Handler;
import android.os.Looper;

import com.socdm.d.adgeneration.observer.ADGMessage;
import com.socdm.d.adgeneration.observer.ADGRecipient;
import com.socdm.d.adgeneration.utils.LogUtils;

// ADGInterstitialRecipient
@Deprecated
public class ADGInterstitialRecipient extends ADGRecipient {

    ADGInterstitial interstitial;
    Handler handler;

    private static final String TAG = "ADGInterstitial";

    public ADGInterstitialRecipient(ADGInterstitial interstitial) {
        super(TAG);
        this.interstitial = interstitial;
        this.handler = new Handler(Looper.myLooper());
    }

    private void showInterstitial() {
        interstitial.setReady(true);
        if (interstitial.isShow()) {
            // If show method was already invoked, Immediately run ShowRunnable.
            handler.post(new ADGInterstitial.ShowRunnable(interstitial));
        } else {
            LogUtils.d("Calling show method then window will be shown.");
        }
    }

    @Override
    public void onMessage(ADGMessage message) {
        String t = message.getType();
        Object m = message.getMessage();
        if (t.equals("AdViewType")) {
            if (m instanceof String) {
                String adViewType = (String) m;
                if (adViewType.equals("ADG")) {
                    LogUtils.d("AdViewType is ADG.");
                    showInterstitial();
                }
            }
        } else if (t.equals("ReceiveMediationType")) {
            if (m instanceof String) {
                String mediationType = (String) m;
                if (mediationType.equals("OriginInterstitial")) {
                    LogUtils.d("ReceiveMediationType is OriginInterstitial.");
                    showInterstitial();
                }
            }
        } else if (t.equals("FinishMediationType")) {
            if (m instanceof String) {
                String mediationType = (String) m;
                if (mediationType.equals("OriginInterstitial")) {
                    LogUtils.d("FinishMediationType is OriginInterstitial.");
                    interstitial.dismiss();
                }
            }
        }
    }
}
