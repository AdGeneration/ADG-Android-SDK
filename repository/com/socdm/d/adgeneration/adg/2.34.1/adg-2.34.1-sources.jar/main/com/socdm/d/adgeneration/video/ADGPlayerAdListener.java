package com.socdm.d.adgeneration.video;

public interface ADGPlayerAdListener {
    void onReadyToPlayAd();

    void onFailedToPlayAd(ADGPlayerError ADGPlayerError);

    void onStartVideo();

    void onClickAd();
}
