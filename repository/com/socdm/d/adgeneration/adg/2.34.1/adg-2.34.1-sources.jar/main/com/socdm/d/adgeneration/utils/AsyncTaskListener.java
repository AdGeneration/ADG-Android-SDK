package com.socdm.d.adgeneration.utils;

public interface AsyncTaskListener<Result> {
    public void onSuccess(Result result);

    public void onError(Exception e);
}
