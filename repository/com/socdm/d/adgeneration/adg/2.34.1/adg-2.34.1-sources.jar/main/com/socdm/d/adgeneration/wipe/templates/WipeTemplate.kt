package com.socdm.d.adgeneration.wipe.templates

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RelativeLayout
import androidx.annotation.RequiresApi
import com.socdm.d.adgeneration.ADGConsts.ADGWipeTheme
import com.socdm.d.adgeneration.utils.DisplayUtils
import com.socdm.d.adgeneration.utils.UIUtils
import com.socdm.d.adgeneration.wipe.templates.layout.ADGLayout
import com.socdm.d.adgeneration.wipe.templates.layout.AdvertisementBarLayout
import com.socdm.d.adgeneration.wipe.templates.layout.CloseButtonLayout
import com.socdm.d.adgeneration.wipe.templates.parts.AdvertisementBar
import com.socdm.d.adgeneration.wipe.templates.parts.CloseButton
import kotlin.math.ceil

@RequiresApi(Build.VERSION_CODES.LOLLIPOP)
@Deprecated("Wipe ad is deprecated.")
class WipeTemplate(context: Context?) : RelativeLayout(context) {
    private var container: ViewGroup? = null
        set(container) {
            removeAllViews()
            container?.let {
                this.addView(it)
            }
            field = container
        }
    var advertisementBarDrawable: GradientDrawable = GradientDrawable()
    var adgLayout: ADGLayout? = null
        private set
    var closeButton: CloseButton? = null
    var closeButtonLayout: CloseButtonLayout? = null
        private set
    var advertisementBar: AdvertisementBar? = null
    var advertisementBarLayout: AdvertisementBarLayout? = null
        private set
    var frameColor: Int = DEFAULT_THEME.frameColor
        set(value) {
            field = value
            advertisementBarDrawable.setColor(frameColor)
        }
    var frameTextColor: Int = DEFAULT_THEME.textColor
        set(value) {
            field = value
            advertisementBar?.setTextColor(value)
        }
    var frameAlpha: Int = 255
        set(value) {
            field = value
            advertisementBarDrawable.alpha = value
        }
    var frameText: String = "Advertisement"
        set(value) {
            field = value
            advertisementBar?.setFrameText(value)
        }
    var frameHidden: Boolean = false
        set(value) {
            field = value
            advertisementBar?.setFrameHidden(value)
        }
    var templateWidth = 0

    companion object {
        const val ADVERTISEMENT_BAR_HEIGHT = 25
        const val MARGIN_ADVERTISEMENT = 2

        val DEFAULT_THEME = ADGWipeTheme.LIGHT
        val WC = DisplayUtils.getWC()

        fun getTemplateHeight(width: Int): Int {
            return getVideoViewHeight(width) + ADVERTISEMENT_BAR_HEIGHT + MARGIN_ADVERTISEMENT
        }
        fun getTemplateWidth(height: Int): Int {
            return getVideoViewWidth(height) - ADVERTISEMENT_BAR_HEIGHT - MARGIN_ADVERTISEMENT
        }
        fun getVideoViewHeight(width: Int): Int {
            return ceil(width * 9.0 / 16.0).toInt()
        }
        fun getVideoViewWidth(height: Int): Int {
            return ceil(height * 16.0 / 9.0).toInt()
        }
    }

    fun createCloseButton() {
        closeButton = CloseButton(context)
        closeButtonLayout?.removeAllViews()
        closeButtonLayout?.addView(closeButton)
    }

    fun createCloseButton(listener: View.OnClickListener?) {
        closeButton = CloseButton(context).apply {
            setOnClickListener(listener)
        }
        closeButtonLayout?.removeAllViews()
        closeButtonLayout?.addView(closeButton)
    }

    fun createAdvertisementBar() {
        advertisementBar = AdvertisementBar(context, frameText, frameTextColor).apply {
            background = advertisementBarDrawable
            setFrameHidden(frameHidden)
        }
        advertisementBarLayout?.removeAllViews()
        advertisementBarLayout?.addView(advertisementBar)
    }

    // validations
    fun checkViews(): Boolean {
        val hasAdg = UIUtils.findViewsWithClass(this, ADGLayout::class.java).size == 1
        val hasButton = UIUtils.findViewsWithClass(this, CloseButtonLayout::class.java).size == 1
        return hasAdg && hasButton
    }

    fun refresh(width: Int) {
        templateWidth = width

        this.removeAllViews()
        this.adgLayout?.removeAllViews()
        this.closeButtonLayout?.removeAllViews()
        this.advertisementBarLayout?.removeAllViews()

        this.adgLayout = ADGLayout(context)
        this.closeButtonLayout = CloseButtonLayout(context)
        this.advertisementBarLayout = AdvertisementBarLayout(context)

        // templateView自体のサイズ
        val templateWidthPx = DisplayUtils.getPixels(resources, templateWidth)
        val templateHeightPx = DisplayUtils.getPixels(resources, getTemplateHeight(templateWidth))
        val advertisementBarHeight = DisplayUtils.getPixels(resources, ADVERTISEMENT_BAR_HEIGHT)
        val marginHeight = DisplayUtils.getPixels(resources, MARGIN_ADVERTISEMENT)
        val frame = LinearLayout(context)
        val advertisementFrame = RelativeLayout(context)
        val advertisementFrameParams = LayoutParams(templateWidthPx, advertisementBarHeight)
        advertisementFrameParams.setMargins(0, 0, 0, marginHeight)
        advertisementFrame.layoutParams = advertisementFrameParams
        advertisementFrame.addView(initAdvertisementBar())
        advertisementFrame.addView(initCloseButtonLayout())

        frame.orientation = LinearLayout.VERTICAL
        frame.layoutParams = LayoutParams(templateWidthPx, templateHeightPx)
        frame.addView(advertisementFrame)
        frame.addView(initAdgLayout())
        container = frame
    }

    // ADG自体の表示領域
    private fun initAdgLayout(): ADGLayout? {
        val layout = adgLayout
        layout?.gravity = Gravity.BOTTOM
        layout?.layoutParams = LayoutParams(
            DisplayUtils.getPixels(resources, templateWidth),
            DisplayUtils.getPixels(resources, getVideoViewHeight(templateWidth)),
        )
        return layout
    }

    private fun initAdvertisementBar(): AdvertisementBarLayout? {
        val layout = advertisementBarLayout
        val width = DisplayUtils.getPixels(context.resources, templateWidth)
        val height = DisplayUtils.getPixels(context.resources, ADVERTISEMENT_BAR_HEIGHT)
        val params = LayoutParams(width, height)
        params.addRule(ALIGN_PARENT_LEFT, TRUE)
        layout?.layoutParams = params
        layout?.gravity = Gravity.START
        return layout
    }

    private fun initCloseButtonLayout(): CloseButtonLayout? {
        val layout = closeButtonLayout
        val width = DisplayUtils.getPixels(context.resources, 20)
        val height = DisplayUtils.getPixels(context.resources, 20)
        val params = LayoutParams(width, height)
        params.rightMargin = DisplayUtils.getPixels(context.resources, 5)
        params.addRule(ALIGN_PARENT_RIGHT, TRUE)
        params.addRule(CENTER_VERTICAL)
        layout?.layoutParams = params
        return layout
    }

    init {
        this.layoutParams = LayoutParams(WC, WC)
        this.gravity = Gravity.CENTER

        // Drawable
        advertisementBarDrawable.shape = GradientDrawable.RECTANGLE
        advertisementBarDrawable.cornerRadius = 40.0f
        advertisementBarDrawable.setColor(frameColor)
    }
}
