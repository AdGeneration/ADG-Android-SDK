package com.socdm.d.adgeneration.mediation;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.AdBridgingObject;
import com.socdm.d.adgeneration.viewable.ViewableMeasurementInterval;
import com.socdm.d.adgeneration.viewable.ViewableParameter;

import java.util.List;

/** ネイティブメディエーション広告のモデルクラス AdBridgingObjectの薄いラッパーとして機能します */
public class ADGNativeMediationModel {

    @NonNull private final AdBridgingObject adObject;

    /**
     * コンストラクタ
     *
     * @param adObject 広告オブジェクト
     */
    public ADGNativeMediationModel(@NonNull final AdBridgingObject adObject) {
        this.adObject = adObject;
    }

    /**
     * 広告オブジェクトを取得します
     *
     * @return 広告オブジェクト
     */
    @NonNull
    AdBridgingObject getAdObject() {
        return adObject;
    }

    /**
     * インプレッショントラッカーを持っているか確認します
     *
     * @return インプレッショントラッカーがある場合true
     */
    public boolean hasImpressionTracker() {
        return adObject.hasImpressionTracker();
    }

    /**
     * Viewableパラメータのリストを取得します
     *
     * @return Viewableパラメータのリスト
     */
    @NonNull
    public List<ViewableParameter> getViewableParameters() {
        return adObject.getViewableParameters();
    }

    /**
     * Viewable計測間隔を取得します
     *
     * @return 計測間隔
     */
    @NonNull
    public ViewableMeasurementInterval getViewableMeasurementInterval() {
        return adObject.getViewableMeasurementInterval();
    }

    /**
     * インプレッションを送信します
     *
     * @param key 送信キー
     * @param progressListener プログレスリスナー
     */
    public void sendImpressions(
            @NonNull final String key,
            @Nullable final AdBridgingObject.OnProgressListener progressListener) {
        adObject.sendImpressions(key, progressListener);
    }

    /**
     * 全てのインプレッションが発火済みか確認します
     *
     * @return 全て発火済みの場合true
     */
    public boolean areAllImpressionsFired() {
        return adObject.areAllImpressionsFired();
    }
}
