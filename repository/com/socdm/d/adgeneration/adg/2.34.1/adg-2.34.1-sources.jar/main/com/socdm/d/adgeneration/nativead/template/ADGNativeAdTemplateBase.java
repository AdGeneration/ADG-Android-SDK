package com.socdm.d.adgeneration.nativead.template;

import android.annotation.TargetApi;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

import com.socdm.d.adgeneration.nativead.ADGNativeAd;

public abstract class ADGNativeAdTemplateBase extends RelativeLayout {
    public ADGNativeAdTemplateBase(Context context) {
        super(context);
    }

    public ADGNativeAdTemplateBase(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ADGNativeAdTemplateBase(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @TargetApi(21)
    public ADGNativeAdTemplateBase(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public abstract Boolean apply(ADGNativeAd nativeAd);

    public abstract void destroy();

    public abstract void finishViewability();

    public abstract void setListener(ADGNativeAdTemplateListener listener);
}
