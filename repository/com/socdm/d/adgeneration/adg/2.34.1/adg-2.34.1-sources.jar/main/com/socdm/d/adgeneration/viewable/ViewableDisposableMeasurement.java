package com.socdm.d.adgeneration.viewable;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.type.Optional;

/**
 * このクラスは、Viewable計測オブジェクトに"使い捨て機能"をラップし、一回限りのViewable計測を可能にします。
 * 一度、計測を終了すると再実行はできなくなります。再実行したいときは、インスタンスを生成し直してください
 */
public final class ViewableDisposableMeasurement implements Viewable {
    @NonNull private Optional<Viewable> viewable;
    private boolean isStarted = false;

    /**
     * 指定したViewable計測オブジェクトに"使い捨て機能"をラップしたインスタンスを生成します
     *
     * @param viewable Viewable計測オブジェクト
     */
    public ViewableDisposableMeasurement(@NonNull final Viewable viewable) {
        this.viewable = Optional.of(viewable);
    }

    @NonNull
    @Override
    public String toString() {
        return getClass().getSimpleName() + " { " + viewable + " }";
    }

    @Override
    public void startMeasurement(@Nullable final OnViewableChangeListener listener) {
        // 一回限りスタート可能
        if (isStarted) {
            return;
        }
        isStarted = true;

        viewable.ifPresent(
                v ->
                        v.startMeasurement(
                                (viewable, key) -> {
                                    if (listener != null) {
                                        listener.onViewableChanged(viewable, key);
                                    }
                                }));
    }

    @Override
    public void stopMeasurement() {
        // 一回限りの実行のため、停止後は内部オブジェクトを解放し、再実行できないようにする
        viewable.ifPresent(Viewable::stopMeasurement);
        viewable = Optional.empty();
    }
}
