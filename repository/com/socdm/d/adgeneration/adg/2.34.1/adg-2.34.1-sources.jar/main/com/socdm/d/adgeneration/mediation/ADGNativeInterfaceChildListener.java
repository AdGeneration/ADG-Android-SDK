package com.socdm.d.adgeneration.mediation;

abstract public class ADGNativeInterfaceChildListener {
    public void onReceiveAd() {
    }

    public void onReceiveAd(Object nativeAd) {
    }

    public void onFailedToReceiveAd() {
    }

    public void onCompleteMovieAd() {
    }

    public void onCloseInterstitial() {
    }

    public void onShowInterstitial() {
    }

    public void onClickAd() {
    }

    public void onReplayMovieAd() {
    }

    public void onReadyMediation(Object mediation) {
    }

    public void onSuccessfulBidder(String bidderSuccessfulName) {
    }
}
