package com.socdm.d.adgeneration.video.vast;

import com.socdm.d.adgeneration.utils.BeaconUtils;
import com.socdm.d.adgeneration.utils.TrackerUtils;

import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;

public class VASTIcon implements Serializable {
    private String program;
    private int height;
    private int width;
    private int xPosition;
    private int yPosition;
    private String apiFramework;
    private VASTResource staticResource;
    private String clickThroughURL;
    private ArrayList<String> clickTrackings = new ArrayList<>();

    public VASTIcon(String apiFramework) {
        this.apiFramework = apiFramework;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getXPosition() {
        return xPosition;
    }

    public void setXPosition(int xPosition) {
        this.xPosition = xPosition;
    }

    public int getYPosition() {
        return yPosition;
    }

    public void setYPosition(int yPosition) {
        this.yPosition = yPosition;
    }

    public void setStaticResource(VASTResource staticResource) {
        this.staticResource = staticResource;
    }

    public VASTResource getStaticResource() {
        return staticResource;
    }

    public String getClickThroughURL() {
        return clickThroughURL;
    }

    public void setClickThroughURL(String clickThroughURL) {
        this.clickThroughURL = clickThroughURL;
    }

    public ArrayList<String> getIconClickTrackings() {
        return clickTrackings;
    }

    public void setIconClickTrackings(ArrayList<String> list) {
        this.clickTrackings = list;
    }

    public boolean isAdg() {
        return apiFramework.equals("adg");
    }

    public void sendIconClickTracking() {
        if (clickTrackings != null) {
            TrackerUtils.callTracker(this.clickTrackings);
        }
    }
}
