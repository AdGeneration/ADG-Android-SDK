package com.socdm.d.adgeneration.mraid;

import android.content.Context;
import android.graphics.Rect;
import androidx.annotation.NonNull;

import com.socdm.d.adgeneration.utils.DisplayUtils;

public class MRAIDScreenMetrics {
    @NonNull private final Context mContext;
    @NonNull private final Rect mScreenRect;
    @NonNull private final Rect mScreenRectDips;
    @NonNull private final Rect mRootViewRect;
    @NonNull private final Rect mRootViewRectDips;
    @NonNull private final Rect mCurrentAdRect;
    @NonNull private final Rect mCurrentAdRectDips;
    @NonNull private final Rect mDefaultAdRect;
    @NonNull private final Rect mDefaultAdRectDips;

    MRAIDScreenMetrics(Context context) {
        mContext = context.getApplicationContext();
        mScreenRect = new Rect();
        mScreenRectDips = new Rect();
        mRootViewRect = new Rect();
        mRootViewRectDips = new Rect();
        mCurrentAdRect = new Rect();
        mCurrentAdRectDips = new Rect();
        mDefaultAdRect = new Rect();
        mDefaultAdRectDips = new Rect();
    }

    private Rect convertToDips(Rect sourceRect) {
        return new Rect(
                DisplayUtils.getDip(mContext.getResources(), sourceRect.left),
                DisplayUtils.getDip(mContext.getResources(), sourceRect.top),
                DisplayUtils.getDip(mContext.getResources(), sourceRect.right),
                DisplayUtils.getDip(mContext.getResources(), sourceRect.bottom)
        );
    }

    void setScreenSize(int width, int height) {
        mScreenRect.set(0, 0, width, height);
        mScreenRectDips.set(convertToDips(mScreenRect));
    }

    @NonNull
    Rect getScreenRect() {
        return mScreenRect;
    }

    @NonNull
    Rect getScreenRectDips() {
        return mScreenRectDips;
    }

    void setRootViewPosition(int x, int y, int width, int height) {
        mRootViewRect.set(x, y, x + width, y + height);
        mRootViewRectDips.set(convertToDips(mRootViewRect));
    }

    @NonNull
    Rect getRootViewRect() {
        return mRootViewRect;
    }

    @NonNull
    Rect getRootViewRectDips() {
        return mRootViewRectDips;
    }

    void setCurrentAdPosition(int x, int y, int width, int height) {
        mCurrentAdRect.set(x, y, x + width, y + height);
        mCurrentAdRectDips.set(convertToDips(mCurrentAdRect));
    }

    @NonNull
    Rect getCurrentAdRect() {
        return mCurrentAdRect;
    }

    @NonNull
    Rect getCurrentAdRectDips() {
        return mCurrentAdRectDips;
    }

    void setDefaultAdPosition(int x, int y, int width, int height) {
        mDefaultAdRect.set(x, y, x + width, y + height);
        mDefaultAdRectDips.set(convertToDips(mDefaultAdRect));
    }

    @NonNull
    Rect getDefaultAdRect() {
        return mDefaultAdRect;
    }

    @NonNull
    Rect getDefaultAdRectDips() {
        return mDefaultAdRectDips;
    }
}
