package com.socdm.d.adgeneration.viewable;

import androidx.annotation.NonNull;

import java.util.UUID;

/** UUIDを使用してキーを生成するデフォルトのKeyProvider実装 */
public class UuidKeyProvider implements KeyProvider {

    /** デフォルトインスタンス */
    public static final UuidKeyProvider INSTANCE = new UuidKeyProvider();

    @NonNull
    @Override
    public String generateKey() {
        return UUID.randomUUID().toString();
    }
}
