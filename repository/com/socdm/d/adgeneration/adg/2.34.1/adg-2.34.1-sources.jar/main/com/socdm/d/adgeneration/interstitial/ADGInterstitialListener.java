package com.socdm.d.adgeneration.interstitial;

import com.socdm.d.adgeneration.ADGListener;

@Deprecated
public abstract class ADGInterstitialListener extends ADGListener {
    public abstract void onCloseInterstitial();
}
