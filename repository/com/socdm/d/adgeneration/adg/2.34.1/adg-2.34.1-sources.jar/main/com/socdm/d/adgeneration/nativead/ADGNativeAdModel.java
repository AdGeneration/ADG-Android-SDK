package com.socdm.d.adgeneration.nativead;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.AdBridgingObject;
import com.socdm.d.adgeneration.adresponse.Native;
import com.socdm.d.adgeneration.viewable.ViewableMeasurementInterval;
import com.socdm.d.adgeneration.viewable.ViewableParameter;

import jp.supership.sscore.type.Optional;

import java.util.ArrayList;
import java.util.List;

public class ADGNativeAdModel {

    /** AdBridgingObjectのインスタンス */
    @NonNull private final AdBridgingObject adObject;

    /** アセット配列 */
    @NonNull final List<ADGNativeAsset> assets;

    /** JSトラッカー */
    @NonNull final Optional<String> jsTracker;
    /** イベントトラッカー */
    @NonNull final List<Object> eventTrackers;

    /** リンク情報 */
    @NonNull final Optional<ADGLink> link;
    /** バージョン */
    final int ver;
    /** 拡張情報 */
    @NonNull final Optional<Object> ext;

    /**
     * オブジェクトを生成します。 必須のデータが不足している場合はOptional.empty()を返します。
     *
     * @param adObject 広告データを持つブリッジオブジェクト
     * @return ADGNativeAdModelのインスタンス(Optional)
     */
    @NonNull
    public static Optional<ADGNativeAdModel> create(@Nullable AdBridgingObject adObject) {
        if (adObject == null || adObject.getNativeAd().isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(new ADGNativeAdModel(adObject));
    }

    private ADGNativeAdModel(@NonNull AdBridgingObject adObject) {

        this.adObject = adObject;

        Optional<Native> nativeAdOrNull = adObject.getNativeAd();
        if (nativeAdOrNull.isEmpty()) {
            // ファクトリメソッド内で、処理が呼ばれる前にチェックされるため、ここに到達することはありません。
            throw new IllegalArgumentException("Native ad data is missing");
        }
        Native nativeAd = nativeAdOrNull.forced();

        // Native.AssetからADGNativeAssetへの変換
        this.assets = new ArrayList<>();
        for (Native.Asset nativeAsset : nativeAd.getAssets()) {
            ADGNativeAsset convertedAsset = ADGNativeAsset.from(nativeAsset);
            this.assets.add(convertedAsset);
        }

        this.jsTracker = nativeAd.jsTracker;

        this.eventTrackers = nativeAd.getEventTrackers();
        // Native.LinkからADGNativeLinkへの変換
        this.link = nativeAd.link.map(ADGLink::new);

        this.ver = nativeAd.ver;

        this.ext = nativeAd.ext;
    }

    @NonNull
    public AdBridgingObject getAdObject() {
        return adObject;
    }

    @NonNull
    public List<ADGNativeAsset> getAssets() {
        return assets;
    }

    @NonNull
    public Optional<String> getJsTracker() {
        return jsTracker;
    }

    @NonNull
    public List<Object> getEventTrackers() {
        return eventTrackers;
    }

    @NonNull
    public Optional<ADGLink> getLink() {
        return link;
    }

    public int getVer() {
        return ver;
    }

    @NonNull
    public Optional<Object> getExt() {
        return ext;
    }

    // --- メソッド ---

    /**
     * 指定された条件を満たした場合にトラッキングイベントを送信します。 実際の処理はadObjectに委譲します。
     *
     * @param key 識別キー
     * @param progress 各トラッキングURLの送信結果を受け取るコールバック
     */
    public void sendImpressions(
            @NonNull String key, @Nullable AdBridgingObject.OnProgressListener progress) {
        adObject.sendImpressions(key, progress);
    }

    /**
     * すべてのインプレッションイベントが発火したかどうかを確認します。 実際の処理はadObjectに委譲します。
     *
     * @return すべて発火済みならtrue
     */
    public boolean areAllImpressionsFired() {
        return adObject.areAllImpressionsFired();
    }

    /**
     * Viewableパラメータを取得します
     *
     * @return Viewableパラメータのリスト
     */
    @NonNull
    public List<ViewableParameter> getViewableParameters() {
        return adObject.getViewableParameters();
    }

    /**
     * Viewable計測間隔を取得します
     *
     * @return 計測間隔（ミリ秒）
     */
    @NonNull
    public ViewableMeasurementInterval getViewableMeasurementInterval() {
        // デフォルトは1000ms
        return adObject.getViewableMeasurementInterval();
    }

    // --- Inner Classes ---

    /** ネイティブ広告のアセット情報を表すクラス */
    public static class ADGNativeAsset {

        // Swiftのenum AssetIDをJavaのenumで表現します。
        public enum AssetID {
            // 各enum定数に、SwiftのrawValueに相当する値を渡します。
            TITLE(1),
            MAIN_IMAGE(2),
            ICON_IMAGE(3),
            SPONSORED(4),
            DESC(5),
            CTA_TEXT(6),
            VIDEO(7),
            ACCOMPANYING_TEXT(501),
            OPT_OUT_URL(502),
            ICON_URL(503),
            UNKNOWN(-1); // 未知のAssetIDを表す

            private final int id;

            // enumのコンストラクタで値を受け取ります。
            AssetID(int id) {
                this.id = id;
            }

            // 値を取得するためのメソッドです。
            public int getId() {
                return id;
            }
        }

        /** アセットID */
        @NonNull final AssetID id;

        /** タイトル情報 */
        @NonNull final Optional<ADGTitle> title;

        /** 画像情報 */
        @NonNull final Optional<ADGImage> image;

        /** データ情報 */
        @NonNull final Optional<ADGData> data;

        /** 動画情報 */
        @NonNull final Optional<ADGVideo> video;

        private ADGNativeAsset(
                @NonNull AssetID id,
                @NonNull Optional<ADGTitle> title,
                @NonNull Optional<ADGImage> image,
                @NonNull Optional<ADGData> data,
                @NonNull Optional<ADGVideo> video) {
            this.id = id;
            this.title = title;
            this.image = image;
            this.data = data;
            this.video = video;
        }

        /**
         * Native.AssetからADGNativeAssetに変換するファクトリメソッド
         *
         * @param asset 変換元のNative.Asset
         * @return 変換されたADGNativeAsset（AssetIDが不明な場合はUNKNOWNを設定）
         */
        @NonNull
        static ADGNativeAsset from(@NonNull Native.Asset asset) {
            // AssetIDの変換 - 見つからない場合はUNKNOWNを設定
            AssetID assetId = AssetID.UNKNOWN; // デフォルト値を未知のIDに変更
            for (AssetID id : AssetID.values()) {
                if (id != AssetID.UNKNOWN && id.getId() == asset.id.value) {
                    assetId = id;
                    break;
                }
            }

            // 各アセットタイプに応じて変換
            Optional<ADGTitle> title = asset.title.map(ADGTitle::new);
            Optional<ADGImage> image = asset.image.map(ADGImage::new);
            Optional<ADGData> data = asset.data.map(ADGData::new);
            Optional<ADGVideo> video = asset.video.map(ADGVideo::new);

            return new ADGNativeAsset(assetId, title, image, data, video);
        }
    }
}
