package com.socdm.d.adgeneration.mediation;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.socdm.d.adgeneration.ADGLogger;
import com.socdm.d.adgeneration.IADGLogger;
import com.socdm.d.adgeneration.impression.ImpressionTracker;
import com.socdm.d.adgeneration.viewable.Viewable;
import com.socdm.d.adgeneration.viewable.ViewableDisposableMeasurement;
import com.socdm.d.adgeneration.viewable.ViewableObstacleMeasurement;
import com.socdm.d.adgeneration.viewable.ViewableParameter;
import com.socdm.d.adgeneration.viewable.ViewableParameters;

import jp.supership.sscore.type.Optional;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/** ネイティブメディエーション広告のコントローラークラス Viewable計測とインプレッション管理を担当します */
public class ADGNativeMediationController {

    /** インプレッションイベントのデリゲート */
    public interface OnImpressionListener {
        /** インプレッション条件を満たしたときに呼ばれます */
        void onNativeMediationImpression();
    }

    @NonNull private final ADGNativeMediationModel model;
    @Nullable private WeakReference<View> viewRef;
    @Nullable private OnImpressionListener impressionDelegate;
    @NonNull private final IADGLogger logger;

    @VisibleForTesting @NonNull Optional<Viewable> viewableMeasurement = Optional.empty();

    /**
     * コンストラクタ
     *
     * @param model データモデル
     * @param view 広告View
     * @param impressionDelegate インプレッションデリゲート
     */
    public ADGNativeMediationController(
            @NonNull final ADGNativeMediationModel model,
            @Nullable final View view,
            @Nullable final OnImpressionListener impressionDelegate) {
        this(model, view, impressionDelegate, ADGLogger.getInstance());
    }

    /**
     * テスト用コンストラクタ
     *
     * @param model データモデル
     * @param view 広告View
     * @param impressionDelegate インプレッションデリゲート
     * @param logger ロガー
     */
    @VisibleForTesting
    ADGNativeMediationController(
            @NonNull final ADGNativeMediationModel model,
            @Nullable final View view,
            @Nullable final OnImpressionListener impressionDelegate,
            @NonNull final IADGLogger logger) {

        this.model = model;
        this.viewRef = view != null ? new WeakReference<>(view) : null;
        this.impressionDelegate = impressionDelegate;
        this.logger = logger;
    }

    /** Viewable計測を開始します */
    public void startViewableMeasurement() {
        final View view = viewRef != null ? viewRef.get() : null;
        if (view == null) {
            logger.getLogger().error("View is null. Cannot start viewable measurement.");
            return;
        }

        // 既存の計測を終了
        finishViewableMeasurement();

        logger.getLogger().debug("Start native mediation viewable measurement.");

        // Viewableパラメータを設定
        final Viewable viewable = getViewable(view);

        viewableMeasurement = Optional.of(viewable);
        viewable.startMeasurement(this::handleViewableChanged);
    }

    @NonNull
    private Viewable getViewable(View view) {
        final List<ViewableParameter> parameters = new ArrayList<>(model.getViewableParameters());
        final ViewableParameters viewableParameters =
                new ViewableParameters(model.getViewableMeasurementInterval(), parameters);

        // Viewable計測を開始
        return new ViewableDisposableMeasurement(
                new ViewableObstacleMeasurement(
                        "NativeMediation", view.getContext(), view, viewableParameters, logger));
    }

    /** Viewable計測を終了します */
    public void finishViewableMeasurement() {
        if (viewableMeasurement.isEmpty()) {
            return;
        }

        logger.getLogger().debug("Finish native mediation viewable measurement.");
        viewableMeasurement.ifPresent(Viewable::stopMeasurement);
        viewableMeasurement = Optional.empty();
    }

    /**
     * Viewable状態変更を処理します
     *
     * @param isViewable ビュー可能かどうか
     * @param key 表示割合
     */
    @VisibleForTesting
    void handleViewableChanged(final boolean isViewable, final String key) {
        if (isViewable) {
            logger.getLogger().debug("Send " + key + " impressions for native mediation.");

            model.sendImpressions(
                    key,
                    (url, error) -> {
                        if (error.isPresent()) {
                            logger.getLogger()
                                    .error(
                                            String.format(
                                                    "Failed to send native mediation impression: %s"
                                                            + " %s %s",
                                                    key, url, error.forced()));
                        } else {
                            logger.getLogger()
                                    .error(
                                            String.format(
                                                    "Native mediation impression succeeded:: %s %s",
                                                    key, url));
                        }
                    });

            // 全インプレッション発火済みなら計測終了
            if (model.areAllImpressionsFired()) {
                finishViewableMeasurement();
            }

            // インプレッション条件を満たした場合の通知
            if (ImpressionTracker.IMP_CONDITION_DATA_KEY.equals(key)) {
                if (impressionDelegate != null) {
                    impressionDelegate.onNativeMediationImpression();
                }
            }
        }
    }

    /** リソースをクリーンアップします */
    public void destroy() {
        finishViewableMeasurement();
        viewRef = null;
        impressionDelegate = null;
    }
}
