package com.socdm.d.adgeneration;

import androidx.annotation.NonNull;

import jp.supership.sscore.logger.SSCoreLogger;

public interface IADGLogger {
    /**
     * ADG SDKのロガーを取得します。
     *
     * @return ADG SDKのロガー
     */
    @NonNull
    SSCoreLogger getLogger();
    /**
     * 開発用のロガーを取得します。このロガーは社外に公開しないログ出力に使用します。
     *
     * @return 開発用のロガー
     */
    @NonNull
    SSCoreLogger getDevelopmentLogger();
}
