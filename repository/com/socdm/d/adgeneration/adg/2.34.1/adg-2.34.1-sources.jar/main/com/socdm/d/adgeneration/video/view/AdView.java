package com.socdm.d.adgeneration.video.view;

import android.content.Context;
import android.graphics.Color;
import android.util.AndroidRuntimeException;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.ADGPlayerError;
import com.socdm.d.adgeneration.video.config.AdConfiguration;
import com.socdm.d.adgeneration.video.config.Const;
import com.socdm.d.adgeneration.video.utils.Dips;
import com.socdm.d.adgeneration.video.utils.Views;

import java.io.IOException;

public class AdView extends FrameLayout implements VastPlayer.VastMediaEventListener {
    /** AdViewのインスタンスを生成できない場合にスローされる例外です */
    public static final class CannotInstantiateException extends Exception {
        @NonNull public final ADGPlayerError error;

        public CannotInstantiateException(@NonNull final ADGPlayerError error) {
            this.error = error;
        }
    }

    /** AdViewからの各種イベントを受け取るリスナーインターフェースです */
    public interface EventListener {
        /** 動画の再生が開始された時に呼ばれます */
        void onAdViewStartVideo();

        /**
         * 広告の再生に失敗した時に呼ばれます
         *
         * @param error エラー情報
         */
        void onAdViewFailedToPlay(@NonNull ADGPlayerError error);

        /** 広告がクリックされた時に呼ばれます */
        void onAdViewClick();

        /** 広告がクリックスルーされた時に呼ばれます */
        void onAdViewClickThrough();

        /** 広告ビューがウィンドウから削除された時に呼ばれます */
        void onAdViewDetachedFromWindow();
    }

    @NonNull private final Context mContext;
    @NonNull final EventListener listener;
    @Nullable private AdConfiguration mAdConfiguration;
    @Nullable private VastPlayer mVastPlayer;
    @Nullable private LinearLayout mEndCreditLayout;
    @Nullable private ImageView mLinkButton;
    @Nullable private ImageView mReplayButton;
    @NonNull private final FrameLayout mSoundButtonLayout;
    @NonNull private final ImageView mSoundOnButton;
    @NonNull private final ImageView mSoundOffButton;
    @Nullable private LinearLayout mPauseLayoutWhenOutView;
    @Nullable private ImageView mPlayIcon;
    private boolean isCompleted;
    private final boolean isTiny;
    private final boolean isNativeOptout;

    public AdView(
            @NonNull final Context context,
            @NonNull final EventListener listener,
            final boolean isTiny,
            final boolean isWipe,
            final boolean isNativeOptout)
            throws CannotInstantiateException {
        super(context);
        mContext = context;
        this.listener = listener;
        this.isTiny = isTiny;
        this.isNativeOptout = isNativeOptout;

        setBackgroundColor(Color.TRANSPARENT);
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        LayoutParams params =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.CENTER;
        setLayoutParams(params);

        mVastPlayer = new VastPlayer(mContext, isWipe);
        mVastPlayer.setVastMediaEventListener(this);
        mVastPlayer.setOnClickListener(new OnClickAdListener());
        mVastPlayer.setBackgroundColor(Color.TRANSPARENT);
        mVastPlayer.setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        LayoutParams vpParams =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        vpParams.gravity = Gravity.CENTER;
        mVastPlayer.setLayoutParams(vpParams);
        addView(mVastPlayer);
        mSoundButtonLayout = new FrameLayout(mContext);
        LayoutParams sblp =
                new LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sblp.gravity = Gravity.START | Gravity.BOTTOM;
        mSoundButtonLayout.setLayoutParams(sblp);
        mSoundButtonLayout.setBackgroundColor(Color.TRANSPARENT);
        addView(mSoundButtonLayout);

        mSoundOffButton = new ImageView(mContext);
        mSoundOffButton.setAdjustViewBounds(true);
        mSoundOffButton.setOnClickListener(new OnSoundOffListener());
        mSoundOffButton.setBackgroundColor(Color.TRANSPARENT);
        mSoundOffButton.setVisibility(INVISIBLE);
        mSoundButtonLayout.addView(mSoundOffButton);

        mSoundOnButton = new ImageView(mContext);
        mSoundOnButton.setAdjustViewBounds(true);
        mSoundOnButton.setOnClickListener(new OnSoundOnListener());
        mSoundOnButton.setBackgroundColor(Color.TRANSPARENT);
        mSoundOnButton.setVisibility(INVISIBLE);
        mSoundButtonLayout.addView(mSoundOnButton);

        if (!isTiny) {
            mEndCreditLayout = new LinearLayout(mContext);
            mEndCreditLayout.setBackgroundColor(Color.argb(80, 0, 0, 0));
            LayoutParams ecwParams =
                    new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
            mEndCreditLayout.setLayoutParams(ecwParams);
            mEndCreditLayout.setOrientation(LinearLayout.HORIZONTAL);
            mEndCreditLayout.setGravity(Gravity.CENTER);
            addView(mEndCreditLayout);

            mReplayButton = new ImageView(mContext);
            mReplayButton.setOnClickListener(new OnReplayListener());
            mReplayButton.setBackgroundColor(Color.TRANSPARENT);
            mEndCreditLayout.addView(mReplayButton);

            mLinkButton = new ImageView(mContext);
            mLinkButton.setOnClickListener(new OnClickThroughAdListener());
            mLinkButton.setBackgroundColor(Color.TRANSPARENT);
            mEndCreditLayout.addView(mLinkButton);

            mPauseLayoutWhenOutView = new LinearLayout(mContext);
            mPauseLayoutWhenOutView.setBackgroundColor(Color.argb(80, 0, 0, 0));
            mPauseLayoutWhenOutView.setLayoutParams(ecwParams);
            mPauseLayoutWhenOutView.setOrientation(LinearLayout.HORIZONTAL);
            mPauseLayoutWhenOutView.setGravity(Gravity.CENTER);
            mPauseLayoutWhenOutView.setVisibility(INVISIBLE);
            addView(mPauseLayoutWhenOutView);

            mPlayIcon = new ImageView(mContext);
            mPlayIcon.setBackgroundColor(Color.TRANSPARENT);
            mPauseLayoutWhenOutView.addView(mPlayIcon);
        }

        try {
            Views.setImageFromAssets(mContext, mSoundOffButton, Const.UI_SOUND_OFF_BUTTON_URL);
            Views.setImageFromAssets(mContext, mSoundOnButton, Const.UI_SOUND_ON_BUTTON_URL);

            if (!isTiny) {
                Views.setImageFromAssets(
                        mContext, mReplayButton, Const.UI_INLINE_REPLAY_BUTTON_URL);
                Views.setImageFromAssets(mContext, mLinkButton, Const.UI_INLINE_LINK_BUTTON_URL);
                Views.setImageFromAssets(mContext, mPlayIcon, Const.UI_VIDEO_ICON_PLAY_URL);
            }
        } catch (Exception e) {
            throw new CannotInstantiateException(ADGPlayerError.UNSPECIFIED);
        }
    }

    public AdView(Context context) {
        super(context);
        throw new AndroidRuntimeException("Default constructor cannot use.");
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        listener.onAdViewDetachedFromWindow();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int soundButtonSize = (int) (MeasureSpec.getSize(widthMeasureSpec) * 0.128);

        int endcreditButtonWidth = (int) (MeasureSpec.getSize(widthMeasureSpec) * 0.285);
        int endcreditButtonHeight = (int) (endcreditButtonWidth / 1.3125);

        if (isTiny) {
            mSoundOffButton.setLayoutParams(
                    new LayoutParams(soundButtonSize * 2, soundButtonSize * 2));
            mSoundOnButton.setLayoutParams(
                    new LayoutParams(soundButtonSize * 2, soundButtonSize * 2));
        } else {
            mSoundOffButton.setLayoutParams(new LayoutParams(soundButtonSize, soundButtonSize));
            mSoundOnButton.setLayoutParams(new LayoutParams(soundButtonSize, soundButtonSize));

            LinearLayout.LayoutParams rbParams =
                    new LinearLayout.LayoutParams(endcreditButtonWidth, endcreditButtonHeight);
            rbParams.rightMargin = (int) Dips.dipsToFloatPixels(20, mContext);
            mReplayButton.setLayoutParams(rbParams);

            LinearLayout.LayoutParams lbParams =
                    new LinearLayout.LayoutParams(endcreditButtonWidth, endcreditButtonHeight);
            mLinkButton.setLayoutParams(lbParams);
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    /** Getter, Setter */
    public VastPlayer getVastPlayer() {
        return mVastPlayer;
    }

    /** Ad control */
    public void startAd(@Nullable final AdConfiguration config) {
        LogUtils.d(this + ": startAd");

        if (config == null) {
            return;
        }

        hideEndCredits();
        mAdConfiguration = config;
        if (mVastPlayer != null) {
            mVastPlayer.setVastAdThenLoadVideo(mAdConfiguration.getVastAd(), this.isNativeOptout);
        }
    }

    public void resume(@NonNull final AdConfiguration config) {
        if (mVastPlayer != null && mVastPlayer.isViewable()) {
            mAdConfiguration = config;
            mVastPlayer.setVastAd(mAdConfiguration.getVastAd());
            mVastPlayer.play();
        }
    }

    public void pause() {
        if (mVastPlayer != null) {
            mVastPlayer.pause();
        }
    }

    public void release() {
        Views.removeFromParent(this);
        removeAllViews();
        reset();
    }

    public void reset() {
        if (mVastPlayer != null) {
            mVastPlayer.releaseVastPlayer();
        }

        mVastPlayer = null;
        mAdConfiguration = null;
    }

    /** Video control */
    private void unmute() {
        if (mVastPlayer != null) {
            mSoundOnButton.setVisibility(INVISIBLE);
            mSoundOffButton.setVisibility(VISIBLE);
            mVastPlayer.unmute();
        }
    }

    private void mute() {
        if (mVastPlayer != null) {
            mSoundOnButton.setVisibility(VISIBLE);
            mSoundOffButton.setVisibility(INVISIBLE);
            mVastPlayer.mute();
        }
    }

    private void replay() {
        if (mVastPlayer != null && mVastPlayer.isInPlaybackState()) {
            mVastPlayer.replay();
            hideEndCredits();
        }
    }

    /** Video Events */
    @Override
    public void onStartVideo() {
        listener.onAdViewStartVideo();
    }

    @Override
    public void onPrepared(VideoView videoView) {
        /*
         * 動画準備完了したら背景色を黒にする。
         * ADGMediaViewの大きさはアプリ任意なので、横幅が動作サイズより大きい場合、
         * 音声ボタンが動画領域より外に出るので、黒背景にする。
         * 動画の準備が出来てから動画領域のサイズが決定するため、それまでAdViewは親のView領域と同サイズになっている。
         * 初期値で設定してしまうと、領域全体が黒背景になってしまうので、このタイミングで設定している。
         */
        setBackgroundColor(Color.BLACK);

        if (mAdConfiguration != null && mAdConfiguration.isSoundEnabled()) {
            unmute();
        } else {
            mute();
        }
    }

    @Override
    public void onPlaying(VideoView videoView) {}

    @Override
    public void onCompletion(VideoView videoView) {
        showEndCredits();
    }

    @Override
    public void onError(ADGPlayerError error) {
        reset();
        listener.onAdViewFailedToPlay(error == null ? ADGPlayerError.UNSPECIFIED : error);
    }

    @Override
    public void onChangeAudioVolume(boolean isOn, VideoView videoView) {
        if (isOn) {
            mSoundOnButton.setVisibility(INVISIBLE);
            mSoundOffButton.setVisibility(VISIBLE);
        } else {
            mSoundOnButton.setVisibility(VISIBLE);
            mSoundOffButton.setVisibility(INVISIBLE);
        }
    }

    public boolean getCompleted() {
        return this.isCompleted;
    }

    private void showEndCredits() {
        isCompleted = true;
        if (!isTiny && mEndCreditLayout != null) {
            mEndCreditLayout.setVisibility(VISIBLE);
            mSoundButtonLayout.setVisibility(INVISIBLE);
        }
    }

    private void hideEndCredits() {
        isCompleted = false;
        if (!isTiny && mEndCreditLayout != null) {
            mEndCreditLayout.setVisibility(INVISIBLE);
            mSoundButtonLayout.setVisibility(VISIBLE);
        }
    }

    public void callWhenInView() {
        if (mVastPlayer == null) {
            return;
        }

        mVastPlayer.callWhenInView();

        if (mVastPlayer.isInPlaybackState()
                && !isTiny
                && !isCompleted
                && mPauseLayoutWhenOutView != null) {
            mPauseLayoutWhenOutView.setVisibility(INVISIBLE);
        }
    }

    public void callWhenOutOfView() {
        if (mVastPlayer == null) {
            return;
        }

        mVastPlayer.callWhenOutView();

        if (!isTiny && !isCompleted && mPauseLayoutWhenOutView != null) {
            mPauseLayoutWhenOutView.setVisibility(VISIBLE);
        }
    }

    private class OnClickAdListener implements OnClickListener {
        @Override
        public void onClick(View view) {
            LogUtils.d(this + ": onClick");
            listener.onAdViewClick();
        }
    }

    private class OnClickThroughAdListener implements OnClickListener {
        @Override
        public void onClick(View view) {
            LogUtils.d(this + ": onClick");
            listener.onAdViewClickThrough();
        }
    }

    private class OnReplayListener implements OnClickListener {
        @Override
        public void onClick(View view) {
            replay();
        }
    }

    private class OnSoundOnListener implements OnClickListener {
        @Override
        public void onClick(View view) {
            unmute();
        }
    }

    private class OnSoundOffListener implements OnClickListener {
        @Override
        public void onClick(View view) {
            mute();
        }
    }
}
