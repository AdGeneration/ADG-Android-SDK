package com.socdm.d.adgeneration.mraid;

import android.graphics.Rect;
import androidx.annotation.NonNull;
import android.webkit.WebView;

import com.socdm.d.adgeneration.utils.LogUtils;

import org.json.JSONObject;

public class MRAIDBridge {

    static void setCurrentPosition(WebView webView, Rect rect) {
        String js = "mraidbridge.setCurrentPosition("
                + stringifyRect(rect)
                + ");";
        injectJavaScript(webView, js);
    }

    static void setDefaultPosition(WebView webView, Rect rect) {
        String js = "mraidbridge.setDefaultPosition("
                + stringifyRect(rect)
                + ");";
        injectJavaScript(webView, js);
    }

    static void setMaxSize(WebView webView, Rect rect) {
        String js = "mraidbridge.setMaxSize("
                + stringifySize(rect)
                + ");";
        injectJavaScript(webView, js);
    }

    static void setScreenSize(WebView webView, Rect rect) {
        String js = "mraidbridge.setScreenSize("
                + stringifySize(rect)
                + ");";
        injectJavaScript(webView, js);
    }

    static void setPlacementType(WebView webView, MRAIDPlacementType placementTyp) {
        String js = "mraidbridge.setPlacementType("
                + JSONObject.quote(placementTyp.toJavascriptString())
                + ");";
        injectJavaScript(webView, js);
    }

    static void setState(WebView webView, MRAIDState state) {
        String js = "mraidbridge.setState("
                + JSONObject.quote(state.toJavascriptString())
                + ");";
        injectJavaScript(webView, js);
    }

    static void setIsViewable(WebView webView, boolean isViewable) {
        String js = "mraidbridge.setIsViewable("
                + stringifyBool(isViewable)
                + ");";
        injectJavaScript(webView, js);
    }

    static void notifyReadyEvent(WebView webView) {
        injectJavaScript(webView, "mraidbridge.notifyReadyEvent();");
    }

    static void notifyErrorEvent(WebView webView, String message, MRAIDCommand command) {
        String js = "mraidbridge.notifyErrorEvent("
                + JSONObject.quote(message)
                + ","
                + JSONObject.quote(command.toJavascriptString())
                + ");";
        injectJavaScript(webView, js);
    }

    static void nativeCallComplete(WebView webView, MRAIDCommand command) {
        String js = "mraidbridge.nativeCallComplete("
                + JSONObject.quote(command.toJavascriptString())
                + ");";
        injectJavaScript(webView, js);
    }

    private static void injectJavaScript(WebView webView, @NonNull String javascript) {
        if (webView == null) {
            LogUtils.d("Attempted to inject Javascript into MRAID WebView while was not attached:\n\t" + javascript);
            return;
        }
        LogUtils.d("Injecting Javascript into MRAID WebView: " + javascript);
        webView.loadUrl("javascript:" + javascript);
    }

    @NonNull
    private static String stringifyRect(Rect rect) {
        return rect.left + "," + rect.top + "," + rect.width() + "," + rect.height();
    }

    @NonNull
    private static String stringifySize(Rect rect) {
        return rect.width() + "," + rect.height();
    }

    private static String stringifyBool(boolean bool) {
        return bool ? "true" : "false";
    }
}
