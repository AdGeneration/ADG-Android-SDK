package com.socdm.d.adgeneration.video.config;

import com.socdm.d.adgeneration.video.vast.VastAd;

import java.io.Serializable;

public class AdConfiguration implements Serializable {
    private final VastAd mVastAd;
    private boolean soundEnabled;

    public AdConfiguration(VastAd vastAd) {
        mVastAd = vastAd;
        soundEnabled = false;
    }

    public VastAd getVastAd() {
        return mVastAd;
    }

    public boolean isSoundEnabled() {
        return soundEnabled;
    }
}
