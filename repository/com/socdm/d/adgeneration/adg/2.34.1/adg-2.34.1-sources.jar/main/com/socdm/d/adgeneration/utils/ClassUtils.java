package com.socdm.d.adgeneration.utils;

import java.lang.reflect.Field;
import java.util.EnumSet;

public class ClassUtils {

    public static Enum getEnum(String className, String enumName) {
        try {
            Class enumClass = Class.forName(className);
            return Enum.valueOf(enumClass, enumName);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static EnumSet getEnumSet(String className) {
        try {
            Class enumClass = Class.forName(className);
            return EnumSet.allOf(enumClass);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static Object getPrivateField(Object classObject, String fieldName) throws IllegalAccessException, NoSuchFieldException {
        Class clazz = classObject.getClass();
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(classObject);
    }

}
