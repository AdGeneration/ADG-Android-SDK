package com.socdm.d.adgeneration.impression;

import androidx.annotation.NonNull;

import jp.supership.sscore.tracking.SSCoreTrackingEvent;

import java.util.ArrayList;
import java.util.List;

/** インプレッションのための広告の表示面積と表示時間に基づくトラッキングイベントを格納するクラスです */
final class ImpressionData {
    /** 識別キー */
    @NonNull final String key;
    /** 広告の表示面積の割合 (0.0 - 1.0) */
    final double ratio;
    /** 広告の表示時間[ミリ秒] */
    final long durationInMilliseconds;

    @NonNull private final List<SSCoreTrackingEvent> events;

    /**
     * インスタンスを初期化します
     *
     * @param key 識別キー
     * @param ratio 広告の表示面積の割合 (0.0 - 1.0)
     * @param durationInMilliseconds 広告の表示時間[ミリ秒]
     * @param events トラッキングイベント
     */
    ImpressionData(
            @NonNull final String key,
            final double ratio,
            final long durationInMilliseconds,
            @NonNull final List<SSCoreTrackingEvent> events) {
        this.key = key;
        this.ratio = ratio;
        this.durationInMilliseconds = durationInMilliseconds;
        this.events = events;
    }

    @NonNull
    @Override
    public String toString() {
        return "ImpressionData {"
                + "key: "
                + key
                + ",\n"
                + "ratio: "
                + ratio
                + ",\n"
                + "durationInMilliseconds: "
                + durationInMilliseconds
                + ",\n"
                + "events: "
                + events
                + ",\n"
                + "}";
    }

    /**
     * 広告の表示時間[秒]を返します
     *
     * @return 広告の表示時間[秒]
     */
    double getDurationInSeconds() {
        return durationInMilliseconds / 1000.0;
    }

    /**
     * トラッキングイベントを取得します
     *
     * @return トラッキングイベント
     */
    @NonNull
    List<SSCoreTrackingEvent> getEvents() {
        return new ArrayList<>(events);
    }
}
