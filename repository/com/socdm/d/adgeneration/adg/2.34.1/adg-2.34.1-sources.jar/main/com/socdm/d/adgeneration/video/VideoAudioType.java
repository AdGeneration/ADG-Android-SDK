package com.socdm.d.adgeneration.video;

public enum VideoAudioType {
    MIX,
    SOLO
}
