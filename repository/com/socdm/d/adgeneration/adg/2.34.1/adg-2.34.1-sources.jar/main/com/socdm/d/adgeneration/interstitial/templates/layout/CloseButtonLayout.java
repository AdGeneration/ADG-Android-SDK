package com.socdm.d.adgeneration.interstitial.templates.layout;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;

import com.socdm.d.adgeneration.interstitial.templates.parts.CloseButton;

@Deprecated
public class CloseButtonLayout extends LinearLayout {

    public CloseButtonLayout(Context context) {
        super(context);
    }

    private boolean checkAddConstraint(View child) {
        return child instanceof CloseButton<?>;
    }

    @Override
    public void addView(View child) {
        if (checkAddConstraint(child)) {
            super.addView(child);
        }
    }

    @Override
    public void addView(View child, android.view.ViewGroup.LayoutParams params) {
        if (checkAddConstraint(child)) {
            super.addView(child, params);
        }
    }

    @Override
    public void addView(View child, int index) {
        if (checkAddConstraint(child)) {
            super.addView(child, index);
        }
    }

    @Override
    public void addView(View child, int width, int height) {
        if (checkAddConstraint(child)) {
            super.addView(child, width, height);
        }
    }

    @Override
    public void addView(View child, int index, android.view.ViewGroup.LayoutParams params) {
        if (checkAddConstraint(child)) {
            super.addView(child, index, params);
        }
    }
}
