package com.socdm.d.adgeneration.video;

import static com.socdm.d.adgeneration.video.utils.DeviceUtils.getDeviceDimensions;

import android.Manifest;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.util.CollectionUtils;
import com.iab.omid.library.supershipjp.adsession.media.InteractionType;
import com.iab.omid.library.supershipjp.adsession.media.Position;
import com.socdm.d.adgeneration.ADGLogger;
import com.socdm.d.adgeneration.Measurement.MeasurementConsts;
import com.socdm.d.adgeneration.Measurement.VideoViewMeasurementManager;
import com.socdm.d.adgeneration.video.broadcast.ScreenStateBroadcastReceiver;
import com.socdm.d.adgeneration.video.cache.CacheService;
import com.socdm.d.adgeneration.video.cache.CachingDownloadTask;
import com.socdm.d.adgeneration.video.config.AdConfiguration;
import com.socdm.d.adgeneration.video.utils.Views;
import com.socdm.d.adgeneration.video.vast.MediaFile;
import com.socdm.d.adgeneration.video.vast.VastAd;
import com.socdm.d.adgeneration.video.vast.VastRequest;
import com.socdm.d.adgeneration.video.view.AdView;
import com.socdm.d.adgeneration.video.view.VastPlayer;
import com.socdm.d.adgeneration.video.view.VideoView;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.RejectedExecutionException;

public class ADGPlayerAdManager
        implements VastRequest.VastRequestListener,
                ScreenStateBroadcastReceiver.ScreenStateBroadcastReceiverListener,
                AdView.EventListener {
    private static final List<String> VIDEO_MIME_TYPES = Arrays.asList("video/mp4", "video/3gpp");
    private static final double ASPECT_RATIO_WEIGHT = 30;
    private static final double AREA_WEIGHT = 70;

    private Context mContext;
    private Activity mActivity;
    private ViewGroup mContentView;
    private VastRequest mRequesting;
    private AdConfiguration mAdConfiguration;
    private AdView mAdView;
    private ScreenStateBroadcastReceiver mScreenStateBroadcastReceiver;
    private ADGPlayerAdListener mAdListener;
    private double mScreenAspectRatio;
    private int mScreenArea;
    private Handler mHander;
    private String mVastString;
    private boolean isTiny = false;
    private boolean isWipe = false;
    private OnActivityLifecycleCallbacks onActivityLifecycleCallbacks =
            new OnActivityLifecycleCallbacks();
    private VideoViewMeasurementManager videoViewMeasurementManager;
    private boolean isNativeOptout = false;

    // View状態を管理するenum
    private enum ViewState {
        IN_VIEW,
        OUT_OF_VIEW,
        NONE
    }

    // 異なるスレッドからアクセスされる可能性があるためvolatileで宣言
    private volatile ViewState pendingViewState = ViewState.NONE;

    public ADGPlayerAdManager(final Context context) {
        mContext = context;
        mAdConfiguration = null;
        mHander = new Handler(Looper.myLooper());

        initializeScreenDimensions();
    }

    public void setAdListener(ADGPlayerAdListener adListener) {
        mAdListener = adListener;
    }

    public void setIsTiny(boolean isTiny) {
        this.isTiny = isTiny;
    }

    public void setIsWipe(boolean isWipe) {
        this.isWipe = isWipe;
    }

    public boolean isReady() {
        return mAdConfiguration != null;
    }

    @Override
    public void vastAdDidLoaded(VastAd vastAd) {
        ADGLogger.getDefault().debug(this + ": Ad request is running...");
        reset();
        mRequesting = null;
        mAdConfiguration = new AdConfiguration(vastAd);
        ready();
    }

    @Override
    public void failedToLoadVastAd(ADGPlayerError error) {
        mRequesting = null;
        onAdViewFailedToPlay(error);
    }

    public void load(String vastString, @Nullable final Boolean isNativeOptout) {
        mVastString = vastString;

        if (isNativeOptout != null) {
            this.isNativeOptout = isNativeOptout;
        }

        if (!CacheService.initializeDiskCache(mContext)) {
            onAdViewFailedToPlay(ADGPlayerError.CACHE_SERVICE_ERROR);
            return;
        }

        boolean isPermissionApproved = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                isPermissionApproved =
                        ContextCompat.checkSelfPermission(
                                        mContext, Manifest.permission.ACCESS_NETWORK_STATE)
                                == PackageManager.PERMISSION_GRANTED;
            } catch (NoClassDefFoundError | NoSuchMethodError | NullPointerException e) {
                ADGLogger.getDefault()
                        .error(
                                "Needs ACCESS_NETWORK_STATE permission.(not import android support"
                                        + " library)",
                                e);
                return;
            }
        }
        if (!isPermissionApproved) {
            ADGLogger.getDefault().error("Needs ACCESS_NETWORK_STATE permission.");
            onAdViewFailedToPlay(ADGPlayerError.SETTING_ERROR);
            return;
        }

        if (!(mContext instanceof Activity)) {
            ADGLogger.getDefault().error("Activity is required.");
            onAdViewFailedToPlay(ADGPlayerError.SETTING_ERROR);
            return;
        }
        mActivity = (Activity) mContext;
        if (!Views.hasHardwareAcceleration(mActivity)) {
            onAdViewFailedToPlay(ADGPlayerError.HARDWARE_ACCELERATION_DISABLED);
            return;
        }

        if (isReady()) {
            ADGLogger.getDefault().debug("ad is already loaded");
            return;
        }

        if (mRequesting != null) {
            ADGLogger.getDefault().debug(this + ": Ad request is running...");
            return;
        }

        mRequesting = new VastRequest(this, mContext);
        if (mVastString.startsWith("http")) {
            ADGLogger.getDefault().error("unsupported getting VAST by HTTP request");
            return;
        } else {
            mHander.post(
                    new Runnable() {
                        public void run() {
                            if (mRequesting == null) {
                                ADGLogger.getDefault().error("Requesting is null");
                                return;
                            }
                            mRequesting.loadXML(mVastString);
                        }
                    });
        }
        ADGLogger.getDefault().debug(this + ": start ad requesting: " + vastString);
    }

    public void showAd(final ViewGroup contentView) {
        mHander.post(
                () -> {
                    if (isReady()) {
                        if (mAdView != null) {
                            Views.removeFromParent(mAdView);
                            mAdView = null;
                        }

                        try {
                            mAdView = new AdView(mContext, this, isTiny, isWipe, isNativeOptout);
                        } catch (AdView.CannotInstantiateException e) {
                            onAdViewFailedToPlay(e.error);
                            return;
                        }

                        mAdView.startAd(mAdConfiguration);

                        mContentView = contentView;
                        mContentView.addView(
                                mAdView,
                                new ViewGroup.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.WRAP_CONTENT));
                        registerScreenStateBroadcastReceiver();
                        mActivity
                                .getApplication()
                                .unregisterActivityLifecycleCallbacks(onActivityLifecycleCallbacks);
                        mActivity
                                .getApplication()
                                .registerActivityLifecycleCallbacks(onActivityLifecycleCallbacks);
                        mAdView.getVastPlayer()
                                .setVastMediaEventListenerForManger(
                                        new VastPlayer.VastMediaEventListenerForManager() {
                                            @Override
                                            public void onVideoLoadEvent(VideoView videoView) {
                                                // スキップ不可の動画をロードしたことを通知
                                                sendLoadedForNonSkippableVideo();
                                            }

                                            @Override
                                            public void onVideoTrackingEvent(
                                                    MeasurementConsts.mediaEvents event,
                                                    VideoView videoView) {
                                                // トラッキングイベントを通知
                                                sendMediaEvent(event, videoView);
                                            }

                                            @Override
                                            public void onBuffering(
                                                    int percent, VideoView videoView) {
                                                // アドジェネでは実質必要ない想定
                                                // 本来はバッファリングがはじまって広告の再生が停止したタイミングで下記を通知する
                                                // sendMediaEvent(MeasurementConsts.mediaEvents.bufferEnd, videoView);
                                                // バッファリングが完了し再生が開始するタイミングで下記を通知する
                                                // sendMediaEvent(MeasurementConsts.mediaEvents.bufferStart, videoView);
                                            }

                                            @Override
                                            public void onSeekTo(VideoView videoView) {
                                                /*
                                                アドジェネの仕様上、skipはないので何もしない
                                                if (videoView == null || videoView.getCurrentPosition() <= 0) {
                                                    return;
                                                }
                                                sendMediaEvent(MeasurementConsts.mediaEvents.skipped, videoView);
                                                 */
                                            }

                                            @Override
                                            public void onError(ADGPlayerError ADGPlayerError) {}

                                            @Override
                                            public void onChangeAudioVolume(
                                                    boolean isOn, VideoView videoView) {
                                                if (isOn) {
                                                    // ボリュームがONになったことを通知
                                                    sendMediaEvent(
                                                            MeasurementConsts.mediaEvents
                                                                    .volumeChangeOn,
                                                            videoView);
                                                } else {
                                                    // ボリュームがOFFになったことを通知
                                                    sendMediaEvent(
                                                            MeasurementConsts.mediaEvents
                                                                    .volumeChangeOff,
                                                            videoView);
                                                }
                                            }
                                        });
                        // NativeVideoフォーマットのOM SDK計測用インスタンスを生成して計測スタート
                        if (mAdView.getVastPlayer() != null
                                && mAdView.getVastPlayer().getVastAd() != null
                                && !CollectionUtils.isEmpty(
                                        mAdView.getVastPlayer().getVastAd().getVerifications())) {
                            startMeasurement();
                        }

                        // 保留中のView状態があれば適用
                        switch (pendingViewState) {
                            case IN_VIEW:
                                mAdView.callWhenInView();
                                break;
                            case OUT_OF_VIEW:
                                mAdView.callWhenOutOfView();
                                break;
                        }
                        pendingViewState = ViewState.NONE;

                    } else {
                        onAdViewFailedToPlay(ADGPlayerError.NO_AD);
                    }
                });
    }

    public void destroy() {
        ADGLogger.getDefault().debug("Destroy ADGPlayerAdManager.");

        reset();
        unregisterScreenStateBroadcastReceiver();
        unregisterActivityLifecycleCallbacks();

        if (mAdView != null) {
            mAdView.release();
            mAdView = null;
        }
        // Finishイベントを送信
        sendMediaEvent(MeasurementConsts.mediaEvents.finish, null);
    }

    public void callWhenInView() {
        if (mAdView != null) {
            mAdView.callWhenInView();
        } else {
            pendingViewState = ViewState.IN_VIEW;
        }
    }

    public void callWhenOutOfView() {
        if (mAdView != null) {
            mAdView.callWhenOutOfView();
        } else {
            pendingViewState = ViewState.OUT_OF_VIEW;
        }
    }

    public void onReadyToPlayAd() {
        mAdConfiguration.getVastAd().impressions();
        mAdListener.onReadyToPlayAd();
    }

    @Override
    public void onAdViewStartVideo() {
        mAdListener.onStartVideo();
    }

    @Override
    public void onAdViewFailedToPlay(@NonNull final ADGPlayerError error) {
        ADGLogger.getDefault().error(error.toString());
        mHander.post(
                () -> {
                    if (mAdListener != null) {
                        mAdListener.onFailedToPlayAd(error);
                    }
                });
    }

    @Override
    public void onAdViewClick() {
        if (isReady() && !mAdView.getCompleted()) {
            onAdViewClickThrough();
        }
    }

    @Override
    public void onAdViewClickThrough() {
        ADGLogger.getDefault().debug("onAdViewClickThrough called.");

        if (isReady()) {
            mAdConfiguration.getVastAd().clickThrough(mContext);

            // InteractionTypeイベントの送信
            if (mAdConfiguration.getVastAd().getClickThrough().startsWith("http")) {
                // URL遷移
                sendUserInteraction(InteractionType.CLICK);
            } else {
                // それ以外(スキーマ遷移など)のケース
                sendUserInteraction(InteractionType.INVITATION_ACCEPTED);
            }

            if (mAdListener != null) {
                mAdListener.onClickAd();
            }
        }
    }

    @Override
    public void onAdViewDetachedFromWindow() {
        unregisterBroadcastReceivers();
        unregisterActivityLifecycleCallbacks();
    }

    @Override
    public void onScreenOn() {}

    @Override
    public void onScreenOff() {}

    private void ready() {
        ADGLogger.getDefault().debug("Ad is ready.");
        final VastAd vastAd = mAdConfiguration.getVastAd();
        updateBestMediaFileNetworkUrl(vastAd);
        boolean hasCache = updateBestMediaFileDiskUrl(vastAd);
        if (hasCache) {
            ADGLogger.getDefault().debug("Load video from disk cache.");
            if (mAdView != null) {
                mAdView.startAd(mAdConfiguration);
            } else {
                onReadyToPlayAd();
            }
        } else {
            ADGLogger.getDefault().debug("Load video from network.");
            final CachingDownloadTask cachingDownloadTask =
                    new CachingDownloadTask(
                            new CachingDownloadTask.CachingDownloadTaskListener() {
                                @Override
                                public void onComplete(boolean success) {
                                    if (mAdConfiguration == null) {
                                        ADGLogger.getDefault().error("Already reset.");
                                        return;
                                    }
                                    if (!success) {
                                        ADGLogger.getDefault().error("CachingDownloadTask error.");
                                        onAdViewFailedToPlay(ADGPlayerError.CACHE_SERVICE_ERROR);
                                        return;
                                    }
                                    boolean hasCache = updateBestMediaFileDiskUrl(vastAd);
                                    if (!hasCache) {
                                        ADGLogger.getDefault()
                                                .error("updateBestMediaFileDiskUrl error.");
                                        onAdViewFailedToPlay(ADGPlayerError.CACHE_SERVICE_ERROR);
                                        return;
                                    }
                                    onReadyToPlayAd();
                                }
                            });
            try {
                cachingDownloadTask.executeOnExecutor(
                        AsyncTask.THREAD_POOL_EXECUTOR, vastAd.getBestMediaFileNetworkUrl());
            } catch (IllegalStateException | RejectedExecutionException | NullPointerException e) {
                e.printStackTrace();
                ADGLogger.getDefault().error("cachingDownloadTask.executeOnExecutor error.");
                onAdViewFailedToPlay(ADGPlayerError.CACHE_SERVICE_ERROR);
            }
        }
    }

    private void reset() {
        mAdConfiguration = null;
        mContentView = null;

        if (mRequesting != null) {
            mRequesting.cancel();
            mRequesting = null;
        }
    }

    private MediaFile selectBestMediaFile(List<MediaFile> mediaFiles) {
        double bestMediaFitness = Double.POSITIVE_INFINITY;
        MediaFile bestMediaFile = null;

        for (MediaFile m : mediaFiles) {
            final String mediaType = m.getType();
            final String mediaUrl = m.getUrl().toString();
            if (!VIDEO_MIME_TYPES.contains(mediaType) || mediaUrl == null) {
                continue;
            }

            final int mediaWidth = m.getWidth();
            final int mediaHeight = m.getHeight();
            if (mediaWidth <= 0 || mediaHeight <= 0) {
                continue;
            }

            final double mediaFitness = calculateFitness(mediaWidth, mediaHeight);
            if (mediaFitness < bestMediaFitness) {
                bestMediaFitness = mediaFitness;
                bestMediaFile = m;
            }
        }

        if (bestMediaFile == null && !mAdConfiguration.getVastAd().getMediaFiles().isEmpty()) {
            bestMediaFile = mAdConfiguration.getVastAd().getMediaFiles().get(0);
        }

        return bestMediaFile;
    }

    private double calculateFitness(final int width, final int height) {
        final double mediaAspectRatio = (double) width / height;
        final int mediaArea = width * height;
        final double aspectRatioRatio = mediaAspectRatio / mScreenAspectRatio;
        final double areaRatio = (double) mediaArea / mScreenArea;
        return ASPECT_RATIO_WEIGHT * Math.abs(Math.log(aspectRatioRatio))
                + AREA_WEIGHT * (Math.pow(areaRatio, 2) * Math.abs(Math.log(areaRatio)));
    }

    private boolean updateBestMediaFileDiskUrl(final VastAd vastAd) {
        final String networkMediaFileUrl = vastAd.getBestMediaFileNetworkUrl();
        if (CacheService.containsKeyDiskCache(networkMediaFileUrl)) {
            final String filePathDiskCache = CacheService.getFilePathDiskCache(networkMediaFileUrl);
            vastAd.setBestMediaFileDiskUrl(filePathDiskCache);
            return true;
        }
        return false;
    }

    private void updateBestMediaFileNetworkUrl(final VastAd vastAd) {
        MediaFile bestMediaFile = selectBestMediaFile(vastAd.getMediaFiles());
        vastAd.setBestMediaFileNetworkUrl(bestMediaFile.getUrl().toString());
    }

    private void initializeScreenDimensions() {
        Point screenDimensions = getDeviceDimensions(mContext);
        int x = screenDimensions.x;
        int y = screenDimensions.y;

        // For landscape, width is always greater than height
        int screenX = Math.max(x, y);
        int screenY = Math.min(x, y);

        float density = mContext.getResources().getDisplayMetrics().density;
        int dpX = (int) Math.ceil(screenX / density);
        int dpY = (int) Math.ceil(screenY / density);
        mScreenAspectRatio = (double) dpX / dpY;
        mScreenArea = dpX * dpY;
    }

    public void unregisterBroadcastReceivers() {
        ADGLogger.getDefault().debug("Unregister broadcast receivers.");

        unregisterScreenStateBroadcastReceiver();
    }

    public void unregisterActivityLifecycleCallbacks() {
        if (mActivity != null) {
            mActivity
                    .getApplication()
                    .unregisterActivityLifecycleCallbacks(onActivityLifecycleCallbacks);
        }
    }

    private void registerScreenStateBroadcastReceiver() {
        ADGLogger.getDefault().debug("register");
        unregisterScreenStateBroadcastReceiver();
        mScreenStateBroadcastReceiver = new ScreenStateBroadcastReceiver(this);
        mScreenStateBroadcastReceiver.register(mContext);
    }

    private void unregisterScreenStateBroadcastReceiver() {
        ADGLogger.getDefault().debug("unregister");
        if (mScreenStateBroadcastReceiver != null) {
            mScreenStateBroadcastReceiver.unregister();
        }
    }

    private class OnActivityLifecycleCallbacks implements Application.ActivityLifecycleCallbacks {
        @Override
        public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}

        @Override
        public void onActivityStarted(Activity activity) {}

        @Override
        public void onActivityResumed(Activity activity) {
            if (activity.equals(mActivity)) {
                if (mAdView != null && isReady()) {
                    mAdView.resume(mAdConfiguration);
                }
            }
        }

        @Override
        public void onActivityPaused(Activity activity) {
            if (activity.equals(mActivity)) {
                if (mAdView != null) {
                    mAdView.pause();
                }
            }
        }

        @Override
        public void onActivityStopped(Activity activity) {}

        @Override
        public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}

        @Override
        public void onActivityDestroyed(Activity activity) {
            if (activity.equals(mActivity)) {
                mActivity.getApplication().unregisterActivityLifecycleCallbacks(this);
            }
        }
    }

    /** OM SDKのアドセッションを生成して計測を開始する */
    private void startMeasurement() {
        // NativeVideoフォーマットのOM SDK計測用インスタンスを生成
        videoViewMeasurementManager =
                new VideoViewMeasurementManager(mContext, mAdView.getVastPlayer());

        if (videoViewMeasurementManager == null) return;

        // 計測スタート
        videoViewMeasurementManager.startMeasurement(mAdView);
    }

    /** スキップ不可能な広告動画をロードした際にコールするイベント */
    public void sendLoadedForNonSkippableVideo() {
        if (videoViewMeasurementManager == null) return;
        videoViewMeasurementManager.sendLoadedForNonSkippableMedia(true, Position.STANDALONE);
    }

    /**
     * 広告クリックでの遷移の際にコールするイベント
     *
     * @param interactionType CLICK(httpまたはhttpsへの遷移) or INVITATION_ACCEPTED(スキーマなどでの遷移)
     */
    public void sendUserInteraction(InteractionType interactionType) {
        try {
            if (interactionType == null || videoViewMeasurementManager == null) return;
            videoViewMeasurementManager.sendUserInteraction(interactionType);
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * 動画の読み込み〜再生終了に伴うトラッキングイベントを送信するイベント
     *
     * @param event
     * @param videoView
     */
    public void sendMediaEvent(MeasurementConsts.mediaEvents event, VideoView videoView) {
        try {
            if (event == null || videoViewMeasurementManager == null) return;
            videoViewMeasurementManager.sendMediaEvent(event, videoView);
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            e.printStackTrace();
        }
    }
}
