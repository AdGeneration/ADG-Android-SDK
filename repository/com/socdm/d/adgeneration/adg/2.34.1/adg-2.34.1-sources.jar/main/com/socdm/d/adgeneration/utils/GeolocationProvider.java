package com.socdm.d.adgeneration.utils;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.socdm.d.adgeneration.ADGSettings;

import jp.supership.sscore.type.Optional;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class GeolocationProvider implements IGeolocationProvider {
    private static volatile GeolocationProvider instance;
    private static final int LOCATION_EXPIRE_MINUTE = 10;

    @Nullable private Location lastKnownLocation = null;
    @NonNull private final Context context;

    public static IGeolocationProvider getInstance(@NonNull final Context context) {
        if (instance == null) {
            synchronized (GeolocationProvider.class) {
                if (instance == null) {
                    instance = new GeolocationProvider(context);
                }
            }
        }
        return instance;
    }

    private GeolocationProvider(@NonNull final Context context) {
        this.context = context.getApplicationContext();
    }

    @NonNull
    @Override
    public Optional<Location> lastKnownLocation() {
        return Optional.of(lastKnownLocation);
    }

    /** 位置情報取得が有効かどうか */
    private boolean isLocationUpdatesEnabled() {
        boolean isGeolocationSettingEnabled = ADGSettings.isGeolocationEnabled();

        // PermissionはAndroid6以前ではtrue
        boolean isPermissionApproved = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                isPermissionApproved =
                        (ContextCompat.checkSelfPermission(
                                                context, Manifest.permission.ACCESS_COARSE_LOCATION)
                                        == PackageManager.PERMISSION_GRANTED
                                || ContextCompat.checkSelfPermission(
                                                context, Manifest.permission.ACCESS_FINE_LOCATION)
                                        == PackageManager.PERMISSION_GRANTED);
            } catch (NoClassDefFoundError | NoSuchMethodError e) {
                // Android6以降で、API Level 23 以前でビルドされてるか、
                // com.android.support:appcompatを導入していないとNoSuchMethodErrorになるのでcatchする
                LogUtils.e(e.getMessage());
                isPermissionApproved = false;
            }
        }

        if (!isGeolocationSettingEnabled) LogUtils.d("Geolocation setting is disable.");
        if (!isPermissionApproved) LogUtils.d("Unauthorized permission of update location.");

        return isGeolocationSettingEnabled && isPermissionApproved;
    }

    /**
     * 位置情報が有効かどうか
     *
     * @return true:有効/false:無効
     */
    @Override
    public boolean isValidLocation() {
        if (!isLocationUpdatesEnabled()) {
            return false;
        }
        if (lastKnownLocation == null) {
            LogUtils.d("Not acquired location yet.");
            return false;
        }

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MINUTE, -LOCATION_EXPIRE_MINUTE);
        long expireDate = cal.getTime().getTime();
        if (lastKnownLocation.getTime() > expireDate) {
            LogUtils.d("Location is valid.");
            return true;
        }
        LogUtils.d("Location is invalid.");
        return false;
    }

    /** 最新の位置情報に更新 */
    @Override
    public void updateLocation() {
        if (!isLocationUpdatesEnabled()) {
            return;
        }

        LocationManager locationManager =
                (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null) {
            LogUtils.d("Unable to get LocationManager.");
            return;
        }

        LogUtils.d("Try to update the most recent location.");
        String networkProvider = getNetworkProvider(context, locationManager);
        String gpsProvider = getGPSProvider(context, locationManager);
        Location networkLocation =
                getLastKnownLocationFromProvider(locationManager, networkProvider);
        Location gpsLocation = getLastKnownLocationFromProvider(locationManager, gpsProvider);

        Location mostRecentLocation = getMostRecentLocation(networkLocation, gpsLocation);
        if (mostRecentLocation == null) {
            return;
        }
        if (lastKnownLocation == null
                || lastKnownLocation.getTime() != mostRecentLocation.getTime()) {
            lastKnownLocation = mostRecentLocation;
            LogUtils.d("Update the most recent location.");
            LogUtils.d(locationDebugLog(lastKnownLocation));
        }
    }

    /**
     * ネットワークプロバイダーを取得
     *
     * @param context Context
     * @param locationManager LocationManager
     * @return provider
     */
    @Nullable
    private static String getNetworkProvider(
            @NonNull final Context context, @NonNull final LocationManager locationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                if (ContextCompat.checkSelfPermission(
                                context, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    return null;
                }
            } catch (NoClassDefFoundError | NoSuchMethodError e) {
                LogUtils.e(e.getMessage());
            }
        }

        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_COARSE);
        return locationManager.getBestProvider(criteria, true);
    }

    /**
     * GPSプロバイダーを取得
     *
     * @param context Context
     * @param locationManager LocationManager
     * @return provider
     */
    @Nullable
    private static String getGPSProvider(
            @NonNull final Context context, @NonNull final LocationManager locationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                if (ContextCompat.checkSelfPermission(
                                context, Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    return null;
                }
            } catch (NoClassDefFoundError | NoSuchMethodError e) {
                LogUtils.e(e.getMessage());
            }
        }

        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        return locationManager.getBestProvider(criteria, true);
    }

    /**
     * 最後に端末が保存した位置情報を取得
     *
     * @param locationManager LocationManager
     * @param provider provider
     * @return Location
     */
    @SuppressLint("MissingPermission")
    @Nullable
    private static Location getLastKnownLocationFromProvider(
            @NonNull final LocationManager locationManager, @Nullable final String provider) {
        if (provider == null) return null;

        try {
            return locationManager.getLastKnownLocation(provider);
        } catch (SecurityException e) {
            LogUtils.d(
                    "Failed to update location from "
                            + provider
                            + " provider: access appears to be disabled.");
        } catch (IllegalArgumentException e) {
            LogUtils.d(
                    "Failed to update location: device has no " + provider + " location provider.");
        } catch (NullPointerException e) { // This happens on 4.2.2 on a few Android TV devices
            LogUtils.d(
                    "Failed to update location: device has no " + provider + " location provider.");
        }
        return null;
    }

    /**
     * ネットワークプロバイダとGPSプロバイダから取得した位置情報取得を比較して、新しい方を返す
     *
     * @param a Location
     * @param b Location
     * @return Location
     */
    @Nullable
    private static Location getMostRecentLocation(
            @Nullable final Location a, @Nullable final Location b) {
        if (a == null) return b;

        if (b == null) return a;

        return (a.getTime() > b.getTime()) ? a : b;
    }

    @NonNull
    private static String locationDebugLog(@NonNull final Location location) {
        String latitude = String.valueOf(location.getLatitude());
        String longitude = String.valueOf(location.getLongitude());
        String timestamp =
                (new SimpleDateFormat("MM-dd kk:mm:ss", Locale.US))
                        .format(new Date(location.getTime()));
        return "latitude:" + latitude + ", longitude:" + longitude + ", timestamp:" + timestamp;
    }
}
