package com.socdm.d.adgeneration.wipe

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.os.Build
import android.os.Handler
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.annotation.RequiresApi
import com.socdm.d.adgeneration.ADG
import com.socdm.d.adgeneration.ADG.AdFrameSize
import com.socdm.d.adgeneration.ADGConsts.*
import com.socdm.d.adgeneration.ADGListener
import com.socdm.d.adgeneration.utils.DisplayUtils
import com.socdm.d.adgeneration.utils.LogUtils
import com.socdm.d.adgeneration.utils.ShowController
import com.socdm.d.adgeneration.wipe.templates.WipeTemplate
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.round

/*
 別箇所ではTargetApiでバージョン分岐の管理を行っているが、ADGWipeはClass全体でLOLLIPOP以上でない限り機能しない。
 なのでアプリ実装側へ強制させる意味でもRequiresApiで管理するようにしている。
 */
@RequiresApi(Build.VERSION_CODES.LOLLIPOP)
@SuppressLint("ClickableViewAccessibility")
@Deprecated("Wipe ad is deprecated.")
class ADGWipe(ct: Context?) {
    // instance variables
    private var activity: Activity? = null
    private var template: WipeTemplate? = null
    private val showController: ShowController
    private var currentSystemUiVisibility: Int = 0
    private val adg: ADG
    private var listener: ADGWipeListener? = null
    var isShow = false
    var isReady = false
    private var canGetActionBarMargin: Boolean = false

    /**
     * ScreenWidth, DisplayUtils#getScreenWidthPx()
     */
    private var screenWidthPx = 0

    /**
     * ActionBarを除いたScreenHeight, DisplayUtils#getScreenHeightPx()
     */
    private var screenHeightPx = 0
    private var position = ADGWipePosition.TOP_RIGHT

    /**
     * WipeのContentView
     */
    private var contentView: ViewGroup? = null

    /**
     * WipeのContentViewWidth
     */
    private var contentWidth: Int = 0
        get() {
            activity?.let {
                var fixedWidth = field
                // contentWidthの最小値
                val minWidth = 135
                // ActionBar込みのScreenSize
                val screenHeight = DisplayUtils.getScreenSize(it).height
                // ScreenWidth
                val screenWidth = DisplayUtils.getScreenSize(it).width
                // contentWidthの横許容最大値
                val maxAdWidth = DisplayUtils.getDip(
                    it.resources,
                    (screenWidth * DEVICES_SCREEN_PORTRAIT_DEFAULT_SIZE_RATIO).toInt(),
                )
                // contentWidthの縦許容最大値
                val maxAdHeight = DisplayUtils.getDip(
                    it.resources,
                    (screenHeight * DEVICES_SCREEN_LANDSCAPE_DEFAULT_SIZE_RATIO).toInt(),
                )
                // 0未満に設定された状態の場合はデフォルトの最大値にする
                if (field <= 0) {
                    fixedWidth = if (screenHeight >= screenWidth) {
                        maxAdWidth
                    } else {
                        WipeTemplate.getVideoViewWidth(maxAdHeight)
                    }
                } else {
                    if (screenHeight >= screenWidth) {
                        if (field > maxAdWidth) {
                            fixedWidth = maxAdWidth
                        } else if (field < minWidth) {
                            fixedWidth = minWidth
                        }
                    } else {
                        if (WipeTemplate.getVideoViewHeight(field) > maxAdHeight) {
                            fixedWidth = WipeTemplate.getVideoViewWidth(maxAdHeight)
                        } else if (WipeTemplate.getVideoViewHeight(field) < WipeTemplate.getVideoViewHeight(
                                minWidth,
                            )
                        ) {
                            fixedWidth = minWidth
                        }
                    }
                }
                return fixedWidth
            } ?: return 0
        }

    /**
     * Wipeの現在表示位置X軸
     */
    private var currentPositionX: Int = 0

    /**
     * Wipeの現在表示位置Y軸
     */
    private var currentPositionY: Int = 0

    /**
     * WipeのX軸marginの固定Px値
     */
    private var marginWidth = DisplayUtils.getPixels(ct!!.resources, DEFAULT_MARGIN_DP)

    /**
     * WipeのY軸marginの固定Px値
     */
    private var marginHeight = DisplayUtils.getPixels(ct!!.resources, DEFAULT_MARGIN_DP)

    /**
     * settableな表示開始時の位置を決定するmargin値
     */
    private var initialMargin = 0

    /**
     * settableな上側margin値
     */
    private var userMarginTop = 0

    /**
     * settableな下側margin値
     */
    private var userMarginBottom = 0

    private val receiverHandler = Handler()

    // instance variable for showController
    private var isPercentage = false
    private var isLoaded = false

    // getter / setter
    @SuppressLint("ObsoleteSdkInt")
    fun setActivity(ct: Context?) {
        if (ct is Activity) {
            activity = ct
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                currentSystemUiVisibility = activity!!.window.decorView.systemUiVisibility
            }
        }
    }

    fun setAdListener(listener: ADGWipeListener?) {
        this.listener = listener
    }

    fun setInitialMarginHeight(margin: Int) {
        this.initialMargin = margin
    }

    fun setMarginTop(margin: Int) {
        this.userMarginTop = margin
        currentPositionY = getFixedPositionOverMarginHeight(currentPositionY)
        updateContentViewPosition()
    }

    fun setMarginBottom(margin: Int) {
        this.userMarginBottom = margin
        currentPositionY = getFixedPositionOverMarginHeight(currentPositionY)
        updateContentViewPosition()
    }

    fun setPosition(position: ADGWipePosition) {
        this.position = position
    }

    fun canGetActionBarMargin(canGetActionBarMargin: Boolean) {
        this.canGetActionBarMargin = canGetActionBarMargin
    }

    fun setWipeViewTheme(theme: ADGWipeTheme) {
        this.setFrameColorTheme(theme)
        this.setFrameTextColorTheme(theme)
    }

    fun setFrameColorTheme(theme: ADGWipeTheme) {
        this.setFrameColor(theme.frameColor)
    }

    // 設定値はここを参考にする
    // Color: https://developer.android.com/reference/android/graphics/drawable/GradientDrawable#setColor(int)
    fun setFrameColor(color: Int) {
        template?.frameColor = color
    }

    // 設定値はここを参考にする
    // Alpha: https://developer.android.com/reference/android/graphics/drawable/GradientDrawable#setAlpha(int)
    fun setFrameColor(color: Int, alpha: Int) {
        template?.frameColor = color
        template?.frameAlpha = alpha
    }

    fun setFrameTextColorTheme(theme: ADGWipeTheme) {
        template?.frameTextColor = theme.textColor
    }

    fun setFrameText(text: String) {
        template?.frameText = text
    }

    fun setFrameHidden(isHidden: Boolean) {
        template?.frameHidden = isHidden
    }

    fun positionInitialize() {
        initPosition()
    }

    fun setWidth(width: Int) {
        contentWidth = width
    }

    fun setLocationId(locationId: String) {
        adg.locationId = locationId
    }

    fun setEnableTestMode(enableTestMode: Boolean) {
        adg.isEnableTestMode = enableTestMode
    }

    // public methods
    fun preload() {
        if (!adg.isReadyForInterstitial) { // not called close from origin_interstitial
            val tempIsShow = isShow
            dismiss()
            isShow = tempIsShow
        }
        if (adg.visibility != View.VISIBLE) {
            adg.visibility = View.VISIBLE
            adg.start()
            isLoaded = true
        }
    }

    // ADGWipeでは show()直呼びを保証せず、 preload() -> show()のフローでの呼び出しを必須とする。
    fun show(): Boolean {
        isShow = checkShow()
        if (isShow) {
            calcScreenSize()
            initTemplate()
            val decorView = activity!!.window.decorView
            if (decorView.windowToken != null) {
                if (isReady && isLoaded) {
                    callADGShow()
                    contentView?.visibility = View.VISIBLE
                } else {
                    LogUtils.d("Ad is not loaded yet. Window will be shown, after ad was loaded.")
                    return false
                }
            } else {
                LogUtils.w("Failed to open the Wipe window.")
                return false
            }
        }
        return isShow
    }

    fun dismiss() {
        isLoaded = false
        adg.visibility = View.GONE
        contentView?.visibility = View.GONE
        listener?.onCloseWipe()
        adg.dismiss()
        isShow = false
        isReady = false
    }

    // 現在はConfiguration情報を使っていないが、今後必要になる可能性があるので一旦受け取るようにする。
    fun configurationChanged(newConfig: Configuration?) {
        if (isShow) {
            calcScreenSize()
            initTemplate()
        }
    }

    // private methods
    private fun checkShow(): Boolean {
        val key = adg.locationId
        if (!key.isNullOrEmpty()) {
            showController.cache(key, 0, isPercentage)
            if (activity == null) {
                LogUtils.w("adg Wipe must have activity instance.")
            } else if (activity!!.isFinishing) {
                LogUtils.w("activity was finished.")
            } else if (!showController.isShow(key)) {
                LogUtils.d("adg Wipe show next.")
                showController.next(key)
            } else {
                LogUtils.d("calledcheckShow OK!")
                showController.reset(key)
                return true
            }
        } else {
            LogUtils.w("ADGWipe must set locationId before show.")
        }
        return false
    }

    private fun callADGShow() {
        adg.show()
    }

    private fun initContentWidth(): Int {
        return activity?.let {
            val screenHeight = DisplayUtils.getScreenSize(it).height
            val screenWidth = DisplayUtils.getScreenSize(it).width
            val maxAdWidth = DisplayUtils.getDip(
                it.resources,
                (screenWidth * DEVICES_SCREEN_PORTRAIT_DEFAULT_SIZE_RATIO).toInt(),
            )
            val maxAdHeight = DisplayUtils.getDip(
                it.resources,
                (screenHeight * DEVICES_SCREEN_LANDSCAPE_DEFAULT_SIZE_RATIO).toInt(),
            )

            if (screenHeight >= screenWidth) {
                maxAdWidth
            } else {
                WipeTemplate.getVideoViewWidth(maxAdHeight)
            }
        } ?: 0
    }

    private fun isPositionTop(): Boolean {
        return when (position) {
            ADGWipePosition.TOP_RIGHT, ADGWipePosition.TOP_LEFT -> true
            else -> false
        }
    }

    private fun isPositionLeft(): Boolean {
        return when (position) {
            ADGWipePosition.TOP_LEFT, ADGWipePosition.BOTTOM_LEFT -> true
            else -> false
        }
    }

    private fun getLeftMaxmizeSize(): Int {
        return screenWidthPx - DisplayUtils.getPixels(activity!!.resources, contentWidth)
    }

    private fun getBottomMaxmizeSize(): Int {
        return screenHeightPx - DisplayUtils.getPixels(
            activity!!.resources,
            WipeTemplate.getTemplateHeight(contentWidth),
        )
    }

    private fun getFixedPositionOverScreenWidth(width: Int): Int {
        return when {
            width <= (0 + marginWidth) -> 0 + marginWidth
            width >= (getLeftMaxmizeSize() - marginWidth) ->
                getLeftMaxmizeSize() - marginWidth

            else -> width
        }
    }

    private fun getFixedPositionTouchUpWidth(width: Int): Int {
        return if (width > getLeftMaxmizeSize() / 2) {
            getLeftMaxmizeSize() - marginWidth
        } else {
            marginWidth
        }
    }

    private fun getFixedPositionOverMarginHeight(height: Int): Int {
        return when {
            height <= marginHeight + userMarginTop -> marginHeight + userMarginTop
            height >= (getBottomMaxmizeSize() - marginHeight - userMarginBottom) ->
                getBottomMaxmizeSize() - marginHeight - userMarginBottom

            else -> height
        }
    }

    private fun updateContentViewPosition() {
        val layoutParams: ViewGroup.LayoutParams? = contentView?.layoutParams
        layoutParams?.let {
            val mlp: ViewGroup.MarginLayoutParams = layoutParams as ViewGroup.MarginLayoutParams
            mlp.leftMargin = currentPositionX
            mlp.topMargin = currentPositionY
            contentView?.layoutParams = mlp
        }
    }

    private fun initTemplate() {
        template?.let {
            it.refresh(contentWidth)
            it.createCloseButton(CloseAction())
            it.createAdvertisementBar()
            it.adgLayout?.addView(adg)
        }

        contentView?.layoutParams?.let {
            it.width = DisplayUtils.getPixels(activity!!.resources, contentWidth)
            it.height = DisplayUtils.getPixels(
                activity!!.resources,
                WipeTemplate.getTemplateHeight(contentWidth),
            )
        }

        template?.parent ?: contentView?.addView(template)
        contentView?.parent
            ?: activity!!.addContentView(contentView, ViewGroup.LayoutParams(WC, WC))
        initPosition()
    }

    private fun initPosition() {
        // Positionの初期化
        val prePositionX =
            if (isPositionLeft()) {
                marginWidth
            } else {
                getLeftMaxmizeSize() - marginWidth
            }
        currentPositionX = getFixedPositionOverScreenWidth(prePositionX)
        // Positionを取得し、その値に対してmarginを適用させる
        var prePositionY: Int =
            getFixedPositionOverMarginHeight(if (isPositionTop()) 0 else getBottomMaxmizeSize())
        prePositionY =
            if (isPositionTop()) {
                prePositionY + DisplayUtils.getPixels(activity!!.resources, initialMargin)
            } else {
                prePositionY - DisplayUtils.getPixels(activity!!.resources, initialMargin)
            }
        // marginが画面からはみ出ないように再度確認
        currentPositionY = getFixedPositionOverMarginHeight(prePositionY)
        updateContentViewPosition()
    }

    private fun calcScreenSize() {
        screenWidthPx = DisplayUtils.getScreenWidthPx(activity!!.resources)
        screenHeightPx =
            DisplayUtils.getScreenHeightPx(activity!!.resources) - if (DisplayUtils.getActionBarShowing(
                    activity!!,
                ) && !canGetActionBarMargin
            ) {
                DisplayUtils.getActionBarSize(activity!!)
            } else {
                0
            }
    }

    // dismiss com.socdm.d.adgeneration.wipe action on click close button
    private inner class CloseAction : View.OnClickListener {
        override fun onClick(v: View) {
            dismiss()
        }
    }

    // ADGListener proxy
    private inner class ADGListenerProxy : ADGListener() {
        override fun onReceiveAd() {
            receiverHandler.post {
                adg.visibility = View.VISIBLE
                isReady = true
                LogUtils.d("onReceiveAd")
                listener?.onReceiveAd()
            }
        }

        override fun onFailedToReceiveAd(code: ADGErrorCode) {
            receiverHandler.post {
                adg.visibility = View.GONE
                // LogUtils.d("onFailedToReceiveAd (code:" + code.name + ")")
                listener?.onFailedToReceiveAd(code)
            }
        }

        override fun onClickAd() {
            receiverHandler.post {
                LogUtils.d("onAdClicked")
                listener?.onClickAd()
                listener?.onOpenUrl()
            }
        }
    }

    private inner class ADGWipeContentLayout(context: Context) : LinearLayout(context) {
        private val mTouchSlop: Int = ViewConfiguration.get(context).scaledTouchSlop

        // 画面が動かされたかどうかの判定、trueの場合は下層のViewにTouchイベントを通達しないようにする。
        private var mIsMoving: Boolean = false

        // タッチ開始時のX座標
        private var mStartX: Int = 0

        // タッチ開始時のY座標
        private var mStartY: Int = 0

        // onInterceptが呼ばれる前のeventX, 座標差分確認のためにつかう
        private var mOldEventX: Int = 0

        // onInterceptが呼ばれる前のeventY, 座標差分確認のためにつかう
        private var mOldEventY: Int = 0

        // Wipe拡大時のスケール
        private var scale = 1.05f

        // Wipeが拡大されているか
        private var scaled = false

        private fun getScaledContentWidth(): Int {
            return ceil(this@ADGWipe.contentWidth * scale).toInt()
        }

        // 挙動に関しては下記を参照
        // https://developer.android.google.cn/training/gestures/viewgroup?hl=ja#intercept
        override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
            // TouchイベントX座標
            val eventX = round(event.rawX).toInt()
            // TouchイベントY座標
            val eventY = round(event.rawY).toInt()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    mStartX = eventX
                    mStartY = eventY
                    mOldEventX = mStartX
                    mOldEventY = mStartY
                    // タッチ時にWipeを拡大する
                    updateScaled(true)
                }

                MotionEvent.ACTION_MOVE -> {
                    // 開始地点を基準として、一定距離以上動いたかどうかの判定
                    val diffX = abs(eventX - mStartX)
                    val diffY = abs(eventY - mStartY)
                    if (!mIsMoving && (diffX >= mTouchSlop || diffY >= mTouchSlop)) {
                        mIsMoving = true
                    }
                    // WipeViewの位置をイベントの距離差分だけ動かす
                    currentPositionX += eventX - mOldEventX
                    currentPositionY += eventY - mOldEventY
                    mOldEventX = eventX
                    mOldEventY = eventY

                    updateContentViewPosition()
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mOldEventX = 0
                    mOldEventY = 0
                    mStartX = 0
                    mStartY = 0
                    updateScaled(false)
                    // X座標
                    currentPositionX = getFixedPositionTouchUpWidth(currentPositionX)
                    // Y座標（画面からはみ出している場合のみ）
                    currentPositionY = getFixedPositionOverMarginHeight(currentPositionY)
                    updateContentViewPosition()
                    // mIsMovingがtrueの場合はreturn trueでTouchイベントを通達しない
                    if (mIsMoving) {
                        mIsMoving = false
                        return true
                    }
                }
            }
            return super.onInterceptTouchEvent(event)
        }

        private fun updateScaled(scaled: Boolean) {
            this.scaled = scaled
            if (scaled) {
                // 拡大時に中心からずれないようにする為
                currentPositionX += this@ADGWipe.contentWidth - getScaledContentWidth()
                currentPositionY += WipeTemplate.getTemplateHeight(this@ADGWipe.contentWidth) - WipeTemplate.getTemplateHeight(
                    getScaledContentWidth(),
                )
                layoutParams.width = DisplayUtils.getPixels(resources, getScaledContentWidth())
                layoutParams.height = DisplayUtils.getPixels(
                    resources,
                    WipeTemplate.getTemplateHeight(getScaledContentWidth()),
                )
            } else {
                // 縮小時に中心からずれないようにする為
                currentPositionX += getScaledContentWidth() - this@ADGWipe.contentWidth
                currentPositionY += WipeTemplate.getTemplateHeight(getScaledContentWidth()) - WipeTemplate.getTemplateHeight(
                    this@ADGWipe.contentWidth,
                )
                layoutParams.width = DisplayUtils.getPixels(resources, this@ADGWipe.contentWidth)
                layoutParams.height = DisplayUtils.getPixels(
                    resources,
                    WipeTemplate.getTemplateHeight(this@ADGWipe.contentWidth),
                )
            }
            this@ADGWipe.updateContentViewPosition()
        }

        override fun onDraw(canvas: Canvas) {
            if (scaled) canvas.scale(scale, scale) else canvas.scale(1f, 1f)
            super.onDraw(canvas)
        }

        init {
            setWillNotDraw(false)
        }
    }

    companion object {
        val MP = DisplayUtils.getMP()
        val WC = DisplayUtils.getWC()

        /**
         * デフォルトのmarginのdp値
         */
        val DEFAULT_MARGIN_DP = 10
    }

    // constructor
    init {
        setActivity(ct)
        showController = ShowController(ct)
        contentWidth = initContentWidth()

        adg = ADG(ct).apply {
            setIsWipe(true)
            setAdFrameSize(AdFrameSize.RECT)
            adListener = ADGListenerProxy()
            visibility = View.GONE
            val params = FrameLayout.LayoutParams(MP, WC)
            layoutParams = params
        }

        template = WipeTemplate(activity).apply {
            refresh(contentWidth)
            createCloseButton(CloseAction())
            createAdvertisementBar()
            adgLayout?.addView(adg)
        }

        activity?.let {
            contentView = ADGWipeContentLayout(it).apply {
                visibility = View.GONE
            }
        }
    }
}
