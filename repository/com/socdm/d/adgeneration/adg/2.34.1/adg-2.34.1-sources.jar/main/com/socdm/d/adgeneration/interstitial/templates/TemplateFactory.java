package com.socdm.d.adgeneration.interstitial.templates;

import android.content.Context;

import com.socdm.d.adgeneration.utils.LogUtils;

@Deprecated
public class TemplateFactory {

    public enum TemplateType {
        TEMPLATE_TYPE_300x250_1,
        TEMPLATE_TYPE_FULL_SCREEN;

        public static TemplateType fromIndex(int index) {
            try {
                return values()[index];
            } catch (IndexOutOfBoundsException e) {
                return null;
            }
        }
    }

    public enum TemplateOrientation {
        PORTRAIT,
        LANDSCAPE
    }

    public static BaseTemplate create(
            Context context, TemplateType type, TemplateOrientation orientation) {
        switch (type) {
            case TEMPLATE_TYPE_300x250_1:
                switch (orientation) {
                    case PORTRAIT:
                        return new Portrait300x250Template(context);
                    case LANDSCAPE:
                        return new Landscape300x250Template(context);
                }
            case TEMPLATE_TYPE_FULL_SCREEN:
                return new FullScreenTemplate(context);
        }
        LogUtils.i("not found template type [" + type + "].");
        return null;
    }
}
