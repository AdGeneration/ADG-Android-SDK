package com.socdm.d.adgeneration;

import android.location.Location;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import jp.supership.sscore.adid.SSCoreAdId;
import jp.supership.sscore.device.SSCoreAppInfo;
import jp.supership.sscore.device.SSCoreDevice;
import jp.supership.sscore.type.Optional;

import java.util.List;

/** 広告リクエストパラメータ */
final class AdRequest {
    /** 1リクエストでの広告取得数 */
    static final int SCHEDULE_COUNT = 1;

    /** 広告枠ID */
    @Nullable final String locationId;
    /** エラーになったレスポンスのscheduleId */
    @NonNull final List<String> errorScheduleIds;

    final boolean isMraidEnabled;
    /** Header biddingのためのパラメータ */
    @NonNull final HeaderBiddingParams headerBiddingParams;
    /** ラベルターゲティング */
    @NonNull final LabelTargeting labelTargeting;

    final int fillerLimit;
    /** Child Directedが有効かどうか */
    final boolean isChildDirectedEnabled;
    /** 1リクエストでの広告取得数 */
    final int scheduleCount;
    /** ADG SDKバージョン */
    @NonNull final String sdkVersion;
    /** デバイス情報 */
    @NonNull Optional<SSCoreDevice> device = Optional.empty();
    /** アプリ情報 */
    @NonNull Optional<SSCoreAppInfo> appInfo = Optional.empty();
    /** 位置情報 */
    @NonNull Optional<Location> location = Optional.empty();
    /** 広告ID */
    @NonNull Optional<SSCoreAdId> adId = Optional.empty();

    AdRequest(
            @Nullable final String locationId,
            @NonNull final List<String> errorScheduleIds,
            final boolean isMraidEnabled,
            @NonNull final HeaderBiddingParams headerBiddingParams,
            @NonNull final LabelTargeting labelTargeting,
            final int fillerLimit,
            final boolean isChildDirectedEnabled) {
        this.locationId = locationId;
        this.errorScheduleIds = errorScheduleIds;
        this.isMraidEnabled = isMraidEnabled;
        this.headerBiddingParams = headerBiddingParams;
        this.labelTargeting = labelTargeting;
        this.fillerLimit = fillerLimit;
        this.isChildDirectedEnabled = isChildDirectedEnabled;
        this.scheduleCount = SCHEDULE_COUNT;
        this.sdkVersion = ADGConsts.SDKVERSION;
    }

    @NonNull
    @Override
    public String toString() {
        return "AdRequest {\n"
                + "locationId: "
                + locationId
                + ",\n"
                + "errorScheduleIds: "
                + errorScheduleIds
                + ",\n"
                + "isMraidEnabled: "
                + isMraidEnabled
                + ",\n"
                + "headerBiddingParams: "
                + headerBiddingParams
                + ",\n"
                + "labelTargeting: "
                + labelTargeting
                + ",\n"
                + "isChildDirectedEnabled: "
                + isChildDirectedEnabled
                + ",\n"
                + "scheduleCount: "
                + scheduleCount
                + ",\n"
                + "location: "
                + location
                + ",\n"
                + "sdkVersion: "
                + sdkVersion
                + ",\n"
                + "device: "
                + device
                + ",\n"
                + "appInfo: "
                + appInfo
                + ",\n"
                + "adId: "
                + adId
                + ",\n"
                + "fillerLimit: "
                + fillerLimit
                + ",\n"
                + "}";
    }
}
