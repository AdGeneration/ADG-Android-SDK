package com.socdm.d.adgeneration.impression;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.viewable.ViewableParameter;

import jp.supership.sscore.tracking.SSCoreTrackingEvent;
import jp.supership.sscore.tracking.SSCoreTrackingEventSendable;
import jp.supership.sscore.type.Optional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** インプレッション関連のトラッキングイベントインターフェースです */
public interface ImpressionTracking {
    /**
     * 広告読み込み時に発火させるイベントを取得します
     *
     * @return 広告読み込み時に発火させるイベント
     */
    @NonNull
    List<SSCoreTrackingEvent> getLoadTriggerEvents();

    /**
     * インプレッションイベントを取得します
     *
     * @return インプレッションイベント
     */
    @NonNull
    Map<String, ImpressionData> getImpressions();

    /**
     * 有効なViewable計測パラメータを生成します。このパラメータをもとにViewable計測を機能させ、 条件が満たされたとき、 {@link
     * ImpressionTracking#sendImpressions(String, SSCoreTrackingEventSendable, OnProgressListener)}
     * メソッドを呼んでください
     *
     * @return Viewable計測パラメータ
     */
    @NonNull
    default List<ViewableParameter> getViewableParameters() {
        final List<ViewableParameter> parameters = new ArrayList<>();

        for (final ImpressionData data : getImpressions().values()) {
            final ViewableParameter parameter =
                    new ViewableParameter(data.key, data.ratio, data.getDurationInSeconds());

            // 無効なパラメータを除外
            if (parameter.ratio > 0 && parameter.duration > 0) {
                parameters.add(parameter);
            }
        }

        return parameters;
    }

    /**
     * 広告読み込み時にこのメソッドを呼び、トラッキングイベントを送信してください
     *
     * @param sender トラッキングイベントを送信するためのオブジェクト
     * @param listener トラッキングイベントごとに送信結果をコールバックします
     */
    default void sendLoadTriggerEvents(
            @NonNull final SSCoreTrackingEventSendable sender,
            @Nullable final OnProgressListener listener) {
        for (final SSCoreTrackingEvent event : getLoadTriggerEvents()) {
            event.fire(
                    sender,
                    error -> {
                        if (listener != null) {
                            listener.onProgress(event.getUrl(), error);
                        }
                    });
        }
    }

    /**
     * 指定された条件(表示面積と表示時間)を満たした場合、このメソッドを呼び、トラッキングイベントを送信してください
     *
     * @param key 識別キー
     * @param sender トラッキングイベントを送信するためのオブジェクト
     * @param listener トラッキングイベントごとに送信結果をコールバックします
     */
    default void sendImpressions(
            @NonNull final String key,
            @NonNull final SSCoreTrackingEventSendable sender,
            @Nullable final OnProgressListener listener) {
        final ImpressionData data = getImpressions().get(key);
        if (data != null) {
            for (final SSCoreTrackingEvent event : data.getEvents()) {
                event.fire(
                        sender,
                        error -> {
                            if (listener != null) {
                                listener.onProgress(event.getUrl(), error);
                            }
                        });
            }
        }
    }

    /**
     * すべての広告読み込み時トリガーイベントが発火したかどうかを確認します
     *
     * @return すべての広告読み込み時トリガーイベントが発火した場合はtrue、それ以外はfalse
     */
    default boolean areLoadTriggerEventsFired() {
        for (final SSCoreTrackingEvent event : getLoadTriggerEvents()) {
            if (!event.isFired()) {
                return false;
            }
        }
        return true;
    }

    /**
     * すべてのインプレッションイベントが発火したかどうかを確認します
     *
     * @return すべてのインプレッションイベントが発火した場合はtrue、それ以外はfalse
     */
    default boolean areAllImpressionsFired() {
        for (final ImpressionData data : getImpressions().values()) {
            for (final SSCoreTrackingEvent event : data.getEvents()) {
                if (!event.isFired()) {
                    return false;
                }
            }
        }
        return true;
    }

    /** 進捗通知用のリスナーです */
    interface OnProgressListener {
        /**
         * 進捗通知時に呼ばれます
         *
         * @param url 処理されたURL
         * @param error エラー情報。成功時は {@link Optional#empty()} が渡されます
         */
        void onProgress(@NonNull String url, @NonNull Optional<Exception> error);
    }
}
