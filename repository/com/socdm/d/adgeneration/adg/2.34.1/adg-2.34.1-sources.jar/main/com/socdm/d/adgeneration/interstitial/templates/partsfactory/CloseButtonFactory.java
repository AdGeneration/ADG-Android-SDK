package com.socdm.d.adgeneration.interstitial.templates.partsfactory;

import android.content.Context;

import com.socdm.d.adgeneration.interstitial.templates.parts.CBImageView;
import com.socdm.d.adgeneration.interstitial.templates.parts.CloseButton;

import java.util.List;

@Deprecated
public abstract class CloseButtonFactory {

    private Context ct;
    private int designType = 0;

    private static final String CUSTOM_ASSETS_PREFIX = "adg_interstitial_close_button_";

    public CloseButtonFactory(Context ct) {
        this.ct = ct;
    }

    public Context getContext() {
        return ct;
    }

    public int getDesignType() {
        return designType;
    }

    public void setDesignType(int designType) {
        this.designType = designType;
    }

    public abstract int getWidth();

    public abstract int getHeight();

    public abstract List<String> getAvailableItems();

    public CloseButton<?> get() {
        List<String> items = getAvailableItems();
        try {
            String fileName = items.get(designType);
            return new CBImageView(getContext(), getWidth(), getHeight(), fileName);
        } catch (IndexOutOfBoundsException e) {
            return new CBImageView(ct, getWidth(), getHeight(), fileName(designType));
        }
    }

    public String fileName(int n) {
        return CUSTOM_ASSETS_PREFIX + intToString3(n) + ".png";
    }

    public String intToString3(int n) {
        return (100 <= n && n < 1000) ? "" + n : "xxx";
    }
}
