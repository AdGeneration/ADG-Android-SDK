package com.socdm.d.adgeneration.utils;

import android.content.Context;
import androidx.annotation.NonNull;

import java.net.MalformedURLException;
import java.net.URL;

public class BeaconUtils {
    private static String userAgent;

    public static void applyUserAgent(@NonNull Context context) {
        if (userAgent == null || userAgent.length() == 0) {
            userAgent = HttpUtils.getUserAgent(context);
        }
    }

    public static void callBeacon(String beacon) {
        if (userAgent == null || userAgent.length() == 0) {
            LogUtils.e("Invalid UserAgent.");
            return;
        }

        final URL beaconURL;
        try {
            beaconURL = new URL(beacon);
        } catch (NullPointerException | IllegalArgumentException | MalformedURLException e) {
            LogUtils.d("Invalid URL:" + e.getMessage());
            return;
        }

        HttpURLConnectionTask requestTask = new HttpURLConnectionTask(beaconURL.toString(), new AsyncTaskListener<String>() {
            @Override
            public void onSuccess(String s) {
                LogUtils.d("Beacon request succeed. " + beaconURL.toString());
            }

            @Override
            public void onError(Exception e) {
                LogUtils.d("Beacon request failed.(" + e.getMessage() + ") " + beaconURL.toString());
            }
        });
        requestTask.setUserAgent(userAgent);
        AsyncTaskUtils.execute(requestTask);
    }
}
