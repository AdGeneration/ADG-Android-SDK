package com.socdm.d.adgeneration.mediation;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.ViewGroup;

import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.IADGLogger;
import com.socdm.d.adgeneration.utils.LogUtils;

import java.util.ArrayList;
import java.util.List;

public class ADGNativeInterface {
    private Context ct;
    private ADGNativeInterfaceListener listener;
    private String className;
    private String adId;
    private String param;
    private ViewGroup layout;
    private Integer width;
    private Integer height;
    private Integer movie;
    private ADGNativeInterfaceChild childAd;
    private Boolean calledStart = false;
    private Boolean enableSound = false;
    private Boolean enableTestMode = false;
    private Boolean usePartsResponse = false;
    private Boolean callNativeAdTrackers = true;
    private Boolean expandFrame = false;
    private Boolean isWipe = false;
    private String contentUrl;
    private String admPayload;
    private String bidderSuccessfulName;
    private ArrayList<String> biddingNotifyUrl;

    private static final List<String> errorClassNames = new ArrayList<String>();
    private boolean isShowingOriginInterstitial = false;
    private boolean isOriginInterstitial = false;
    private static final int CONDITION_BORDER = 2;

    private Handler handler = new Handler(Looper.myLooper());
    private final IADGLogger logger;
    private final MediationController controller;

    public ADGNativeInterface(MediationModel model, IADGLogger logger) {
        super();
        this.logger = logger;
        this.controller = new MediationController(model, mediationControllerListener, logger);
    }

    public static boolean isValidClassName(@Nullable final String name) {
        if (TextUtils.isEmpty(name)) return false;

        final String className = MediationClassNameMapper.getCorrectClassName(name);
        try {
            Class.forName(className);
        } catch (ClassNotFoundException e) {
            addErrorClassName(className);
            return false;
        }

        if (errorClassNames != null) {
            return !errorClassNames.contains(className);
        }
        return true;
    }

    private static int numOfInvalidClasses() {
        if (errorClassNames != null) {
            return errorClassNames.size();
        }
        return 0;
    }

    public static boolean isNormalCondition() {
        return numOfInvalidClasses() < CONDITION_BORDER;
    }

    private static void addErrorClassName(String str) {
        if (errorClassNames != null) {
            if (errorClassNames.indexOf(str) < 0) {
                errorClassNames.add(str);
            }
        }
    }

    public boolean isShowingOriginInterstitial() {
        return isShowingOriginInterstitial;
    }

    public boolean isOriginInterstitial() {
        return isOriginInterstitial;
    }

    public void setContext(Context ct) {
        this.ct = ct;
    }

    public void setListener(ADGNativeInterfaceListener listener) {
        this.listener = listener;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public void setAdId(String adId) {
        this.adId = adId;
    }

    public void setMovie(int movie) {
        this.movie = movie;
    }

    public void setParam(String param) {
        this.param = param;
    }

    public void setExpandFrame(boolean expandFrame) {
        this.expandFrame = expandFrame;
    }

    public void setLayout(ViewGroup layout) {
        this.layout = layout;
    }

    public void setSize(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public void setEnableSound(Boolean enableSound) {
        this.enableSound = enableSound;
    }

    public void setEnableTestMode(Boolean enableTestMode) {
        this.enableTestMode = enableTestMode;
    }

    public void setUsePartsResponse(Boolean usePartsResponse) {
        this.usePartsResponse = usePartsResponse;
    }

    public void setCallNativeAdTrackers(Boolean callNativeAdTrackers) {
        this.callNativeAdTrackers = callNativeAdTrackers;
    }

    public void setContentUrl(String url) {
        this.contentUrl = url;
    }

    public void setIsWipe(boolean isWipe) {
        this.isWipe = isWipe;
    }

    public void setAdmPayload(String admPayload) {
        this.admPayload = admPayload;
    }

    public void setBidderSuccessfulName(String bidderSuccessfulName) {
        this.bidderSuccessfulName = bidderSuccessfulName;
    }

    public void setBiddingNotifyUrl(ArrayList<String> biddingNotifyUrl) {
        this.biddingNotifyUrl = biddingNotifyUrl;
    }

    public void callWhenInView() {
        if (this.childAd != null) {
            this.childAd.callWhenInView();
        }
    }

    public void callWhenOutOfView() {
        if (this.childAd != null) {
            this.childAd.callWhenOutOfView();
        }
    }

    public Boolean loadChild(@Nullable final String locationId) {
        if (this.className == null || this.className.length() < 1) {
            return false;
        }

        this.className = MediationClassNameMapper.getCorrectClassName(className);

        if (!isValidClassName(this.className)) {
            return false;
        }

        try {
            Class<?> cls = Class.forName(this.className);
            this.childAd = (ADGNativeInterfaceChild) cls.newInstance();
        } catch (InstantiationException
                | ClassNotFoundException
                | IllegalAccessException
                | ClassCastException
                | NoClassDefFoundError e) {
            return errorProcess(e);
        }

        this.childAd.setLocationId(locationId);
        this.childAd.setContext(this.ct);
        this.childAd.setAdId(this.adId);
        this.childAd.setParam(this.param);
        this.childAd.setLayout(this.layout);
        this.childAd.setSize(this.width, this.height);
        this.childAd.setEnableSound(this.enableSound);
        this.childAd.setEnableTestMode(this.enableTestMode);
        this.childAd.setExpandFrame(this.expandFrame);
        this.childAd.setUsePartsResponse(this.usePartsResponse);
        this.childAd.setCallNativeAdTrackers(this.callNativeAdTrackers);
        this.childAd.setContentUrl(this.contentUrl);
        this.childAd.setIsWipe(this.isWipe);
        this.childAd.setAdmPayload(this.admPayload);
        this.childAd.setBidderSuccessfulName(this.bidderSuccessfulName);
        this.childAd.setBiddingNotifyUrl(this.biddingNotifyUrl);
        this.childAd.setListener(
                new ADGNativeInterfaceChildListener() {
                    @Override
                    public void onReceiveAd() {
                        beforeListener();
                        if (listener != null) {
                            listener.onReceiveAd();
                        }
                    }

                    @Override
                    public void onReceiveAd(Object nativeAd) {
                        beforeListener();
                        if (listener != null) {
                            listener.onReceiveAd(nativeAd);
                        }
                    }

                    @Override
                    public void onFailedToReceiveAd() {
                        beforeListener();
                        if (listener != null) {
                            listener.onFailedToReceiveAd();
                        }
                    }

                    @Override
                    public void onCompleteMovieAd() {
                        controller.isMovieCompleted = true;
                        beforeListener();
                        controller.setMediationTimer();
                    }

                    @Override
                    public void onCloseInterstitial() {
                        isShowingOriginInterstitial = false;
                        if (listener != null) {
                            listener.onCloseInterstitial();
                        }
                    }

                    @Override
                    public void onShowInterstitial() {
                        isShowingOriginInterstitial = true;
                    }

                    @Override
                    public void onClickAd() {
                        if (listener != null) {
                            listener.onClickAd();
                        }
                    }

                    @Override
                    public void onReplayMovieAd() {
                        controller.clearMediationTimer();
                    }

                    @Override
                    public void onReadyMediation(Object mediation) {
                        if (listener != null) {
                            listener.onReadyMediation(mediation);
                        }
                    }

                    @Override
                    public void onSuccessfulBidder(String bidderSuccessfulName) {
                        listener.onSuccessfulBidder(bidderSuccessfulName);
                    }
                });

        if (this.childAd.checkOSVersion() != true) {
            writeLog("Not supported OS");
            addErrorClassName(className);
            return false;
        }

        try {
            controller.isProcessing = this.childAd.loadProcess();
        } catch (NoClassDefFoundError e) {
            return errorProcess(e);
        }
        isOriginInterstitial = this.childAd.isOriginInterstitial;
        return this.controller.isProcessing;
    }

    public void startChild() {
        controller.setMediationTimer();

        if (this.childAd != null) {
            if (!this.calledStart) {
                this.calledStart = true;
                this.childAd.startProcess();
            }
        }
    }

    public void stopChild() {
        controller.clearMediationTimer();

        if (this.childAd != null) {
            this.childAd.stopProcess();
        }
    }

    public void finishChild() {
        controller.clearMediationTimer();
        clearFlag();
        if (this.childAd != null) {
            this.childAd.finishProcess();
            this.childAd = null;
        }
    }

    // 現在はメディエーションはすべてtrue
    public Boolean isLateImp() {
        return true;
    }

    private Boolean errorProcess(Throwable e) {
        addErrorClassName(this.className);
        writeLog(e.getMessage());
        this.childAd = null;
        return false;
    }

    private void beforeListener() {
        controller.isProcessing = false;
    }

    public void resumeMediationTimer() {
        controller.resumeMediationTimer();
    }

    public void pauseMediationTimer() {
        controller.pauseMediationTimer();
    }

    private void clearFlag() {
        isShowingOriginInterstitial = false;
        isOriginInterstitial = false;
    }

    private void writeLog(String str) {
        LogUtils.w("Mediation Error:" + str);
    }

    private final MediationController.MediationControllerListener mediationControllerListener =
            new MediationController.MediationControllerListener() {
                @Override
                public void onReachedRotation() {
                    listener.onReachRotateTime();
                }

                @Override
                public void onTimedOut() {
                    listener.onFailedToReceiveAd();
                }
            };
}
