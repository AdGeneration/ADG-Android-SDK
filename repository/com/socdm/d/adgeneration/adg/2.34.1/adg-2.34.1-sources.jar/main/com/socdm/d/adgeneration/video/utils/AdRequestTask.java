package com.socdm.d.adgeneration.video.utils;

import android.content.Context;
import android.os.AsyncTask;

import com.socdm.d.adgeneration.utils.HttpUtils;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.ADGPlayerError;
import com.socdm.d.adgeneration.video.config.Const;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

public class AdRequestTask extends AsyncTask<URL, Integer, String> {
    public static final String SUCCESS = "success";
    public static final String FAILED = "failed";

    private AdRequestTaskListener listener;
    private Map<String, List<String>> responseHeader;
    private String responseBody;
    private Context mContext;

    public interface AdRequestTaskListener {
        void onPostExecute(Map<String, List<String>> header, String body);

        void onCancelled();
    }

    public AdRequestTask(AdRequestTaskListener asyncCallback, Context context) {
        this.listener = asyncCallback;
        this.mContext = context;
    }


    protected String doInBackground(URL... urls) {
        InputStream in = null;
        try {
            HttpURLConnection connection = (HttpURLConnection) urls[0].openConnection();
            connection.setUseCaches(false);
            connection.setRequestMethod("GET");
            connection.setReadTimeout(Const.HTTP_REQUEST_TIMEOUT);
            String userAgent = HttpUtils.getUserAgent(mContext);
            if (userAgent != null) {
                connection.setRequestProperty("User-Agent", userAgent);
            }
            connection.connect();

            in = connection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            responseBody = sb.toString();
            responseHeader = connection.getHeaderFields();
            return SUCCESS;
        } catch (Exception e) {
            LogUtils.e(ADGPlayerError.NETWORK_ERROR.toString(), e);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                    LogUtils.e(ADGPlayerError.UNSPECIFIED.toString(), e);
                }
            }
        }

        return FAILED;
    }

    protected void onPostExecute(String result) {
        super.onPostExecute(result);
        if (this.listener != null) {
            this.listener.onPostExecute(responseHeader, responseBody);
        }
    }

    protected void onCancelled() {
        super.onCancelled();
        if (this.listener != null) {
            this.listener.onCancelled();
        }
    }

}
