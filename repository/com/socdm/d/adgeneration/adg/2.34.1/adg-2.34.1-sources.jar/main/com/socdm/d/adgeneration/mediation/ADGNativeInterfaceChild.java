package com.socdm.d.adgeneration.mediation;

import android.content.Context;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.utils.LogUtils;

import jp.supership.sscore.type.Optional;

import java.util.ArrayList;

public abstract class ADGNativeInterfaceChild {
    protected Context ct;
    protected ADGNativeInterfaceChildListener listener;
    protected String adId;
    protected String param;
    protected ViewGroup layout;
    protected Integer width;
    protected Integer height;
    protected Boolean isOriginInterstitial = false;
    protected Boolean enableSound = false;
    protected Boolean enableTestMode = false;
    protected Boolean usePartsResponse = false;
    protected Boolean callNativeAdTrackers = true;
    protected Boolean expandFrame = false;
    protected String contentUrl;
    protected Boolean isWipe = false;
    protected String admPayload;
    protected String bidderSuccessfulName;
    protected ArrayList<String> biddingNotifyUrl;
    @NonNull protected Optional<String> locationId = Optional.empty();

    public void setContext(Context ct) {
        this.ct = ct;
    }

    public void setListener(ADGNativeInterfaceChildListener listener) {
        this.listener = listener;
    }

    public void setAdId(String adId) {
        this.adId = adId;
    }

    public void setParam(String param) {
        this.param = param;
    }

    public void setLayout(ViewGroup layout) {
        this.layout = layout;
    }

    public void setSize(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public boolean checkOSVersion() {
        return true;
    }

    public boolean isOriginInterstitial() {
        return isOriginInterstitial;
    }

    public void setEnableSound(Boolean enableSound) {
        this.enableSound = enableSound;
    }

    public void setEnableTestMode(Boolean enableTestMode) {
        this.enableTestMode = enableTestMode;
    }

    public void setUsePartsResponse(Boolean usePartsResponse) {
        this.usePartsResponse = usePartsResponse;
    }

    public void setCallNativeAdTrackers(Boolean callNativeAdTrackers) {
        this.callNativeAdTrackers = callNativeAdTrackers;
    }

    public void setExpandFrame(boolean expandFrame) {
        this.expandFrame = expandFrame;
    }

    public void setContentUrl(String url) {
        this.contentUrl = url;
    }

    public void setIsWipe(Boolean isWipe) {
        this.isWipe = isWipe;
    }

    public void setAdmPayload(String admPayload) {
        this.admPayload = admPayload;
    }

    public void setBidderSuccessfulName(String bidderSuccessfulName) {
        this.bidderSuccessfulName = bidderSuccessfulName;
    }

    public void setBiddingNotifyUrl(ArrayList<String> biddingNotifyUrl) {
        this.biddingNotifyUrl = biddingNotifyUrl;
    }

    public void setLocationId(@Nullable final String locationId) {
        this.locationId = Optional.of(locationId);
    }

    public void errorProcess(Exception e) {
        LogUtils.w(e.getMessage());
    }

    public void callWhenInView() {}

    public void callWhenOutOfView() {}

    public abstract boolean loadProcess();

    public abstract void startProcess();

    @Deprecated
    public abstract void stopProcess();

    public abstract void finishProcess();
}
