package com.socdm.d.adgeneration.viewable;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ScrollView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.IADGLogger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * このクラスは、Viewable計測において、対象のViewに重なっているViewを障害物として扱い、そのViewとの交差判定を追加で行います。
 * 障害物によって指定の表示割合を下回る場合は非表示と判定されます
 */
public final class ViewableObstacleMeasurement extends ViewableMeasurement {
    @NonNull private static final List<String> obstacleViewNamesToIgnore = new ArrayList<>();

    /**
     * 無視する障害物Viewのクラス名を追加します
     *
     * @param className <code>getClass().getName()</code> で取得できるクラス名
     */
    public static synchronized void addObstacleViewNameToIgnore(@NonNull final String className) {
        obstacleViewNamesToIgnore.add(className);
    }

    /**
     * インスタンスを生成します。計測パラメータはデフォルト値が採用されます
     *
     * @param tag タグ名
     * @param context アプリケーションコンテキスト
     * @param view 計測対象のView
     * @param logger ロガー
     */
    public ViewableObstacleMeasurement(
            @NonNull final String tag,
            @NonNull final Context context,
            @NonNull final View view,
            @Nullable final IADGLogger logger) {
        super(tag, context, view, logger);
    }

    /**
     * インスタンスを生成します
     *
     * @param tag タグ名
     * @param context アプリケーションコンテキスト
     * @param view 計測対象のView
     * @param parameters 計測パラメータ
     * @param logger ロガー
     */
    public ViewableObstacleMeasurement(
            @NonNull final String tag,
            @NonNull final Context context,
            @NonNull final View view,
            @NonNull final ViewableParameters parameters,
            @Nullable final IADGLogger logger) {
        super(tag, context, view, parameters, logger);
    }

    @Override
    @NonNull
    protected List<VisibleResult> isVisible(
            @NonNull final View view, @NonNull final ViewableParameters parameters) {
        final List<ViewableParameter> viewableParameters = parameters.getParameters();

        if (view.getWindowVisibility() != View.VISIBLE
                || view.getVisibility() != View.VISIBLE
                || !view.isShown()) {
            return VisibleResult.resultsAsInvisible(viewableParameters);
        }

        return isVisibleConsideringOverlap(view, parameters);
    }

    /**
     * 指定したViewが画面に表示されているかどうかを返します。障害物が存在する場合を考慮します
     *
     * @param view 対象のView
     * @param parameters 計測パラメータ。表示割合以上画面に表示されていればtrueと判定されます
     * @return 各計測パラメータごとの判定結果
     */
    @NonNull
    private List<VisibleResult> isVisibleConsideringOverlap(
            @NonNull final View view, @NonNull final ViewableParameters parameters) {
        final List<ViewableParameter> viewableParameters = parameters.getParameters();

        final ViewGroup rootView = (ViewGroup) view.getRootView();
        if (rootView == null) {
            return VisibleResult.resultsAsInvisible(viewableParameters);
        }

        // 対象Viewの面積
        final int originalArea = view.getWidth() * view.getHeight();

        // contentView(action barが含まれない)の画面上の位置
        final ViewGroup contentView = view.getRootView().findViewById(android.R.id.content);
        if (contentView == null) {
            return VisibleResult.resultsAsInvisible(viewableParameters);
        }
        final Rect contentViewFrameInWindowCoord = createRectInWindow(contentView);

        // 画面に表示されている面積を計算
        final Rect visibleRect = createVisibleRectInWindow(view, contentViewFrameInWindowCoord);
        if (visibleRect == null) {
            // 画面内に表示されていない
            return VisibleResult.resultsAsInvisible(viewableParameters);
        }
        final int visibleArea = visibleRect.width() * visibleRect.height();

        // 表示されている割合が最小の割合未満の場合は非表示判定
        if (visibleArea < (originalArea * parameters.getMinimumRatio())) {
            return VisibleResult.resultsAsInvisible(viewableParameters);
        }

        // 重なっているViewを探索して障害物領域を計算
        final List<String> obstacleViewNames = new ArrayList<>();
        final List<Rect> obstacles =
                findObstacles(
                        rootView,
                        view,
                        visibleRect,
                        contentViewFrameInWindowCoord,
                        obstacleViewNames);

        // 障害となる領域を構成する矩形の配列を生成し、面積を計算
        final ObstacleRects obstacleRects = new ObstacleRects(obstacles);
        final int obstacleArea = obstacleRects.calculateArea();

        // 画面表示領域から重なっている領域を除いた表示領域を計算
        final double trueVisibleArea = visibleArea - obstacleArea;

        logger.ifPresent(
                l ->
                        l.getLogger()
                                .debug(
                                        String.format(
                                                Locale.ENGLISH,
                                                "\ntag=%s\n"
                                                        + "parameters=%s\n"
                                                        + "visibleArea=%f\n"
                                                        + "percentageInView=%.1f%%\n"
                                                        + "visibleRect=%s\n"
                                                        + "originalArea=%d\n"
                                                        + "obstacles=%s\n"
                                                        + "obstacleArea=%d\n"
                                                        + "obstacleViewNames=%s",
                                                tag,
                                                viewableParameters,
                                                trueVisibleArea,
                                                (trueVisibleArea * 100.0 / originalArea),
                                                visibleRect,
                                                originalArea,
                                                obstacleRects.getRects(),
                                                obstacleArea,
                                                obstacleViewNames)));

        final List<VisibleResult> results = new ArrayList<>(viewableParameters.size());
        for (ViewableParameter parameter : viewableParameters) {
            results.add(
                    new VisibleResult(
                            trueVisibleArea >= (originalArea * parameter.ratio), parameter));
        }

        return results;
    }

    /**
     * 指定したViewに重なっているViewを探索し、障害物となる領域を計算します
     *
     * @param rootView ルートView
     * @param targetView 対象View
     * @param targetRect 対象Viewのウィンドウ座標系におけるRect
     * @param contentViewFrame ウィンドウ座標系におけるcontentViewのRect
     * @return 障害物となる領域のリスト
     */
    @NonNull
    private List<Rect> findObstacles(
            @NonNull final ViewGroup rootView,
            @NonNull final View targetView,
            @NonNull final Rect targetRect,
            @NonNull final Rect contentViewFrame,
            @NonNull final List<String> outObstacleViewNames) {

        final List<Rect> obstacles = new ArrayList<>();

        final List<View> subviews = allSubviews(rootView);
        Collections.reverse(subviews);

        for (int i = 0; i < subviews.size(); i++) {
            final View other = subviews.get(i);

            // 対象Viewに到達したら探索終了
            if (other == targetView) {
                break;
            }

            // 非表示のViewは除外
            if (other.getVisibility() != View.VISIBLE || other.getAlpha() == 0) {
                continue;
            }

            // 対象Viewの子Viewは除外
            if (isDescendantOf(other, targetView)) {
                continue;
            }

            // ViewのRect取得
            final Rect viewRect = createVisibleRectInWindow(other, contentViewFrame);
            if (viewRect == null) {
                // 画面内に表示されていない
                continue;
            }

            // 交差判定
            final Rect intersection = new Rect();
            if (intersection.setIntersect(targetRect, viewRect)) {
                //                logger.ifPresent(
                //                        l ->
                //                                l.getLogger()
                //                                        .debug(
                //                                                "\ntag="
                //                                                        + tag
                //                                                        + "\nobstacle="
                //                                                        + other
                //                                                        + "\nobstacleVisibleRect="
                //                                                        + viewRect
                //                                                        + "\nintersection="
                //                                                        + intersection));
                obstacles.add(intersection);
                outObstacleViewNames.add(other.getClass().getSimpleName());
            }
        }

        return obstacles;
    }

    /**
     * 指定したViewを含むView階層における全てのViewをリストで返します。 リストは最背面のViewから最前面のViewの順に格納されます
     *
     * @param view 対象View
     * @return Viewリスト
     */
    @NonNull
    private static List<View> allSubviews(@NonNull final View view) {
        final List<View> views = new ArrayList<>();

        // 無視する障害物Viewは子Viewを含めサブビューリストに入れない
        if (obstacleViewNamesToIgnore.contains(view.getClass().getName())) {
            return views;
        }

        views.add(view);

        if (view instanceof ViewGroup) {
            final ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                views.addAll(allSubviews(viewGroup.getChildAt(i)));
            }
        }

        return views;
    }

    /**
     * View階層において、指定したViewの先祖にScrollViewが存在すれば、ScrollViewを返します
     *
     * @param view 対象View
     * @return ScrollViewが存在する場合はScrollView、それ以外はnull
     */
    @Nullable
    private static ScrollView findScrollViewAncestor(@NonNull final View view) {
        ViewParent parent = view.getParent();
        while (parent != null) {
            if (parent instanceof ScrollView) {
                return (ScrollView) parent;
            }
            parent = parent.getParent();
        }
        return null;
    }

    /**
     * <code>view1</code> が <code>view2</code> の子孫であるかどうかを返します
     *
     * @param view1 対象View
     * @param view2 先祖View
     * @return 子孫である場合はtrue、それ以外はfalse
     */
    private static boolean isDescendantOf(@NonNull final View view1, @NonNull final View view2) {
        ViewParent ancestor = view1.getParent();
        while (ancestor != null) {
            if (ancestor == view2) {
                return true;
            }
            ancestor = ancestor.getParent();
        }
        return false;
    }

    /**
     * 指定したViewのウィンドウ座標系におけるRectを生成します
     *
     * @param view 対象View
     * @return 対象Viewのウィンドウ座標系におけるRect
     */
    @NonNull
    private static Rect createRectInWindow(@NonNull final View view) {
        final int[] point = {view.getLeft(), view.getTop()};
        view.getLocationInWindow(point);
        return new Rect(
                point[0], point[1], point[0] + view.getWidth(), point[1] + view.getHeight());
    }

    /**
     * 指定したViewが画面に表示されている場合のRectを生成します。 ScrollView内に存在する場合は、ScrollView内の表示領域を考慮します。
     * 画面内に表示されていない場合はnullを返します
     *
     * @param view 対象View
     * @param contentViewFrameInWindowCoord contentViewのウィンドウ座標系におけるRect
     * @return 画面に表示されている場合のRect、画面内に表示されていない場合はnull
     */
    @Nullable
    private static Rect createVisibleRectInWindow(
            @NonNull final View view, @NonNull final Rect contentViewFrameInWindowCoord) {
        final Rect viewFrameInWindowCoord = createRectInWindow(view);

        // 画面に表示されている面積を計算
        final Rect visibleRectInWindow = new Rect();
        if (!visibleRectInWindow.setIntersect(
                viewFrameInWindowCoord, contentViewFrameInWindowCoord)) {
            // 画面内に表示されていない
            return null;
        }

        // ScrollView内の表示領域を考慮
        final ScrollView scrollView = findScrollViewAncestor(view);
        final Rect visibleRect;
        if (scrollView != null) {
            final Rect scrollViewFrameInWindowCoord = createRectInWindow(scrollView);

            // ScrollViewに表示されている面積を計算
            final Rect intersection = new Rect();
            if (!intersection.setIntersect(viewFrameInWindowCoord, scrollViewFrameInWindowCoord)) {
                // ScrollView内に表示されていない
                return null;
            }

            visibleRect = intersection;
        } else {
            // ScrollView内にいなければウィンドウ座標系の面積を使う
            visibleRect = visibleRectInWindow;
        }

        return visibleRect;
    }
}
