package com.socdm.d.adgeneration.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class DisplayUtils {
    @SuppressLint("NewApi")
    @SuppressWarnings("deprecation")
    public static Point getClientSize(Activity activity) {
        Point point = new Point(0, 0);
        if (activity != null) {
            Display display = activity.getWindowManager().getDefaultDisplay();
            if (Integer.valueOf(android.os.Build.VERSION.SDK_INT) < 13) {
                point.x = display.getWidth();
                point.y = display.getHeight();
            } else {
                display.getSize(point);
            }
        }
        return point;
    }

    public static Size getScreenSize(Context context) {
        Integer bestWidthPixels = null;
        Integer bestHeightPixels = null;

        final WindowManager windowManager =
                (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        final Display display = windowManager.getDefaultDisplay();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            final Point screenSize = new Point();
            display.getRealSize(screenSize);
            bestWidthPixels = screenSize.x;
            bestHeightPixels = screenSize.y;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            try {
                Method getRawWidth = Display.class.getMethod("getRawWidth");
                Method getRawHeight = Display.class.getMethod("getRawHeight");
                bestWidthPixels = (Integer) getRawWidth.invoke(display);
                bestHeightPixels = (Integer) getRawHeight.invoke(display);
            } catch (Exception e) {
                // Best effort. If this fails, just get the height and width normally,
                // which may not capture the pixels used in the notification bar.
                LogUtils.w("Display#getRawWidth/Height failed.", e);
            }
        } else {
            bestWidthPixels = display.getWidth();
            bestHeightPixels = display.getHeight();
        }

        if (bestWidthPixels == null || bestHeightPixels == null) {
            final DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
            bestWidthPixels = displayMetrics.widthPixels;
            bestHeightPixels = displayMetrics.heightPixels;
        }

        return new Size(bestWidthPixels, bestHeightPixels);
    }

    public static int getScreenHeightPx(Resources r) {
        LogUtils.d(
                "r.getConfiguration().screenHeightDp: "
                        + getPixels(r, r.getConfiguration().screenHeightDp));
        return getPixels(r, r.getConfiguration().screenHeightDp);
    }

    public static int getScreenWidthPx(Resources r) {
        LogUtils.d(
                "r.getConfiguration().screenWidthDp: "
                        + getPixels(r, r.getConfiguration().screenWidthDp));
        return getPixels(r, r.getConfiguration().screenWidthDp);
    }

    public static int getActionBarSize(Activity activity) {
        TypedArray actionBarSizeAttributes =
                activity.getTheme()
                        .obtainStyledAttributes(new int[] {android.R.attr.actionBarSize});
        int mActionBarSize = (int) actionBarSizeAttributes.getDimension(0, 0);
        actionBarSizeAttributes.recycle();
        return mActionBarSize;
    }

    public static boolean getActionBarShowing(Activity activity) {
        android.app.ActionBar actionBar = activity.getActionBar();
        if (actionBar != null) {
            return actionBar.isShowing();
        }
        try {
            Class<?> AppCompatActivityCls =
                    Class.forName("android.support.v7.app.AppCompatActivity");
            if (AppCompatActivityCls.isInstance(activity)) {
                Object appCompatActionBar =
                        activity.getClass().getMethod("getSupportActionBar").invoke(activity);
                if (appCompatActionBar != null) {
                    return (boolean)
                            appCompatActionBar
                                    .getClass()
                                    .getMethod("isShowing")
                                    .invoke(appCompatActionBar);
                }
            }
        } catch (ClassNotFoundException ignore) {
            LogUtils.d(ignore.getMessage());
            // support-v7をimplementしてない場合はAndroidXも確認する。
            return getActionBarShowingWithAndroidX(activity);
        } catch (NoSuchMethodException ignore) {
            LogUtils.d(ignore.getMessage());
            // support-v7をimplementしてない場合はAndroidXも確認する。
            return getActionBarShowingWithAndroidX(activity);
        } catch (IllegalAccessException ignore) {
            LogUtils.d(ignore.getMessage());
            // support-v7をimplementしてない場合はAndroidXも確認する。
            return getActionBarShowingWithAndroidX(activity);
        } catch (InvocationTargetException ignore) {
            LogUtils.d(ignore.getMessage());
            // support-v7をimplementしてない場合はAndroidXも確認する。
            return getActionBarShowingWithAndroidX(activity);
        }
        return false;
    }

    private static boolean getActionBarShowingWithAndroidX(Activity activity) {
        android.app.ActionBar actionBar = activity.getActionBar();
        if (actionBar != null) {
            return actionBar.isShowing();
        }
        try {
            Class<?> AppCompatActivityCls =
                    Class.forName("androidx.appcompat.app.AppCompatActivity");
            if (AppCompatActivityCls.isInstance(activity)) {
                Object appCompatActionBar =
                        activity.getClass().getMethod("getSupportActionBar").invoke(activity);
                if (appCompatActionBar != null) {
                    return (boolean)
                            appCompatActionBar
                                    .getClass()
                                    .getMethod("isShowing")
                                    .invoke(appCompatActionBar);
                }
            }
        } catch (ClassNotFoundException ignore) {
            LogUtils.d(ignore.getMessage());
            // AndroidXをimplementしてない場合はfalseを返す。
            return false;
        } catch (NoSuchMethodException ignore) {
            LogUtils.d(ignore.getMessage());
            // AndroidXをimplementしてない場合はfalseを返す。
            return false;
        } catch (IllegalAccessException ignore) {
            LogUtils.d(ignore.getMessage());
            // AndroidXをimplementしてない場合はfalseを返す。
            return false;
        } catch (InvocationTargetException ignore) {
            LogUtils.d(ignore.getMessage());
            // AndroidXをimplementしてない場合はfalseを返す。
            return false;
        }
        return false;
    }

    public static Point getClientOrigin(Activity activity) {
        Point ret = new Point(0, 0);
        if (activity != null) {
            Rect rectagle = new Rect();
            activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rectagle);
            ret.set(rectagle.left, rectagle.top);
        }
        return ret;
    }

    /**
     * dp単位の値をピクセル単位の値に変換します
     *
     * @param r Resourcesオブジェクト
     * @param dipValue 変換したいdp単位の値
     * @return 変換後のピクセル単位の値
     */
    public static int getPixels(Resources r, int dipValue) {
        int px =
                (int)
                        TypedValue.applyDimension(
                                TypedValue.COMPLEX_UNIT_DIP, dipValue, r.getDisplayMetrics());
        return px;
    }

    /**
     * dp単位の値をピクセル単位の値に変換します
     *
     * @param r Resourcesオブジェクト
     * @param dipValue 変換したいdp単位の値
     * @return 変換後のピクセル単位の値
     */
    public static float getPixels(Resources r, float dipValue) {
        float px =
                TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP, dipValue, r.getDisplayMetrics());
        return px;
    }

    public static int getDip(Resources r, int pixels) {
        return (int) (pixels / (r.getDisplayMetrics().densityDpi / 160f));
    }

    public static float getDip(Resources r, float pixels) {
        return (pixels / (r.getDisplayMetrics().densityDpi / 160f));
    }

    @SuppressWarnings("deprecation")
    public static int getFP() {
        return android.os.Build.VERSION.SDK_INT < 8
                ? LayoutParams.FILL_PARENT
                : LayoutParams.MATCH_PARENT;
    }

    public static int getWC() {
        return LayoutParams.WRAP_CONTENT;
    }

    public static int getMP() {
        return LayoutParams.MATCH_PARENT;
    }

    /** android.util.SizeはAPI Level 21以上のため、代替クラス */
    public static final class Size {
        private final int mWidth;
        private final int mHeight;

        public Size(int width, int height) {
            mWidth = width;
            mHeight = height;
        }

        public int getWidth() {
            return mWidth;
        }

        public int getHeight() {
            return mHeight;
        }

        @Override
        public boolean equals(final Object obj) {
            if (obj == null) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            if (obj instanceof Size) {
                Size other = (Size) obj;
                return mWidth == other.mWidth && mHeight == other.mHeight;
            }
            return false;
        }

        @Override
        public String toString() {
            return mWidth + "x" + mHeight;
        }
    }
}
