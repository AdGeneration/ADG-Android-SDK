package com.socdm.d.adgeneration.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class AssetUtils {
    public static Bitmap getBitmap(Context ct, String fileName) {
        InputStream is = null;
        try {
            is = ct.getAssets().open(fileName);
            return BitmapFactory.decodeStream(is);
        } catch (Exception e) {
            LogUtils.w("failed to open the bitmap from assets");
            return null;
        } finally {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (Exception e) {
                LogUtils.w("failed to close inputstream for open the bitmap");
            }
        }
    }

    public static String getMRAIDSource(Context context) {
        return getFileAssets(context, "adg_mraid.js");
    }

    @Nullable
    public static String getOMSDKSource(@NonNull Context context) {
        return getFileAssets(context, "omsdk-v1.js");
    }

    @Nullable
    private static String getFileAssets(@NonNull Context context, @NonNull String fileName) {
        BufferedReader reader = null;
        try {
            StringBuilder builder = new StringBuilder();
            InputStream stream = context.getAssets().open(fileName);
            reader = new BufferedReader(new InputStreamReader(stream));
            String str;
            while ((str = reader.readLine()) != null) {
                builder.append(str);
            }
            return builder.toString();
        } catch (Exception e) {
            LogUtils.e("Error opening assets:" + fileName);
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (Exception e) {
                    LogUtils.e("Error closing assets:" + fileName);
                    e.printStackTrace();
                }
            }
        }
        return null;
    }
}
