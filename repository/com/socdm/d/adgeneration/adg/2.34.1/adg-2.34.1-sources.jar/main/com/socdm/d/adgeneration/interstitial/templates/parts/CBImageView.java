package com.socdm.d.adgeneration.interstitial.templates.parts;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.ViewGroup.LayoutParams;

import com.socdm.d.adgeneration.utils.AssetUtils;
import com.socdm.d.adgeneration.utils.DisplayUtils;

@Deprecated
public class CBImageView extends androidx.appcompat.widget.AppCompatImageView
        implements CloseButton<CBImageView> {

    public CBImageView(Context context, int w, int h, String fileName) {
        super(context);
        int width = DisplayUtils.getPixels(getResources(), w);
        int height = DisplayUtils.getPixels(getResources(), h);
        this.setLayoutParams(new LayoutParams(width, height));
        Bitmap bitmap = AssetUtils.getBitmap(context, fileName);
        if (bitmap != null) {
            this.setImageBitmap(bitmap);
        }
    }

    @Override
    public CBImageView get() {
        return this;
    }
}
