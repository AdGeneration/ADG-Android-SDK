package com.socdm.d.adgeneration.utils;

import android.app.Activity;

import java.util.Timer;
import java.util.TimerTask;

public class TimerUtils {
    public static Timer renew(Timer oldTimer) {
        TimerUtils.stopTimer(oldTimer);
        return new Timer();
    }

    public static void stopTimer(Timer timer) {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    public static void run(TimerTask task) {
        Timer timer = new Timer();
        timer.schedule(task, 0);
    }

    public static TimerTask timerTaskWithUIThread(final Activity activity, final Runnable runnable) {
        return new TimerTask() {
            @Override
            public void run() {
                if (activity != null) {
                    activity.runOnUiThread(runnable);
                }
            }
        };
    }

    public static TimerTask timerTask(final Runnable runnable) {
        return new TimerTask() {
            @Override
            public void run() {
                runnable.run();
            }
        };
    }
}
