package com.socdm.d.adgeneration.nativead;

import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.adresponse.Native;

public class ADGData {
    @Nullable private String value;
    @Nullable private String label;
    @Nullable private Object ext;

    public ADGData(@Nullable Native.Asset.NativeData obj) {
        if (obj != null) {
            this.value = obj.value;
            obj.label.ifPresent(l -> this.label = l);
            obj.ext.ifPresent(e -> this.ext = e);
        }
    }

    @Nullable
    public String getValue() {
        return value;
    }

    @Nullable
    public String getLabel() {
        return label;
    }

    @Nullable
    public Object getExt() {
        return ext;
    }
}
