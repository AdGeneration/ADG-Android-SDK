package com.socdm.d.adgeneration.interstitial.templates.partsfactory;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

@Deprecated
public class Background315x300Factory extends BackgroundFactory {

    public Background315x300Factory(Context ct) {
        super(ct);
    }

    @Override
    public List<String> getAvailableItems() {
        List<String> items = new ArrayList<String>();
        items.add("adg_interstitial_bg_315x300_001.png");
        items.add("adg_interstitial_bg_315x300_002.png");
        items.add("adg_interstitial_bg_315x300_003.png");
        items.add("adg_interstitial_bg_315x300_004.png");
        return items;
    }
}
