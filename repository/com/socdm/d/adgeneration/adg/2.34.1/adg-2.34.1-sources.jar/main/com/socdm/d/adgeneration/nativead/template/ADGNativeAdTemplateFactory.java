package com.socdm.d.adgeneration.nativead.template;

import android.content.Context;
import android.graphics.Point;
import android.os.Build;

import com.socdm.d.adgeneration.utils.LogUtils;

public class ADGNativeAdTemplateFactory {
    public static ADGNativeAdTemplateBase createTemplate(Context context, Point size) {
        LogUtils.d("template size:" + size.x + "x" + size.y);

        if (!canSupported()) {
            LogUtils.d("A native ad template is not supported on this OS version.");
            return null;
        }

        if (size.x >= 300 && size.y >= 250) {
            return new ADGNativeAdTemplateRectView(context);
        } else if ((double)size.x / size.y > 3){
            return new ADGNativeAdTemplateBannerView(context);
        }
        return null;
    }

    private static Boolean canSupported() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1;
    }
}
