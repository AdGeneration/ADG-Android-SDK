package com.socdm.d.adgeneration.wipe

import com.socdm.d.adgeneration.ADGListener

@Deprecated("Wipe ad is deprecated.")
abstract class ADGWipeListener : ADGListener() {
    abstract fun onCloseWipe()
}
