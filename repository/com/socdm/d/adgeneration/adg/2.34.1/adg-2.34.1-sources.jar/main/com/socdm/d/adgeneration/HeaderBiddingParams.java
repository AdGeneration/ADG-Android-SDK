package com.socdm.d.adgeneration;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Header bidding用のリクエストパラメータ */
final class HeaderBiddingParams {
    @NonNull private final Map<String, String> params = new ConcurrentHashMap<>();

    /**
     * Key-Valueをセットします。Valueは空文字を許容します
     *
     * @param key キー
     * @param value 値
     */
    void setKeyValue(@Nullable final String key, @Nullable final String value) {
        // valueは空文字を許容する
        if (!TextUtils.isEmpty(key) && value != null) {
            params.put(key, value);
        }
    }

    /** すべてのKey-Valueを削除します */
    void removeAllKeyValues() {
        params.clear();
    }

    /**
     * 追加されたKey-ValueをMapに変換して返します
     *
     * @return Key-ValueのMap
     */
    @NonNull
    Map<String, String> toMap() {
        // ディープコピーを返す
        return new ConcurrentHashMap<>(params);
    }

    @NonNull
    @Override
    public String toString() {
        return params.toString();
    }
}
