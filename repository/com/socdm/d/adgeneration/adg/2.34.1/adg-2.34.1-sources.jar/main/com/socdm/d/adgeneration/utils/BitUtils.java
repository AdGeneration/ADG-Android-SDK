package com.socdm.d.adgeneration.utils;

public class BitUtils {

    public static boolean isBitON(int num, int index) {
        if (num < 0 || index <= 0) return false;
        index -= 1;
        num = num >> index;
        num = num & 0x00000001;
        return num == 1;
    }
}
