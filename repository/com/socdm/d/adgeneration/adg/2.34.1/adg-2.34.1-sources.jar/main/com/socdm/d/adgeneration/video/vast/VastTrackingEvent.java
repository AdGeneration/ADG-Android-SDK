package com.socdm.d.adgeneration.video.vast;

public enum VastTrackingEvent {
    CREATIVE_VIEW("creativeView"),
    START("start"),
    FIRST_QUARTILE("firstQuartile"),
    MIDPOINT("midpoint"),
    THIRD_QUARTILE("thirdQuartile"),
    COMPLETE("complete"),
    MUTE("mute"),
    UNMUTE("unmute"),
    PAUSE("pause"),
    REWIND("rewind"),
    RESUME("resume"),
    EXPAND("expand"),
    COLLAPSE("collapse"),
    ACCEPT_INVITATION_LINEAR("acceptInvitationLinear"),
    CLOSE_LINEAR("closeLinear"),
    SKIP("skip"),
    PROGRESS("progress"),
    EXT_INVIEW("inview"),
    EXT_OUTVIEW("outview");

    private final String message;

    VastTrackingEvent(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return this.message;
    }
}