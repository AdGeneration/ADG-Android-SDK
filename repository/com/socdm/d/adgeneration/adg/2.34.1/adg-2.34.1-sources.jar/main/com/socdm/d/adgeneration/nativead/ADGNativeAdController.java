package com.socdm.d.adgeneration.nativead;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.ADGLogger;
import com.socdm.d.adgeneration.IADGLogger;
import com.socdm.d.adgeneration.impression.ImpressionTracker;
import com.socdm.d.adgeneration.viewable.Viewable;
import com.socdm.d.adgeneration.viewable.ViewableDisposableMeasurement;
import com.socdm.d.adgeneration.viewable.ViewableObstacleMeasurement;
import com.socdm.d.adgeneration.viewable.ViewableParameter;
import com.socdm.d.adgeneration.viewable.ViewableParameters;

import jp.supership.sscore.type.Optional;

import java.util.ArrayList;
import java.util.List;

/** ネイティブ広告のコントローラークラス Viewable計測とインプレッショントラッキングを管理します */
public final class ADGNativeAdController {

    /** ネイティブ広告コントローラーのイベントリスナー */
    public interface OnNativeAdControllerListener {
        /**
         * Viewabilityが変更されたときに呼ばれます
         *
         * @param isViewable ビュー可能かどうか
         * @param key トラッキングキー
         */
        void onViewabilityChanged(final boolean isViewable, @NonNull final String key);
    }

    /** インプレッションイベントリスナー */
    public interface OnImpressionListener {
        /** ネイティブ広告がインプレッション条件を満たしたときに呼ばれます */
        void onNativeAdImpression();
    }

    @NonNull private final ADGNativeAdModel model;

    @androidx.annotation.VisibleForTesting @NonNull
    Optional<Viewable> viewableMeasurement = Optional.empty();

    /** ネイティブ広告コントローラーイベントリスナー */
    @Nullable private OnNativeAdControllerListener listener;
    /** インプレッションイベントリスナー */
    @Nullable private OnImpressionListener impressionListener;

    @NonNull private final IADGLogger logger = ADGLogger.getInstance();

    /**
     * インスタンスを初期化します
     *
     * @param model モデル
     */
    public ADGNativeAdController(@NonNull final ADGNativeAdModel model) {
        this.model = model;
    }

    /**
     * ネイティブ広告コントローラーイベントリスナーを設定します
     *
     * @param listener イベントリスナー
     */
    public void setOnNativeAdControllerListener(
            @Nullable final OnNativeAdControllerListener listener) {
        this.listener = listener;
    }

    /**
     * インプレッションイベントリスナーを設定します
     *
     * @param impressionListener インプレッションイベントリスナー
     */
    public void setOnImpressionListener(@Nullable final OnImpressionListener impressionListener) {
        this.impressionListener = impressionListener;
    }

    /**
     * Viewable計測を開始します
     *
     * @param view ビュー
     * @param video 動画広告ならばtrue、それ以外はfalse
     */
    public void startViewableMeasurement(@NonNull final View view, final boolean video) {
        // Reset
        finishViewableMeasurement();

        logger.getLogger().debug("Start viewable measurement.");

        // 動画広告のIn-view/Out-of-view制御に使用するため、Viewable計測パラメータにvideoAdParameterを追加
        List<ViewableParameter> parameters = new ArrayList<>(model.getViewableParameters());
        if (video) {
            parameters.add(ViewableParameter.VIDEO_AD);
        }

        ViewableParameters viewableParameters =
                new ViewableParameters(model.getViewableMeasurementInterval(), parameters);

        // Viewable計測の開始
        final Viewable viewable =
                new ViewableDisposableMeasurement(
                        new ViewableObstacleMeasurement(
                                "NativeAd", view.getContext(), view, viewableParameters, logger));
        viewableMeasurement = Optional.of(viewable);
        viewable.startMeasurement(
                (isViewable, key) -> {
                    handleViewableChanged(isViewable, key, video);
                });
    }

    /**
     * Viewable変更を処理します
     *
     * @param isViewable ビュー可能かどうか
     * @param key トラッキングキー
     * @param video 動画広告かどうか
     */
    @androidx.annotation.VisibleForTesting
    void handleViewableChanged(final boolean isViewable, final String key, final boolean video) {

        if (isViewable) {

            // In-view
            logger.getLogger().debug("Send " + key + " impressions.");

            model.sendImpressions(
                    key,
                    (url, error) -> {
                        if (error.isPresent()) {
                            logger.getLogger()
                                    .error(
                                            "Failed to send impression: "
                                                    + key
                                                    + " "
                                                    + url
                                                    + " "
                                                    + error.forced());
                        } else {
                            logger.getLogger().debug("Impression succeeded: " + key + " " + url);
                        }
                    });

            if (!video && model.areAllImpressionsFired()) {
                finishViewableMeasurement();
            }

            if (ImpressionTracker.IMP_CONDITION_DATA_KEY.equals(key)) {
                if (impressionListener != null) {
                    impressionListener.onNativeAdImpression();
                }
            }
        }

        if (listener != null) {
            listener.onViewabilityChanged(isViewable, key);
        }
    }

    /** Viewable計測を終了します */
    public void finishViewableMeasurement() {
        if (viewableMeasurement.isEmpty()) {
            return;
        }

        logger.getLogger().debug("Finish viewable measurement.");

        viewableMeasurement.ifPresent(Viewable::stopMeasurement);
        viewableMeasurement = Optional.empty();
    }
}
