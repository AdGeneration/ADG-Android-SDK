package com.socdm.d.adgeneration;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.iab.omid.library.supershipjp.Omid;
import com.socdm.d.adgeneration.viewable.ViewableMeasurementInterval;
import com.socdm.d.adgeneration.viewable.ViewableParameter;
import com.socdm.d.adgeneration.viewable.ViewableParameters;

import jp.supership.sscore.SSCoreKit;
import jp.supership.sscore.device.SSCoreAppInfoProvider;
import jp.supership.sscore.device.SSCoreDeviceProvider;

import java.util.ArrayList;
import java.util.List;

/** ADG SDKの検証用ユーティリティ */
public final class ADGDebugUtils {
    /** trueならば旧仕様のトラッキングロジックを使用します */
    // TODO: 新仕様のパラメータがサーバから返却されるようになったら、この一時的な設定を削除する
    public static volatile boolean useLegacyTracking = true;

    private ADGDebugUtils() {}

    /**
     * SDKの詳細情報をログに出力します
     *
     * @param context コンテキスト
     */
    public static void logSDKDetails(@NonNull final Context context) {
        final Context appContext = context.getApplicationContext();
        new SSCoreDeviceProvider(appContext)
                .provideDevice(
                        device -> {
                            new SSCoreAppInfoProvider(appContext)
                                    .provideAppInfo(
                                            appInfo -> {
                                                final StringBuilder sb = new StringBuilder();
                                                sb.append(
                                                        "----------------------------------------\n");
                                                sb.append("<SDK>\n");
                                                sb.append("ADG: ")
                                                        .append(ADGConsts.SDKVERSION)
                                                        .append("\n");
                                                sb.append("SSCore: ")
                                                        .append(SSCoreKit.VERSION_STRING)
                                                        .append(" debugBuild: ")
                                                        .append(SSCoreKit.DEBUG_BUILD)
                                                        .append("\n");
                                                sb.append("OMSDK: ")
                                                        .append(Omid.getVersion())
                                                        .append("\n\n");

                                                device.data.ifPresent(
                                                        data -> {
                                                            sb.append("<Device Info>\n");
                                                            sb.append("Maker: ")
                                                                    .append(data.manufacturer)
                                                                    .append("\n");
                                                            sb.append("Model Name: ")
                                                                    .append(data.modelName)
                                                                    .append("\n");
                                                            sb.append("Brand: ")
                                                                    .append(data.brand)
                                                                    .append("\n");
                                                            sb.append("OS: ")
                                                                    .append(data.os)
                                                                    .append("\n");
                                                            sb.append("OS Version: ")
                                                                    .append(data.osVersion)
                                                                    .append("\n");
                                                            sb.append("API Level: ")
                                                                    .append(data.apiLevel)
                                                                    .append("\n");
                                                            sb.append("Architecture: ")
                                                                    .append(data.architecture)
                                                                    .append(" ")
                                                                    .append(data.bitness)
                                                                    .append("bit\n");
                                                            sb.append("Network Type: ")
                                                                    .append(data.networkType)
                                                                    .append("\n");
                                                            sb.append("Carrier Name: ")
                                                                    .append(data.carrierName)
                                                                    .append("\n");
                                                            sb.append("Carrier Number: ")
                                                                    .append(data.carrierNumber)
                                                                    .append("\n");
                                                            sb.append("ISO Country Code: ")
                                                                    .append(data.isoCountryCode)
                                                                    .append("\n");
                                                            sb.append("Language: ")
                                                                    .append(data.language)
                                                                    .append("\n");
                                                            sb.append("Locale: ")
                                                                    .append(data.locale)
                                                                    .append("\n");
                                                            sb.append("TZ: ")
                                                                    .append(data.timeZone)
                                                                    .append("\n");
                                                            sb.append("Screen Size (dp): ")
                                                                    .append(data.screenWidthInDp)
                                                                    .append("x")
                                                                    .append(data.screenHeightInDp)
                                                                    .append("\n");
                                                            sb.append("Screen Size (px): ")
                                                                    .append(
                                                                            data.screenWidthInPixels)
                                                                    .append("x")
                                                                    .append(
                                                                            data.screenHeightInPixels)
                                                                    .append("\n");
                                                            sb.append("Density: ")
                                                                    .append(data.density)
                                                                    .append("\n");
                                                            data.orientation.ifPresent(
                                                                    orientation -> {
                                                                        sb.append("Orientation: ")
                                                                                .append(orientation)
                                                                                .append("\n");
                                                                    });
                                                            sb.append("\n");
                                                        });

                                                appInfo.data.ifPresent(
                                                        data -> {
                                                            sb.append("<App Info>\n");
                                                            sb.append("App ID: ")
                                                                    .append(data.appId)
                                                                    .append("\n");
                                                            sb.append("App Name: ")
                                                                    .append(data.appName)
                                                                    .append("\n");
                                                            sb.append("App Version: ")
                                                                    .append(data.appVersion)
                                                                    .append("\n");
                                                            sb.append("App Version Code: ")
                                                                    .append(data.buildNumber)
                                                                    .append("\n");
                                                            sb.append("\n");
                                                        });

                                                sb.append("<Current Settings>\n");
                                                sb.append("Geolocation Enabled: ")
                                                        .append(ADGSettings.isGeolocationEnabled())
                                                        .append("\n");
                                                sb.append("Child Directed: ")
                                                        .append(ADGSettings.getChildDirectedState())
                                                        .append("\n");
                                                sb.append("Debug Logging: ")
                                                        .append(ADGSettings.isDebugLogging())
                                                        .append("\n");
                                                sb.append(
                                                        "----------------------------------------");
                                                Log.d(ADGLogger.getDefault().tag, sb.toString());
                                            });
                        });
    }

    /**
     * このメソッドはデバッグ用です。このメソッドを使用すると、Viewable計測パラメータは指定されたパラメータで上書きされます
     *
     * @param measurementIntervalInSeconds 計測間隔[秒]
     * @param parameters Viewable計測パラメータ
     */
    public static void setViewableParametersForDebugging(
            final double measurementIntervalInSeconds,
            @NonNull final ViewableParameter... parameters) {
        ViewableParameters.setParametersForDebugging(
                new ViewableMeasurementInterval(measurementIntervalInSeconds),
                new ArrayList<>(List.of(parameters)));
    }

    /**
     * このメソッドはデバッグ用です。 {@link ADGDebugUtils#setViewableParametersForDebugging}
     * メソッドで追加されたViewable計測パラメータを削除します
     */
    public static void removeViewableParametersForDebugging() {
        ViewableParameters.removeParametersForDebugging();
    }
}
