package com.socdm.d.adgeneration.video.view;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.socdm.d.adgeneration.nativead.icon.ADGAnimation;
import com.socdm.d.adgeneration.nativead.icon.ADGImageView;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.vast.VASTIcon;

public class VastInformationIconView extends LinearLayout {

    private final int WC = ViewGroup.LayoutParams.WRAP_CONTENT;
    private final int MP = ViewGroup.LayoutParams.MATCH_PARENT;
    private final int CONTRACTED_WIDTH = 0;
    private final int ICON_WIDTH = 17;
    private final int ICON_HEIGHT = 15;
    private final int ANIMATION_DURATION = 0;
    private final int SLEEP_MILLISECONDS = 3000;
    private final int TEXT_SIZE = 10;
    private final int ROUND_RECT = 4;

    private Context context;
    private TextView expandableView;
    private ImageView informationIconView;
    private boolean expandable;
    private boolean isWipe;
    private com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner corner;
    private com.socdm.d.adgeneration.video.view.VastInformationIconView.BackgroundType backgroundType;
    private VASTIcon vastIcon;

    public VASTIcon getVastIcon() {
        return vastIcon;
    }

    public enum Corner {
        TOP_LEFT,
        TOP_RIGHT,
        BOTTOM_LEFT,
        BOTTOM_RIGHT
    }

    public enum BackgroundType {
        WHITE(Color.argb(204, 255, 255, 255), Color.BLACK),
        BLACK(Color.argb(204, 0, 0, 0), Color.WHITE);

        private final int backgroundColor;
        private final int textColor;

        BackgroundType(int backgroundColor, int textColor) {
            this.backgroundColor = backgroundColor;
            this.textColor = textColor;
        }
    }

    public VastInformationIconView(Context context, VASTIcon vastIcon) {
        this(context, vastIcon, false, com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.TOP_RIGHT, com.socdm.d.adgeneration.video.view.VastInformationIconView.BackgroundType.WHITE, false);
    }

    public VastInformationIconView(Context context, VASTIcon vastIcon, boolean expandable, com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner corner, com.socdm.d.adgeneration.video.view.VastInformationIconView.BackgroundType backgroundType, boolean isWipe) {
        super(context);
        this.context = context;
        this.corner = corner;
        this.expandable = expandable;
        this.isWipe = isWipe;
        this.backgroundType = backgroundType;

        if (vastIcon == null || TextUtils.isEmpty(vastIcon.getClickThroughURL()) ||
                vastIcon.getStaticResource() == null || TextUtils.isEmpty(vastIcon.getStaticResource().getUrlString())) {
            LogUtils.w("information icons not found.");
            return;
        }

        this.vastIcon = vastIcon;

        // WipeAdの場合、iマークのテキストは表示しない
        String containerText = isWipe ? "" : vastIcon.getProgram();
        String iconUrl = getIconUrl(vastIcon);

        this.setLayoutParams(new LinearLayout.LayoutParams(MP, MP));
        this.setGravity(getLayoutGravity());

        expandableView = new TextView(context);
        expandableView.setTextSize(TEXT_SIZE / getResources().getConfiguration().fontScale);
        expandableView.setText(containerText);
        expandableView.setHeight(convertPx(ICON_HEIGHT));
        expandableView.setTextColor(this.backgroundType.textColor);
        expandableView.setLayoutParams(new RelativeLayout.LayoutParams(WC, WC));
        if (!isWipe) {
            if (corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.TOP_LEFT) || corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.BOTTOM_LEFT)) {
                expandableView.setPadding(convertPx(2), convertPx(1), convertPx(4), convertPx(1));
            } else if (corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.TOP_RIGHT) || corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.BOTTOM_RIGHT)) {
                expandableView.setPadding(convertPx(4), convertPx(1), convertPx(2), convertPx(1));
            }
        }
        if (this.expandable) {
            expandableView.setWidth(CONTRACTED_WIDTH);
        }
        int expandWidth = getWidthByText(containerText);
        ADGAnimation contract = new ADGAnimation(expandableView, -expandWidth, CONTRACTED_WIDTH + expandWidth, ANIMATION_DURATION);
        ADGAnimation expand = new ADGAnimation(expandableView, expandWidth, CONTRACTED_WIDTH, ANIMATION_DURATION);
        expandableView.setOnTouchListener(getTouchEvent(vastIcon.getClickThroughURL(), contract, expand));
        rounded(expandableView, !(this.expandable || isWipe));

        informationIconView = new ADGImageView(context, iconUrl, convertPx(ICON_WIDTH - 4), convertPx(ICON_HEIGHT - 2));
        informationIconView.setMinimumWidth(convertPx(ICON_WIDTH));
        informationIconView.setLayoutParams(new ViewGroup.LayoutParams(WC, convertPx(ICON_HEIGHT)));
        informationIconView.setPadding(convertPx(2), convertPx(1), convertPx(2), convertPx(1));
        informationIconView.setOnTouchListener(getTouchEvent(vastIcon.getClickThroughURL(), contract, expand));
        rounded(informationIconView, this.expandable || isWipe);

        if (corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.TOP_LEFT) || corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.BOTTOM_LEFT)) {
            this.addView(informationIconView);
            this.addView(expandableView);
        } else if (corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.TOP_RIGHT) || corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.BOTTOM_RIGHT)) {
            this.addView(expandableView);
            this.addView(informationIconView);
        }
    }

    /**
     * アイコン画像のURLを取得する
     *
     * @param vastIcon
     * @return アイコン画像URL
     */
    @Nullable
    private String getIconUrl(VASTIcon vastIcon) {
        if (vastIcon.getStaticResource().getUrlString() == null || vastIcon.getStaticResource().getUrlString().isEmpty()) {
            return null;
        }

        return vastIcon.getStaticResource().getUrlString();
    }

    private int getLayoutGravity() {
        if (corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.TOP_LEFT)) {
            return Gravity.LEFT | Gravity.TOP;
        } else if (corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.TOP_RIGHT)) {
            return Gravity.RIGHT | Gravity.TOP;
        } else if (corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.BOTTOM_LEFT)) {
            return Gravity.LEFT | Gravity.BOTTOM;
        } else if (corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.BOTTOM_RIGHT)) {
            return Gravity.RIGHT | Gravity.BOTTOM;
        }
        return 0;
    }

    /**
     * 文字列からコンテナの表示幅を取得する
     * padding分(計6px), 余裕をもたせる分(1px)を加える
     *
     * @param text 表示する文字列
     * @return コンテナ幅
     */
    private int getWidthByText(String text) {
        return (int) (expandableView.getPaint().measureText(text) + convertPx(6) + convertPx(1));
    }

    /**
     * アイコンをタッチしたときのイベント
     * ビューが閉じていれば, 表示する. ビューが開いていれば対象URLへ遷移する
     *
     * @param url               遷移先URL
     * @param contractAnimation 縮小アニメーション
     * @param expandAnimation   拡大アニメーション
     * @return
     */
    @NonNull
    private View.OnTouchListener getTouchEvent(final String url, final ADGAnimation contractAnimation, final ADGAnimation expandAnimation) {
        return new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction() & MotionEvent.ACTION_MASK) {
                    case MotionEvent.ACTION_DOWN:
                        if (!isWipe) touchedProcess(url, contractAnimation, expandAnimation, v);
                        break;
                    case MotionEvent.ACTION_UP:
                        if (isWipe) touchedProcess(url, contractAnimation, expandAnimation, v);
                        break;
                    default:
                        break;
                }
                return true;
            }
        };
    }

    private void touchedProcess(String url, final ADGAnimation contractAnimation, final ADGAnimation expandAnimation, View v) {
        if (expandable && !isWipe) {
            expandableView.clearAnimation();
            if (expandableView.getWidth() > CONTRACTED_WIDTH) {
                sendIconClickTracking();
                transition(v, url);
            } else {
                expandableView.startAnimation(expandAnimation);
                rounded(expandableView, true);
                rounded(informationIconView, false);
                new Handler(Looper.myLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        expandableView.startAnimation(contractAnimation);
                        new Handler(Looper.myLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                rounded(informationIconView, true);
                            }
                        }, ANIMATION_DURATION);
                    }
                }, SLEEP_MILLISECONDS);
            }
        } else {
            sendIconClickTracking();
            transition(v, url);
        }
    }

    /**
     * 背景の一部を角丸にする
     *
     * @param view    対象のビュー
     * @param rounded trueなら角丸
     */
    private void rounded(View view, boolean rounded) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(this.backgroundType.backgroundColor);
        if (rounded) {
            float[] outerRadii = new float[0];
            if (corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.TOP_LEFT)) {
                outerRadii = new float[]{0, 0, 0, 0, convertPx(ROUND_RECT), convertPx(ROUND_RECT), 0, 0};
            } else if (corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.TOP_RIGHT)) {
                outerRadii = new float[]{0, 0, 0, 0, 0, 0, convertPx(ROUND_RECT), convertPx(ROUND_RECT)};
            } else if (corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.BOTTOM_LEFT)) {
                outerRadii = new float[]{0, 0, convertPx(ROUND_RECT), convertPx(ROUND_RECT), 0, 0, 0, 0};
            } else if (corner.equals(com.socdm.d.adgeneration.video.view.VastInformationIconView.Corner.BOTTOM_RIGHT)) {
                outerRadii = new float[]{convertPx(ROUND_RECT), convertPx(ROUND_RECT), 0, 0, 0, 0, 0, 0};
            }
            drawable.setCornerRadii(outerRadii);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            view.setBackground(drawable);
        } else {
            view.setBackgroundDrawable(drawable);
        }
    }

    /**
     * 対象URLへ遷移させる
     *
     * @param view
     * @param url
     */
    private void transition(View view, String url) {
        Uri uri = Uri.parse(url);
        Intent i = new Intent(Intent.ACTION_VIEW, uri);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            view.getContext().startActivity(i);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    private int convertPx(float dp) {
        float density = this.context.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private void sendIconClickTracking() {
        this.vastIcon.sendIconClickTracking();
    }

}
