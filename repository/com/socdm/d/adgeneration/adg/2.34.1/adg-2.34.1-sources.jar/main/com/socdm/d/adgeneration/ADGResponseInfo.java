package com.socdm.d.adgeneration;

import androidx.annotation.NonNull;

import jp.supership.sscore.type.Optional;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 広告レスポンスのメタデータ（クリエイティブIDやDSP IDなど）を呼び出し側へ公開する不変オブジェクト。
 * <p>ADG#getResponseInfo() から取得し、ログや分析用途で利用します。</p>
 */
public class ADGResponseInfo {
    @NonNull private final Optional<String> adId;
    @NonNull private final Optional<String> className;
    @NonNull private final Optional<String> creativeId;
    @NonNull private final Optional<String> adNetworkId;
    @NonNull private final Optional<String> dspId;
    @NonNull private final Optional<String> seat;

    public ADGResponseInfo(
            @NonNull Optional<String> adId,
            @NonNull Optional<String> className,
            @NonNull Optional<String> creativeId,
            @NonNull Optional<String> adNetworkId,
            @NonNull Optional<String> dspId,
            @NonNull Optional<String> seat) {
        this.adId = adId;
        this.className = className;
        this.creativeId = creativeId;
        this.adNetworkId = adNetworkId;
        this.dspId = dspId;
        this.seat = seat;
    }

    /**
     * AdIdを取得します。
     *
     * @return AdId
     */
    @NonNull
    public String getAdId() {
        return adId.orElse("");
    }

    /**
     * メディエーションクラス名を取得します。
     *
     * @return メディエーションクラス名
     */
    @NonNull
    public String getClassName() {
        return className.orElse("");
    }

    /**
     * クリエイティブIDを取得します。
     *
     * @return クリエイティブID
     */
    @NonNull
    public String getCreativeId() {
        return creativeId.orElse("");
    }

    /**
     * アドネットワークIDを取得します。
     *
     * @return アドネットワークID
     */
    @NonNull
    public String getAdNetworkId() {
        return adNetworkId.orElse("");
    }

    /**
     * DSP IDを取得します。
     *
     * @return DSP ID
     */
    @NonNull
    public String getDspId() {
        return dspId.orElse("");
    }

    /**
     * Seatを取得します。
     *
     * @return Seat
     */
    @NonNull
    public String getSeat() {
        return seat.orElse("");
    }

    @NonNull
    @Override
    public String toString() {
        try {
            return new JSONObject()
                    .put("adId", getAdId())
                    .put("adNetworkId", getAdNetworkId())
                    .put("className", getClassName())
                    .put("creativeId", getCreativeId())
                    .put("dspId", getDspId())
                    .put("seat", getSeat())
                    .toString(2);
        } catch (JSONException e) {
            return super.toString();
        }
    }
}
