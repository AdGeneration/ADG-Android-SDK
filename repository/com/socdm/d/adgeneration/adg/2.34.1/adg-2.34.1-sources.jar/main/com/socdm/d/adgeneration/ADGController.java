package com.socdm.d.adgeneration;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.adresponse.Response;
import com.socdm.d.adgeneration.mediation.ADGNativeMediationController;
import com.socdm.d.adgeneration.nativead.ADGNativeAd;
import com.socdm.d.adgeneration.nativead.ADGNativeAdController;
import com.socdm.d.adgeneration.utils.GeolocationProvider;

import jp.supership.sscore.adid.SSCoreAdIdProvider;
import jp.supership.sscore.adid.SSCoreAdInfoLoader;
import jp.supership.sscore.device.SSCoreAppInfoProvider;
import jp.supership.sscore.device.SSCoreDeviceProvider;
import jp.supership.sscore.http.SSCoreHttp;
import jp.supership.sscore.timer.SSCoreScheduledTimer;
import jp.supership.sscore.timer.SSCoreTimerResumable;
import jp.supership.sscore.tracking.SSCoreTrackingEventSendable;
import jp.supership.sscore.tracking.SSCoreTrackingEventSender;
import jp.supership.sscore.type.Optional;
import jp.supership.sscore.type.Result;

import java.util.ArrayList;
import java.util.List;

final class ADGController
        implements ADGNativeMediationController.OnImpressionListener,
                ADGNativeAdController.OnImpressionListener {
    interface Listener {
        void onReceivedAd();

        void onReceivedMediationNativeAd(@NonNull final Object mediationNativeAd);

        void onFailedToReceiveAd(@NonNull final ADGConsts.ADGErrorCode code);

        void onClickedAd();

        void onFinishImpression();

        /// 広告ローテーションがスケジュールされた時間になったら実行されるデリゲートメソッドです
        void onRotationTimerFired();

        ///  インプレッション有効期限タイマーがスケジュールされた時間になったら実行されるデリゲートメソッドです
        void onExpire();
    }

    interface OnAdLoadCallback {
        void onAdLoaded(@NonNull Result<ADGResponse, ADGConsts.ADGErrorCode> result);
    }

    interface CompletionCallback {
        void onCompleted(@Nullable Object object);
    }

    interface OnRotationTimerFireCallback {
        void onRotationTimerFired();
    }

    /** 連続して発生したリクエストエラーがこの回数に達した場合、 {@link ADGConsts.ADGErrorCode#EXCEED_LIMIT} (エラー多発)が返されます */
    static final int MAX_ERROR_COUNT = 5;

    @NonNull private final AdClient.IAdClient adClient;
    @NonNull private final SSCoreTimerResumable rotationTimer;
    @NonNull private final SSCoreTimerResumable expirationTimer;
    @NonNull private final SSCoreTrackingEventSendable trackingEventSender;
    @NonNull private final IADGLogger logger;

    @NonNull
    private AdRequestErrorCounter errorCounter = new AdRequestErrorCounter(MAX_ERROR_COUNT);

    @NonNull Optional<AdBridgingObject> adModel = Optional.empty();

    @NonNull private final List<ADGNativeAd> nativeAds = new ArrayList<>();
    @NonNull private final Handler mainHandler = new Handler(Looper.getMainLooper());

    /** ADGインスタンス単位のパラメータ */
    @NonNull final AdParams adParams = new AdParams();

    @Nullable Listener listener;
    boolean isWorking = false;

    @NonNull
    static ADGController newInstance(
            @NonNull final Context activity, @NonNull final IADGLogger logger) {
        final Context appContext = activity.getApplicationContext();

        final SSCoreAdInfoLoader adInfoLoader = SSCoreAdInfoLoader.getInstance(appContext);
        adInfoLoader.setLogger(logger.getLogger());

        final AdClient.IAdClient adClient =
                AdClient.newClient(
                        logger,
                        SSCoreHttp.newClient(),
                        GeolocationProvider.getInstance(appContext),
                        new SSCoreDeviceProvider(appContext),
                        new SSCoreAppInfoProvider(appContext),
                        new SSCoreAdIdProvider(adInfoLoader),
                        new AdRequestValidator(
                                new AdRequestValidator.LocationIdValidator(),
                                new AdRequestValidator.PermissionValidator(activity),
                                new AdRequestValidator.ReachabilityValidator(activity),
                                new AdRequestValidator.ActivityStateValidator(activity)));

        return new ADGController(
                adClient,
                new SSCoreScheduledTimer(),
                new SSCoreScheduledTimer(),
                new SSCoreTrackingEventSender(),
                logger);
    }

    ADGController(
            @NonNull final AdClient.IAdClient adClient,
            @NonNull final SSCoreTimerResumable rotationTimer,
            @NonNull final SSCoreTimerResumable expirationTimer,
            @NonNull final SSCoreTrackingEventSendable trackingEventSender,
            @NonNull final IADGLogger logger) {
        this.adClient = adClient;
        this.rotationTimer = rotationTimer;
        this.expirationTimer = expirationTimer;
        this.trackingEventSender = trackingEventSender;
        this.logger = logger;
    }

    void requestAd(@NonNull final OnAdLoadCallback listener) {
        logger.getLogger().debug("Start loading an ad.");

        final AdRequest adRequest =
                new AdRequest(
                        adParams.locationId,
                        adParams.getErrorScheduleIds(),
                        adParams.isMraidEnabled,
                        adParams.headerBiddingParams,
                        adParams.labelTargeting,
                        adParams.fillerLimit,
                        ADGSettings.isChildDirectedEnabled());
        adClient.requestAd(
                adRequest,
                result -> {
                    // APSのbidIdなどは1リクエストごとに払い出され、重複して送信してはいけない気がするため
                    // リクエスト終了時にHeader biddingパラメータをクリアする。
                    // APS連携のときはADGのローテーション設定はOFFにすること。ローテーションした場合、
                    // APSのHeader biddingパラメータは、ここでクリアしているため送信されない
                    adParams.headerBiddingParams.removeAllKeyValues();
                    // なお、ラベルターゲティングはリクエストごとに送信する必要があるため、クリアしてはいけない

                    if (result.data.isPresent()) {
                        final Response response = result.data.forced();

                        logger.getLogger().debug("Ad request succeeded: " + response);

                        AdBridgingObject.loadResources(
                                response,
                                trackingEventSender,
                                result1 -> {
                                    if (result1.data.isPresent()) {
                                        final AdBridgingObject object = result1.data.forced();
                                        adModel = Optional.of(object);

                                        final ADGResponse adResponse = new ADGResponse(object);
                                        if (TextUtils.isEmpty(adResponse.getScheduleId())
                                                || adParams.shouldClearErrorScheduleIds()) {
                                            adParams.clearErrorScheduleIds();
                                        }
                                        mainHandler.post(
                                                () ->
                                                        listener.onAdLoaded(
                                                                Result.success(adResponse)));
                                    } else {
                                        result1.error.ifPresent(
                                                e -> {
                                                    logger.getLogger()
                                                            .error("Ad request failed: " + e);
                                                });

                                        adParams.clearErrorScheduleIds();
                                        mainHandler.post(
                                                () ->
                                                        listener.onAdLoaded(
                                                                Result.failure(
                                                                        ADGConsts.ADGErrorCode
                                                                                .COMMUNICATION_ERROR)));
                                    }
                                });
                    } else {
                        final ADGConsts.ADGErrorCode code;
                        if (result.error.isPresent()) {
                            final Throwable e = result.error.forced();

                            logger.getLogger().error("Ad request failed: " + e);

                            if (e instanceof AdRequestValidator.NoConnectionException) {
                                code = ADGConsts.ADGErrorCode.NEED_CONNECTION;
                            } else {
                                code = ADGConsts.ADGErrorCode.COMMUNICATION_ERROR;
                            }
                        } else {
                            code = ADGConsts.ADGErrorCode.COMMUNICATION_ERROR;
                        }
                        adParams.clearErrorScheduleIds();
                        mainHandler.post(() -> listener.onAdLoaded(Result.failure(code)));
                    }
                });
    }

    void cancelRequest() {
        logger.getLogger().debug("Cancel loading an ad.");
        adClient.cancelRequest();
    }

    void stopNativeAds() {
        for (final ADGNativeAd nativeAd : nativeAds) {
            nativeAd.stop();
        }
        // FIXME: nativeAdsがリセットされていないため、ADGNativeAdオブジェクトが解放されず、リロードされるたびにメモリリークする
    }

    /**
     * ローテーションタイマーが既にセットされている場合はキャンセルし、新たにタスクをスケジュールします。 `delayInMilliseconds` が0以下の場合は何もしません
     *
     * @param delayInMilliseconds この時間が経過した後にタスクを実行します
     * @param callback スケジュールされた時間になったら呼ばれるコールバック
     */
    void setRotationTimer(
            final long delayInMilliseconds, @Nullable final OnRotationTimerFireCallback callback) {
        if (delayInMilliseconds <= 0) {
            logger.getLogger()
                    .warn("Rotation timer is not set because delay is less than or equal to 0.");
            return;
        }

        rotationTimer.cancelAndSchedule(
                delayInMilliseconds,
                () -> {
                    if (callback != null) {
                        callback.onRotationTimerFired();
                    }
                });
    }

    /** ローテーションタイマーがセットされている場合はキャンセルします。セットされていない場合は何もしません */
    void cancelRotationTimerIfScheduled() {
        rotationTimer.cancelIfScheduled();
    }

    void resumeRotationTimer() {
        rotationTimer.resumeTimer();
    }

    void pauseRotationTimer() {
        rotationTimer.pauseTimer();
    }

    void cancelExpirationTimerIfScheduled() {
        expirationTimer.cancelIfScheduled();
    }

    void resumeExpirationTimer() {
        expirationTimer.resumeTimer();
    }

    void pauseExpirationTimer() {
        expirationTimer.pauseTimer();
    }

    private void didReceive() {
        adModel.ifPresent(
                ad -> {
                    if (ad.isImpExpirationEnabled()) {
                        cancelAndSetExpirationTimer();
                    }
                    if (!ad.isInViewChargingEnabled() || ADGDebugUtils.useLegacyTracking) {
                        cancelAndSetRotationTimer();
                    }
                });
        resetRequestErrorCounter();
    }

    void dispatchReceivedAdEvent(@Nullable final CompletionCallback callback) {
        // 必ずメインスレッドでコールバックされることを保証する
        mainHandler.post(
                () -> {
                    logger.getLogger().debug("Received an ad.");

                    didReceive();

                    if (isWorking && listener != null) {
                        listener.onReceivedAd();
                    }
                    if (callback != null) {
                        callback.onCompleted(null);
                    }
                });
    }

    void dispatchReceivedMediationNativeAdEvent(
            @NonNull final Object mediationNativeAd, @Nullable final CompletionCallback callback) {
        // 必ずメインスレッドでコールバックされることを保証する
        mainHandler.post(
                () -> {
                    logger.getLogger().debug("Received a mediation native ad.");

                    didReceive();

                    if (mediationNativeAd instanceof ADGNativeAd) {
                        final ADGNativeAd nativeAd = (ADGNativeAd) mediationNativeAd;
                        nativeAds.add(nativeAd);
                        nativeAd.getController().setOnImpressionListener(this);
                    }

                    if (isWorking && listener != null) {
                        listener.onReceivedMediationNativeAd(mediationNativeAd);
                    }
                    if (callback != null) {
                        callback.onCompleted(mediationNativeAd);
                    }
                });
    }

    void dispatchFailedToReceiveAdEvent(
            @NonNull final ADGConsts.ADGErrorCode code,
            @Nullable final CompletionCallback callback) {
        // 必ずメインスレッドでコールバックされることを保証する
        mainHandler.post(
                () -> {
                    if (code == ADGConsts.ADGErrorCode.NO_AD) {
                        logger.getLogger()
                                .debug("Received NoAd. Setting rotation timer for retry.");
                        cancelAndSetRotationTimer();
                    }

                    // 連続して発生したリクエストエラーをカウントし、上限に達した場合はEXCEED_LIMIT(エラー多発)を返す
                    errorCounter.increase();
                    final ADGConsts.ADGErrorCode returnCode =
                            errorCounter.isReachedLimit()
                                    ? ADGConsts.ADGErrorCode.EXCEED_LIMIT
                                    : code;

                    logger.getLogger()
                            .error("Failed to receive an ad: " + code + " -> " + returnCode);

                    if (isWorking && listener != null) {
                        listener.onFailedToReceiveAd(returnCode);
                    }
                    if (callback != null) {
                        callback.onCompleted(returnCode);
                    }
                });
    }

    void dispatchClickedAdEvent(@Nullable final CompletionCallback callback) {
        // 必ずメインスレッドでコールバックされることを保証する
        mainHandler.post(
                () -> {
                    logger.getLogger().debug("Clicked an ad.");

                    // clickイベントに関してはisWorking:falseであっても通知する
                    if (listener != null) {
                        listener.onClickedAd();
                    }
                    if (callback != null) {
                        callback.onCompleted(null);
                    }
                });
    }

    void sendWinNotificationBeacons() {
        logger.getLogger().debug("Send Win/Loss notification beacons.");
        adModel.ifPresent(
                ad ->
                        ad.sendWinNotificationBeacons(
                                createProgressListener("Win/Loss notification beacon", null)));
    }

    void sendLoadTriggerEvents() {
        logger.getLogger().debug("Send Load trigger events.");
        adModel.ifPresent(
                ad -> ad.sendLoadTriggerEvents(createProgressListener("Load trigger event", null)));
    }

    void sendImpressions(final String key) {
        logger.getLogger().debug("Send " + key + " impressions.");
        adModel.ifPresent(ad -> ad.sendImpressions(key, createProgressListener("impression", key)));
    }

    private AdBridgingObject.OnProgressListener createProgressListener(
            final String eventName, @Nullable final String key) {
        final String logKeyInfo = (key != null) ? key + " " : "";
        return (url, error) -> {
            if (error.isPresent()) {
                logger.getLogger()
                        .error(
                                "Failed to send " + eventName + ": " + logKeyInfo + url,
                                error.forced());
            } else {
                logger.getLogger().debug(eventName + " succeeded: " + logKeyInfo + url);
            }
        };
    }

    /** リクエストエラー回数をリセットします */
    private void resetRequestErrorCounter() {
        errorCounter = new AdRequestErrorCounter(MAX_ERROR_COUNT);
    }

    @Override
    public void onNativeAdImpression() {
        logger.getLogger().debug("Native ad impression occurred. Canceling expiration timer.");
        cancelExpirationTimerIfScheduled();

        adModel.ifPresent(
                ad -> {
                    if (ad.isInViewChargingEnabled()) {
                        cancelAndSetRotationTimer();
                    }
                });

        dispatchImpressionEvent(null);
    }

    @Override
    public void onNativeMediationImpression() {
        expirationTimer.cancelIfScheduled();
        adModel.ifPresent(
                ad -> {
                    if (ad.isInViewChargingEnabled()) {
                        cancelAndSetRotationTimer();
                    }
                });
        dispatchImpressionEvent(null);
    }

    void dispatchImpressionEvent(@Nullable final CompletionCallback callback) {
        mainHandler.post(
                () -> {
                    logger.getLogger().debug("Finished impression.");

                    if (isWorking && listener != null) {
                        listener.onFinishImpression();
                    }
                    if (callback != null) {
                        callback.onCompleted(null);
                    }
                });
    }

    private void cancelAndSetRotationTimer() {
        rotationTimer.cancelIfScheduled();
        adModel.ifPresent(
                ad -> {
                    final long delay = ad.getRotationInMilliseconds();
                    if (delay <= 0) {
                        logger.getLogger()
                                .warn(
                                        "Rotation timer is not set because delay is less than or"
                                                + " equal to 0.");
                        return;
                    }
                    logger.getLogger().debug("Set rotation timer: " + delay + "ms");
                    rotationTimer.cancelAndSchedule(
                            delay,
                            () -> {
                                if (listener != null) {
                                    listener.onRotationTimerFired();
                                }
                            });
                });
    }

    private void cancelAndSetExpirationTimer() {
        expirationTimer.cancelIfScheduled();
        adModel.ifPresent(
                ad -> {
                    final double delay = ad.getImpExpireInMilliseconds();
                    if (delay <= 0) {
                        logger.getLogger()
                                .warn(
                                        "Expiration timer is not set because delay is less than or"
                                                + " equal to 0.");
                        return;
                    }
                    logger.getLogger().debug("Set expiration timer: " + delay + "ms");
                    expirationTimer.cancelAndSchedule(
                            (long) delay,
                            () -> {
                                if (listener != null) {
                                    listener.onExpire();
                                }
                            });
                });
    }
}
