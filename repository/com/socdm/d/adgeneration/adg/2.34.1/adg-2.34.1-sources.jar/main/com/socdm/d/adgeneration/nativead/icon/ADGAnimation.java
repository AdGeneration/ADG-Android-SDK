package com.socdm.d.adgeneration.nativead.icon;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Transformation;

public class ADGAnimation extends Animation {

    final int addWidth;
    View view;
    int startWidth;

    public ADGAnimation(View view, int addWidth, int startWidth, int duration) {
        this.view = view;
        this.addWidth = addWidth;
        this.startWidth = startWidth;
        this.setDuration(duration);
    }

    @Override
    protected void applyTransformation(float interpolatedTime, Transformation t) {
        int newWidth = (int) (startWidth + addWidth * interpolatedTime);
        view.getLayoutParams().width = newWidth;
        view.requestLayout();
    }

    @Override
    public void initialize(int width, int height, int parentWidth, int parentHeight) {
        super.initialize(width, height, parentWidth, parentHeight);
    }

    @Override
    public boolean willChangeBounds() {
        return true;
    }

}
