package com.socdm.d.adgeneration.nativead.template;

public interface ADGNativeAdTemplateListener {
    void onClickAd();
}
