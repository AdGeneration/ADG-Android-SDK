package com.socdm.d.adgeneration.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class StringUtils {

    private static final String DEFAULT_ENCODING = "UTF-8";

    /**
     * クエリ文字列をMap型に変換する
     *
     * @param query クエリ文字列
     * @return 変換したHashMap
     */
    public static Map<String, String> queryToMap(String query) {
        Map<String, String> result = new HashMap<>();
        String[] pairs = query.split("&");
        if (pairs != null && pairs.length > 0) {
            for (String pair : pairs) {
                String[] param = pair.split("=", 2);
                if (param != null && param.length == 2) {
                    result.put(param[0], param[1]);
                } else {
                    result.put(param[0], "");
                }
            }
        }
        return result;
    }

    public static String urlEncode(String value) {
        if (value == null) {
            return "";
        }
        try {
            return URLEncoder.encode(value, DEFAULT_ENCODING);
        } catch (UnsupportedEncodingException ex) {
            throw new RuntimeException(ex);
        }
    }

    /*
     * Licensed to the Apache Software Foundation (ASF) under one or more
     * contributor license agreements.  See the NOTICE file distributed with
     * this work for additional information regarding copyright ownership.
     * The ASF licenses this file to You under the Apache License, Version 2.0
     * (the "License"); you may not use this file except in compliance with
     * the License.  You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */

    /**
     * The empty String <code>""</code>.
     *
     * @since 2.0
     */
    public static final String EMPTY = "";

    /**
     * Joins the elements of the provided <code>Iterator</code> into a single String containing the
     * provided elements.
     *
     * <p>
     *
     * <p>No delimiter is added before or after the list. Null objects or empty strings within the
     * iteration are represented by empty strings.
     *
     * <p>
     *
     * <p>See the examples here: {@link #join(Object[], char)}.
     *
     * @param iterator the <code>Iterator</code> of values to join together, may be null
     * @param separator the separator character to use
     * @return the joined String, <code>null</code> if null iterator input
     * @since 2.0
     */
    public static String join(Iterator iterator, char separator) {
        // handle null, zero and one elements before building a buffer
        if (iterator == null) {
            return null;
        }
        if (!iterator.hasNext()) {
            return EMPTY;
        }
        Object first = iterator.next();
        if (!iterator.hasNext()) {
            return first != null ? first.toString() : EMPTY;
        }
        // two or more elements
        StringBuilder buf = new StringBuilder(256); // Java default is 16, probably too small
        if (first != null) {
            buf.append(first);
        }
        while (iterator.hasNext()) {
            buf.append(separator);
            Object obj = iterator.next();
            if (obj != null) {
                buf.append(obj);
            }
        }
        return buf.toString();
    }

    /**
     * Joins the elements of the provided <code>Iterator</code> into a single String containing the
     * provided elements.
     *
     * <p>
     *
     * <p>No delimiter is added before or after the list. A <code>null</code> separator is the same
     * as an empty String ("").
     *
     * <p>
     *
     * <p>See the examples here: {@link #join(Object[], String)}.
     *
     * @param iterator the <code>Iterator</code> of values to join together, may be null
     * @param separator the separator character to use, null treated as ""
     * @return the joined String, <code>null</code> if null iterator input
     */
    public static String join(Iterator iterator, String separator) {
        // handle null, zero and one elements before building a buffer
        if (iterator == null) {
            return null;
        }
        if (!iterator.hasNext()) {
            return EMPTY;
        }
        Object first = iterator.next();
        if (!iterator.hasNext()) {
            return first != null ? first.toString() : EMPTY;
        }
        // two or more elements
        StringBuilder buf = new StringBuilder(256); // Java default is 16, probably too small
        if (first != null) {
            buf.append(first);
        }
        while (iterator.hasNext()) {
            if (separator != null) {
                buf.append(separator);
            }
            Object obj = iterator.next();
            if (obj != null) {
                buf.append(obj);
            }
        }
        return buf.toString();
    }

    /**
     * Joins the elements of the provided <code>Collection</code> into a single String containing
     * the provided elements.
     *
     * <p>
     *
     * <p>No delimiter is added before or after the list. Null objects or empty strings within the
     * iteration are represented by empty strings.
     *
     * <p>
     *
     * <p>See the examples here: {@link #join(Object[], char)}.
     *
     * @param collection the <code>Collection</code> of values to join together, may be null
     * @param separator the separator character to use
     * @return the joined String, <code>null</code> if null iterator input
     * @since 2.3
     */
    public static String join(Collection collection, char separator) {
        if (collection == null) {
            return null;
        }
        return join(collection.iterator(), separator);
    }

    /**
     * Joins the elements of the provided <code>Collection</code> into a single String containing
     * the provided elements.
     *
     * <p>
     *
     * <p>No delimiter is added before or after the list. A <code>null</code> separator is the same
     * as an empty String ("").
     *
     * <p>
     *
     * <p>See the examples here: {@link #join(Object[], String)}.
     *
     * @param collection the <code>Collection</code> of values to join together, may be null
     * @param separator the separator character to use, null treated as ""
     * @return the joined String, <code>null</code> if null iterator input
     * @since 2.3
     */
    public static String join(Collection collection, String separator) {
        if (collection == null) {
            return null;
        }
        return join(collection.iterator(), separator);
    }
}
