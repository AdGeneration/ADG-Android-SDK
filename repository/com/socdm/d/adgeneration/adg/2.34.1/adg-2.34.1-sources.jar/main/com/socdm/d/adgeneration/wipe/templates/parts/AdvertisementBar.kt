package com.socdm.d.adgeneration.wipe.templates.parts

import android.annotation.SuppressLint
import android.content.Context
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.TextView
import com.socdm.d.adgeneration.ADGConsts.ADGWipeTheme
import com.socdm.d.adgeneration.utils.DisplayUtils

@SuppressLint("AppCompatCustomView")
@Deprecated("Wipe ad is deprecated.")
class AdvertisementBar(context: Context?, text: String, textColor: Int) : TextView(context) {
    init {
        // CloseButtonSize = 20( + MarginRight =  5) + MarginRight = 5
        val rightMargin = DisplayUtils.getPixels(resources, 30)
        val leftMargin = DisplayUtils.getPixels(resources, 10)
        var layoutParams = (ViewGroup.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        this.layoutParams = layoutParams
        this.setTextColor(textColor)
        this.gravity = Gravity.CENTER
        this.setPadding(leftMargin, 0, rightMargin, 0)
        this.text = text
        this.ellipsize = TextUtils.TruncateAt.MIDDLE
        this.setSingleLine()
        this.textSize = 13f
    }

    fun setWipeViewTheme(type: ADGWipeTheme) {
        when (type) {
            ADGWipeTheme.DARK, ADGWipeTheme.LIGHT -> {
                this.visibility = View.VISIBLE
                this.setTextColor(type.textColor)
            }
        }
    }

    fun setFrameHidden(isHidden: Boolean) {
        if (isHidden) this.visibility = View.GONE else this.visibility = VISIBLE
    }

    fun setFrameText(text: String) {
        this.text = text
    }
}
