package com.socdm.d.adgeneration.video.Measurement;

import java.io.Serializable;
import java.net.URL;
import java.util.HashMap;

public class VerificationModel implements Serializable {
    private String vendor;
    private String apiFromework;
    private boolean browserOptional;
    private URL javaScriptResource;
    private HashMap<String, URL> trackingEvents;
    private String verificationParameters;

    public void VerificationModel() {
        vendor = null;
        apiFromework = null;
        browserOptional = false;
        javaScriptResource = null;
        trackingEvents = new HashMap<>();
        verificationParameters = null;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getApiFromework() {
        return apiFromework;
    }

    public void setApiFromework(String apiFromework) {
        this.apiFromework = apiFromework;
    }

    public boolean isBrowserOptional() {
        return browserOptional;
    }

    public void setBrowserOptional(boolean browserOptional) {
        this.browserOptional = browserOptional;
    }

    public URL getJavaScriptResource() {
        return javaScriptResource;
    }

    public void setJavaScriptResource(URL javaScriptResource) {
        this.javaScriptResource = javaScriptResource;
    }

    public HashMap<String, URL> getTrackingEvents() {
        return trackingEvents;
    }

    public void setTrackingEvents(HashMap<String, URL> trackingEvents) {
        this.trackingEvents = trackingEvents;
    }

    public String getVerificationParameters() {
        return verificationParameters;
    }

    public void setVerificationParameters(String verificationParameters) {
        this.verificationParameters = verificationParameters;
    }
}
