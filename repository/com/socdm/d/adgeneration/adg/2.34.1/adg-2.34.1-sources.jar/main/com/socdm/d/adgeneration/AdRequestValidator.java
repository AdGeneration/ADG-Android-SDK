package com.socdm.d.adgeneration;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;

import androidx.annotation.NonNull;

import jp.supership.sscore.device.SSCoreReachability;
import jp.supership.sscore.type.Optional;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;

/** 広告リクエストパラメータのバリデーションを行うためのクラスです */
final class AdRequestValidator implements AdRequestValidation {
    @NonNull private final ArrayList<AdRequestValidation> validators = new ArrayList<>();

    /**
     * インスタンスを生成します
     *
     * @param validators 広告リクエストパラメータのバリデーション
     */
    AdRequestValidator(@NonNull final AdRequestValidation... validators) {
        Collections.addAll(this.validators, validators);
    }

    @NonNull
    @Override
    public Optional<Exception> validate(@NonNull final AdRequest request) {
        for (final AdRequestValidation validator : validators) {
            final Optional<Exception> error = validator.validate(request);
            if (error.isPresent()) {
                return error;
            }
        }
        return Optional.empty();
    }

    /** 広告枠IDのバリデーションを行うクラスです */
    static final class LocationIdValidator implements AdRequestValidation {
        @NonNull
        @Override
        public Optional<Exception> validate(@NonNull final AdRequest request) {
            if (request.locationId == null || request.locationId.isEmpty()) {
                return Optional.of(new Exception("locationId is null or empty."));
            }
            return Optional.empty();
        }
    }

    /** AndroidManifestのパーミッションのバリデーションを行うクラスです */
    static final class PermissionValidator implements AdRequestValidation {
        @NonNull private final Context context;

        /**
         * インスタンスを生成します
         *
         * @param context コンテキスト
         */
        PermissionValidator(@NonNull final Context context) {
            // Activityが破棄された場合に参照を保持され続けるのを防ぐため、ApplicationContextを使用する
            this.context = context.getApplicationContext();
        }

        @NonNull
        @Override
        public Optional<Exception> validate(@NonNull final AdRequest request) {
            final boolean internetGranted =
                    context.checkCallingOrSelfPermission(Manifest.permission.INTERNET)
                            == PackageManager.PERMISSION_GRANTED;
            final boolean accessNetworkStateGranted =
                    context.checkCallingOrSelfPermission(Manifest.permission.ACCESS_NETWORK_STATE)
                            == PackageManager.PERMISSION_GRANTED;

            if (!internetGranted) {
                return Optional.of(
                        new Exception(
                                Manifest.permission.INTERNET + " permission missing in manifest."));
            }
            if (!accessNetworkStateGranted) {
                return Optional.of(
                        new Exception(
                                Manifest.permission.ACCESS_NETWORK_STATE
                                        + " permission missing in manifest."));
            }

            return Optional.empty();
        }
    }

    /** ネットワーク接続状態のバリデーションを行うクラスです */
    static final class ReachabilityValidator implements AdRequestValidation {
        @NonNull private final SSCoreReachability.Reachable2 reachability;

        /**
         * インスタンスを生成します
         *
         * @param context コンテキスト
         */
        ReachabilityValidator(@NonNull final Context context) {
            reachability = new SSCoreReachability.Reachability(context);
        }

        @NonNull
        @Override
        public Optional<Exception> validate(@NonNull final AdRequest request) {
            if (!reachability.isReachable()) {
                return Optional.of(new NoConnectionException());
            }
            return Optional.empty();
        }
    }

    /** アクティビティの状態のバリデーションを行うクラスです */
    static final class ActivityStateValidator implements AdRequestValidation {
        @NonNull private final Optional<WeakReference<Activity>> activityOpt;

        /**
         * インスタンスを生成します
         *
         * @param context コンテキスト(Activity)
         */
        ActivityStateValidator(@NonNull final Context context) {
            if (context instanceof Activity) {
                final Activity activity = (Activity) context;
                activityOpt = Optional.of(new WeakReference<>(activity));
            } else {
                activityOpt = Optional.empty();
            }
        }

        @NonNull
        @Override
        public Optional<Exception> validate(@NonNull final AdRequest request) {
            try {
                final WeakReference<Activity> activityRef = activityOpt.unwrap();
                final Activity activity = activityRef.get();
                if (activity == null) {
                    return Optional.of(new Exception("Activity has been destroyed."));
                }
                if (activity.isFinishing()) {
                    return Optional.of(new Exception("Activity has been finished."));
                }
            } catch (Optional.NotPresentException ignored) {
                // コンテキストがActivityではない場合はバリデーションをスキップ
            }
            return Optional.empty();
        }
    }

    /** ネットワーク接続がない場合にスローされる例外です */
    static final class NoConnectionException extends Exception {
        /** インスタンスを生成します */
        NoConnectionException() {
            super("Network is not connected.");
        }
    }
}
