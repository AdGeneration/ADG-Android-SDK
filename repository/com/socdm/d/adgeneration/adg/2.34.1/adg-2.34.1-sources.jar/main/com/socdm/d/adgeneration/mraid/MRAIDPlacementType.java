package com.socdm.d.adgeneration.mraid;

import java.util.Locale;

public enum MRAIDPlacementType {
    INLINE,
    INTERSTITIAL;

    String toJavascriptString() {
        return toString().toLowerCase(Locale.US);
    }
}
