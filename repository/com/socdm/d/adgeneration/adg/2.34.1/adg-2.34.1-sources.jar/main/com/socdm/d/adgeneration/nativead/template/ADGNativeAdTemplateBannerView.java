package com.socdm.d.adgeneration.nativead.template;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.socdm.d.adgeneration.R;
import com.socdm.d.adgeneration.nativead.ADGInformationIconView;
import com.socdm.d.adgeneration.nativead.ADGMediaView;
import com.socdm.d.adgeneration.nativead.ADGNativeAd;
import com.socdm.d.adgeneration.nativead.ADGNativeAdOnClickListener;
import com.socdm.d.adgeneration.utils.LogUtils;

public class ADGNativeAdTemplateBannerView extends ADGNativeAdTemplateBase {

    FrameLayout mMediaContainer;
    RelativeLayout mAdContainer;
    TextView mTitleView;
    TextView mSponsoredView;
    TextView mCTATextView;
    ADGMediaView mMediaView;
    ADGNativeAdTemplateListener mListener;
    ADGNativeAd mNativeAd;

    public ADGNativeAdTemplateBannerView(Context context) {
        super(context);
        setup();
    }

    public ADGNativeAdTemplateBannerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setup();
    }

    public ADGNativeAdTemplateBannerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setup();
    }

    public ADGNativeAdTemplateBannerView(
            Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        setup();
    }

    private void setup() {
        View layout =
                LayoutInflater.from(getContext())
                        .inflate(R.layout.adg_native_ad_template_banner_view, this);
        mAdContainer =
                (RelativeLayout) layout.findViewById(R.id.adg_native_ad_template_banner_view);
        mMediaContainer =
                (FrameLayout)
                        layout.findViewById(
                                R.id.adg_native_ad_template_banner_view_media_container);
        mTitleView = (TextView) layout.findViewById(R.id.adg_native_ad_template_banner_view_title);
        mTitleView.setText("");
        mSponsoredView =
                (TextView) layout.findViewById(R.id.adg_native_ad_template_banner_view_sponsored);
        mSponsoredView.setText("");
        mCTATextView =
                (TextView) layout.findViewById(R.id.adg_native_ad_template_banner_view_cta_text);
        mCTATextView.setText("");
    }

    public Boolean apply(ADGNativeAd nativeAd) {
        if (nativeAd == null) {
            LogUtils.e("ADGNativeAd is null.");
            return false;
        }
        String title = nativeAd.getTitle() != null ? nativeAd.getTitle().getText() : null;
        String ctaText = nativeAd.getCtatext() != null ? nativeAd.getCtatext().getValue() : null;
        String sponsored =
                nativeAd.getSponsored() != null ? nativeAd.getSponsored().getValue() : "";
        Boolean canLoadMedia = nativeAd.canLoadMedia();

        if (TextUtils.isEmpty(title) || TextUtils.isEmpty(ctaText) || !canLoadMedia) {
            LogUtils.e("Lack of parts for native ad template.");
            return false;
        }

        mNativeAd = nativeAd;

        mMediaView = new ADGMediaView(getContext());
        mMediaView.setIsTiny(true);
        mMediaView.setAdgNativeAd(mNativeAd);
        mMediaContainer.addView(
                mMediaView,
                new RelativeLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mMediaView.load();
        mMediaContainer
                .getViewTreeObserver()
                .addOnGlobalLayoutListener(
                        new ViewTreeObserver.OnGlobalLayoutListener() {
                            @Override
                            public void onGlobalLayout() {
                                int height = mMediaContainer.getMeasuredHeight();
                                ViewGroup.LayoutParams params = mMediaContainer.getLayoutParams();
                                params.width = (height * 16) / 9;
                                mMediaContainer.setLayoutParams(params);

                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                    mMediaContainer
                                            .getViewTreeObserver()
                                            .removeOnGlobalLayoutListener(this);
                                } else {
                                    mMediaContainer
                                            .getViewTreeObserver()
                                            .removeGlobalOnLayoutListener(this);
                                }
                            }
                        });

        mNativeAd.setInformationIconViewDefault(false);
        ADGInformationIconView informationIconView =
                new ADGInformationIconView(
                        getContext(),
                        mNativeAd,
                        true,
                        ADGInformationIconView.Corner.TOP_RIGHT,
                        ADGInformationIconView.BackgroundType.WHITE);
        mAdContainer.addView(informationIconView);

        mTitleView.setText(title);
        mSponsoredView.setText(sponsored);
        mCTATextView.setText(ctaText);

        mNativeAd.setClickEvent(
                getContext(),
                this,
                new ADGNativeAdOnClickListener() {
                    @Override
                    public void onClickAd() {
                        if (mListener != null) {
                            mListener.onClickAd();
                        }
                    }
                });

        return true;
    }

    @Override
    public void setListener(ADGNativeAdTemplateListener listener) {
        this.mListener = listener;
    }

    @Override
    public void destroy() {
        finishViewability();
        if (mMediaView != null) {
            mMediaView.destroy();
        }

        this.removeAllViews();

        ViewParent parent = this.getParent();
        if (parent != null) {
            ((ViewGroup) parent).removeView(this);
        }
    }

    @Override
    public void finishViewability() {
        if (mNativeAd != null) {
            mNativeAd.stop();
        }
    }
}
