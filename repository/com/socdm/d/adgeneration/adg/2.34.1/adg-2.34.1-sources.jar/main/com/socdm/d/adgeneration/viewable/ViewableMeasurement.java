package com.socdm.d.adgeneration.viewable;

import static android.view.View.VISIBLE;

import android.content.Context;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.os.HandlerCompat;

import com.socdm.d.adgeneration.IADGLogger;
import com.socdm.d.adgeneration.utils.AppProcessUtils;

import jp.supership.sscore.type.Optional;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * このクラスは、Viewable計測において、ウィンドウに表示されているかどうかを判定します。 計測ロジックは、対象のViewに重なっているViewがある場合を考慮していません。
 * 代わりに障害物判定も行う {@link ViewableObstacleMeasurement} クラスを使用してください
 */
public class ViewableMeasurement implements Viewable {
    private enum Visibility {
        VISIBLE,
        INVISIBLE,
    }

    /** タグ名 */
    @NonNull public final String tag;

    /** アプリケーションコンテキスト */
    @NonNull private final Context appContext;
    /** 計測パラメータ */
    @NonNull private final ViewableParameters parameters;
    /** 計測対象のView */
    @NonNull private final WeakReference<View> view;
    /** ロガー */
    @NonNull protected final Optional<IADGLogger> logger;
    /** 計測処理実行スケジューラ */
    @NonNull private Optional<ViewableCheckTask> task = Optional.empty();
    /** リスナー */
    @Nullable private OnViewableChangeListener listener;
    /** 表示開始時刻 */
    @NonNull private final HashMap<ViewableParameter, Date> displayStartTimes = new HashMap<>();
    /** 現在の表示状態 */
    @NonNull
    private final HashMap<ViewableParameter, Visibility> currentVisibilities = new HashMap<>();

    /**
     * インスタンスを生成します。計測パラメータはデフォルト値が採用されます
     *
     * @param tag タグ名
     * @param context アプリケーションコンテキスト
     * @param view 計測対象のView
     * @param logger ロガー
     */
    public ViewableMeasurement(
            @NonNull final String tag,
            @NonNull final Context context,
            @NonNull final View view,
            @Nullable final IADGLogger logger) {
        this(tag, context, view, ViewableParameters.DEFAULT, logger);
    }

    /**
     * インスタンスを生成します
     *
     * @param tag タグ名
     * @param context アプリケーションコンテキスト
     * @param view 計測対象のView
     * @param parameters 計測パラメータ
     * @param logger ロガー
     */
    public ViewableMeasurement(
            @NonNull final String tag,
            @NonNull final Context context,
            @NonNull final View view,
            @NonNull final ViewableParameters parameters,
            @Nullable final IADGLogger logger) {
        this.tag = tag;
        appContext = context.getApplicationContext();
        this.view = new WeakReference<>(view);
        this.parameters = ViewableParameters.parametersForDebugging().orElse(parameters);
        this.logger = Optional.of(logger);
    }

    @NonNull
    @Override
    public String toString() {
        return getClass().getSimpleName() + " { tag: " + tag + ", parameters: " + parameters + " }";
    }

    @Override
    public void startMeasurement(@Nullable final OnViewableChangeListener listener) {
        // Reset
        stopMeasurement();

        if (parameters.getParameters().isEmpty()) {
            return;
        }

        this.listener = listener;

        task = Optional.of(new ViewableCheckTask());
        task.ifPresent(ViewableCheckTask::startMeasurement);
    }

    @Override
    public void stopMeasurement() {
        displayStartTimes.clear();
        currentVisibilities.clear();

        task.ifPresent(ViewableCheckTask::stopMeasurement);
        task = Optional.empty();
    }

    /**
     * 指定したViewが画面に表示されているかどうかを返します
     *
     * @param view 対象のView
     * @param parameters 計測パラメータ。表示割合以上画面に表示されていればtrueと判定されます
     * @return 各計測パラメータごとの判定結果
     */
    @NonNull
    protected List<VisibleResult> isVisible(
            @NonNull final View view, @NonNull final ViewableParameters parameters) {
        final List<ViewableParameter> viewableParameters = parameters.getParameters();

        if (view.getWindowVisibility() != VISIBLE
                || view.getVisibility() != VISIBLE
                || !view.isShown()) {
            return VisibleResult.resultsAsInvisible(viewableParameters);
        }

        // 画面上の位置
        final int[] point = {view.getLeft(), view.getTop()};
        view.getLocationOnScreen(point);
        final int viewLeft = point[0];
        final int viewTop = point[1];

        // Viewの面積
        final int viewWidth = view.getWidth();
        final int viewHeight = view.getHeight();
        final int viewArea = viewWidth * viewHeight;

        final int viewRight = viewLeft + viewWidth;
        final int viewBottom = viewTop + viewHeight;

        // Viewが配置されているwindowの大きさ(action barが含まれる)
        final Rect displayFrame = new Rect();
        view.getRootView().getWindowVisibleDisplayFrame(displayFrame);

        // contentView(action barが含まれない)
        final ViewGroup contentView = view.getRootView().findViewById(android.R.id.content);
        if (contentView == null) {
            return VisibleResult.resultsAsInvisible(viewableParameters);
        }

        int xDistance;
        // contentViewより左にviewがあるとき
        if (viewLeft < contentView.getLeft()) {
            xDistance = contentView.getLeft() - viewLeft;
        }
        // contentViewの中にあるとき
        else if (viewRight <= contentView.getRight()) {
            xDistance = 0;
        }
        // contentViewより右にviewがあるとき
        else {
            xDistance = viewRight - contentView.getRight();
        }
        xDistance = Math.abs(xDistance);
        // 可視領域の幅(contentView内に入っている部分の幅)
        final int inViewWidth = xDistance <= viewWidth ? viewWidth - xDistance : 0;

        int yDistance;
        // contentViewより上にviewがあるとき
        if (viewTop < displayFrame.top + contentView.getTop()) {
            yDistance = displayFrame.top + contentView.getTop() - viewTop;
        }
        // contentViewの中にあるとき
        else if (viewBottom <= (displayFrame.top + contentView.getBottom())) {
            yDistance = 0;
        }
        // contentViewより下にviewがあるとき
        else {
            yDistance = viewBottom - (displayFrame.top + contentView.getBottom());
        }
        yDistance = Math.abs(yDistance);
        // 可視領域の高さ(contentView内に入っている部分の高さ)
        final int inViewHeight = yDistance <= viewHeight ? viewHeight - yDistance : 0;

        // 可視領域
        int inViewArea = inViewWidth * inViewHeight;

        final List<VisibleResult> results = new ArrayList<>(viewableParameters.size());
        for (ViewableParameter parameter : viewableParameters) {
            results.add(new VisibleResult(inViewArea >= (viewArea * parameter.ratio), parameter));
        }

        return results;
    }

    private void changeVisibility(
            @NonNull final ViewableParameter parameter, @NonNull final Visibility newState) {
        final Visibility currentVisibility =
                Optional.of(currentVisibilities.get(parameter)).orElse(Visibility.INVISIBLE);

        if (currentVisibility == newState) {
            return;
        }

        currentVisibilities.put(parameter, newState);

        logger.ifPresent(
                l ->
                        l.getLogger()
                                .debug(
                                        "Viewable changed: "
                                                + tag
                                                + " "
                                                + (newState == Visibility.VISIBLE
                                                        ? "In-view"
                                                        : "Out-of-view")
                                                + " ratio="
                                                + parameter.ratio));

        if (listener != null) {
            listener.onViewableChanged(newState == Visibility.VISIBLE, parameter.key);
        }
    }

    private final class ViewableCheckTask {
        @NonNull
        private final ScheduledExecutorService executorService =
                Executors.newSingleThreadScheduledExecutor();

        @NonNull private final Handler handler = HandlerCompat.createAsync(Looper.getMainLooper());
        @NonNull private Optional<Runnable> mainThreadTask = Optional.empty();

        void startMeasurement() {
            logger.ifPresent(
                    l ->
                            l.getLogger()
                                    .debug(
                                            "Viewable measurement started: "
                                                    + tag
                                                    + " "
                                                    + parameters));

            final View view = ViewableMeasurement.this.view.get();
            if (view == null) {
                logger.ifPresent(
                        l ->
                                l.getLogger()
                                        .error(
                                                "Viewable measurement failed because the target"
                                                        + " view is null: "
                                                        + tag));
                return;
            }

            mainThreadTask =
                    Optional.of(
                            () -> {
                                final View view1 = ViewableMeasurement.this.view.get();
                                if (view1 == null) {
                                    logger.ifPresent(
                                            l ->
                                                    l.getLogger()
                                                            .error(
                                                                    "Viewable check failed because"
                                                                            + " the target view is"
                                                                            + " null: "
                                                                            + tag));
                                    return;
                                }

                                final List<VisibleResult> results = isVisible(view1, parameters);
                                for (VisibleResult result : results) {
                                    if (result.isVisible) {
                                        if (!displayStartTimes.containsKey(result.parameter)) {
                                            // 表示開始時刻を記録
                                            displayStartTimes.put(result.parameter, new Date());
                                        }

                                        // 一定時間以上表示されていればIn-viewと判定
                                        final Date displayStartTime =
                                                displayStartTimes.get(result.parameter);
                                        if (displayStartTime != null) {
                                            final long displayDuration =
                                                    new Date().getTime()
                                                            - displayStartTime.getTime();
                                            if (displayDuration
                                                    >= result.parameter.duration * 1000) {
                                                changeVisibility(
                                                        result.parameter, Visibility.VISIBLE);
                                            }
                                        }
                                    } else {
                                        // 表示されていない場合は表示開始時刻をリセット
                                        displayStartTimes.remove(result.parameter);
                                        changeVisibility(result.parameter, Visibility.INVISIBLE);
                                    }
                                }
                            });

            // 計測処理の定期実行
            executorService.scheduleWithFixedDelay(
                    () -> {
                        if (ViewableMeasurement.this.view.get() == null) {
                            logger.ifPresent(
                                    l ->
                                            l.getLogger()
                                                    .error(
                                                            "Viewable measurement will stop because"
                                                                    + " the target view is null: "
                                                                    + tag));
                            ViewableMeasurement.this.stopMeasurement();
                            return;
                        }

                        // アプリがバックグラウンド中に計測を続行しているとANRが発生する事案があったため、
                        // フォアグラウンドでない場合は計測を強制終了する
                        if (!AppProcessUtils.isForeground(appContext)) {
                            logger.ifPresent(
                                    l ->
                                            l.getLogger()
                                                    .debug(
                                                            "Viewable measurement will stop because"
                                                                    + " the app is not in the"
                                                                    + " foreground: "
                                                                    + tag));
                            ViewableMeasurement.this.stopMeasurement();
                            return;
                        }

                        mainThreadTask.ifPresent(handler::post);
                    },
                    0,
                    parameters.measurementInterval.inMilliseconds(),
                    TimeUnit.MILLISECONDS);
        }

        void stopMeasurement() {
            logger.ifPresent(l -> l.getLogger().debug("Viewable measurement stopped: " + tag));

            handler.removeCallbacksAndMessages(null);
            mainThreadTask = Optional.empty();
            executorService.shutdown();
        }
    }

    protected static final class VisibleResult {
        public final boolean isVisible;
        @NonNull public final ViewableParameter parameter;

        public VisibleResult(final boolean isVisible, @NonNull final ViewableParameter parameter) {
            this.isVisible = isVisible;
            this.parameter = parameter;
        }

        @NonNull
        public static List<VisibleResult> resultsAsInvisible(
                @NonNull final List<ViewableParameter> parameters) {
            final List<VisibleResult> results = new ArrayList<>(parameters.size());
            for (ViewableParameter parameter : parameters) {
                results.add(new VisibleResult(false, parameter));
            }
            return results;
        }
    }
}
