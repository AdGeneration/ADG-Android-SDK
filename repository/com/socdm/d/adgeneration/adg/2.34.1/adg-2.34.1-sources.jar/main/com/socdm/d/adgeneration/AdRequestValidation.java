package com.socdm.d.adgeneration;

import androidx.annotation.NonNull;

import jp.supership.sscore.type.Optional;

/** 広告リクエストパラメータのバリデーションを行うためのインタフェースです */
interface AdRequestValidation {
    /**
     * 広告リクエストパラメータのバリデーションを行います
     *
     * @param request 広告リクエストパラメータ
     * @return バリデーションが成功した場合は {@link Optional#empty()} を返し、それ以外は例外を返します
     */
    @NonNull
    Optional<Exception> validate(@NonNull AdRequest request);
}
