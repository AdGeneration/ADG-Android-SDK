package com.socdm.d.adgeneration.mediation;

import androidx.annotation.NonNull;

public final class MediationClassNameMapper {
    @NonNull
    private static final String PACKAGE_NAME_ADMOB_ADAPTER = "com.socdm.d.adgeneration.adapter.admob";

    /**
     * 　レスポンスに含まれるクラス名と実際のメディエーションのクラス名をマッピングする
     *
     * @param className クラス名
     * @return 実際のクラス名
     */
    @NonNull
    public static String getCorrectClassName(@NonNull final String className) {
        if (className.contains(
                "com.socdm.d.adgeneration.mediation.GADAdMobInterstitialMediation") ||
                className.contains("com.socdm.d.adgeneration.mediation.GADAdMobMediation") ||
                className.contains(
                        "com.socdm.d.adgeneration.mediation.GADAdMobAdvancedMediation")) {
            String[] splits = className.split("\\.");
            if (splits.length > 0) {
                String mediationClassName = splits[splits.length - 1];
                return String.format("%s.%s", PACKAGE_NAME_ADMOB_ADAPTER, mediationClassName);
            }
        }

        return className;
    }
}
