package com.socdm.d.adgeneration.utils;

import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DateUtils {

    private static final String _TAG = "ADGDateUtils";
    private static final String RFC822_FORMAT = "EEE, dd-MMM-yyyy HH:mm:ss Z";

    /**
     * 現在日時に引数に与えられた日数分加えたDateインスタンスを返す.
     *
     * @param Integer days
     * @return Date addedDate
     */
    public static Date addDates(Integer days) {
        if (days == 0) {
            return null;
        }
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, days);
        return cal.getTime();
    }

    /**
     * RFC822Formatの文字列をDate型にパースする.
     *
     * @param dateString
     * @return Date
     */
    public static Date parseDate(String dateString) {
        SimpleDateFormat sdf = new SimpleDateFormat(RFC822_FORMAT, Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        try {
            if (dateString != null && dateString.length() > 0) {
                return sdf.parse(dateString);
            }
        } catch (ParseException e) {
            Log.i(_TAG, "parseDate:ParseException");
        }
        return null;
    }

    /**
     * Date型からRFC822Formatの文字列にフォーマットする.
     *
     * @param date
     * @return
     */
    public static String formatDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat(RFC822_FORMAT, Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        return date != null ? sdf.format(date) : "";
    }

    /**
     * 与えられたDateが現在日時と比較して過去かどうか判定する.
     *
     * @param target
     * @return boolean
     */
    public static boolean isPast(Date target) {
        if (target != null) {
            return target.getTime() < new Date().getTime();
        }
        return true;
    }

    /**
     * 与えられた日付文字列が現在日時と比較して過去かどうか判定する.
     *
     * @param dateString
     * @return boolean
     */
    public static boolean isPast(String dateString) {
        Date target = parseDate(dateString);
        return isPast(target);
    }
}
