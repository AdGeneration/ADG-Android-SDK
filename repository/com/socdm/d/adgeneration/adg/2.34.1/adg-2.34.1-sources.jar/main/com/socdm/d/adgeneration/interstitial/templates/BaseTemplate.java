package com.socdm.d.adgeneration.interstitial.templates;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.socdm.d.adgeneration.interstitial.templates.layout.ADGLayout;
import com.socdm.d.adgeneration.interstitial.templates.layout.CloseButtonLayout;
import com.socdm.d.adgeneration.interstitial.templates.parts.CloseButton;
import com.socdm.d.adgeneration.interstitial.templates.partsfactory.BackgroundFactory;
import com.socdm.d.adgeneration.interstitial.templates.partsfactory.CloseButtonFactory;
import com.socdm.d.adgeneration.utils.DisplayUtils;
import com.socdm.d.adgeneration.utils.UIUtils;

@Deprecated
public abstract class BaseTemplate extends RelativeLayout {

    private ViewGroup container;
    private ADGLayout adgLayout;
    private CloseButtonLayout closeButtonLayout;

    private BackgroundFactory backgroundFactory;
    private CloseButtonFactory closeButtonFactory;

    static final int FP = DisplayUtils.getFP();
    static final int WC = DisplayUtils.getWC();
    static final int DEFAULT_BG_COLOR = Color.argb((int) (255 * 0.7), 30, 30, 30);

    public BaseTemplate(Context context) {
        super(context);
        refresh();
    }

    // template initialize method.
    // this method was called any times for refresh template.
    public abstract void initTemplate();

    // getter / setter
    public ViewGroup getContainer() {
        return container;
    }

    public void setContainer(ViewGroup container) {
        this.removeAllViews();
        if (container != null) {
            container.setBackgroundColor(DEFAULT_BG_COLOR);
            this.addView(container);
        }
        this.container = container;
    }

    public ADGLayout getAdgLayout() {
        return adgLayout;
    }

    public CloseButtonLayout getCloseButtonLayout() {
        return closeButtonLayout;
    }

    public BackgroundFactory getBackgroundFactory() {
        return backgroundFactory;
    }

    public void setBackgroundFactory(BackgroundFactory backgroundFactory) {
        this.backgroundFactory = backgroundFactory;
    }

    public CloseButtonFactory getCloseButtonFactory() {
        return closeButtonFactory;
    }

    public void setCloseButtonFactory(CloseButtonFactory closeButtonFactory) {
        this.closeButtonFactory = closeButtonFactory;
    }

    public int getGapForDisplay(int templateHeight) {
        return getGapForDisplay(templateHeight, 0);
    }

    public int getGapForDisplay(int templateHeight, int padding) {
        Activity activity = null;
        try {
            activity = (Activity) getContext();
        } catch (ClassCastException e) {
            return 0;
        }
        if (activity != null) {
            Point size = DisplayUtils.getClientSize(activity);
            Point origin = DisplayUtils.getClientOrigin(activity);
            int contentHeight = size.y - origin.y;
            int th = DisplayUtils.getPixels(getResources(), templateHeight);
            if (0 < contentHeight && contentHeight < th) {
                int gap = th - contentHeight;
                int pad = DisplayUtils.getPixels(getResources(), padding);
                return gap - pad;
            }
        }
        return 0;
    }

    // switch design methods
    public void setBackgroundType(int designType) {
        BitmapDrawable bd = this.backgroundFactory.get(designType);
        if (container != null) {
            if (bd != null) {
                this._setBackgroundDrawable(bd);
            } else {
                ColorDrawable cd = new ColorDrawable(DEFAULT_BG_COLOR);
                this._setBackgroundDrawable(cd);
            }
        }
    }

    @SuppressLint("NewApi")
    @SuppressWarnings("deprecation")
    private void _setBackgroundDrawable(Drawable drawable) {
        if (container != null) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                this.container.setBackgroundDrawable(drawable);
            } else {
                this.container.setBackground(drawable);
            }
        }
    }

    public void setCloseButtonType(int designType) {
        this.closeButtonFactory.setDesignType(designType);
    }

    public void createCloseButton() {
        CloseButton<?> ifcb = this.closeButtonFactory.get();
        if (ifcb != null) {
            this.closeButtonLayout.removeAllViews();
            this.closeButtonLayout.addView(ifcb.get());
        }
    }

    public void createCloseButton(OnClickListener listener) {
        CloseButton<? extends View> ifcb = this.closeButtonFactory.get();
        if (ifcb != null) {
            View closeButton = ifcb.get();
            closeButton.setOnClickListener(listener);
            this.closeButtonLayout.removeAllViews();
            this.closeButtonLayout.addView(closeButton);
        }
    }

    // refresh template
    public void refresh() {
        this.removeAllViews();
        if (this.adgLayout != null && this.closeButtonLayout != null) {
            this.adgLayout.removeAllViews();
            this.closeButtonLayout.removeAllViews();
        }
        this.setLayoutParams(new LayoutParams(FP, FP));
        this.setGravity(Gravity.CENTER);
        this._setBackgroundDrawable(null);
        this.adgLayout = new ADGLayout(getContext());
        this.closeButtonLayout = new CloseButtonLayout(getContext());
        initTemplate();
    }

    // validations
    public final boolean checkViews() {
        boolean hasAdg = UIUtils.findViewsWithClass(this, ADGLayout.class).size() == 1;
        boolean hasButton = UIUtils.findViewsWithClass(this, CloseButtonLayout.class).size() == 1;
        return hasAdg && hasButton;
    }
}
