package com.socdm.d.adgeneration.impression;

import androidx.annotation.NonNull;

import com.socdm.d.adgeneration.adresponse.CreativeParams;
import com.socdm.d.adgeneration.adresponse.Native;
import com.socdm.d.adgeneration.adresponse.ResponseResult;
import com.socdm.d.adgeneration.adresponse.Trackers;

import jp.supership.sscore.tracking.SSCoreSingleFireTracker;
import jp.supership.sscore.tracking.SSCoreTracker;
import jp.supership.sscore.tracking.SSCoreTrackingEvent;
import jp.supership.sscore.type.Optional;
import jp.supership.sscore.vast.VastManager;
import jp.supership.sscore.vast.model.Impression;
import jp.supership.sscore.vast.model.Vast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** 旧仕様のインプレッション関連のトラッキングイベントを生成するクラスです */
public final class LegacyImpressionTracker implements ImpressionTracking {
    public static final String IMPRESSION_DATA_KEY = "legacy.viewable.imp";

    @NonNull private final List<SSCoreTrackingEvent> loadTriggerEvents;
    @NonNull private final Map<String, ImpressionData> impressions;

    /**
     * インスタンスを初期化します
     *
     * @param result レスポンスデータ
     * @param vast レスポンスにVASTが含まれる場合は VAST オブジェクトを渡す必要があります
     * @return 初期化されたインスタンス、初期化に失敗した場合は {@link Optional#empty()}
     */
    @NonNull
    public static Optional<ImpressionTracking> create(
            @NonNull final ResponseResult result, @NonNull final Optional<Vast> vast) {
        try {
            final Trackers trackers = result.trackers.unwrap();
            return Optional.of(new LegacyImpressionTracker(result, trackers, vast));
        } catch (Optional.NotPresentException e) {
            return Optional.empty();
        }
    }

    private LegacyImpressionTracker(
            @NonNull final ResponseResult result,
            @NonNull final Trackers trackers,
            @NonNull final Optional<Vast> vast) {
        final CreativeParams.Viewability viewability =
                result.creativeParams
                        .flatMap(creativeParams -> creativeParams.viewability)
                        .orElse(CreativeParams.Viewability.DEFAULT);

        // ロードトリガーイベントの初期化
        this.loadTriggerEvents = initializeLoadTriggerEvents(result, trackers, viewability, vast);

        // インプレッションイベントの初期化
        this.impressions = initializeImpressions(result, trackers, viewability);
    }

    @Override
    @NonNull
    public List<SSCoreTrackingEvent> getLoadTriggerEvents() {
        return new ArrayList<>(loadTriggerEvents);
    }

    @Override
    @NonNull
    public Map<String, ImpressionData> getImpressions() {
        return new HashMap<>(impressions);
    }

    @NonNull
    private static List<SSCoreTrackingEvent> initializeLoadTriggerEvents(
            @NonNull final ResponseResult result,
            @NonNull final Trackers trackers,
            @NonNull final CreativeParams.Viewability viewability,
            @NonNull final Optional<Vast> vast) {
        final List<String> urls = new ArrayList<>();

        // viewableMeasuredの処理
        if (trackers.viewableMeasured.isPresent() && viewability.isValidInLegacy()) {
            urls.addAll(trackers.viewableMeasured.forced().getUrls());
        }

        // impの処理
        if (!viewability.chargeWhenLoading) {
            urls.addAll(trackers.imp.getUrls());
        } else {
            // trackers.impの中からbeaconurlと重複している値を削除する
            final String beaconUrl = result.beaconUrl.maybe();
            for (final String url : trackers.imp.getUrls()) {
                if (!url.equals(beaconUrl)) {
                    urls.add(url);
                }
            }

            // beaconurlを追加
            if (beaconUrl != null) {
                urls.add(beaconUrl);
            }
        }

        // ネイティブ広告のインプレッショントラッカー
        try {
            final Native nativeAd = result.nativeAd.unwrap();
            urls.addAll(nativeAd.getImpTrackers());
        } catch (Optional.NotPresentException ignored) {
        }

        // VASTの <Impression> 要素
        // 旧実装では動画プレイヤーの準備が整ったタイミングで送信していたが、大差ないため一旦、ロード完了時に送信する実装にしておく
        try {
            final List<Impression> impressions =
                    VastManager.getInstance().getImpressions(vast.unwrap());
            for (final Impression impression : impressions) {
                urls.add(impression.getUrl());
            }
        } catch (Optional.NotPresentException ignored) {
        }

        final List<SSCoreTrackingEvent> events = new ArrayList<>();
        for (final String url : urls) {
            try {
                final SSCoreTracker tracker = new SSCoreTracker(url);
                events.add(new SSCoreSingleFireTracker(tracker));
            } catch (final Exception e) {
                // 無効なURLはスキップ
            }
        }

        return events;
    }

    @NonNull
    private static Map<String, ImpressionData> initializeImpressions(
            @NonNull final ResponseResult result,
            @NonNull final Trackers trackers,
            @NonNull final CreativeParams.Viewability viewability) {
        final Map<String, ImpressionData> data = new HashMap<>();

        if (!trackers.viewableImp.isPresent() || !viewability.isValidInLegacy()) {
            return data;
        }

        final List<String> urls = new ArrayList<>();
        final Trackers.ViewableImp viewableImp = trackers.viewableImp.forced();

        if (!viewability.chargeWhenLoading) {
            urls.addAll(viewableImp.getUrls());
        } else {
            // trackers.viewable_impの中からbeaconurlと重複している値を削除する
            final String beaconUrl = result.beaconUrl.maybe();
            for (final String url : viewableImp.getUrls()) {
                if (!url.equals(beaconUrl)) {
                    urls.add(url);
                }
            }
        }

        final List<SSCoreTrackingEvent> events = new ArrayList<>();
        for (final String url : urls) {
            try {
                final SSCoreTracker tracker = new SSCoreTracker(url);
                events.add(new SSCoreSingleFireTracker(tracker));
            } catch (final Exception e) {
                // 無効なURLはスキップ
            }
        }

        final ImpressionData impressionData =
                new ImpressionData(
                        IMPRESSION_DATA_KEY,
                        viewability.ratio,
                        viewability.getDurationInMilliseconds(),
                        events);
        data.put(impressionData.key, impressionData);

        return data;
    }
}
