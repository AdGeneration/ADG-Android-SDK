package com.socdm.d.adgeneration.video.view;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.Measurement.MeasurementConsts;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.ADGPlayerError;
import com.socdm.d.adgeneration.video.vast.VASTIcon;
import com.socdm.d.adgeneration.video.vast.VastAd;
import com.socdm.d.adgeneration.video.vast.VastEventState;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class VastPlayer extends FrameLayout implements VideoView.VideoViewListener {
    @NonNull private final Context mContext;
    @Nullable private VastAd mVastAd;
    @NonNull private final VideoView mVideoView;
    @Nullable private VastMediaEventListener mListener;
    @Nullable private VastMediaEventListenerForManager mListenerForManager;
    private boolean mIsViewable;
    private boolean isCompleted;
    private final boolean isWipe;
    private boolean isNativeOptout = false;
    private volatile boolean mWaitingForPlaybackWhenInView = false;
    @NonNull private final Runner videoLoop = new Runner(this);
    @Nullable private ProgressBar progressBar;

    public VastPlayer(Context context) {
        this(context, false);
    }

    public VastPlayer(@NonNull Context context, boolean isWipe) {
        super(context);
        mContext = context;
        this.isWipe = isWipe;

        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setBackgroundColor(Color.TRANSPARENT);
        setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        LayoutParams params =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.CENTER;
        setLayoutParams(params);

        mVideoView = new VideoView(mContext);
        mVideoView.setVideoViewListener(this);
        mVideoView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        mVideoView.setBackgroundColor(Color.TRANSPARENT);
        mVideoView.setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        LayoutParams videoViewParams =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        videoViewParams.gravity = Gravity.CENTER;
        mVideoView.setLayoutParams(videoViewParams);
        addView(mVideoView);

        videoLoop.start();
    }

    public void setVastAdThenLoadVideo(@NonNull VastAd vastAd, boolean isNativeOptout) {
        mVastAd = vastAd;
        mVideoView.setVideoURL(mVastAd.getBestMediaFileUrl());
        this.isNativeOptout = isNativeOptout;
        // VASTに含まれるIconsを表示させる
        setVastInformationIconView();
        // プログレスバーを表示させる
        setVastProgressBarView();
    }

    public void setVastAd(VastAd vastAd) {
        mVastAd = vastAd;
    }

    public VastAd getVastAd() {
        return mVastAd;
    }

    public void setVastMediaEventListener(VastMediaEventListener listener) {
        mListener = listener;
    }

    public void setVastMediaEventListenerForManger(VastMediaEventListenerForManager listener) {
        mListenerForManager = listener;
    }

    public boolean isInPlaybackState() {
        return mVideoView.isInPlaybackState();
    }

    public boolean isViewable() {
        return mIsViewable;
    }

    public void releaseVastPlayer() {
        videoLoop.stop();
        mVideoView.stopPlayback();
        mIsViewable = false;
        if (mVastAd != null) {
            mVastAd.release();
            mVastAd = null;
        }
    }

    /** Video control */
    public void play() {
        if (!mVideoView.isInPlaybackState()
                || mVideoView.isPlaying()
                || isCompleted
                || mVastAd == null) {
            return;
        }

        if (mVastAd.getCurrentTime() > 0) {
            // 以前の続きから再生
            mVastAd.resume();
            if (mListenerForManager != null) {
                mListenerForManager.onVideoTrackingEvent(
                        MeasurementConsts.mediaEvents.resume, mVideoView);
            }
            mVideoView.seekTo((int) mVastAd.getCurrentTime());
        } else {
            // 新規再生
            if (mListenerForManager != null) {
                mListenerForManager.onVideoTrackingEvent(
                        MeasurementConsts.mediaEvents.impression, mVideoView);
            }
        }

        mVideoView.start();

        if (mListener != null) {
            mListener.onPlaying(mVideoView);
        }

        // 新規再生時のみスタートイベントを発行
        if (mVastAd.getCurrentTime() <= 0 && mListenerForManager != null) {
            mListenerForManager.onVideoTrackingEvent(
                    MeasurementConsts.mediaEvents.start, mVideoView);
        }
    }

    public void pause() {
        if (mVideoView.isInPlaybackState() && mVideoView.isPlaying()) {
            mVideoView.pause();
            if (mVastAd != null) {
                mVastAd.pause();
            }
            if (mListenerForManager != null) {
                mListenerForManager.onVideoTrackingEvent(
                        MeasurementConsts.mediaEvents.pause, mVideoView); // 動画のpause
            }
        }
    }

    public void unmute() {
        if (mVastAd != null) {
            mVideoView.setVolume(1, 1);
            mVastAd.unmute();
        }
    }

    public void mute() {
        if (mVastAd != null) {
            mVideoView.setVolume(0, 0);
            mVastAd.mute();
        }
    }

    public void replay() {
        if (!mVideoView.isPlaying()) {
            isCompleted = false;
            mVideoView.pause();
            mVideoView.seekTo(0);
            mVideoView.start();
        }
    }

    /** Video Events */
    @Override
    public void onPrepared() {
        if (mVastAd == null) {
            return;
        }
        mVideoView.seekTo((int) mVastAd.getCurrentTime());

        // InView待機中なら自動的に再生開始
        if (mWaitingForPlaybackWhenInView && mIsViewable) {
            mWaitingForPlaybackWhenInView = false;
            play();
            LogUtils.d("Auto-playing video after preparation completed while in view.");
        }

        process();

        if (mListener != null) {
            mListener.onPrepared(mVideoView); // 動画ロード完了
        }
        if (mListenerForManager != null) {
            mListenerForManager.onVideoLoadEvent(mVideoView);
        }
    }

    @Override
    public void onCompletion() {
        isCompleted = true;
        if (mVastAd == null) {
            return;
        }
        float duration = (float) mVideoView.getDuration();
        if (mVastAd.compareStateNext(VastEventState.COMPLETE)) {
            if (duration != -1) {
                // 再生終了間際の指定だとonProgressが発生しない可能性があるので、ここでも呼んでおく
                mVastAd.progress((long) duration, 100);
            }
        }
        if (mVastAd.getVastEventState() == VastEventState.THIRD_QUARTILE) {
            mVastAd.complete();
            if (mListener != null) {
                mListener.onCompletion(mVideoView); // 動画再生完了
            }
            if (mListenerForManager != null) {
                mListenerForManager.onVideoTrackingEvent(
                        MeasurementConsts.mediaEvents.complete, mVideoView);
            }
        }
    }

    @Override
    public void onError() {
        LogUtils.e(ADGPlayerError.FAILED_TO_PREPARE_MEDIA.toString());
        if (mListener != null) {
            mListener.onError(ADGPlayerError.FAILED_TO_PREPARE_MEDIA);
        }
    }

    @Override
    public void onBuffering(int percent) {
        if (mListenerForManager != null) {
            mListenerForManager.onBuffering(percent, mVideoView); // 動画のバッファリング量の確認
        }
    }

    @Override
    public void onSeekTo(int msec) {
        if (mListenerForManager != null) {
            mListenerForManager.onSeekTo(mVideoView); // 動画のシーク
        }
    }

    @Override
    public void onChangeAudioVolume(boolean isOn) {
        if (mListener != null) {
            mListener.onChangeAudioVolume(isOn, mVideoView); // 動画の音量変更
        }
        if (mListenerForManager != null) {
            mListenerForManager.onChangeAudioVolume(isOn, mVideoView);
        }
    }

    private void onTimeUpdate() {
        if (mVideoView.isPlaying()) {
            float duration = (float) mVideoView.getDuration();
            float currentPosition = (float) mVideoView.getCurrentPosition();
            float percentile = currentPosition / duration;

            // プログレスバーを表示更新
            if (progressBar != null) {
                progressBar.setProgress(Math.round(percentile * 100));
            }

            if (mVastAd == null) {
                return;
            }
            mVastAd.setCurrentTime(currentPosition);

            VastEventState state = mVastAd.getVastEventState();
            if (state.compareTo(VastEventState.START) < 0 && currentPosition > 1000) {
                mVastAd.start();
                if (mListener != null) {
                    mListener.onStartVideo();
                }
            } else if (state == VastEventState.START && percentile > 0.25) {
                mVastAd.firstQuartile();
                if (mListenerForManager != null) {
                    mListenerForManager.onVideoTrackingEvent(
                            MeasurementConsts.mediaEvents.firstQuartile, mVideoView); // 動画25%まで再生
                }
            } else if (state == VastEventState.FIRST_QUARTILE && percentile > 0.5) {
                mVastAd.midpoint();
                if (mListenerForManager != null) {
                    mListenerForManager.onVideoTrackingEvent(
                            MeasurementConsts.mediaEvents.midpoint, mVideoView); // 動画50%まで再生
                }
            } else if (state == VastEventState.MIDPOINT && percentile > 0.75) {
                mVastAd.thirdQuartile();
                if (mListenerForManager != null) {
                    mListenerForManager.onVideoTrackingEvent(
                            MeasurementConsts.mediaEvents.thirdQuartile, mVideoView); // 動画75%まで再生
                }
            }
            if (state != VastEventState.COMPLETE) {
                // 初回再生時のみ（リプレイ時は発生させない
                mVastAd.progress((long) currentPosition, (int) (percentile * 100));
            }
        }
    }

    /* View Events */

    /** VAST広告に対してiマークViewをaddする */
    private void setVastInformationIconView() {
        if (mVastAd == null || mVastAd.getIcons().isEmpty()) {
            return;
        }
        VASTIcon icon = getIconWithSelectIndustry(mVastAd.getIcons());
        if (icon == null) {
            return;
        }
        VastInformationIconView vastInformationIconView =
                isWipe
                        ?
                        // wipeAdの場合は左上配置
                        new VastInformationIconView(
                                mContext,
                                icon,
                                false,
                                VastInformationIconView.Corner.TOP_LEFT,
                                com.socdm.d.adgeneration.video.view.VastInformationIconView
                                        .BackgroundType.WHITE,
                                isWipe)
                        :
                        // wipeAdじゃない場合はデフォルト右上配置
                        new VastInformationIconView(mContext, icon);
        if (isNativeOptout) {
            return;
        }
        addView(vastInformationIconView);
    }

    /**
     * apiFramework="adg" & IconURLが有効な場合は優先的に表示する apiFramework="adg" & IconURLが無効な場合は表示しない
     * apiFramework="adg"がない場合はclosestを表示する(一番最後のIconsの一番最初のIconを表示する)
     *
     * @param icons VAST内に含まれる<Icons>タグの要素リスト
     * @return VAST広告に表示するiマーク
     */
    @Nullable
    private VASTIcon getIconWithSelectIndustry(ArrayList<VASTIcon> icons) {
        // iconsの要素をすべてチェック
        for (VASTIcon icon : icons) {
            // 要素内に必須の値がないなら次のリストへ
            if (icon == null || icon.getStaticResource() == null) {
                continue;
            }
            // apiFramework="adg"かチェック
            if (icon.isAdg()) {
                // iマークの画像が有効なURLかチェック
                if (URLUtil.isValidUrl(icon.getStaticResource().getUrlString())) {
                    return icon;
                } else {
                    return null;
                }
            }
        }
        // Closest Iconの値チェック
        // mVastAdはnullチェック済み（呼び出し元でチェック済み）
        VASTIcon closestIcon = mVastAd.getClosestIcon();
        if (closestIcon != null && closestIcon.getStaticResource() != null) {
            // iマークの画像が有効なURLかチェック
            if (URLUtil.isValidUrl(closestIcon.getStaticResource().getUrlString())) {
                return closestIcon;
            } else {
                return null;
            }
        }
        return null;
    }

    private void setVastProgressBarView() {
        progressBar = new ProgressBar(mContext, null, android.R.attr.progressBarStyleHorizontal);
        LayoutParams progressBarParams = new LayoutParams(LayoutParams.MATCH_PARENT, 30);
        progressBarParams.topMargin = -15;
        progressBarParams.bottomMargin = -15;
        progressBarParams.gravity = Gravity.BOTTOM;
        progressBar.setLayoutParams(progressBarParams);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.getProgressDrawable().setColorFilter(Color.RED, PorterDuff.Mode.SRC_IN);
        addView(progressBar);
    }

    void callWhenInView() {
        if (mVastAd != null) {
            mIsViewable = true;

            if (mVideoView.isInPlaybackState()) {
                // 準備完了済みなら即座に再生
                play();
                mWaitingForPlaybackWhenInView = false;
            } else {
                // 準備中の場合はフラグを立てて待機
                mWaitingForPlaybackWhenInView = true;
            }

            mVastAd.inView();
        }

        LogUtils.d("The VAST player is in view.");
    }

    void callWhenOutView() {
        if (mVastAd != null) {
            mIsViewable = false;
            // OutOfViewになったら待機フラグもクリア
            mWaitingForPlaybackWhenInView = false;
            pause();
            mVastAd.outView();
        }

        LogUtils.d("The VAST player is out of view.");
    }

    private void process() {
        onTimeUpdate();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        LogUtils.d("called VastPlayer.onDetachedFromWindow()");
        videoLoop.stop();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        LogUtils.d(this + ": onWindowVisibilityChanged:" + (visibility == VISIBLE));
        super.onWindowVisibilityChanged(visibility);
        if (visibility == VISIBLE) {
            videoLoop.start();
        } else {
            videoLoop.stop();
            if (mIsViewable) {
                callWhenOutView();
            }
        }
    }

    private class Runner implements Runnable {
        private Thread thread = null;
        private Handler handler = null;
        boolean running = false;

        private WeakReference<VastPlayer> mSelf;

        public Runner(VastPlayer self) {
            this.mSelf = new WeakReference(self);
        }

        public void start() {
            if (thread == null) {
                thread = new Thread(this);
            }

            if (handler == null) {
                handler = new Handler(Looper.myLooper());
            }

            try {
                thread.start();
                running = true;
            } catch (IllegalThreadStateException ignore) {
                // nothing to do
            }
        }

        public void stop() {
            running = false;
            thread = null;
        }

        @Override
        public void run() {
            while (running) {
                final VastPlayer self = mSelf.get();
                if (self == null) {
                    stop();
                    return;
                }

                handler.post(
                        new Runnable() {
                            @Override
                            public void run() {
                                if (self == null) {
                                    return;
                                }

                                self.process();
                            }
                        });

                try {
                    Thread.sleep(100);
                } catch (InterruptedException ignore) {
                    // nothing to do
                }
            }
        }
    }

    public interface VastMediaEventListener {
        void onStartVideo();

        void onPrepared(VideoView videoView);

        void onPlaying(VideoView videoView);

        void onCompletion(VideoView videoView);

        void onError(ADGPlayerError ADGPlayerError);

        void onChangeAudioVolume(boolean isOn, VideoView videoView);
    }

    public interface VastMediaEventListenerForManager {
        void onVideoLoadEvent(VideoView videoView);

        void onVideoTrackingEvent(MeasurementConsts.mediaEvents event, VideoView videoView);

        void onBuffering(int percent, VideoView videoView);

        void onSeekTo(VideoView videoView);

        void onError(ADGPlayerError ADGPlayerError);

        void onChangeAudioVolume(boolean isOn, VideoView videoView);
    }
}
