package com.socdm.d.adgeneration.utils;

import java.math.BigDecimal;

public class NumberUtils {

    /**
     * 広告に指定する幅サイズを取得する
     * @param originalWidth 広告の元の幅
     * @param originalHeight 広告の元の高さ
     * @param width 指定する幅
     * @param height 指定する高さ
     * @return
     */
    public static int getWidth(int originalWidth, int originalHeight, int width, int height) {
        BigDecimal ratio = getRatio(originalWidth, originalHeight, width, height);
        return new BigDecimal(originalWidth).multiply(ratio).intValue();
    }

    /**
     * 広告に指定する高さを取得する
     * @param originalWidth 広告の元の幅
     * @param originalHeight 広告の元の高さ
     * @param width 指定する幅
     * @param height 指定する高さ
     * @return
     */
    public static int getHeight(int originalWidth, int originalHeight, int width, int height) {
        BigDecimal ratio = getRatio(originalWidth, originalHeight, width, height);
        return new BigDecimal(originalHeight).multiply(ratio).intValue();
    }

    private static BigDecimal getRatio(int originalWidth, int originalHeight, int width, int height) {
        BigDecimal ratioWidth = new BigDecimal(width).divide(new BigDecimal(originalWidth), 2, BigDecimal.ROUND_HALF_UP);
        BigDecimal ratioHeight = new BigDecimal(height).divide(new BigDecimal(originalHeight), 2, BigDecimal.ROUND_HALF_UP);
        return ratioWidth.compareTo(ratioHeight) == -1 ? ratioWidth : ratioHeight;
    }
}
