package com.socdm.d.adgeneration.mraid;

import java.util.Locale;

public enum MRAIDState {
    LOADING,
    DEFAULT,
    RESIZED,
    EXPANDED,
    HIDDEN;

    String toJavascriptString() {
        return toString().toLowerCase(Locale.US);
    }
}
