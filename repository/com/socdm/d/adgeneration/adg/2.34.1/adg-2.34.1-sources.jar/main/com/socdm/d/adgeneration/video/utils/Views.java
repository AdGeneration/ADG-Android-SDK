package com.socdm.d.adgeneration.video.utils;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import com.socdm.d.adgeneration.utils.LogUtils;

import java.io.IOException;
import java.io.InputStream;

public class Views {
    public static void removeFromParent(View view) {
        if (view == null || view.getParent() == null) {
            return;
        }

        if (view.getParent() instanceof ViewGroup) {
            ((ViewGroup) view.getParent()).removeView(view);
        }
    }

    /**
     * Returns true if the given Activity has hardware acceleration enabled
     * in its manifest, or in its foreground window.
     * <p>
     * TODO(husky): Remove when initialize() is refactored (see TODO there)
     * TODO(dtrainor) This is still used by other classes.  Make sure to pull some version of this
     * out before removing it.
     */
    public static boolean hasHardwareAcceleration(Activity activity) {
        // Has HW acceleration been enabled manually in the current window?
        Window window = activity.getWindow();
        if (window != null) {
            if ((window.getAttributes().flags
                    & WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED) != 0) {
                return true;
            }
        }

        // Has HW acceleration been enabled in the manifest?
        try {
            ActivityInfo info = activity.getPackageManager().getActivityInfo(
                    activity.getComponentName(), 0);
            if ((info.flags & ActivityInfo.FLAG_HARDWARE_ACCELERATED) != 0) {
                return true;
            }
        } catch (PackageManager.NameNotFoundException e) {
            LogUtils.d("getActivityInfo(self) should not fail");
        }

        return false;
    }

    public static void setBackground(View view, Drawable d) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            setBackgroundNewApi(view, d);
        } else {
            view.setBackgroundDrawable(d);
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private static void setBackgroundNewApi(View view, Drawable d) {
        view.setBackground(d);
    }

    public static void setImageFromAssets(Context context, ImageView view, String path) throws IOException {
        InputStream is = context.getResources().getAssets().open(path);
        Bitmap bm = BitmapFactory.decodeStream(is);
        view.setImageBitmap(bm);
    }

    public static void clearChild(ViewGroup parent) {
        int ct = parent.getChildCount();
        View view;
        for (int i = 0; i < ct; i++) {
            view = parent.getChildAt(i);
            if (view instanceof ViewGroup) {
                clearChild((ViewGroup) view);
            } else if (view instanceof ImageView) {
                Drawable drawable = ((ImageView) view).getDrawable();
                if (drawable != null && drawable instanceof BitmapDrawable) {
                    Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
                    if (bitmap != null) {
                        bitmap.recycle();
                    }
                }
                ((ImageView) view).setImageDrawable(null);
            }
            setBackground(view, null);
            view.setOnClickListener(null);
            view.setOnLongClickListener(null);
        }
        parent.removeAllViews();
    }
}
