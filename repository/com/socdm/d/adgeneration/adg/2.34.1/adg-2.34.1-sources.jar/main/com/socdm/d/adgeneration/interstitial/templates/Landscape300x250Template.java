package com.socdm.d.adgeneration.interstitial.templates;

import android.content.Context;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.socdm.d.adgeneration.interstitial.templates.layout.ADGLayout;
import com.socdm.d.adgeneration.interstitial.templates.layout.CloseButtonLayout;
import com.socdm.d.adgeneration.interstitial.templates.partsfactory.Background315x300Factory;
import com.socdm.d.adgeneration.interstitial.templates.partsfactory.CloseButton300x30Factory;
import com.socdm.d.adgeneration.utils.DisplayUtils;

@Deprecated
public class Landscape300x250Template extends BaseTemplate {

    private static final int WIDTH = 315;
    private static final int HEIGHT = 300;

    public Landscape300x250Template(Context context) {
        super(context);
        this.setBackgroundFactory(new Background315x300Factory(context));
        this.setCloseButtonFactory(new CloseButton300x30Factory(context));
    }

    @Override
    public void initTemplate() {
        int width = DisplayUtils.getPixels(getResources(), WIDTH);
        int height = DisplayUtils.getPixels(getResources(), HEIGHT);
        int p = DisplayUtils.getPixels(getResources(), 10);
        LinearLayout frame = new LinearLayout(getContext());
        frame.setOrientation(LinearLayout.VERTICAL);
        frame.setGravity(Gravity.CENTER_HORIZONTAL);
        frame.setPadding(0, p, 0, 0);
        frame.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        frame.addView(initAdgLayout());
        frame.addView(initCloseButtonLayout());
        this.setContainer(frame);
    }

    private ADGLayout initAdgLayout() {
        ADGLayout layout = this.getAdgLayout();
        int width = DisplayUtils.getPixels(getContext().getResources(), 300);
        int height = DisplayUtils.getPixels(getContext().getResources(), 250);
        layout.setLayoutParams(new RelativeLayout.LayoutParams(width, height));
        return layout;
    }

    private CloseButtonLayout initCloseButtonLayout() {
        final CloseButtonLayout layout = this.getCloseButtonLayout();
        int width = DisplayUtils.getPixels(getContext().getResources(), 300);
        int height = DisplayUtils.getPixels(getContext().getResources(), 40);
        layout.setLayoutParams(new RelativeLayout.LayoutParams(width, height));
        layout.setGravity(Gravity.CENTER_VERTICAL);
        this.post(
                new Runnable() {
                    @Override
                    public void run() {
                        int gap = getGapForDisplay(HEIGHT);
                        if (gap > 0) {
                            LinearLayout.LayoutParams lp =
                                    (LinearLayout.LayoutParams) layout.getLayoutParams();
                            lp.setMargins(0, -gap, 0, 0);
                            layout.setLayoutParams(lp);
                        }
                    }
                });
        return layout;
    }
}
