package com.socdm.d.adgeneration.wipe.templates.layout

import android.content.Context
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.socdm.d.adgeneration.wipe.templates.parts.AdvertisementBar

@Deprecated("Wipe ad is deprecated.")
class AdvertisementBarLayout(context: Context?) : LinearLayout(context) {
    private fun checkAddConstraint(child: View?): Boolean {
        return child is AdvertisementBar
    }

    override fun addView(child: View?) {
        if (checkAddConstraint(child)) {
            super.addView(child)
        }
    }

    override fun addView(child: View?, params: ViewGroup.LayoutParams?) {
        if (checkAddConstraint(child)) {
            super.addView(child, params)
        }
    }

    override fun addView(child: View?, index: Int) {
        if (checkAddConstraint(child)) {
            super.addView(child, index)
        }
    }

    override fun addView(child: View?, width: Int, height: Int) {
        if (checkAddConstraint(child)) {
            super.addView(child, width, height)
        }
    }

    override fun addView(child: View?, index: Int, params: ViewGroup.LayoutParams?) {
        if (checkAddConstraint(child)) {
            super.addView(child, index, params)
        }
    }

    // onInterceptTouchEvent()を呼び出すためにtrueを返す
    // https://developer.android.com/reference/android/view/ViewGroup?hl=ja#onInterceptTouchEvent(android.view.MotionEvent)
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        return true
    }
}
