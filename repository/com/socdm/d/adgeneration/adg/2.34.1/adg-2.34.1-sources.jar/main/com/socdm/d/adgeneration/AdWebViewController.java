package com.socdm.d.adgeneration;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Point;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;

import com.socdm.d.adgeneration.utils.DisplayUtils;

import jp.supership.sscore.type.Optional;

/**
 * 広告表示用のWebViewを制御するクラスです。このクラスは内部でWebViewを2つ生成し、交互に切り替えて使用します。 これは、OM
 * SDKの計測において、HTML広告の終了タイミングで送信するsessionFinishイベントを正常に送信完了させるための措置です。
 * OM計測はJavaScriptによって行われるため、送信が完了する前にWebViewがリロードされてしまうと、送信処理が切断されてしまいます。
 * (OMのドキュメントによると、最低1秒はWebViewを保持しておく必要があります)
 * この問題に対応するため、2つのWebViewを交互に使用し、片方が裏で送信処理を継続している間に、もう一方が新しい広告リソースのロードおよび表示を行います。
 * これにより、特に待機時間を要することなく広告を更新することが可能となります
 */
final class AdWebViewController {
    @NonNull private final Context context;
    @NonNull private final IADGLogger logger;
    /** WebView A */
    @NonNull private Optional<WebView> webViewA = Optional.empty();
    /** WebView B */
    @NonNull private Optional<WebView> webViewB = Optional.empty();
    /** 現在表示中のWebViewがAならばtrue、Bならばfalse */
    private boolean isASide = false;
    /** WebViewの背景色 */
    private int backgroundColor = Color.TRANSPARENT;

    AdWebViewController(@NonNull final Context context, @NonNull final IADGLogger logger) {
        this.context = context;
        this.logger = logger;
    }

    /**
     * WebViewの背景色を設定します
     *
     * @param color 背景色
     */
    void setBackgroundColor(final int color) {
        // webViewが生成済の場合は即時反映、未生成の場合はメンバ変数に格納しておき生成時に反映
        backgroundColor = color;
        webViewA.ifPresent(webView -> webView.setBackgroundColor(color));
        webViewB.ifPresent(webView -> webView.setBackgroundColor(color));
    }

    /**
     * WebViewの表示サイズを更新します
     *
     * @param width 幅
     * @param height 高さ
     * @param scale スケール
     */
    void updateViewSize(final int width, final int height, final double scale) {
        final FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(width, height);
        String js =
                "var meta = document.querySelector('meta[name=\"viewport\"]');"
                        + "if (meta) {"
                        + "    meta.setAttribute('content', 'width=device-width, initial-scale="
                        + scale
                        + "');"
                        + "} else {"
                        + "    meta = document.createElement('meta');"
                        + "    meta.name = 'viewport';"
                        + "    meta.content = 'width=device-width, initial-scale="
                        + scale
                        + "';"
                        + "    document.head.appendChild(meta);"
                        + "}";

        webViewA.ifPresent(
                webView -> {
                    webView.setLayoutParams(params);
                    webView.post(() -> webView.evaluateJavascript(js, null));
                });
        webViewB.ifPresent(
                webView -> {
                    webView.setLayoutParams(params);
                    webView.post(() -> webView.evaluateJavascript(js, null));
                });
    }

    /** WebViewを非表示にします */
    void hideWebView() {
        // 非表示は全てのWebViewに対して行う = HTMLタイプの広告の非表示化
        webViewA.ifPresent(webView -> webView.setVisibility(View.GONE));
        webViewB.ifPresent(webView -> webView.setVisibility(View.GONE));
    }

    /** WebViewを表示します */
    void showWebView() {
        // 表示は現在のWebViewのみ行う
        if (isASide) {
            webViewA.ifPresent(webView -> webView.setVisibility(View.VISIBLE));
            webViewB.ifPresent(webView -> webView.setVisibility(View.GONE));
        } else {
            webViewA.ifPresent(webView -> webView.setVisibility(View.GONE));
            webViewB.ifPresent(webView -> webView.setVisibility(View.VISIBLE));
        }
    }

    /**
     * WebViewを取得します
     *
     * @return WebView
     */
    @NonNull
    Optional<WebView> getWebView() {
        return isASide ? webViewA : webViewB;
    }

    /**
     * 広告表示用のWebViewを準備します
     *
     * @param parentView WebViewを追加するViewGroup
     * @param adSize 広告のサイズ
     * @param storageEnabled WebストレージおよびDBを有効にするかどうか
     * @param webViewClient WebViewClient
     * @param webChromeClient WebChromeClient
     * @return WebViewの準備に成功した場合はtrue、それ以外はfalse
     */
    boolean prepareWebView(
            @NonNull final ViewGroup parentView,
            @NonNull final Point adSize,
            final boolean storageEnabled,
            @NonNull final WebViewClient webViewClient,
            @NonNull final WebChromeClient webChromeClient) {
        if (!isASide) {
            isASide = true;

            if (webViewA.isEmpty()) {
                webViewA = createWebView(adSize, storageEnabled, webViewClient, webChromeClient);
                webViewA.ifPresent(parentView::addView);

                logger.getLogger().debug("The ad webView (A) has been created.");
            }

            webViewA.ifPresent(webView -> webView.setVisibility(View.VISIBLE));
            webViewB.ifPresent(webView -> webView.setVisibility(View.GONE));

            logger.getLogger().debug("Use the ad webView (A).");

            return webViewA.isPresent();
        } else {
            isASide = false;

            if (webViewB.isEmpty()) {
                webViewB = createWebView(adSize, storageEnabled, webViewClient, webChromeClient);
                webViewB.ifPresent(parentView::addView);

                logger.getLogger().debug("The ad webView (B) has been created.");
            }

            webViewA.ifPresent(webView -> webView.setVisibility(View.GONE));
            webViewB.ifPresent(webView -> webView.setVisibility(View.VISIBLE));

            logger.getLogger().debug("Use the ad webView (B).");

            return webViewB.isPresent();
        }
    }

    /**
     * WebViewを破棄します
     *
     * @param parentView webViewが追加されているViewGroup
     */
    void destroyWebView(@NonNull final ViewGroup parentView) {
        webViewA.ifPresent(view -> destroy(view, parentView));
        webViewB.ifPresent(view -> destroy(view, parentView));
    }

    @NonNull
    private Optional<WebView> createWebView(
            @NonNull final Point adSize,
            final boolean storageEnabled,
            @NonNull final WebViewClient webViewClient,
            @NonNull final WebChromeClient webChromeClient) {
        final WebView webView;
        // https://github.com/ad-generation-development/ssp-sdk/issues/185
        try {
            webView =
                    new WebView(context) {
                        @Override
                        protected void onScrollChanged(int l, int t, int oldl, int oldt) {
                            if (l != 0 || t != 0) {
                                super.scrollTo(0, 0);
                            }
                        }
                    };
        } catch (Exception e) {
            logger.getLogger().error("Failed to create a webView.", e);
            return Optional.empty();
        }

        webView.setBackgroundColor(backgroundColor);
        webView.setLayoutParams(new FrameLayout.LayoutParams(px(adSize.x), px(adSize.y)));
        webView.setHorizontalScrollBarEnabled(false);
        webView.setVerticalScrollBarEnabled(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.clearCache(true);
        webView.getSettings().setSupportMultipleWindows(true);

        // redmine 11876
        // https://code.google.com/p/android/issues/detail?id=40944
        try {
            webView.getSettings().setJavaScriptEnabled(true);
            webView.getSettings().setDatabaseEnabled(storageEnabled);
            webView.getSettings().setDomStorageEnabled(storageEnabled);
        } catch (NullPointerException ignored) {
        }

        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(webViewClient);
        webView.setWebChromeClient(webChromeClient);

        webView.setVisibility(View.VISIBLE);

        return Optional.of(webView);
    }

    private void destroy(@NonNull final WebView webView, @NonNull final ViewGroup parentView) {
        if (webViewA.maybe() == webView || webViewB.maybe() == webView) {
            try {
                parentView.removeView(webView);

                webView.stopLoading();
                webView.removeAllViews();
                webView.setWebViewClient(null);
                webView.setWebChromeClient(null);
                webView.destroy();
            } catch (Exception e) {
                logger.getLogger().error("Failed to destroy a webView.", e);
            }

            if (webViewA.maybe() == webView) {
                webViewA = Optional.empty();
                logger.getLogger().debug("The ad webView (A) has been destroyed.");
            } else if (webViewB.maybe() == webView) {
                webViewB = Optional.empty();
                logger.getLogger().debug("The ad webView (B) has been destroyed.");
            }
        }
    }

    private int px(final int dipValue) {
        return DisplayUtils.getPixels(context.getResources(), dipValue);
    }
}
