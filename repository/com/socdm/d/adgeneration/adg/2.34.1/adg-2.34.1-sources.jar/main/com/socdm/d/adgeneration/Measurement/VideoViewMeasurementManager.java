package com.socdm.d.adgeneration.Measurement;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.view.View;

import com.iab.omid.library.supershipjp.Omid;
import com.iab.omid.library.supershipjp.adsession.media.InteractionType;
import com.iab.omid.library.supershipjp.adsession.media.MediaEvents;
import com.iab.omid.library.supershipjp.adsession.media.PlayerState;
import com.iab.omid.library.supershipjp.adsession.media.Position;
import com.iab.omid.library.supershipjp.adsession.media.VastProperties;
import com.socdm.d.adgeneration.utils.AsyncTaskListener;
import com.socdm.d.adgeneration.utils.AsyncTaskUtils;
import com.socdm.d.adgeneration.utils.HttpURLConnectionTask;
import com.socdm.d.adgeneration.utils.LogUtils;
import com.socdm.d.adgeneration.video.Measurement.VerificationModel;
import com.socdm.d.adgeneration.video.view.VastPlayer;
import com.socdm.d.adgeneration.video.view.VideoView;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * ネイティブビデオ (NativeVideo) フォーマットの広告について
 * OM SDKの計測およびトラッキングをおこなうクラス
 */
public class VideoViewMeasurementManager extends BaseMeasurementManager {

    public MediaEvents mediaEvents;

    public void setVastPlayer(VastPlayer vastPlayer) {
        this.vastPlayer = vastPlayer;
    }

    public VastPlayer vastPlayer;

    public boolean isLoaded() {
        return this.loaded;
    }

    public void setLoaded(boolean loaded) {
        this.loaded = loaded;
    }

    public boolean loaded;

    /**
     * コンストラクタ
     *
     * @param ct コンテキスト
     * @param vastPlayer 動画広告を再生するプレイヤー
     */
    public VideoViewMeasurementManager(@NonNull Context ct, @NonNull VastPlayer vastPlayer) {
        super(ct);
        // プレイヤーをset
        setVastPlayer(vastPlayer);
        // 動画のロードをしていないためfalseで初期化する
        setLoaded(false);
    }

    /**
     * アドセッションを生成し計測開始
     *
     * @param adView 計測対象のView
     * @return Activate OK(true) or NG(false)
     */
    @Override
    public boolean startMeasurement(@NonNull View adView) {
        if (!Omid.isActive()) {
            onFailed("OM SDK is not Activated.");
            return false;
        }

        // VASTで返却された値を元にリソースファイルを準備する
        createVerificationScriptResourceWithoutParameters(this.vastPlayer.getVastAd().getVerifications());
        // セッションの準備
        createAdSession(MeasurementConsts.formatType.nativeVideo, null);
        // ビデオイベント発行用インスタンスを生成
        createMediaEventsPublisher();

        LogUtils.d("adSession starts.");
        return super.startMeasurement(adView);
    }

    /**
     * イベント発行用インスタンスを生成する
     */
    private void createMediaEventsPublisher() {
        if (super.adSession == null) {
            return;
        }
        try {
            this.mediaEvents = MediaEvents.createMediaEvents(this.adSession);
            LogUtils.d("mediaEvents Publish");
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            onFailed("mediaEvents is not Published");
            e.printStackTrace();
        }
    }

    /**
     * スキップ可能な広告動画のロード開始を通知する
     *
     * @param skipOffset スキップ可能となる秒数
     * @param isAutoPlay 自動再生の有無
     * @param position ビデオの再生位置
     */
    public void sendLoadedForSkippableMedia(@NonNull Float skipOffset, boolean isAutoPlay, @NonNull Position position) {
        final VastProperties vProps = VastProperties.createVastPropertiesForSkippableMedia(skipOffset, isAutoPlay, position);
        try {
            if (this.adEvents == null) {
                return;
            }

            setLoaded(true);
            this.adEvents.loaded(vProps);
            LogUtils.d("ForSkip loaded :");
        } catch (Exception e) {
            onFailed("adEvents is not sending ForSkip");
            e.printStackTrace();
        }
    }

    /**
     * スキップ不可の広告動画のロード開始を通知する
     *
     * @param isAutoPlay 自動再生の有無
     * @param position ビデオの再生位置
     */
    public void sendLoadedForNonSkippableMedia(boolean isAutoPlay, @NonNull Position position) {
        final VastProperties vProps = VastProperties.createVastPropertiesForNonSkippableMedia(isAutoPlay, position);
        try {
            if (this.adEvents == null) {
                return;
            }

            setLoaded(true);
            this.adEvents.loaded(vProps);
            LogUtils.d("NonSkip loaded :");
        } catch (Exception e) {
            onFailed("adEvents is not sending NonSkip");
            e.printStackTrace();
        }
    }

    /**
     * プレイヤー領域の変化を通知する
     *
     * @param state プレイヤーの再生モード
     */
    public void sendPlayerStateChange(@NonNull PlayerState state) {
        try {
            if (this.mediaEvents == null) {
                return;
            }
            this.mediaEvents.playerStateChange(state);
            LogUtils.d("playerStateChange : state = " + state);
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            onFailed("mediaEvents is not sending PlayerStateChange");
            e.printStackTrace();
        }
    }

    /**
     * 画面遷移時のタイプを通知する
     *
     * @param type ユーザーインタラクションのタイプ
     */
    public void sendUserInteraction(@NonNull InteractionType type) {
        try {
            if (this.mediaEvents == null) {
                return;
            }
            this.mediaEvents.adUserInteraction(type);
            LogUtils.d("adUserInteraction : type = " + type);
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            onFailed("mediaEvents is not sending adUserInteraction");
            e.printStackTrace();
        }
    }

    /**
     * 動画イベントを通知する
     *
     * @param event 動画イベントのタイプ
     * @param videoView 再生プレイヤーの実体
     */
    public void sendMediaEvent(@NonNull MeasurementConsts.mediaEvents event, @Nullable VideoView videoView) {
        // 動画のロードが未完了ならトラッキングイベントを受け付けない
        if (!isLoaded() || this.adSession == null) {
            return;
        }

        try {
            switch (event) {
                // インプレッション開始
                case impression:
                    if (super.adEvents == null) return;
                    super.adEvents.impressionOccurred();
                    LogUtils.d("sendMediaEvent : impression");
                    break;
                // 再生開始
                case start:
                    if (this.mediaEvents == null || videoView == null) return;
                    float vol = videoView.isVolume() ? 1.0f : 0.0f;
                    this.mediaEvents.start(videoView.getDuration(), vol);
                    LogUtils.d("sendMediaEvent : start");
                    break;
                // 25%
                case firstQuartile:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.firstQuartile();
                    LogUtils.d("sendMediaEvent : firstQuartile");
                    break;
                // 50%
                case midpoint:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.midpoint();
                    LogUtils.d("sendMediaEvent : midpoint");
                    break;
                // 75%
                case thirdQuartile:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.thirdQuartile();
                    LogUtils.d("sendMediaEvent : thirdQuartile");
                    break;
                // 100%
                case complete:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.complete();
                    LogUtils.d("sendMediaEvent : complete");
                    break;
                // 一時停止
                case pause:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.pause();
                    LogUtils.d("sendMediaEvent : pause");
                    break;
                // 再生再開
                case resume:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.resume();
                    LogUtils.d("sendMediaEvent : resume");
                    break;
                // バッファリングにより再生を停止
                case bufferStart:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.bufferStart();
                    LogUtils.d("sendMediaEvent : bufferStart");
                    break;
                // バッファリング後に再生を再開
                case bufferEnd:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.bufferFinish();
                    LogUtils.d("sendMediaEvent : bufferEnd");
                    break;
                // プレイヤーのボリュームをONに変更した
                case volumeChangeOn:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.volumeChange(1.0f);
                    LogUtils.d("sendMediaEvent : volumeChangeOn");
                    break;
                // プレイヤーのボリュームをOFFに変更した
                case volumeChangeOff:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.volumeChange(0.0f);
                    LogUtils.d("sendMediaEvent : volumeChangeOff");
                    break;
                // 再生の早期終了
                case skipped:
                    if (this.mediaEvents == null) return;
                    this.mediaEvents.skipped();
                    LogUtils.d("sendMediaEvent : skipped");
                    break;
                // プレイヤーの破棄
                case finish:
                    finishMeasurement();
                    LogUtils.d("sendMediaEvent : finish");
                    break;
                default:
                    break;
            }
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) {
            onFailed("mediaEvent is not sending");
            e.printStackTrace();
        }
    }

    /**
     * エラー用のトラッキングURLへリクエストをおこない、Exceptionを返却する
     *
     * @param msg エラーメッセージ
     * @return Exception エラー
     */
    @Override
    public IllegalArgumentException onFailed(@Nullable String msg) {
        if (this.vastPlayer == null || this.vastPlayer.getVastAd() == null) {
            return super.onFailed(msg);
        }

        ArrayList<VerificationModel> verificationsList = this.vastPlayer.getVastAd().getVerifications();
        if (verificationsList != null) {
            // VASTに含まれる各計測ベンダーのトラッキングイベントを検索
            for (VerificationModel model : verificationsList) {
                // 各計測ベンダーのverificationNotExecutedのURLを検索
                HashMap<String, URL> trackingEvents = model.getTrackingEvents();
                if (trackingEvents == null) {
                    continue;
                }
                if (trackingEvents.get(MeasurementConsts.NOT_EXECUTED) == null) {
                    continue;
                }
                // エラー用のURLへリクエストをおこなう
                httpErrorRequest(trackingEvents.get(MeasurementConsts.NOT_EXECUTED));
            }
        }

        return super.onFailed(msg);
    }

    /**
     * HTTPリクエストを行う
     *
     * @param url エラー通知先
     */
    private void httpErrorRequest(@Nullable final URL url) {
        if (url == null) {
            LogUtils.w("httpErrorRequest URL is none.");
            return;
        }

        HttpURLConnectionTask requestTask = new HttpURLConnectionTask(url.toString(), new AsyncTaskListener<String>() {
            @Override
            public void onSuccess(String s) {
                LogUtils.d("request succeed. " + url.toString());
            }

            @Override
            public void onError(Exception e) {
                LogUtils.d("request failed.(" + e.getMessage() + ") " + url.toString());
            }
        });
        AsyncTaskUtils.execute(requestTask);
    }
}
