package com.socdm.d.adgeneration.observer;

abstract public class ADGRecipient implements Observer {

    public String tag;

    public ADGRecipient(String tag) {
        this.tag = tag;
    }

}
