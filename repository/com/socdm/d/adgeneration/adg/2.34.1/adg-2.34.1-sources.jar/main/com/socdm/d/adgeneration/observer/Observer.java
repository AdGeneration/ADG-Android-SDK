package com.socdm.d.adgeneration.observer;

public interface Observer {
    public void onMessage(ADGMessage message);
}
