package com.socdm.d.adgeneration.viewable;

import android.graphics.Rect;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** 障害物を構成する矩形群を表すクラスです */
final class ObstacleRects {
    /** 障害物を構成する矩形群 */
    private final List<Rect> rects;

    /**
     * 障害物Viewの矩形の配列から障害物同士が重なっている領域を差し引き、視認性の障害となる領域を構成する矩形の配列を生成します
     *
     * @param obstacleViewRects 障害物Viewの矩形の配列
     */
    ObstacleRects(@Nullable final List<Rect> obstacleViewRects) {
        if (obstacleViewRects == null || obstacleViewRects.isEmpty()) {
            rects = new ArrayList<>();
            return;
        }

        List<Rect> currentObstacles = new ArrayList<>(obstacleViewRects);
        List<Rect> remainingObstacles = new ArrayList<>();
        List<Rect> pickedObstacles = new ArrayList<>();

        while (!currentObstacles.isEmpty()) {
            // 面積が最大の障害物を選択
            Collections.sort(
                    currentObstacles,
                    (a, b) -> {
                        float areaA = a.width() * a.height();
                        float areaB = b.width() * b.height();
                        return Float.compare(areaB, areaA); // descending order
                    });
            final Rect nextPicked = currentObstacles.remove(0);
            pickedObstacles.add(nextPicked);

            // 選択した領域を除いた他の領域をremainingObstaclesにコピー
            for (Rect obstacle : currentObstacles) {
                fragmentize(obstacle, nextPicked, remainingObstacles);
            }

            currentObstacles = remainingObstacles;
            remainingObstacles = new ArrayList<>();
        }
        this.rects = pickedObstacles;
    }

    /**
     * 障害物を構成する矩形群の面積を計算します
     *
     * @return 面積
     */
    int calculateArea() {
        int area = 0;
        for (Rect r : rects) {
            area += r.width() * r.height();
        }
        return area;
    }

    /**
     * 障害物を構成する矩形群を返します
     *
     * @return 障害物を構成する矩形群
     */
    @NonNull
    List<Rect> getRects() {
        List<Rect> deepCopyRects = new ArrayList<>();
        for (Rect rect : rects) {
            deepCopyRects.add(new Rect(rect));
        }
        return deepCopyRects;
    }

    /**
     * `target` と `rect` が交差する場合、交差部分を除いて `target` を複数の矩形に分解します
     *
     * @param target 分解対象の矩形
     * @param rect この矩形と交差する矩形を分解します
     * @param remainingObstacles 残りの障害物リスト
     */
    private static void fragmentize(
            @NonNull final Rect target,
            @NonNull final Rect rect,
            @NonNull final List<Rect> remainingObstacles) {
        if (rect.contains(target)) {
            // 完全に含まれる場合は何もしない(残りの障害物リストから除外)
            return;
        }

        // 交差している場合は交差部分を除いて対象の矩形を分解し、障害物リストにそれぞれ追加
        final Rect trimmedRect = new Rect();
        if (!trimmedRect.setIntersect(target, rect)) {
            // 交差していない場合はそのまま残りの障害物リストに追加
            remainingObstacles.add(new Rect(target));
            return;
        }
        final Rect leftRect = new Rect(target.left, target.top, trimmedRect.left, target.bottom);
        final Rect topRect =
                new Rect(trimmedRect.left, target.top, trimmedRect.right, trimmedRect.top);
        final Rect bottomRect =
                new Rect(trimmedRect.left, trimmedRect.bottom, trimmedRect.right, target.bottom);
        final Rect rightRect = new Rect(trimmedRect.right, target.top, target.right, target.bottom);

        if (isNotEmpty(leftRect)) {
            remainingObstacles.add(leftRect);
        }
        if (isNotEmpty(topRect)) {
            remainingObstacles.add(topRect);
        }
        if (isNotEmpty(bottomRect)) {
            remainingObstacles.add(bottomRect);
        }
        if (isNotEmpty(rightRect)) {
            remainingObstacles.add(rightRect);
        }
    }

    /**
     * 矩形の幅および高さが0でないならばtrueを返し、それ以外はfalseを返します
     *
     * @param rect 対象の矩形
     * @return 矩形の幅および高さが0でないならばtrueを返し、それ以外はfalse
     */
    private static boolean isNotEmpty(@NonNull Rect rect) {
        return !(rect.width() <= 0) && !(rect.height() <= 0);
    }
}
