package com.socdm.d.adgeneration.observer;

public class ADGMessage {

    private String type;
    private Object message;

    public ADGMessage(String type, Object message) {
        this.setType(type);
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

}
