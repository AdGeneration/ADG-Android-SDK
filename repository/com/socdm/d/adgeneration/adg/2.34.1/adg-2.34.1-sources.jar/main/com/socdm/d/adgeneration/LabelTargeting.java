package com.socdm.d.adgeneration;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** ラベルターゲティング用のリクエストパラメータ */
final class LabelTargeting {
    @NonNull private final Map<String, String> labelTargeting = new ConcurrentHashMap<>();

    /**
     * Key-Valueを追加します
     *
     * @param key キー
     * @param value 値
     */
    void addKeyValue(@Nullable final String key, @Nullable final String value) {
        if (TextUtils.isEmpty(key) || TextUtils.isEmpty(value)) {
            return;
        }

        if (labelTargeting.containsKey(key)) {
            // 既に存在するKeyならば、カンマ区切りでValueを追加する
            // TODO: Valueが重複している場合、重複を許容するかどうか
            labelTargeting.put(key, labelTargeting.get(key) + "," + value);
        } else {
            labelTargeting.put(key, value);
        }
    }

    /**
     * 指定したキーのKey-Valueを削除します
     *
     * @param key キー
     */
    void removeKeyValue(@Nullable final String key) {
        if (!TextUtils.isEmpty(key)) {
            labelTargeting.remove(key);
        }
    }

    /** すべてのKey-Valueを削除します */
    void removeAllKeyValues() {
        labelTargeting.clear();
    }

    /**
     * 追加されたKey-ValueをMapに変換して返します
     *
     * @return Key-ValueのMap
     */
    @NonNull
    Map<String, String> toMap() {
        // ディープコピーを返す
        return new ConcurrentHashMap<>(labelTargeting);
    }

    /**
     * ラベルターゲティングの仕様に則り、キーに"label_"を付与したMapを返します
     *
     * @return キーに"label_"を付与したMap
     */
    @NonNull
    Map<String, String> toMapWithPrefix() {
        final Map<String, String> prefixedMap = new ConcurrentHashMap<>();
        for (final Map.Entry<String, String> entry : labelTargeting.entrySet()) {
            if (entry.getKey().startsWith("label_")) {
                // 既に"label_"が付与されている場合はそのまま追加
                prefixedMap.put(entry.getKey(), entry.getValue());
            } else {
                prefixedMap.put("label_" + entry.getKey(), entry.getValue());
            }
        }
        return prefixedMap;
    }

    @NonNull
    @Override
    public String toString() {
        return labelTargeting.toString();
    }
}
