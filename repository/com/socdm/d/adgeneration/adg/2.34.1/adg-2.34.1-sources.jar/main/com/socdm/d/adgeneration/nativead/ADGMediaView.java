package com.socdm.d.adgeneration.nativead;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;

import com.socdm.d.adgeneration.ADGLogger;
import com.socdm.d.adgeneration.nativead.icon.ADGImageView;

public class ADGMediaView extends RelativeLayout {
    private ADGNativeAd mAdgNativeAd;
    private ImageView mAdgImageView;
    private boolean isTiny = false;

    public ADGMediaView(Context context) {
        super(context);
    }

    public ADGMediaView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ADGMediaView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public ADGMediaView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    /**
     * {@link ADGNativeAd} オブジェクトを設定します
     *
     * @param nativeAd {@link ADGNativeAd} オブジェクト
     */
    public void setAdgNativeAd(@NonNull final ADGNativeAd nativeAd) {
        mAdgNativeAd = nativeAd;
    }

    public void setIsTiny(boolean isTiny) {
        this.isTiny = isTiny;
    }

    /** メイン画像または動画のロードを開始します */
    public void load() {
        // 動画広告
        if (mAdgNativeAd.loadVideo(
                getContext(),
                isTiny,
                new ADGNativeAd.OnShowVideoAdListener() {
                    @NonNull
                    @Override
                    public ViewGroup onShowVideoAd() {
                        return ADGMediaView.this;
                    }
                })) {
            return;
        }

        // 静止画広告
        if (mAdgNativeAd.getMainImage() != null
                && !TextUtils.isEmpty(mAdgNativeAd.getMainImage().getUrl())) {
            mAdgImageView =
                    new ADGImageView(
                            getContext(), mAdgNativeAd.getMainImage().getUrl(), null, null);
            mAdgImageView.setAdjustViewBounds(true);
            addView(
                    mAdgImageView,
                    new ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            ADGLogger.getInstance().getLogger().warn("Invalid ADGMediaView.");
        }
    }

    /**
     * メイン画像または動画をViewから破棄します。
     * 特に、複数の動画を配置する場合や、アプリ側でMediaPlayerを扱い、動画や音声を再生している場合、不要になったものから適宜破棄を行う必要があります。
     * 破棄されないままMediaPlayerの生成を繰り返すとクラッシュを引き起こす場合があります
     */
    public void destroy() {
        if (mAdgImageView != null) {
            mAdgImageView.setImageDrawable(null);
            removeView(mAdgImageView);
            mAdgImageView = null;
        }

        if (mAdgNativeAd != null) {
            mAdgNativeAd.destroyVideo();
            mAdgNativeAd = null;
        }
    }

    public static void safeRemoveFromParentView(ViewGroup parent) {
        if (parent == null) return;
        for (int i = 0; i < parent.getChildCount(); i++) {
            View child = parent.getChildAt(i);
            if (child instanceof ADGMediaView) {
                ((ADGMediaView) child).destroy();
                parent.removeView(child);
            } else if (child instanceof ViewGroup) {
                safeRemoveFromParentView((ViewGroup) child);
            }
        }
    }
}
