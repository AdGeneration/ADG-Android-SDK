package com.socdm.d.adgeneration.nativead;

import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.adresponse.Native;

public class ADGVideo {
    @Nullable private String vasttag;

    public ADGVideo(@Nullable Native.Asset.Video obj) {
        if (obj != null) {
            vasttag = obj.vasttag;
        }
    }

    @Nullable
    public String getVasttag() {
        return vasttag;
    }
}
