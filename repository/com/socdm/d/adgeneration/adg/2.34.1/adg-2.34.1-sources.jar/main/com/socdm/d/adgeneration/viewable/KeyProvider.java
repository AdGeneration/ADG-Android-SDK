package com.socdm.d.adgeneration.viewable;

import androidx.annotation.NonNull;

/** Viewableパラメータのキー生成を提供するインターフェース */
public interface KeyProvider {
    /**
     * 一意のキーを生成します
     *
     * @return 生成されたキー
     */
    @NonNull
    String generateKey();
}
