package com.socdm.d.adgeneration;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.utils.LogUtils;

import jp.supership.sscore.logger.SSCoreLogger;
import jp.supership.sscore.logger.SSCoreNoticeLogger;

public final class ADGLogger implements IADGLogger {
    static {
        SSCoreNoticeLogger.setLogger(new SSCoreNoticeLogger.AndroidLogger("ADGSDK"));
    }

    @NonNull private static final String TAG = "ADGSDK";
    @NonNull private static final ADGLogger instance = new ADGLogger();

    @NonNull private static SSCoreLogger defaultLogger = new SSCoreLogger(TAG);
    @NonNull private static SSCoreLogger developmentLogger = new SSCoreLogger(TAG + "-Dev", true);

    private ADGLogger() {}

    @NonNull
    public static ADGLogger getInstance() {
        return instance;
    }

    @NonNull
    @Override
    public SSCoreLogger getLogger() {
        return defaultLogger;
    }

    @Override
    @NonNull
    public SSCoreLogger getDevelopmentLogger() {
        return developmentLogger;
    }

    /**
     * ADG SDKのロガーを取得します。
     *
     * @return ADG SDKのロガー
     */
    @NonNull
    public static SSCoreLogger getDefault() {
        return defaultLogger;
    }

    /**
     * ADG SDKのロガーを変更します。
     *
     * @param logger ロガー。nullを指定した場合はデフォルトのロガーに初期化します
     */
    public static synchronized void setDefault(@Nullable final SSCoreLogger logger) {
        defaultLogger = logger != null ? logger : new SSCoreLogger(TAG);
    }

    /**
     * 開発用のロガーを取得します。このロガーは社外に公開しないログ出力に使用します。
     *
     * @return 開発用のロガー
     */
    @NonNull
    public static SSCoreLogger getDevelopment() {
        return developmentLogger;
    }

    /**
     * 開発用のロガーを変更します。このロガーは開発時のみ使用することを想定しているため、public APIにはしていません。
     *
     * @param logger ロガー。nullを指定した場合はデフォルトのロガーに初期化します
     */
    static synchronized void setDevelopment(@Nullable final SSCoreLogger logger) {
        developmentLogger =
                logger != null && logger.isDevelopment
                        ? logger
                        : new SSCoreLogger(TAG + "-Dev", true);
    }

    static boolean isEnabled() {
        return defaultLogger.level != SSCoreLogger.LogLevel.OFF;
    }

    static void setEnabled(final boolean enabled) {
        if (enabled) {
            // ADG SDKのロガーの有効化
            defaultLogger.level = SSCoreLogger.LogLevel.DEBUG;
            developmentLogger.level = SSCoreLogger.LogLevel.DEBUG;
            // SSCoreモジュールのロガーの有効化
            SSCoreLogger.DEFAULT.level = SSCoreLogger.LogLevel.DEBUG;
            SSCoreLogger.DEVELOPMENT.level = SSCoreLogger.LogLevel.DEBUG;
            // 旧ADG SDKのロガーの有効化
            LogUtils.setLogLevel(Log.DEBUG);
        } else {
            defaultLogger.level = SSCoreLogger.LogLevel.OFF;
            developmentLogger.level = SSCoreLogger.LogLevel.OFF;
            SSCoreLogger.DEFAULT.level = SSCoreLogger.LogLevel.OFF;
            SSCoreLogger.DEVELOPMENT.level = SSCoreLogger.LogLevel.OFF;
            // LogUtilsで使用する最高のレベルはERRORのため、それ以上のASSERTを設定し事実上のオフにする
            LogUtils.setLogLevel(Log.ASSERT);
        }
    }
}
