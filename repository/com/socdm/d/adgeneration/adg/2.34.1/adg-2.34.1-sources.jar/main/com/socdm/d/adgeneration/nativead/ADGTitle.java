package com.socdm.d.adgeneration.nativead;

import androidx.annotation.Nullable;

import com.socdm.d.adgeneration.adresponse.Native;

public class ADGTitle {
    private String text;
    private Object ext;

    public ADGTitle(@Nullable Native.Asset.Title obj) {
        if (obj != null) {
            this.text = obj.text;
            obj.ext.ifPresent(e -> this.ext = e);
        }
    }

    public String getText() {
        return text;
    }

    public Object getExt() {
        return ext;
    }
}
